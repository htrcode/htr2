import React, { useState, useEffect, useRef } from 'react';
import { 
  X, Download, Printer, ShieldCheck, CheckCircle2, Clock, AlertCircle, FileText, 
  MapPin, Cpu, HardDrive, Shield, Wifi, Server, Check, HelpCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Invoice, Settings, Plan, Game } from '../types';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import trademarkLogo from '../assets/images/hector_logo_transparent.png';
import { dataService } from '../services/dataService';

// Fallback helper to approximate OKLCH color values to standard RGBA
// This prevents html2canvas from failing with "unsupported color function oklch"
const convertOklchToRgb = (cssText: string): string => {
  return cssText.replace(/oklch\(([\d%.]+)\s+([\d%.]+)\s+([\d%.]+)(?:\s*\/\s*([\d%.]+))?\)/g, (match, l, c, h, a) => {
    const lightness = parseFloat(l.endsWith('%') ? parseFloat(l)/100 : l);
    const chroma = parseFloat(c.endsWith('%') ? parseFloat(c)/100 : c);
    const hue = parseFloat(h);
    const alpha = a ? parseFloat(a.endsWith('%') ? parseFloat(a)/100 : a) : 1;

    // 1. Grayscale if chroma is very low
    if (chroma < 0.015) {
      const v = Math.round(lightness * 255);
      return `rgba(${v}, ${v}, ${v}, ${alpha})`;
    }

    // 2. Map hues to standard vibrant colors based on hue angle
    let r = 100, g = 100, b = 100;
    if (hue >= 240 && hue < 320) {
      // Purple / Violet (Brand colors)
      if (lightness > 0.8) { r = 245; g = 243; b = 255; } // purple-50
      else if (lightness > 0.5) { r = 139; g = 92; b = 246; } // purple-500
      else { r = 76; g = 29; b = 149; } // purple-900
    } else if (hue >= 180 && hue < 240) {
      // Blue
      if (lightness > 0.8) { r = 239; g = 246; b = 255; }
      else if (lightness > 0.5) { r = 59; g = 130; b = 246; }
      else { r = 30; g = 58; b = 138; }
    } else if (hue >= 100 && hue < 180) {
      // Green
      if (lightness > 0.8) { r = 240; g = 253; b = 244; }
      else if (lightness > 0.5) { r = 34; g = 197; b = 94; }
      else { r = 20; g = 83; b = 45; }
    } else if (hue >= 40 && hue < 100) {
      // Yellow / Amber
      if (lightness > 0.8) { r = 254; g = 243; b = 199; }
      else if (lightness > 0.5) { r = 245; g = 158; b = 11; }
      else { r = 120; g = 53; b = 4; }
    } else {
      // Red
      if (lightness > 0.8) { r = 254; g = 242; b = 242; }
      else if (lightness > 0.5) { r = 239; g = 68; b = 68; }
      else { r = 127; g = 29; b = 29; }
    }

    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  });
};

interface InvoiceDocumentModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice: Invoice | null;
  clientEmail?: string;
  clientName?: string;
  settings?: Settings;
  isAdminView?: boolean;
}

export const InvoiceDocumentModal: React.FC<InvoiceDocumentModalProps> = ({
  isOpen,
  onClose,
  invoice,
  clientEmail,
  clientName,
  settings,
  isAdminView = false
}) => {
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const pdfRef = useRef<HTMLDivElement>(null);
  
  // Dynamic Catalog State to fetch product specs
  const [plans, setPlans] = useState<Plan[]>([]);
  const [games, setGames] = useState<Game[]>([]);

  useEffect(() => {
    if (isOpen) {
      dataService.getPlans().then(setPlans).catch(e => console.warn('Failed to load plans for invoice specs:', e));
      dataService.getGames().then(setGames).catch(e => console.warn('Failed to load games for invoice specs:', e));
    }
  }, [isOpen]);

  if (!isOpen || !invoice) return null;

  const invoiceNum = invoice.invoiceNumber || invoice.id || 'INV-000000';
  const issueDate = invoice.timestamp 
    ? new Date(invoice.timestamp).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
    : new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
  const issueTime = invoice.timestamp 
    ? new Date(invoice.timestamp).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })
    : '';

  const paymentMethod = invoice.paymentMethod || invoice.method || 'UPI / Manual Transfer (Outside)';
  const formattedTotal = typeof invoice.total === 'number' 
    ? `₹${invoice.total.toLocaleString('en-IN', { minimumFractionDigits: 2 })}` 
    : String(invoice.total).startsWith('₹') || String(invoice.total).startsWith('$') 
      ? String(invoice.total) 
      : `₹${invoice.total}`;

  // Helper to find specifications of a plan dynamically
  const getItemSpecs = (planId?: string) => {
    if (!planId) return null;

    // 1. Check in regular plans (VPS / Dedicated / Bot)
    const matchedPlan = plans.find(p => p.id === planId || p.product_id === planId);
    if (matchedPlan) {
      const specs: string[] = [];
      if (matchedPlan.cpu) specs.push(`vCPU: ${matchedPlan.cpu}`);
      if (matchedPlan.ram) specs.push(`RAM: ${matchedPlan.ram}`);
      if (matchedPlan.storage) specs.push(`Storage: ${matchedPlan.storage}`);
      if (matchedPlan.processor) specs.push(`Processor: ${matchedPlan.processor}`);
      if (matchedPlan.networkSpeed) specs.push(`Port Speed: ${matchedPlan.networkSpeed}`);
      if (matchedPlan.ddosProtection) specs.push(`DDoS: ${matchedPlan.ddosProtection}`);
      return specs.length > 0 ? specs : matchedPlan.features || [];
    }

    // 2. Check in game server plans
    for (const game of games) {
      const matchedOpt = game.ramOptions?.find(opt => opt.product_id === planId || opt.id === planId);
      if (matchedOpt) {
        const specs: string[] = [];
        if (matchedOpt.cpu) specs.push(`CPU Core: ${matchedOpt.cpu}`);
        if (matchedOpt.ram) specs.push(`RAM Limit: ${matchedOpt.ram}`);
        if (matchedOpt.storage) specs.push(`Storage: ${matchedOpt.storage}`);
        if (matchedOpt.slots) specs.push(`Slots: ${matchedOpt.slots}`);
        if (matchedOpt.networkSpeed) specs.push(`Network: ${matchedOpt.networkSpeed}`);
        if (matchedOpt.ddosProtection) specs.push(`DDoS Protection: ${matchedOpt.ddosProtection}`);
        return specs.length > 0 ? specs : matchedOpt.features || [];
      }
    }

    return null;
  };

  // Helper to parse selected configurations and addons from notes
  const parsedConfigs = () => {
    if (!invoice.notes) return null;
    const parts = invoice.notes.split(' | ');
    const configs: { label: string; value: string }[] = [];
    parts.forEach(part => {
      const idx = part.indexOf(': ');
      if (idx !== -1) {
        const label = part.slice(0, idx).trim();
        const value = part.slice(idx + 2).trim();
        // Ignore internal metadata details like UTR or standard Payment Complete messages
        if (label && value && !label.toLowerCase().includes('utr') && !label.toLowerCase().includes('payment')) {
          configs.push({ label, value });
        }
      }
    });
    return configs.length > 0 ? configs : null;
  };

  const selectedConfigs = parsedConfigs();

  // Native high-fidelity PDF Generator
  const handleDownloadPdf = async () => {
    if (!pdfRef.current || isGeneratingPdf) return;
    setIsGeneratingPdf(true);

    try {
      const element = pdfRef.current;

      const canvas = await html2canvas(element, {
        scale: 2, // High resolution
        useCORS: true,
        backgroundColor: '#ffffff',
        logging: false,
        onclone: (clonedDoc) => {
          // 1. Process stylesheet oklch declarations to standard RGB so html2canvas can parse them
          const styleElements = clonedDoc.querySelectorAll('style, link[rel="stylesheet"]');
          styleElements.forEach((styleEl) => {
            if (styleEl.textContent && styleEl.textContent.includes('oklch')) {
              styleEl.textContent = convertOklchToRgb(styleEl.textContent);
            }
          });

          // 2. Process inline oklch styles
          const allNodes = clonedDoc.querySelectorAll('*');
          allNodes.forEach((node) => {
            const htmlNode = node as HTMLElement;
            if (htmlNode.style && htmlNode.style.cssText && htmlNode.style.cssText.includes('oklch')) {
              htmlNode.style.cssText = convertOklchToRgb(htmlNode.style.cssText);
            }
          });
        }
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      const imgWidth = 210; // A4 width mm
      const imgHeight = (canvas.height * imgWidth) / canvas.width;

      pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight);
      pdf.save(`Hector_Hosting_Invoice_${invoiceNum}.pdf`);
    } catch (err) {
      console.error('High-fidelity PDF generation failed:', err);
      alert('Could not download PDF. Please use the Print Invoice button.');
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  // Handle Native Browser Print
  const handlePrint = () => {
    window.print();
  };

  // Explicit inline styling for rendering perfection in jsPDF / html2canvas
  const styles = {
    canvas: {
      backgroundColor: '#ffffff',
      color: '#0f172a',
      fontFamily: 'system-ui, -apple-system, sans-serif'
    },
    headerBg: {
      borderBottom: '3px solid #6d28d9'
    },
    invoiceMetaBadge: {
      backgroundColor: '#f5f3ff',
      color: '#4c1d95',
      borderColor: '#ddd6fe',
      borderWidth: '1px',
      borderStyle: 'solid' as const
    },
    billedToCard: {
      backgroundColor: '#f8fafc',
      borderColor: '#e2e8f0',
      borderWidth: '1px',
      borderStyle: 'solid' as const
    },
    tableHeader: {
      backgroundColor: '#f1f5f9',
      color: '#334155',
      borderBottom: '2px solid #cbd5e1'
    },
    tableRow: {
      borderBottom: '1px solid #e2e8f0'
    },
    specsBox: {
      backgroundColor: '#f8fafc',
      borderColor: '#e2e8f0',
      borderWidth: '1px',
      borderStyle: 'solid' as const,
      color: '#475569'
    },
    configBadge: {
      backgroundColor: '#eff6ff',
      color: '#1e3a8a',
      borderColor: '#bfdbfe',
      borderWidth: '1px',
      borderStyle: 'solid' as const
    },
    summaryCard: {
      backgroundColor: '#f8fafc',
      borderColor: '#e2e8f0',
      borderWidth: '1px',
      borderStyle: 'solid' as const
    },
    footerLine: {
      borderTop: '2px solid #0f172a'
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[1500] flex items-center justify-center p-4 sm:p-6 backdrop-blur-md bg-black/80 overflow-y-auto print:p-0 print:bg-white print:static print:inset-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="max-w-3xl w-full bg-[#0d091a] border border-accent/30 rounded-3xl p-6 sm:p-8 shadow-2xl relative my-auto print:border-0 print:shadow-none print:p-0 print:text-black print:bg-white print:max-w-none print:w-full print:rounded-none"
        >
          {/* TOP CONTROLS BAR (Hidden during printing) */}
          <div className="flex items-center justify-between gap-4 mb-6 pb-4 border-b border-border/80 print:hidden">
            <div className="flex items-center gap-2 text-accent">
              <FileText size={20} />
              <span className="text-xs font-black uppercase tracking-wider text-white">
                Tax Invoice Document
              </span>
              <span className="px-2 py-0.5 rounded-full bg-accent/20 text-[9px] font-mono text-accent border border-accent/30 font-bold">
                {invoice.status}
              </span>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={handleDownloadPdf}
                disabled={isGeneratingPdf}
                className="px-4 py-2 bg-gradient-to-r from-accent to-indigo-600 hover:opacity-90 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-accent/20 flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isGeneratingPdf ? (
                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <Download size={14} />
                )}
                <span>Download PDF</span>
              </button>

              <button
                onClick={handlePrint}
                className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer"
              >
                <Printer size={14} />
                <span>Print Invoice</span>
              </button>

              <button
                onClick={onClose}
                className="p-2 hover:bg-white/10 text-slate-400 hover:text-white rounded-xl transition-colors"
              >
                <X size={20} />
              </button>
            </div>
          </div>

          {/* INVOICE CANVAS (Rendered as high-fidelity printable document) */}
          <div
            id={`pdf-invoice-${invoiceNum}`}
            ref={pdfRef}
            style={styles.canvas}
            className="p-8 sm:p-10 rounded-2xl shadow-inner font-sans space-y-8 border border-slate-200 print:border-0 print:p-0 print:rounded-none"
          >
            {/* Header / Company Branding */}
            <div 
              style={styles.headerBg} 
              className="flex flex-col sm:flex-row items-start justify-between gap-6 pb-6"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-3">
                  <img 
                    src={trademarkLogo} 
                    alt="Hector Hosting Logo" 
                    className="h-10 w-auto object-contain shrink-0" 
                  />
                  <div>
                    <h1 className="text-xl font-black text-slate-900 tracking-tight leading-none uppercase">
                      {settings?.site_name || 'HECTOR HOSTING'}
                    </h1>
                    <p className="text-[9px] font-bold text-purple-700 tracking-widest uppercase mt-0.5">
                      Cloud Server & Infrastructure Station
                    </p>
                  </div>
                </div>
                <p className="text-[11px] text-slate-500 pt-3 font-medium">
                  Hector Hosting Ltd.
                </p>
                <p className="text-[11px] text-slate-500 font-medium">
                  Support: {settings?.support_email || 'support@hector.host'} • Web: https://hector.host
                </p>
              </div>

              <div className="text-left sm:text-right space-y-1">
                <div 
                  style={styles.invoiceMetaBadge} 
                  className="inline-block px-3 py-1 font-mono font-bold text-xs rounded-lg"
                >
                  TAX INVOICE #{invoiceNum}
                </div>
                <p className="text-xs text-slate-600 font-medium pt-1.5">
                  <strong>Date:</strong> {issueDate} {issueTime && `at ${issueTime}`}
                </p>
                <p className="text-xs text-slate-600 font-medium">
                  <strong>Method:</strong> {paymentMethod}
                </p>
                {invoice.utrNumber && (
                  <p className="text-xs font-mono text-purple-900 font-bold bg-purple-50 px-2.5 py-0.5 rounded border border-purple-200 inline-block">
                    Ref / UTR: {invoice.utrNumber}
                  </p>
                )}
              </div>
            </div>

            {/* Billed To vs Payment Status Grid */}
            <div 
              style={styles.billedToCard} 
              className="grid grid-cols-1 sm:grid-cols-2 gap-6 p-5 rounded-xl"
            >
              <div>
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 block mb-1">
                  Billed To (Client Account)
                </span>
                <p className="text-sm font-black text-slate-900">
                  {clientName || 'Valued Client'}
                </p>
                <p className="text-xs text-slate-600 font-mono mt-1">
                  Email: {clientEmail || 'N/A'}
                </p>
                <p className="text-xs text-slate-600 font-mono mt-0.5">
                  Phone: N/A
                </p>
              </div>

              <div className="sm:text-right flex flex-col justify-between">
                <div>
                  <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 block mb-1">
                    Payment Verification Status
                  </span>
                  <div className="inline-flex items-center gap-1.5 text-xs font-black uppercase tracking-wider">
                    {invoice.status === 'Paid' ? (
                      <span className="inline-flex items-center gap-1.5 text-emerald-800 bg-emerald-50 border border-emerald-300 px-3 py-1 rounded-full font-bold">
                        <CheckCircle2 size={13} className="text-emerald-600" />
                        VERIFIED PAID
                      </span>
                    ) : invoice.status === 'Unpaid' ? (
                      <span className="inline-flex items-center gap-1.5 text-amber-800 bg-amber-50 border border-amber-300 px-3 py-1 rounded-full font-bold">
                        <Clock size={13} className="text-amber-600" />
                        PENDING VERIFICATION
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 text-rose-800 bg-rose-50 border border-rose-300 px-3 py-1 rounded-full font-bold">
                        <AlertCircle size={13} className="text-rose-600" />
                        CANCELLED
                      </span>
                    )}
                  </div>
                </div>

                <p className="text-[10px] text-slate-400 font-mono mt-2">
                  System Record ID: {invoice.id}
                </p>
              </div>
            </div>

            {/* Line Items Table */}
            <div>
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr style={styles.tableHeader} className="text-[10px] font-black uppercase tracking-wider">
                    <th className="p-3">Item & Description</th>
                    <th className="p-3">Expiry Date</th>
                    <th className="p-3 text-center">Qty</th>
                    <th className="p-3 text-right">Unit Price</th>
                    <th className="p-3 text-right">Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-xs font-sans">
                  {invoice.items && invoice.items.length > 0 ? (
                    invoice.items.map((item, idx) => {
                      const unitPrice = parseFloat(String(item.price).replace(/[^0-9.]/g, '')) || 0;
                      const subTotal = unitPrice * (item.quantity || 1);
                      const specs = getItemSpecs(item.planId);
                      return (
                        <tr key={idx} style={styles.tableRow} className="hover:bg-slate-50/50">
                          <td className="p-3 space-y-2">
                            <div>
                              <p className="font-black text-slate-900 text-sm">{item.name}</p>
                              <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                                30-Day Recurring Infrastructure Instance
                              </p>
                            </div>

                            {/* Dynamically Loaded Product Specifications */}
                            {specs && specs.length > 0 && (
                              <div 
                                style={styles.specsBox} 
                                className="p-2.5 rounded-lg text-[10px] font-mono grid grid-cols-2 gap-x-4 gap-y-1 max-w-md"
                              >
                                {specs.map((spec, sIdx) => (
                                  <div key={sIdx} className="flex items-center gap-1.5 truncate">
                                    <span className="w-1 h-1 rounded-full bg-purple-500 shrink-0" />
                                    <span>{spec}</span>
                                  </div>
                                ))}
                              </div>
                            )}
                          </td>
                          <td className="p-3">
                            <span className="text-slate-600 font-mono font-bold text-xs">
                                N/A
                            </span>
                          </td>
                          <td className="p-3 text-center font-mono font-bold text-slate-800">
                            {item.quantity || 1}
                          </td>
                          <td className="p-3 text-right font-mono text-slate-700">
                            ₹{unitPrice.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                          </td>
                          <td className="p-3 text-right font-mono font-black text-slate-900">
                            ₹{subTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr style={styles.tableRow}>
                      <td className="p-3 font-black text-slate-900">Hosting Infrastructure Subscription</td>
                      <td className="p-3 text-slate-600 font-mono font-bold text-xs">N/A</td>
                      <td className="p-3 text-center font-mono font-bold text-slate-800">1</td>
                      <td className="p-3 text-right font-mono text-slate-700">{formattedTotal}</td>
                      <td className="p-3 text-right font-mono font-black text-slate-900">{formattedTotal}</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Selected Custom Options & Addons Section */}
            {selectedConfigs && (
              <div className="space-y-2.5 p-4 border border-blue-100 bg-blue-50/50 rounded-xl">
                <span className="text-[10px] font-black uppercase tracking-wider text-blue-900/60 block">
                  Configured Deployment Addons & Software Parameters
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {selectedConfigs.map((config, cIdx) => (
                    <div 
                      key={cIdx} 
                      style={styles.configBadge} 
                      className="p-2 rounded-lg flex items-center justify-between gap-3"
                    >
                      <span className="font-bold text-[10px] text-blue-900 uppercase tracking-tight shrink-0">
                        {config.label}
                      </span>
                      <span className="font-mono text-[11px] text-slate-700 truncate text-right">
                        {config.value}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Financial Summary Box */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-6 pt-4 border-t border-slate-200">
              <div className="space-y-2 max-w-sm">
                <p className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                  Terms & Payment Notice
                </p>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  {invoice.notes && !invoice.notes.includes(' | ') 
                    ? invoice.notes 
                    : 'This invoice serves as official confirmation of billing ledger entry. Payments are non-refundable except as specified in terms.'}
                </p>
              </div>

              <div 
                style={styles.summaryCard} 
                className="w-full sm:w-64 p-4 rounded-xl space-y-2.5"
              >
                <div className="flex justify-between text-xs text-slate-600 font-medium">
                  <span>Subtotal:</span>
                  <span className="font-mono text-slate-900 font-bold">{formattedTotal}</span>
                </div>
                <div className="flex justify-between text-xs text-slate-600 font-medium">
                  <span>Taxes (GST 0% Included):</span>
                  <span className="font-mono text-emerald-700 font-bold">₹0.00</span>
                </div>
                <div className="pt-2.5 border-t border-slate-200 flex justify-between items-center text-slate-900 font-black">
                  <span className="text-[10px] uppercase tracking-wider text-slate-500">Grand Total:</span>
                  <span className="text-lg font-mono text-purple-800">{formattedTotal}</span>
                </div>
              </div>
            </div>

            {/* Authorization Seal & Verification Footer */}
            <div 
              style={styles.footerLine} 
              className="pt-6 flex flex-col sm:flex-row justify-between items-center gap-4 text-slate-500"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600 shrink-0">
                  <ShieldCheck size={20} />
                </div>
                <div>
                  <p className="text-[10px] font-black uppercase tracking-wider text-slate-900">
                    Digitally Authorized Invoice
                  </p>
                  <p className="text-[9px] font-mono text-slate-500">
                    Hector Billing Engine • Tamper-Evident Ledger Entry
                  </p>
                </div>
              </div>

              <div className="text-center sm:text-right">
                <p className="font-serif italic text-sm text-slate-800 font-black">
                  Hector Finance & Accounting
                </p>
                <p className="text-[9px] uppercase tracking-wider font-bold text-slate-400 mt-0.5">
                  Authorized Signatory
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
