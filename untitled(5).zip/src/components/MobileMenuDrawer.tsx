import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, Server, Gamepad2, Cpu, BookOpen, Scale, Headphones, 
  User, ChevronDown, ShoppingCart, ExternalLink, LogOut, 
  LayoutDashboard, ShieldAlert, Sparkles, CheckCircle2,
  Bot, Box, Globe, Shield, Activity, ArrowRight
} from 'lucide-react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Logo } from './Logo';
import { GAME_CATALOG } from '../data/games';
import { authService } from '../services/authService';
import { User as FirebaseUser } from 'firebase/auth';
import { Settings } from '../types';

interface MobileMenuDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  user: FirebaseUser | null;
  isAdmin: boolean;
  setIsAdminMode: (val: boolean) => void;
  settings: Settings;
  cartCount?: number;
  onOpenCart?: () => void;
  activeCurrency?: 'INR' | 'USD';
  setActiveCurrency?: (c: 'INR' | 'USD') => void;
}

export const MobileMenuDrawer: React.FC<MobileMenuDrawerProps> = ({
  isOpen,
  onClose,
  user,
  isAdmin,
  setIsAdminMode,
  settings,
  cartCount = 0,
  onOpenCart,
  activeCurrency = 'INR',
  setActiveCurrency,
}) => {
  const location = useLocation();
  const navigate = useNavigate();

  // Accordion active state (single accordion open at a time for clean UX)
  const [expandedSection, setExpandedSection] = useState<string | null>(null);

  const toggleSection = (section: string) => {
    setExpandedSection(prev => (prev === section ? null : section));
  };

  // Close menu automatically on route change
  useEffect(() => {
    onClose();
    setExpandedSection(null);
  }, [location.pathname]);

  // Lock body scroll when drawer is open to prevent background jumping
  useEffect(() => {
    if (isOpen) {
      const originalOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = originalOverflow;
      };
    }
  }, [isOpen]);

  const handleLogout = async () => {
    onClose();
    await authService.logout();
    navigate('/auth/login');
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop Blur Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/85 backdrop-blur-md z-[200]"
            aria-hidden="true"
          />

          {/* Slide-in Mobile Drawer in Professional Smooth Black & Purple Theme */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 28, stiffness: 280 }}
            className="fixed inset-y-0 right-0 w-full sm:w-[420px] max-w-full bg-[#08060c] border-l border-[#231938] z-[200] flex flex-col shadow-2xl overflow-hidden font-sans"
          >
            {/* Header: HectorHosting Brand & Controls */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-[#231938] bg-[#08060c]/95 backdrop-blur-md sticky top-0 z-10 shrink-0">
              {/* Brand Logo & Smooth Black/Purple Typography */}
              <Link 
                to="/" 
                onClick={onClose} 
                className="flex items-center gap-3 group active:scale-95 transition-transform"
              >
                <div className="relative">
                  <Logo size={36} />
                </div>
                <div className="flex items-baseline font-bold tracking-tight text-xl leading-none">
                  <span className="text-white font-black tracking-tight">Hector</span>
                  <span className="text-purple-400 font-black tracking-tight ml-0.5">Hosting</span>
                </div>
              </Link>

              {/* Action Controls: Close Button */}
              <div className="flex items-center gap-2">
                <button
                  onClick={onClose}
                  className="p-2.5 rounded-xl border border-[#231938] bg-[#130e22] text-slate-400 hover:text-white hover:border-purple-500/50 transition-all min-w-[40px] min-h-[40px] flex items-center justify-center active:scale-95"
                  aria-label="Close menu"
                >
                  <X size={20} />
                </button>
              </div>
            </div>

            {/* Scrollable Navigation Body */}
            <div className="flex-1 overflow-y-auto px-4 py-4 space-y-2.5 no-scrollbar">
              
              {/* 1. Client Portal & Billing (Smooth Black/Purple Pill) */}
              <div className="rounded-2xl border border-[#231938] bg-[#130e22] overflow-hidden transition-colors shadow-sm">
                <button
                  onClick={() => {
                    if (user) {
                      toggleSection('client-portal');
                    } else {
                      navigate('/auth/login');
                      onClose();
                    }
                  }}
                  className="w-full flex items-center justify-between px-5 py-4 text-left group hover:bg-[#1a1330] transition-colors"
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <User size={20} className="text-purple-400 shrink-0" />
                    <div className="truncate">
                      <span className="text-[15px] font-semibold text-slate-100 block group-hover:text-purple-200 transition-colors">
                        Client Portal & Billing
                      </span>
                      {user && (
                        <span className="text-[11px] text-slate-400 block truncate">
                          {user.displayName || user.email}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {user ? (
                      <>
                        {isAdmin && (
                          <span className="px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-wider bg-purple-500/20 text-purple-300 border border-purple-500/40">
                            Admin
                          </span>
                        )}
                        <ChevronDown 
                          size={18} 
                          className={`text-slate-400 transition-transform duration-200 ${
                            expandedSection === 'client-portal' ? 'rotate-180 text-purple-400' : ''
                          }`} 
                        />
                      </>
                    ) : (
                      <span className="text-[11px] font-bold text-purple-400 uppercase tracking-wider">
                        Login →
                      </span>
                    )}
                  </div>
                </button>

                {/* Expanded Client Portal Menu for Logged-in Users */}
                <AnimatePresence>
                  {user && expandedSection === 'client-portal' && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.18 }}
                      className="border-t border-[#231938] bg-[#0c0817] px-3 py-3 space-y-2"
                    >
                      <Link
                        to="/dashboard"
                        onClick={onClose}
                        className="flex items-center gap-3 px-3.5 py-2.5 rounded-xl bg-[#19112d] hover:bg-[#22173f] text-slate-200 hover:text-white border border-[#38245e] transition-colors"
                      >
                        <LayoutDashboard size={16} className="text-purple-400" />
                        <span className="text-xs font-bold uppercase tracking-wider">Client Dashboard</span>
                      </Link>

                      <a
                        href="https://gp.hector.host"
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-[#19112d] hover:bg-[#22173f] text-slate-200 hover:text-white border border-[#38245e] transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <Server size={16} className="text-emerald-400" />
                          <span className="text-xs font-bold uppercase tracking-wider">Game Panel (Pterodactyl)</span>
                        </div>
                        <ExternalLink size={13} className="text-slate-400" />
                      </a>

                      {isAdmin && (
                        <button
                          onClick={() => {
                            setIsAdminMode(true);
                            navigate('/admin');
                            onClose();
                          }}
                          className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl bg-[#221136] hover:bg-[#30184c] text-purple-300 hover:text-white border border-purple-800/60 transition-colors"
                        >
                          <ShieldAlert size={16} className="text-purple-400" />
                          <span className="text-xs font-bold uppercase tracking-wider">Admin Control Center</span>
                        </button>
                      )}

                      <button
                        onClick={handleLogout}
                        className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl hover:bg-rose-950/30 text-rose-400 hover:text-rose-300 border border-transparent hover:border-rose-900/40 transition-colors"
                      >
                        <LogOut size={16} />
                        <span className="text-xs font-bold uppercase tracking-wider">Sign Out</span>
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* 2. Home Overview */}
              <Link
                to="/"
                onClick={onClose}
                className={`w-full flex items-center justify-between px-5 py-4 rounded-2xl border transition-all duration-200 group ${
                  location.pathname === '/'
                    ? 'bg-[#1e1338] border-[#432d6f] text-purple-300 shadow-sm'
                    : 'bg-[#130e22] border-[#231938] hover:bg-[#1a1330] hover:border-[#3d2b61] text-slate-100'
                }`}
              >
                <div className="flex items-center gap-3.5">
                  <Server size={20} className="text-purple-400 shrink-0" />
                  <span className="text-[15px] font-semibold block group-hover:text-purple-200 transition-colors">
                    Home Overview
                  </span>
                </div>
              </Link>

              {/* 3. Game Servers (Accordion) */}
              <div className="rounded-2xl border border-[#231938] bg-[#130e22] overflow-hidden transition-colors shadow-sm">
                <button
                  onClick={() => toggleSection('games')}
                  className="w-full flex items-center justify-between px-5 py-4 text-left group hover:bg-[#1a1330] transition-colors"
                >
                  <div className="flex items-center gap-3.5">
                    <Gamepad2 size={20} className="text-purple-400 shrink-0" />
                    <span className="text-[15px] font-semibold text-slate-100 group-hover:text-purple-200 transition-colors">
                      Game Servers
                    </span>
                  </div>
                  <ChevronDown
                    size={18}
                    className={`text-slate-400 transition-transform duration-200 ${
                      expandedSection === 'games' ? 'rotate-180 text-purple-400' : ''
                    }`}
                  />
                </button>

                <AnimatePresence>
                  {expandedSection === 'games' && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="border-t border-[#231938] bg-[#0c0817] px-3 py-3 space-y-1.5"
                    >
                      {/* Game Quick Items */}
                      {GAME_CATALOG.slice(0, 7).map((game) => (
                        <Link
                          key={game.id}
                          to={`/game/${game.id}`}
                          onClick={onClose}
                          className="flex items-center justify-between p-2.5 rounded-xl hover:bg-[#19112d] border border-transparent hover:border-[#38245e] transition-all group"
                        >
                          <div className="flex items-center gap-3">
                            <img
                              src={game.image}
                              alt={game.title}
                              className="w-7 h-7 rounded-lg object-cover border border-[#2e1d4a]"
                            />
                            <div>
                              <span className="text-xs font-bold text-slate-200 group-hover:text-white block">
                                {game.title}
                              </span>
                              <span className="text-[10px] text-slate-400 block font-medium">
                                {game.category} Hosting
                              </span>
                            </div>
                          </div>

                          <span className="text-[11px] font-bold text-purple-300 bg-purple-950/60 border border-purple-800/40 px-2 py-0.5 rounded-md">
                            ₹{game.startingPriceInr}/mo
                          </span>
                        </Link>
                      ))}

                      {/* Browse All Games Link */}
                      <Link
                        to="/game-servers"
                        onClick={onClose}
                        className="flex items-center justify-center gap-2 p-2.5 mt-1 rounded-xl bg-[#20133c] hover:bg-[#2b1952] border border-[#48287a] text-purple-200 hover:text-white font-bold text-xs transition-all text-center"
                      >
                        <span>Browse All 100+ Game Nodes</span>
                        <ArrowRight size={14} />
                      </Link>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* 4. Other Servers (Accordion) */}
              <div className="rounded-2xl border border-[#231938] bg-[#130e22] overflow-hidden transition-colors shadow-sm">
                <button
                  onClick={() => toggleSection('other-servers')}
                  className="w-full flex items-center justify-between px-5 py-4 text-left group hover:bg-[#1a1330] transition-colors"
                >
                  <div className="flex items-center gap-3.5">
                    <Cpu size={20} className="text-purple-400 shrink-0" />
                    <span className="text-[15px] font-semibold text-slate-100 group-hover:text-purple-200 transition-colors">
                      Other Servers
                    </span>
                  </div>
                  <ChevronDown
                    size={18}
                    className={`text-slate-400 transition-transform duration-200 ${
                      expandedSection === 'other-servers' ? 'rotate-180 text-purple-400' : ''
                    }`}
                  />
                </button>

                <AnimatePresence>
                  {expandedSection === 'other-servers' && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="border-t border-[#231938] bg-[#0c0817] px-3 py-3 space-y-1.5"
                    >
                      <Link
                        to="/vps-hosting"
                        onClick={onClose}
                        className="flex items-center justify-between p-2.5 rounded-xl hover:bg-[#19112d] border border-transparent hover:border-[#38245e] transition-all group"
                      >
                        <div className="flex items-center gap-3">
                          <Cpu size={16} className="text-purple-400" />
                          <div>
                            <span className="text-xs font-bold text-slate-200 group-hover:text-white block">
                              Cloud NVMe VPS
                            </span>
                            <span className="text-[10px] text-slate-400 block">
                              KVM AMD RYZEN™ 9 5950X virtual machines
                            </span>
                          </div>
                        </div>
                        <span className="text-[11px] font-bold text-purple-300">View Plans →</span>
                      </Link>

                      <Link
                        to="/discord-bot-hosting"
                        onClick={onClose}
                        className="flex items-center justify-between p-2.5 rounded-xl hover:bg-[#19112d] border border-transparent hover:border-[#38245e] transition-all group"
                      >
                        <div className="flex items-center gap-3">
                          <Bot size={16} className="text-indigo-400" />
                          <div>
                            <span className="text-xs font-bold text-slate-200 group-hover:text-white block">
                              Discord Bot Hosting
                            </span>
                            <span className="text-[10px] text-slate-400 block">
                              Node.js, Python, Java 24/7 uptime
                            </span>
                          </div>
                        </div>
                        <span className="text-[11px] font-bold text-indigo-400">View Plans →</span>
                      </Link>

                      <Link
                        to="/dedicated-servers"
                        onClick={onClose}
                        className="flex items-center justify-between p-2.5 rounded-xl hover:bg-[#19112d] border border-transparent hover:border-[#38245e] transition-all group"
                      >
                        <div className="flex items-center gap-3">
                          <Server size={16} className="text-emerald-400" />
                          <div>
                            <span className="text-xs font-bold text-slate-200 group-hover:text-white block">
                              Dedicated Bare-Metal
                            </span>
                            <span className="text-[10px] text-slate-400 block">
                              Enterprise single-tenant compute
                            </span>
                          </div>
                        </div>
                        <span className="text-[11px] font-bold text-emerald-400">View Plans →</span>
                      </Link>

                      <Link
                        to="/web-hosting"
                        onClick={onClose}
                        className="flex items-center justify-between p-2.5 rounded-xl hover:bg-[#19112d] border border-transparent hover:border-[#38245e] transition-all group"
                      >
                        <div className="flex items-center gap-3">
                          <Globe size={16} className="text-amber-400" />
                          <div>
                            <span className="text-xs font-bold text-slate-200 group-hover:text-white block">
                              Web Hosting
                            </span>
                            <span className="text-[10px] text-slate-400 block">
                              Ultra-fast NVMe with cPanel
                            </span>
                          </div>
                        </div>
                        <span className="text-[11px] font-bold text-amber-400">View Plans →</span>
                      </Link>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* 5. Learn & About (Accordion) */}
              <div className="rounded-2xl border border-[#231938] bg-[#130e22] overflow-hidden transition-colors shadow-sm">
                <button
                  onClick={() => toggleSection('learn-about')}
                  className="w-full flex items-center justify-between px-5 py-4 text-left group hover:bg-[#1a1330] transition-colors"
                >
                  <div className="flex items-center gap-3.5">
                    <BookOpen size={20} className="text-purple-400 shrink-0" />
                    <span className="text-[15px] font-semibold text-slate-100 group-hover:text-purple-200 transition-colors">
                      Learn & About
                    </span>
                  </div>
                  <ChevronDown
                    size={18}
                    className={`text-slate-400 transition-transform duration-200 ${
                      expandedSection === 'learn-about' ? 'rotate-180 text-purple-400' : ''
                    }`}
                  />
                </button>

                <AnimatePresence>
                  {expandedSection === 'learn-about' && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="border-t border-[#231938] bg-[#0c0817] px-3 py-3 space-y-1"
                    >
                      <Link
                        to="/about"
                        onClick={onClose}
                        className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-[#19112d] text-slate-200 hover:text-white transition-colors"
                      >
                        <Shield size={16} className="text-purple-400" />
                        <span className="text-xs font-bold">About Enterprise</span>
                      </Link>

                      <Link
                        to="/infrastructure"
                        onClick={onClose}
                        className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-[#19112d] text-slate-200 hover:text-white transition-colors"
                      >
                        <Server size={16} className="text-purple-400" />
                        <span className="text-xs font-bold">Global Data Centers & Routing</span>
                      </Link>

                      <Link
                        to="/status"
                        onClick={onClose}
                        className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-[#19112d] text-slate-200 hover:text-white transition-colors"
                      >
                        <Activity size={16} className="text-emerald-400" />
                        <span className="text-xs font-bold">Live SLA & System Status</span>
                      </Link>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* 6. Legal (Accordion) */}
              <div className="rounded-2xl border border-[#231938] bg-[#130e22] overflow-hidden transition-colors shadow-sm">
                <button
                  onClick={() => toggleSection('legal')}
                  className="w-full flex items-center justify-between px-5 py-4 text-left group hover:bg-[#1a1330] transition-colors"
                >
                  <div className="flex items-center gap-3.5">
                    <Scale size={20} className="text-purple-400 shrink-0" />
                    <span className="text-[15px] font-semibold text-slate-100 group-hover:text-purple-200 transition-colors">
                      Legal
                    </span>
                  </div>
                  <ChevronDown
                    size={18}
                    className={`text-slate-400 transition-transform duration-200 ${
                      expandedSection === 'legal' ? 'rotate-180 text-purple-400' : ''
                    }`}
                  />
                </button>

                <AnimatePresence>
                  {expandedSection === 'legal' && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="border-t border-[#231938] bg-[#0c0817] px-3 py-3 space-y-1"
                    >
                      <Link
                        to="/tos"
                        onClick={onClose}
                        className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-[#19112d] text-slate-200 hover:text-white transition-colors"
                      >
                        <span className="text-xs font-bold">Terms of Service</span>
                      </Link>
                      <Link
                        to="/privacy"
                        onClick={onClose}
                        className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-[#19112d] text-slate-200 hover:text-white transition-colors"
                      >
                        <span className="text-xs font-bold">Privacy Policy</span>
                      </Link>
                      <Link
                        to="/refund"
                        onClick={onClose}
                        className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-[#19112d] text-slate-200 hover:text-white transition-colors"
                      >
                        <span className="text-xs font-bold">Refund Policy</span>
                      </Link>
                      <Link
                        to="/legal"
                        onClick={onClose}
                        className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-[#19112d] text-slate-200 hover:text-white transition-colors"
                      >
                        <span className="text-xs font-bold">Legal Notices</span>
                      </Link>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* 7. Contact & Support */}
              <Link
                to="/contact"
                onClick={onClose}
                className="w-full flex items-center justify-between px-5 py-4 rounded-2xl border border-[#231938] bg-[#130e22] hover:bg-[#1a1330] hover:border-[#3d2b61] transition-all duration-200 text-slate-100 group shadow-sm"
              >
                <div className="flex items-center gap-3.5">
                  <Headphones size={20} className="text-purple-400 shrink-0" />
                  <span className="text-[15px] font-semibold block group-hover:text-purple-200 transition-colors">
                    Contact & Support
                  </span>
                </div>
              </Link>

              {/* 8. Currency Toggle (Exact bottom pill in Black & Purple theme) */}
              <div className="w-full flex items-center justify-between px-5 py-3 rounded-2xl bg-[#130e22] border border-[#231938] mt-2 shadow-sm">
                <span className="text-[14px] font-medium text-slate-400">
                  Currency
                </span>

                <div className="flex items-center gap-1.5">
                  {/* INR Option */}
                  <button
                    onClick={() => setActiveCurrency?.('INR')}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                      activeCurrency === 'INR'
                        ? 'bg-[#281545] text-purple-300 border border-[#522b8c] shadow-sm shadow-purple-950/50'
                        : 'text-slate-400 hover:text-white border border-transparent'
                    }`}
                  >
                    <span>🇮🇳</span>
                    <span>INR (₹)</span>
                  </button>

                  {/* USD Option */}
                  <button
                    onClick={() => setActiveCurrency?.('USD')}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                      activeCurrency === 'USD'
                        ? 'bg-[#281545] text-purple-300 border border-[#522b8c] shadow-sm shadow-purple-950/50'
                        : 'text-slate-400 hover:text-white border border-transparent'
                    }`}
                  >
                    <span>🇺🇸</span>
                    <span>USD ($)</span>
                  </button>
                </div>
              </div>

            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
