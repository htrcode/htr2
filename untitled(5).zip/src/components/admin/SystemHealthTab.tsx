import React, { useState, useEffect } from 'react';
import { 
  Activity, RefreshCw, AlertTriangle, CheckCircle2, 
  Clock, Plus, Trash2, Edit2, Play, Pause, ExternalLink, 
  Radio, Shield, ChevronDown, ChevronRight, X, Info
} from 'lucide-react';
import { StatusIncident, IncidentUpdate } from '../../types';
import { betterStackService, BetterStackStatusResponse, BetterStackMonitor, BetterStackResource } from '../../services/betterStackService';
import { dataService } from '../../services/dataService';
import { logService } from '../../services/logService';

interface SystemHealthTabProps {
  onShowToast: (msg: string, type?: 'success' | 'info' | 'error') => void;
}

export const SystemHealthTab: React.FC<SystemHealthTabProps> = ({ onShowToast }) => {
  const [betterStackData, setBetterStackData] = useState<BetterStackStatusResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [togglingMonitorId, setTogglingMonitorId] = useState<string | null>(null);

  // Firestore Custom Incidents
  const [customIncidents, setCustomIncidents] = useState<StatusIncident[]>([]);
  const [isLoadingFirestore, setIsLoadingFirestore] = useState(false);

  // Active Sub-Tab
  const [subTab, setSubTab] = useState<'monitors' | 'incidents'>('monitors');

  // Incident Modal State
  const [isIncidentModalOpen, setIsIncidentModalOpen] = useState(false);
  const [editingIncident, setEditingIncident] = useState<StatusIncident | null>(null);
  const [incidentForm, setIncidentForm] = useState({
    title: '',
    serviceName: '',
    severity: 'minor' as StatusIncident['severity'],
    status: 'investigating' as StatusIncident['status'],
    description: '',
    updateMessage: ''
  });

  // Fetch Better Stack Live Telemetry
  const fetchBetterStack = async (force = false) => {
    if (force) setIsRefreshing(true);
    else setIsLoading(true);
    try {
      const res = await betterStackService.getStatus(force);
      setBetterStackData(res);
      if (force) {
        onShowToast('Better Stack monitors & node telemetry refreshed.', 'success');
      }
    } catch (err: any) {
      console.error('Error fetching Better Stack status:', err);
      onShowToast(`Failed to fetch Better Stack telemetry: ${err.message}`, 'error');
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  // Subscribe to Firestore Incidents
  useEffect(() => {
    fetchBetterStack(false);

    setIsLoadingFirestore(true);
    const unsubIncidents = dataService.subscribeIncidents((incidents) => {
      setCustomIncidents(incidents);
      setIsLoadingFirestore(false);
    });

    return () => {
      unsubIncidents();
    };
  }, []);

  // Toggle Monitor Pause/Resume
  const handleToggleMonitor = async (monitor: BetterStackMonitor) => {
    setTogglingMonitorId(monitor.id);
    const newPaused = !monitor.paused;
    try {
      await betterStackService.toggleMonitor(monitor.id, newPaused);
      onShowToast(`Monitor "${monitor.name}" ${newPaused ? 'paused' : 'resumed'}.`, 'success');
      logService.addLog('info', `Toggled monitor ${monitor.name} (ID: ${monitor.id}) to ${newPaused ? 'paused' : 'active'}`);
      await fetchBetterStack(true);
    } catch (err: any) {
      console.error('Failed to toggle monitor:', err);
      onShowToast(`Failed to toggle monitor: ${err.message}`, 'error');
    } finally {
      setTogglingMonitorId(null);
    }
  };

  // Open Create Incident
  const openCreateIncident = () => {
    setEditingIncident(null);
    setIncidentForm({
      title: '',
      serviceName: betterStackData?.monitors?.[0]?.name || 'Mumbai Ryzen-KVM-01',
      severity: 'minor',
      status: 'investigating',
      description: '',
      updateMessage: 'Investigating degraded network performance reported in Mumbai datacenter.'
    });
    setIsIncidentModalOpen(true);
  };

  // Open Edit Incident
  const openEditIncident = (inc: StatusIncident) => {
    setEditingIncident(inc);
    setIncidentForm({
      title: inc.title,
      serviceName: inc.serviceName || '',
      severity: inc.severity,
      status: inc.status,
      description: inc.description,
      updateMessage: ''
    });
    setIsIncidentModalOpen(true);
  };

  // Save Incident to Firestore
  const handleSaveIncident = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!incidentForm.title.trim()) {
      alert('Please provide an incident title.');
      return;
    }

    try {
      const now = new Date().toISOString();
      if (editingIncident) {
        // Update existing incident
        const updatesList = [...(editingIncident.updates || [])];
        if (incidentForm.updateMessage.trim()) {
          updatesList.unshift({
            id: `up-${Date.now()}`,
            message: incidentForm.updateMessage.trim(),
            status: incidentForm.status,
            timestamp: now
          });
        }

        const updatePayload: Partial<StatusIncident> = {
          title: incidentForm.title,
          serviceName: incidentForm.serviceName,
          severity: incidentForm.severity,
          status: incidentForm.status,
          description: incidentForm.description,
          updates: updatesList,
          updatedAt: now,
          ...(incidentForm.status === 'resolved' ? { resolvedAt: now } : {})
        };

        await dataService.updateIncident(editingIncident.id, updatePayload);
        onShowToast(`Incident "${incidentForm.title}" updated.`, 'success');
        logService.addLog('warning', `Incident updated: ${incidentForm.title} (${incidentForm.status})`);
      } else {
        // Create new incident
        const initialUpdates: IncidentUpdate[] = incidentForm.updateMessage.trim() ? [{
          id: `up-${Date.now()}`,
          message: incidentForm.updateMessage.trim(),
          status: incidentForm.status,
          timestamp: now
        }] : [{
          id: `up-${Date.now()}`,
          message: incidentForm.description || 'Issue identified and staff is responding.',
          status: incidentForm.status,
          timestamp: now
        }];

        const newIncidentData: Omit<StatusIncident, 'id'> = {
          title: incidentForm.title,
          serviceName: incidentForm.serviceName,
          severity: incidentForm.severity,
          status: incidentForm.status,
          description: incidentForm.description,
          updates: initialUpdates,
          createdAt: now,
          updatedAt: now,
          ...(incidentForm.status === 'resolved' ? { resolvedAt: now } : {})
        };

        await dataService.addIncident(newIncidentData);
        onShowToast(`Incident published to public Status Page!`, 'success');
        logService.addLog('warning', `New Incident broadcasted: ${incidentForm.title}`);
      }

      setIsIncidentModalOpen(false);
    } catch (err: any) {
      console.error(err);
      onShowToast(`Error saving incident: ${err.message}`, 'error');
    }
  };

  // Delete Incident
  const handleDeleteIncident = async (id: string, title: string) => {
    if (!window.confirm(`Delete incident "${title}"?`)) return;
    try {
      await dataService.deleteIncident(id);
      onShowToast(`Incident "${title}" deleted.`, 'info');
      logService.addLog('info', `Deleted status incident: ${title}`);
    } catch (err: any) {
      onShowToast(`Error deleting incident: ${err.message}`, 'error');
    }
  };

  const allMonitors = betterStackData?.monitors || [];
  const betterStackIncidents = betterStackData?.incidents || [];
  const overallState = betterStackData?.summary?.overall_status || 'operational';
  const uptimeScore = betterStackData?.summary?.uptime_percentage || '99.98%';

  return (
    <div className="space-y-6">
      {/* Top Banner & Refresh */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Activity size={18} className="text-emerald-400" />
            <h2 className="text-base font-bold text-white tracking-tight">
              System Health & Uptime Center
            </h2>
            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
              overallState === 'operational' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
              overallState === 'degraded' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
              'bg-rose-500/10 text-rose-400 border border-rose-500/20'
            }`}>
              {overallState}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Real-time Better Stack telemetry integration, node heartbeat checks, pause/resume controls, and public incident broadcasts.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <a
            href="/status"
            target="_blank"
            rel="noopener noreferrer"
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5"
            title="Open public status page in new tab"
          >
            <span>Public Status Page</span>
            <ExternalLink size={12} />
          </a>
          <button
            onClick={() => fetchBetterStack(true)}
            disabled={isRefreshing || isLoading}
            className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <RefreshCw size={13} className={isRefreshing ? 'animate-spin' : ''} />
            <span>Sync Better Stack</span>
          </button>
        </div>
      </div>

      {/* Top Telemetry KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Overall Health */}
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-4 shadow-sm">
          <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider block mb-1">
            Aggregate Health
          </span>
          <div className="text-xl font-bold font-mono capitalize text-white flex items-center gap-2">
            <span className={`w-2.5 h-2.5 rounded-full ${
              overallState === 'operational' ? 'bg-emerald-400' :
              overallState === 'degraded' ? 'bg-amber-400' : 'bg-rose-400'
            }`} />
            <span>{overallState}</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1 font-mono">
            Provider: Better Stack API
          </p>
        </div>

        {/* Global Uptime */}
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-4 shadow-sm">
          <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider block mb-1">
            Average Uptime (30d)
          </span>
          <div className="text-xl font-bold font-mono text-emerald-400">
            {uptimeScore}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            SLA Standard: 99.95% Target
          </p>
        </div>

        {/* Live Monitors */}
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-4 shadow-sm">
          <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider block mb-1">
            Active Heartbeat Probes
          </span>
          <div className="text-xl font-bold font-mono text-white">
            {allMonitors.length} Monitors
          </div>
          <p className="text-[11px] text-slate-400 mt-1 flex items-center gap-1.5">
            <span className="text-emerald-400 font-semibold">{allMonitors.filter(m => m.status === 'up' && !m.paused).length} Online</span>
            <span>·</span>
            <span className="text-amber-400">{allMonitors.filter(m => m.paused).length} Paused</span>
          </p>
        </div>

        {/* Broadcast Incidents */}
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-4 shadow-sm">
          <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider block mb-1">
            Active Incidents
          </span>
          <div className={`text-xl font-bold font-mono ${
            (customIncidents.filter(i => i.status !== 'resolved').length + betterStackIncidents.filter(i => i.status !== 'Resolved').length) > 0 
              ? 'text-amber-400' 
              : 'text-slate-300'
          }`}>
            {customIncidents.filter(i => i.status !== 'resolved').length + betterStackIncidents.filter(i => i.status !== 'Resolved').length}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            {customIncidents.length} total incident records in history
          </p>
        </div>
      </div>

      {/* Sub-Tab Navigation Header */}
      <div className="flex items-center justify-between border-b border-slate-800 bg-[#0c111d] px-4 rounded-xl">
        <div className="flex items-center gap-1">
          <button
            onClick={() => setSubTab('monitors')}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition-all ${
              subTab === 'monitors'
                ? 'border-emerald-500 text-emerald-400 bg-emerald-500/5'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Radio size={14} />
            <span>Better Stack Monitors ({allMonitors.length})</span>
          </button>

          <button
            onClick={() => setSubTab('incidents')}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition-all ${
              subTab === 'incidents'
                ? 'border-amber-500 text-amber-400 bg-amber-500/5'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <AlertTriangle size={14} />
            <span>Broadcast Incidents ({customIncidents.length})</span>
            {customIncidents.filter(i => i.status !== 'resolved').length > 0 && (
              <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-amber-500/20 text-amber-300 font-mono">
                {customIncidents.filter(i => i.status !== 'resolved').length}
              </span>
            )}
          </button>
        </div>

        {subTab === 'incidents' && (
          <button
            onClick={openCreateIncident}
            className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <Plus size={13} />
            <span>+ Broadcast Incident</span>
          </button>
        )}
      </div>

      {/* --- SUB-TAB 1: BETTER STACK MONITORS --- */}
      {subTab === 'monitors' && (
        <div className="space-y-4">
          <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden shadow-sm">
            <div className="p-4 bg-slate-900/80 border-b border-slate-800 flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                  Live Better Stack Heartbeat Monitors
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Direct API connection to Better Stack Uptime. Pause or resume monitors during maintenance windows.
                </p>
              </div>
              <span className="text-[11px] font-mono text-slate-400">
                Auto-syncs with status.hector.host
              </span>
            </div>

            {isLoading ? (
              <div className="p-12 text-center text-xs text-slate-400 flex flex-col items-center justify-center space-y-2">
                <RefreshCw size={24} className="animate-spin text-emerald-400" />
                <p>Loading live probe responses from Better Stack API...</p>
              </div>
            ) : allMonitors.length === 0 ? (
              <div className="p-12 text-center text-xs text-slate-500 space-y-3">
                <Radio size={28} className="mx-auto text-slate-600" />
                <p>No Better Stack monitors returned by API or token not configured.</p>
                <button
                  onClick={() => fetchBetterStack(true)}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium"
                >
                  Retry Sync
                </button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-900/60 text-[10px] uppercase font-semibold text-slate-400 tracking-wider">
                    <tr>
                      <th className="p-3.5">Monitor Name</th>
                      <th className="p-3.5">Endpoint URL / Host</th>
                      <th className="p-3.5">Check Type</th>
                      <th className="p-3.5">Interval</th>
                      <th className="p-3.5">Probe Status</th>
                      <th className="p-3.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {allMonitors.map(m => {
                      const isUp = m.status === 'up';
                      const isPaused = m.paused;
                      const isToggling = togglingMonitorId === m.id;

                      return (
                        <tr key={m.id} className="hover:bg-slate-850/40 transition-colors">
                          <td className="p-3.5">
                            <div className="font-semibold text-white flex items-center gap-2">
                              <span className={`w-2 h-2 rounded-full ${
                                isPaused ? 'bg-amber-400' :
                                isUp ? 'bg-emerald-400' : 'bg-rose-500 animate-ping'
                              }`} />
                              <span>{m.name}</span>
                            </div>
                            <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                              ID: {m.id} · Regions: {m.regions?.join(', ') || 'Global'}
                            </div>
                          </td>
                          <td className="p-3.5 font-mono text-[11px] text-slate-300 max-w-xs truncate">
                            {m.url || 'ICMP Ping Host'}
                          </td>
                          <td className="p-3.5 uppercase font-mono text-[11px] text-slate-400">
                            {m.monitor_type || 'HTTP'}
                          </td>
                          <td className="p-3.5 text-slate-400 font-mono text-[11px]">
                            {m.check_frequency ? `${m.check_frequency}s` : '30s'}
                          </td>
                          <td className="p-3.5">
                            <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-[11px] font-semibold uppercase ${
                              isPaused ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                              isUp ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                              'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                            }`}>
                              {isPaused ? 'Paused' : isUp ? 'Up' : 'Down'}
                            </span>
                          </td>
                          <td className="p-3.5 text-right">
                            <button
                              onClick={() => handleToggleMonitor(m)}
                              disabled={isToggling}
                              className={`px-3 py-1 rounded text-[11px] font-semibold transition-colors inline-flex items-center gap-1.5 ${
                                isPaused 
                                  ? 'bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-500/30'
                                  : 'bg-amber-600/20 hover:bg-amber-600/30 text-amber-400 border border-amber-500/30'
                              } disabled:opacity-50`}
                              title={isPaused ? 'Resume monitoring' : 'Pause probe during maintenance'}
                            >
                              {isToggling ? (
                                <RefreshCw size={11} className="animate-spin" />
                              ) : isPaused ? (
                                <Play size={11} />
                              ) : (
                                <Pause size={11} />
                              )}
                              <span>{isPaused ? 'Resume' : 'Pause'}</span>
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* --- SUB-TAB 2: BROADCAST INCIDENTS --- */}
      {subTab === 'incidents' && (
        <div className="space-y-4">
          <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden shadow-sm">
            <div className="p-4 bg-slate-900/80 border-b border-slate-800 flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                  Public Status Incidents & Outage Bulletins
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Incidents broadcasted here show immediately on the public /status page with live timeline updates.
                </p>
              </div>
            </div>

            {customIncidents.length === 0 ? (
              <div className="p-12 text-center text-xs text-slate-500 space-y-3">
                <CheckCircle2 size={32} className="mx-auto text-emerald-400" />
                <p className="font-semibold text-slate-300">No Incidents Reported</p>
                <p className="text-slate-500 text-[11px]">All infrastructure clusters are operating without any reported alerts.</p>
                <button
                  onClick={openCreateIncident}
                  className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-semibold"
                >
                  + Broadcast Incident Notice
                </button>
              </div>
            ) : (
              <div className="divide-y divide-slate-800">
                {customIncidents.map(inc => {
                  const isResolved = inc.status === 'resolved';
                  return (
                    <div key={inc.id} className="p-4 hover:bg-slate-850/30 transition-colors space-y-3">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            inc.severity === 'critical' ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' :
                            inc.severity === 'major' ? 'bg-orange-500/20 text-orange-400 border border-orange-500/30' :
                            inc.severity === 'maintenance' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' :
                            'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                          }`}>
                            {inc.severity}
                          </span>
                          <h4 className="text-sm font-bold text-white">{inc.title}</h4>
                          {inc.serviceName && (
                            <span className="text-[11px] text-slate-400 font-mono">
                              • {inc.serviceName}
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-2 self-end sm:self-auto">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            isResolved ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                            inc.status === 'monitoring' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' :
                            'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                          }`}>
                            {inc.status}
                          </span>
                          <button
                            onClick={() => openEditIncident(inc)}
                            className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs font-medium transition-colors flex items-center gap-1"
                          >
                            <Edit2 size={11} /> Update
                          </button>
                          <button
                            onClick={() => handleDeleteIncident(inc.id, inc.title)}
                            className="p-1 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded transition-colors"
                            title="Delete Incident"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </div>

                      <p className="text-xs text-slate-300 leading-relaxed">
                        {inc.description}
                      </p>

                      {/* Recent timeline entry */}
                      {inc.updates && inc.updates.length > 0 && (
                        <div className="p-2.5 bg-slate-900 border border-slate-800/80 rounded-lg text-xs space-y-1">
                          <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono">
                            <span className="uppercase font-semibold text-slate-400">Latest Update ({inc.updates[0].status})</span>
                            <span>{new Date(inc.updates[0].timestamp).toLocaleString()}</span>
                          </div>
                          <p className="text-slate-300 text-[11px]">{inc.updates[0].message}</p>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* --- MODAL 1: INCIDENT BROADCAST MODAL --- */}
      {isIncidentModalOpen && (
        <div className="fixed inset-0 z-[1400] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="w-full max-w-xl bg-[#0f172a] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
            <div className="p-5 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertTriangle size={16} className="text-amber-400" />
                <h3 className="text-sm font-bold text-white">
                  {editingIncident ? 'Update Status Incident' : 'Broadcast Public Incident'}
                </h3>
              </div>
              <button onClick={() => setIsIncidentModalOpen(false)} className="text-slate-400 hover:text-white">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSaveIncident} className="p-6 space-y-4 text-xs">
              <div>
                <label className="text-[11px] font-semibold text-slate-300 block mb-1">Incident Headline</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Degraded Network Latency in Mumbai DC-01"
                  value={incidentForm.title}
                  onChange={(e) => setIncidentForm({ ...incidentForm, title: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-[11px] font-semibold text-slate-300 block mb-1">Impacted Component / Service</label>
                  <input
                    type="text"
                    placeholder="e.g. Ryzen KVM Nodes or Pterodactyl Panel"
                    value={incidentForm.serviceName}
                    onChange={(e) => setIncidentForm({ ...incidentForm, serviceName: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-300 block mb-1">Severity</label>
                  <select
                    value={incidentForm.severity}
                    onChange={(e) => setIncidentForm({ ...incidentForm, severity: e.target.value as any })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white outline-none focus:border-amber-500"
                  >
                    <option value="minor">Minor / Partial Degradation</option>
                    <option value="major">Major Outage</option>
                    <option value="critical">Critical Outage</option>
                    <option value="maintenance">Scheduled Maintenance</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-300 block mb-1">Current State</label>
                <select
                  value={incidentForm.status}
                  onChange={(e) => setIncidentForm({ ...incidentForm, status: e.target.value as any })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white outline-none focus:border-amber-500 font-semibold"
                >
                  <option value="investigating">Investigating (Initial Alert)</option>
                  <option value="identified">Identified (Root Cause Found)</option>
                  <option value="monitoring">Monitoring (Fix Applied)</option>
                  <option value="resolved">Resolved (Normal Operations Resumed)</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-300 block mb-1">Incident Description / Impact</label>
                <textarea
                  rows={2}
                  required
                  placeholder="Detail what clients are experiencing (e.g. 50-70ms elevated ping to Indian servers)..."
                  value={incidentForm.description}
                  onChange={(e) => setIncidentForm({ ...incidentForm, description: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-300 block mb-1">
                  {editingIncident ? 'Add New Timeline Update' : 'Initial Timeline Note'}
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g. Upstream transit carrier fiber cut detected near Mumbai. Traffic rerouted via Chennai..."
                  value={incidentForm.updateMessage}
                  onChange={(e) => setIncidentForm({ ...incidentForm, updateMessage: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white outline-none focus:border-amber-500"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsIncidentModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-semibold shadow-sm"
                >
                  {editingIncident ? 'Save Updates' : 'Broadcast to Status Page'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
