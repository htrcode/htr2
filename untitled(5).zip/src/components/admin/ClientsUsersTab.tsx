import React, { useState } from 'react';
import { 
  Users, Search, User, ShieldCheck, CreditCard, 
  Box, ArrowRight, Shield, Trash2, RefreshCw 
} from 'lucide-react';
import { UserProfile, UserService, Invoice } from '../../types';
import { parseAmount, formatINR } from '../../utils/formatUtils';

interface ClientsUsersTabProps {
  users: UserProfile[];
  services: UserService[];
  invoices: Invoice[];
  onOpenClientProfile: (userId: string) => void;
  onToggleUserRole: (userId: string, currentRole: 'admin' | 'user') => Promise<void>;
  onDeleteUser: (userId: string) => Promise<void>;
  onRefresh: () => void;
  isLoading: boolean;
}

export const ClientsUsersTab: React.FC<ClientsUsersTabProps> = ({
  users,
  services,
  invoices,
  onOpenClientProfile,
  onToggleUserRole,
  onDeleteUser,
  onRefresh,
  isLoading
}) => {
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState<'ALL' | 'admin' | 'user'>('ALL');

  const filteredUsers = users.filter(u => {
    const q = search.toLowerCase();
    const matchSearch = 
      (u.email && u.email.toLowerCase().includes(q)) ||
      (u.displayName && u.displayName.toLowerCase().includes(q)) ||
      (u.id && u.id.toLowerCase().includes(q));

    const matchRole = roleFilter === 'ALL' || u.role === roleFilter;
    return matchSearch && matchRole;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm">
        <div>
          <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
            <Users size={18} className="text-purple-400" />
            Client Directory & RBAC Governance
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            WHMCS-standard client directory. View real-time active services, invoice histories, and grant administrative credentials.
          </p>
        </div>
        <button
          onClick={onRefresh}
          disabled={isLoading}
          className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded-lg transition-colors disabled:opacity-50"
          title="Refresh Clients"
        >
          <RefreshCw size={14} className={isLoading ? 'animate-spin' : ''} />
        </button>
      </div>

      {/* Search and Filters */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder="Search email, name, UID..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 outline-none focus:border-purple-500"
          />
        </div>

        <div className="flex items-center gap-1.5 w-full sm:w-auto">
          {(['ALL', 'admin', 'user'] as const).map(r => (
            <button
              key={r}
              onClick={() => setRoleFilter(r)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                roleFilter === r
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {r === 'ALL' ? 'All Accounts' : r === 'admin' ? 'Administrators' : 'Clients'}
            </button>
          ))}
        </div>
      </div>

      {/* Clients Table */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900/80 text-[10px] uppercase font-semibold text-slate-400 tracking-wider border-b border-slate-800">
              <tr>
                <th className="p-3.5">Client Profile</th>
                <th className="p-3.5">UID</th>
                <th className="p-3.5">Services</th>
                <th className="p-3.5">Invoices & Spent</th>
                <th className="p-3.5">Role</th>
                <th className="p-3.5">Joined Date</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filteredUsers.map(u => {
                const clientEmail = (u.email || '').toLowerCase().trim();
                const userServices = services.filter(s => 
                  s.userId === u.id || 
                  (s.userId && s.userId.toLowerCase().trim() === clientEmail) ||
                  (s.panelEmail && s.panelEmail.toLowerCase().trim() === clientEmail)
                );
                const userInvoices = invoices.filter(i => 
                  i.userId === u.id || 
                  (i.userId && i.userId.toLowerCase().trim() === clientEmail)
                );
                const paidTotal = userInvoices
                  .filter(i => i.status === 'Paid')
                  .reduce((sum, i) => sum + parseAmount(i.total), 0);

                return (
                  <tr key={u.id} className="hover:bg-slate-850/40 transition-colors">
                    <td className="p-3.5">
                      <button
                        onClick={() => onOpenClientProfile(u.id)}
                        className="flex items-center gap-3 text-left group"
                        title="Open Client 360° Profile"
                      >
                        <div className="w-8 h-8 rounded-full bg-blue-500/20 text-blue-400 font-bold flex items-center justify-center text-xs shrink-0">
                          {(u.displayName || u.email)?.[0]?.toUpperCase() || 'U'}
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-white group-hover:text-blue-400 truncate flex items-center gap-1">
                            <span>{u.displayName || u.email?.split('@')[0]}</span>
                            <ArrowRight size={10} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                          </p>
                          <p className="text-[10px] text-slate-400 font-mono truncate">{u.email}</p>
                        </div>
                      </button>
                    </td>
                    <td className="p-3.5 font-mono text-[11px] text-slate-400 max-w-[130px] truncate" title={u.id}>
                      {u.id}
                    </td>
                    <td className="p-3.5">
                      <span className="font-medium text-white">{userServices.length}</span>
                      <span className="text-[10px] text-slate-500 ml-1">
                        ({userServices.filter(s => s.status === 'active').length} active)
                      </span>
                    </td>
                    <td className="p-3.5">
                      <div className="font-mono text-white font-semibold">{formatINR(paidTotal)}</div>
                      <div className="text-[10px] text-slate-500">{userInvoices.length} invoices</div>
                    </td>
                    <td className="p-3.5">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-[11px] font-semibold ${
                        u.role === 'admin'
                          ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                          : 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                      }`}>
                        {u.role === 'admin' ? <ShieldCheck size={11} /> : <User size={11} />}
                        {u.role === 'admin' ? 'Administrator' : 'Client'}
                      </span>
                    </td>
                    <td className="p-3.5 text-slate-400 text-[11px]">
                      {u.createdAt ? new Date(u.createdAt).toLocaleDateString() : 'Recent'}
                    </td>
                    <td className="p-3.5 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => onOpenClientProfile(u.id)}
                          className="px-2.5 py-1 bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 border border-blue-500/30 rounded text-[11px] font-medium transition-colors"
                        >
                          Profile 360°
                        </button>
                        <button
                          onClick={() => onToggleUserRole(u.id, u.role)}
                          className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px] font-medium transition-colors"
                          title={u.role === 'admin' ? 'Demote to Client' : 'Promote to Admin'}
                        >
                          {u.role === 'admin' ? 'Revoke Admin' : 'Make Admin'}
                        </button>
                        <button
                          onClick={() => onDeleteUser(u.id)}
                          className="p-1 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded transition-colors"
                          title="Delete User"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {filteredUsers.length === 0 && (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-xs text-slate-500">
                    No matching client accounts found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
