import React, { useState } from 'react';
import { 
  X, User, Mail, Calendar, Shield, ShieldCheck, Box, CreditCard, 
  LifeBuoy, ExternalLink, CheckCircle2, Clock, AlertTriangle, 
  Trash2, Plus, Server, Edit3, Power, RefreshCw, Key, MapPin
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { UserProfile, UserService, Invoice, Ticket } from '../../types';
import { adminService } from '../../services/adminService';
import { logService } from '../../services/logService';
import { parseAmount, formatINR } from '../../utils/formatUtils';

interface ClientProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  client: UserProfile | null;
  services: UserService[];
  invoices: Invoice[];
  tickets: Ticket[];
  onUpdateServiceStatus: (serviceId: string, status: UserService['status']) => Promise<void>;
  onVerifyInvoice: (invoiceId: string) => Promise<void>;
  onOpenEditService: (service: UserService) => void;
  onOpenInvoiceDoc: (invoice: Invoice) => void;
  onOpenCreateInvoiceForClient: (clientId: string, clientEmail: string) => void;
  onOpenCreateServiceForClient: (clientId: string, clientEmail: string) => void;
  onToggleUserRole: (userId: string, currentRole: 'admin' | 'user') => Promise<void>;
  onDeleteUser: (userId: string) => Promise<void>;
  onNavigateToTicket: (ticketId: string) => void;
}

export const ClientProfileModal: React.FC<ClientProfileModalProps> = ({
  isOpen,
  onClose,
  client,
  services,
  invoices,
  tickets,
  onUpdateServiceStatus,
  onVerifyInvoice,
  onOpenEditService,
  onOpenInvoiceDoc,
  onOpenCreateInvoiceForClient,
  onOpenCreateServiceForClient,
  onToggleUserRole,
  onDeleteUser,
  onNavigateToTicket
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'services' | 'invoices' | 'tickets' | 'actions'>('overview');
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  if (!isOpen || !client) return null;

  const clientEmail = (client.email || '').toLowerCase().trim();
  const clientId = client.id;

  // Filter client-specific connected records
  const clientServices = services.filter(s => 
    s.userId === clientId || 
    (s.panelEmail && s.panelEmail.toLowerCase().trim() === clientEmail) ||
    (s.userId && s.userId.toLowerCase().trim() === clientEmail)
  );

  const clientInvoices = invoices.filter(inv => 
    inv.userId === clientId || 
    (inv.userId && inv.userId.toLowerCase().trim() === clientEmail)
  );

  const clientTickets = tickets.filter(t => 
    t.userId === clientId || 
    (t.userEmail && t.userEmail.toLowerCase().trim() === clientEmail)
  );

  // Financial Computations
  const totalBilled = clientInvoices.reduce((sum, inv) => sum + parseAmount(inv.total), 0);
  const totalPaid = clientInvoices
    .filter(inv => inv.status === 'Paid')
    .reduce((sum, inv) => sum + parseAmount(inv.total), 0);
  const totalUnpaid = clientInvoices
    .filter(inv => inv.status === 'Unpaid' || inv.status === 'pending' || inv.status === 'UPI_PENDING_VERIFICATION')
    .reduce((sum, inv) => sum + parseAmount(inv.total), 0);

  const activeServicesCount = clientServices.filter(s => s.status === 'active').length;

  return (
    <div className="fixed inset-0 z-[1200] flex items-center justify-center p-4 sm:p-6 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 15 }}
        className="w-full max-w-5xl bg-[#0f172a] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
      >
        {/* Modal Top Header (WHMCS Client Summary Banner) */}
        <div className="p-6 bg-slate-900 border-b border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-indigo-500/20 to-blue-600/30 border border-indigo-500/30 flex items-center justify-center text-xl font-bold text-indigo-400 shrink-0 shadow-inner">
              {client.photoURL ? (
                <img src={client.photoURL} alt="" className="w-full h-full object-cover rounded-2xl" />
              ) : (
                (client.displayName || client.email)?.[0]?.toUpperCase() || 'U'
              )}
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h2 className="text-xl font-bold text-white tracking-tight">
                  {client.displayName || client.email?.split('@')[0] || 'Client Profile'}
                </h2>
                <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-semibold ${
                  client.role === 'admin' 
                    ? 'bg-purple-500/10 text-purple-400 border border-purple-500/30' 
                    : 'bg-blue-500/10 text-blue-400 border border-blue-500/30'
                }`}>
                  {client.role === 'admin' ? <ShieldCheck size={12} /> : <User size={12} />}
                  {client.role === 'admin' ? 'Administrator' : 'Client Account'}
                </span>
                {totalUnpaid > 0 && (
                  <span className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/30 text-xs font-semibold">
                    Outstanding Balance: ₹{totalUnpaid.toLocaleString('en-IN')}
                  </span>
                )}
              </div>
              <div className="flex items-center gap-3 text-xs text-slate-400 mt-1 flex-wrap font-mono">
                <span className="flex items-center gap-1">
                  <Mail size={12} className="text-slate-500" />
                  {client.email}
                </span>
                <span>·</span>
                <span className="text-slate-400">UID: <span className="text-slate-300">{client.id}</span></span>
                {client.createdAt && (
                  <>
                    <span>·</span>
                    <span className="flex items-center gap-1 text-slate-400">
                      <Calendar size={12} className="text-slate-500" />
                      Client Since {new Date(client.createdAt).toLocaleDateString()}
                    </span>
                  </>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end md:self-auto">
            <button
              onClick={() => onOpenCreateInvoiceForClient(client.id, client.email)}
              className="px-3 py-1.5 bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 border border-blue-500/30 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5"
            >
              <CreditCard size={13} />
              + Invoice
            </button>
            <button
              onClick={() => onOpenCreateServiceForClient(client.id, client.email)}
              className="px-3 py-1.5 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-500/30 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5"
            >
              <Box size={13} />
              + Service
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
              title="Close Profile"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Financial & Status Summary Ribbon */}
        <div className="grid grid-cols-2 sm:grid-cols-4 divide-x divide-slate-800 border-b border-slate-800 bg-slate-900/60">
          <div className="p-4">
            <span className="text-[11px] font-medium uppercase tracking-wider text-slate-400 block mb-1">Total Invoiced</span>
            <span className="text-lg font-bold text-white font-mono">₹{totalBilled.toLocaleString('en-IN')}</span>
          </div>
          <div className="p-4">
            <span className="text-[11px] font-medium uppercase tracking-wider text-slate-400 block mb-1">Total Paid</span>
            <span className="text-lg font-bold text-emerald-400 font-mono">₹{totalPaid.toLocaleString('en-IN')}</span>
          </div>
          <div className="p-4">
            <span className="text-[11px] font-medium uppercase tracking-wider text-slate-400 block mb-1">Unpaid Balance</span>
            <span className={`text-lg font-bold font-mono ${totalUnpaid > 0 ? 'text-amber-400' : 'text-slate-400'}`}>
              ₹{totalUnpaid.toLocaleString('en-IN')}
            </span>
          </div>
          <div className="p-4">
            <span className="text-[11px] font-medium uppercase tracking-wider text-slate-400 block mb-1">Active Services</span>
            <span className="text-lg font-bold text-indigo-400 font-mono">{activeServicesCount} / {clientServices.length}</span>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 px-6 border-b border-slate-800 bg-slate-900/40">
          {[
            { id: 'overview', label: 'Client Overview', icon: User, count: null },
            { id: 'services', label: 'Hosting Services', icon: Box, count: clientServices.length },
            { id: 'invoices', label: 'Invoices & Billing', icon: CreditCard, count: clientInvoices.length },
            { id: 'tickets', label: 'Support Tickets', icon: LifeBuoy, count: clientTickets.length },
            { id: 'actions', label: 'Account Controls', icon: Shield, count: null }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition-all ${
                activeTab === tab.id
                  ? 'border-blue-500 text-blue-400 bg-blue-500/5'
                  : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
              }`}
            >
              <tab.icon size={14} />
              <span>{tab.label}</span>
              {tab.count !== null && (
                <span className={`px-1.5 py-0.2 rounded text-[10px] font-mono ${
                  activeTab === tab.id ? 'bg-blue-500/20 text-blue-300' : 'bg-slate-800 text-slate-400'
                }`}>
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Tab Content Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Account Details Box */}
                <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
                  <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                    <User size={14} className="text-blue-400" /> Account Information
                  </h4>
                  <div className="space-y-3 text-xs divide-y divide-slate-800/60">
                    <div className="flex justify-between py-1.5">
                      <span className="text-slate-400">Full Name</span>
                      <span className="text-white font-medium">{client.displayName || 'Not Provided'}</span>
                    </div>
                    <div className="flex justify-between py-1.5">
                      <span className="text-slate-400">Email Address</span>
                      <span className="text-white font-mono">{client.email}</span>
                    </div>
                    <div className="flex justify-between py-1.5">
                      <span className="text-slate-400">Database User ID</span>
                      <span className="text-slate-300 font-mono text-[11px]">{client.id}</span>
                    </div>
                    <div className="flex justify-between py-1.5">
                      <span className="text-slate-400">Registered On</span>
                      <span className="text-slate-300">{client.createdAt ? new Date(client.createdAt).toLocaleString() : 'N/A'}</span>
                    </div>
                    <div className="flex justify-between py-1.5">
                      <span className="text-slate-400">Last Session Active</span>
                      <span className="text-slate-300">{client.lastLogin ? new Date(client.lastLogin).toLocaleString() : 'Recent'}</span>
                    </div>
                    <div className="flex justify-between py-1.5">
                      <span className="text-slate-400">Pterodactyl Panel ID</span>
                      <span className="text-indigo-400 font-mono">{client.pterodactylId ? `#${client.pterodactylId} (${client.pterodactylUsername || client.email})` : 'Linked on Demand'}</span>
                    </div>
                  </div>
                </div>

                {/* Quick Snapshot Box */}
                <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
                  <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                    <CreditCard size={14} className="text-emerald-400" /> Financial & Service Status
                  </h4>
                  <div className="space-y-3 text-xs divide-y divide-slate-800/60">
                    <div className="flex justify-between py-1.5">
                      <span className="text-slate-400">Total Invoices Created</span>
                      <span className="text-white font-medium">{clientInvoices.length} invoices</span>
                    </div>
                    <div className="flex justify-between py-1.5">
                      <span className="text-slate-400">Paid Invoices</span>
                      <span className="text-emerald-400 font-medium">{clientInvoices.filter(i => i.status === 'Paid').length} paid</span>
                    </div>
                    <div className="flex justify-between py-1.5">
                      <span className="text-slate-400">Pending / Unpaid</span>
                      <span className={`font-medium ${totalUnpaid > 0 ? 'text-amber-400' : 'text-slate-400'}`}>
                        {clientInvoices.filter(i => i.status === 'Unpaid').length} invoices (₹{totalUnpaid.toLocaleString('en-IN')})
                      </span>
                    </div>
                    <div className="flex justify-between py-1.5">
                      <span className="text-slate-400">Active Hosting Servers</span>
                      <span className="text-indigo-400 font-medium">{activeServicesCount} operational</span>
                    </div>
                    <div className="flex justify-between py-1.5">
                      <span className="text-slate-400">Support Tickets Submitted</span>
                      <span className="text-slate-300 font-medium">{clientTickets.length} tickets ({clientTickets.filter(t => t.status === 'open' || t.status === 'in_progress' || t.status === 'waiting_user').length} active)</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Recent Services Preview */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Active Services</h4>
                  <button onClick={() => setActiveTab('services')} className="text-xs text-blue-400 hover:underline">
                    View all {clientServices.length} services →
                  </button>
                </div>
                {clientServices.length === 0 ? (
                  <div className="p-6 bg-slate-900/40 border border-slate-800 rounded-xl text-center text-xs text-slate-500">
                    No hosting services active for this client.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {clientServices.slice(0, 4).map(srv => (
                      <div key={srv.id} className="p-3.5 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between">
                        <div className="min-w-0 pr-3">
                          <p className="text-xs font-bold text-white truncate flex items-center gap-1.5">
                            <Server size={12} className="text-blue-400" />
                            {srv.name}
                          </p>
                          <p className="text-[11px] text-slate-400 font-mono truncate mt-0.5">
                            {srv.ip || 'Allocating IP'} · {srv.nodeName || 'Cluster-01'}
                          </p>
                        </div>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                          srv.status === 'active' ? 'bg-emerald-500/10 text-emerald-400' :
                          srv.status === 'suspended' ? 'bg-amber-500/10 text-amber-400' : 'bg-slate-800 text-slate-400'
                        }`}>
                          {srv.status}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: SERVICES */}
          {activeTab === 'services' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white">Client Hosting Services ({clientServices.length})</h3>
                  <p className="text-xs text-slate-400">All server instances, VPS nodes, and game deployments provisioned for this client.</p>
                </div>
                <button
                  onClick={() => onOpenCreateServiceForClient(client.id, client.email)}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5"
                >
                  <Plus size={14} />
                  Provision New Service
                </button>
              </div>

              {clientServices.length === 0 ? (
                <div className="py-12 bg-slate-900/40 border border-slate-800 rounded-xl text-center text-xs text-slate-500">
                  <Box size={28} className="mx-auto text-slate-600 mb-2" />
                  No services found for this client.
                </div>
              ) : (
                <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-900">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-800/60 text-[10px] uppercase font-semibold text-slate-400 tracking-wider">
                      <tr>
                        <th className="p-3.5">Service Name</th>
                        <th className="p-3.5">Node & IP Address</th>
                        <th className="p-3.5">Billing & Expiry</th>
                        <th className="p-3.5">Status</th>
                        <th className="p-3.5 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {clientServices.map(srv => (
                        <tr key={srv.id} className="hover:bg-slate-850/50">
                          <td className="p-3.5">
                            <div className="font-semibold text-white">{srv.name}</div>
                            <div className="text-[10px] text-slate-500 font-mono">ID: {srv.id}</div>
                          </td>
                          <td className="p-3.5">
                            <div className="text-slate-300 font-mono text-[11px]">{srv.ip || 'No IP Allocated'}</div>
                            <div className="text-[10px] text-slate-500">{srv.nodeName || 'Cluster-01'} · {srv.location || 'Mumbai'}</div>
                          </td>
                          <td className="p-3.5">
                            <div className="text-white font-medium">₹{srv.price || 0}/mo</div>
                            <div className="text-[10px] text-slate-500">
                              Expires: {srv.expiresAt ? new Date(srv.expiresAt).toLocaleDateString() : 'Auto-renew'}
                            </div>
                          </td>
                          <td className="p-3.5">
                            <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold ${
                              srv.status === 'active' ? 'bg-emerald-500/10 text-emerald-400' :
                              srv.status === 'pending' ? 'bg-amber-500/10 text-amber-400' :
                              srv.status === 'suspended' ? 'bg-orange-500/10 text-orange-400' : 'bg-rose-500/10 text-rose-400'
                            }`}>
                              <span className={`w-1.5 h-1.5 rounded-full ${
                                srv.status === 'active' ? 'bg-emerald-400' :
                                srv.status === 'pending' ? 'bg-amber-400' :
                                srv.status === 'suspended' ? 'bg-orange-400' : 'bg-rose-400'
                              }`} />
                              {srv.status}
                            </span>
                          </td>
                          <td className="p-3.5 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => onOpenEditService(srv)}
                                className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] font-medium transition-colors flex items-center gap-1"
                                title="Edit IP, Port and Credentials"
                              >
                                <Edit3 size={11} /> Edit
                              </button>
                              {srv.status === 'active' ? (
                                <button
                                  onClick={() => onUpdateServiceStatus(srv.id, 'suspended')}
                                  className="px-2.5 py-1 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded text-[11px] font-medium transition-colors"
                                >
                                  Suspend
                                </button>
                              ) : (
                                <button
                                  onClick={() => onUpdateServiceStatus(srv.id, 'active')}
                                  className="px-2.5 py-1 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded text-[11px] font-medium transition-colors"
                                >
                                  Activate
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: INVOICES */}
          {activeTab === 'invoices' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white">Billing Invoices ({clientInvoices.length})</h3>
                  <p className="text-xs text-slate-400">All issued billing invoices, payment attempts, and UPI transaction references.</p>
                </div>
                <button
                  onClick={() => onOpenCreateInvoiceForClient(client.id, client.email)}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5"
                >
                  <Plus size={14} />
                  + Create Invoice
                </button>
              </div>

              {clientInvoices.length === 0 ? (
                <div className="py-12 bg-slate-900/40 border border-slate-800 rounded-xl text-center text-xs text-slate-500">
                  <CreditCard size={28} className="mx-auto text-slate-600 mb-2" />
                  No invoices found for this client.
                </div>
              ) : (
                <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-900">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-800/60 text-[10px] uppercase font-semibold text-slate-400 tracking-wider">
                      <tr>
                        <th className="p-3.5">Invoice #</th>
                        <th className="p-3.5">Total Amount</th>
                        <th className="p-3.5">Payment Method & UTR</th>
                        <th className="p-3.5">Created Date</th>
                        <th className="p-3.5">Status</th>
                        <th className="p-3.5 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {clientInvoices.map(inv => (
                        <tr key={inv.id} className="hover:bg-slate-850/50">
                          <td className="p-3.5">
                            <span className="font-mono font-bold text-blue-400">{inv.invoiceNumber || inv.id}</span>
                          </td>
                          <td className="p-3.5 font-bold font-mono text-white">
                            {formatINR(inv.total, 2)}
                          </td>
                          <td className="p-3.5">
                            <div className="text-slate-300 font-medium">{inv.paymentMethod || inv.method || 'UPI / Manual'}</div>
                            {inv.utrNumber && (
                              <div className="text-[10px] font-mono text-emerald-400">UTR: {inv.utrNumber}</div>
                            )}
                          </td>
                          <td className="p-3.5 text-slate-400">
                            {inv.timestamp ? new Date(inv.timestamp).toLocaleDateString() : 'Recent'}
                          </td>
                          <td className="p-3.5">
                            <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-[11px] font-semibold ${
                              inv.status === 'Paid' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                              inv.status === 'Unpaid' || inv.status === 'pending' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                              'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                            }`}>
                              {inv.status}
                            </span>
                          </td>
                          <td className="p-3.5 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {inv.status !== 'Paid' && (
                                <button
                                  onClick={() => onVerifyInvoice(inv.id)}
                                  className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[11px] font-semibold transition-colors flex items-center gap-1 shadow-sm"
                                  title="Verify Payment and Activate Linked Service"
                                >
                                  <CheckCircle2 size={12} /> Mark Paid & Provision
                                </button>
                              )}
                              <button
                                onClick={() => onOpenInvoiceDoc(inv)}
                                className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] font-medium transition-colors"
                              >
                                View PDF
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: SUPPORT TICKETS */}
          {activeTab === 'tickets' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white">Support Desk Tickets ({clientTickets.length})</h3>
                  <p className="text-xs text-slate-400">All customer support conversations, inquiries, and billing requests.</p>
                </div>
              </div>

              {clientTickets.length === 0 ? (
                <div className="py-12 bg-slate-900/40 border border-slate-800 rounded-xl text-center text-xs text-slate-500">
                  <LifeBuoy size={28} className="mx-auto text-slate-600 mb-2" />
                  No tickets found for this client.
                </div>
              ) : (
                <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-900">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-800/60 text-[10px] uppercase font-semibold text-slate-400 tracking-wider">
                      <tr>
                        <th className="p-3.5">Ticket #</th>
                        <th className="p-3.5">Subject</th>
                        <th className="p-3.5">Department</th>
                        <th className="p-3.5">Status</th>
                        <th className="p-3.5 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {clientTickets.map(t => (
                        <tr key={t.id} className="hover:bg-slate-850/50">
                          <td className="p-3.5 font-mono font-bold text-blue-400">
                            #{t.ticketNumber || t.id.slice(0, 8)}
                          </td>
                          <td className="p-3.5">
                            <div className="font-semibold text-white">{t.subject}</div>
                            {t.lastMessage && (
                              <div className="text-[11px] text-slate-400 truncate max-w-xs">{t.lastMessage}</div>
                            )}
                          </td>
                          <td className="p-3.5 text-slate-300 capitalize">
                            {t.department || 'General'}
                          </td>
                          <td className="p-3.5">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                              t.status === 'open' ? 'bg-emerald-500/10 text-emerald-400' :
                              t.status === 'in_progress' ? 'bg-blue-500/10 text-blue-400' :
                              t.status === 'waiting_user' ? 'bg-amber-500/10 text-amber-400' :
                              t.status === 'resolved' ? 'bg-purple-500/10 text-purple-400' : 'bg-slate-800 text-slate-400'
                            }`}>
                              {t.status.replace('_', ' ')}
                            </span>
                          </td>
                          <td className="p-3.5 text-right">
                            <button
                              onClick={() => {
                                onNavigateToTicket(t.id);
                                onClose();
                              }}
                              className="px-2.5 py-1 bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 border border-blue-500/30 rounded text-[11px] font-medium transition-colors"
                            >
                              Open in Desk →
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* TAB 5: ACCOUNT ACTIONS */}
          {activeTab === 'actions' && (
            <div className="space-y-6">
              {/* Role Toggle Box */}
              <div className="p-5 bg-slate-900 border border-slate-800 rounded-xl space-y-3">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <Shield size={14} className="text-blue-400" /> Administrative Access & Role
                </h4>
                <p className="text-xs text-slate-400">
                  Current role is <strong className="text-white">{client.role === 'admin' ? 'Administrator' : 'Standard Client'}</strong>.
                  Promoting this user to Admin grants full access to the Hector control panel, billing system, and server daemons.
                </p>
                <button
                  onClick={() => onToggleUserRole(client.id, client.role)}
                  className={`px-4 py-2 rounded-lg text-xs font-semibold transition-colors flex items-center gap-2 ${
                    client.role === 'admin'
                      ? 'bg-amber-600/20 hover:bg-amber-600/30 text-amber-400 border border-amber-500/30'
                      : 'bg-blue-600 hover:bg-blue-500 text-white'
                  }`}
                >
                  <Shield size={14} />
                  {client.role === 'admin' ? 'Demote to Standard Client' : 'Promote to Administrator'}
                </button>
              </div>

              {/* Danger Zone */}
              <div className="p-5 bg-rose-950/20 border border-rose-900/40 rounded-xl space-y-3">
                <h4 className="text-xs font-bold text-rose-400 uppercase tracking-wider flex items-center gap-2">
                  <AlertTriangle size={14} /> Danger Zone: Delete Client Account
                </h4>
                <p className="text-xs text-slate-400">
                  Permanently deletes this client record from the database. Note: If the client has active hosting services or unpaid invoices, disassociate or terminate them first to prevent data orphans.
                </p>
                <button
                  onClick={() => onDeleteUser(client.id)}
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-2"
                >
                  <Trash2 size={14} />
                  Delete Client Account
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-900 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2 font-mono text-[11px]">
            <span>Hector Billing & Infrastructure Suite</span>
            <span>·</span>
            <span className="text-slate-500">Connected 360° Data Sync Active</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold transition-colors"
          >
            Close Summary
          </button>
        </div>
      </motion.div>
    </div>
  );
};
