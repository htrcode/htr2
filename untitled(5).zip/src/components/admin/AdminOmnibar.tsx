import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, User, CreditCard, Box, LifeBuoy, Layers, 
  ArrowRight, X, Sparkles, Command, Server, CheckCircle2 
} from 'lucide-react';
import { UserProfile, UserService, Invoice, Ticket, Plan } from '../../types';
import { formatINR } from '../../utils/formatUtils';

interface AdminOmnibarProps {
  isOpen: boolean;
  onClose: () => void;
  users: UserProfile[];
  services: UserService[];
  invoices: Invoice[];
  tickets: Ticket[];
  plans: Plan[];
  onSelectUser: (user: UserProfile) => void;
  onSelectInvoice: (invoice: Invoice) => void;
  onSelectService: (service: UserService) => void;
  onSelectTicket: (ticketId: string) => void;
  onSelectPlan: (plan: Plan) => void;
}

export const AdminOmnibar: React.FC<AdminOmnibarProps> = ({
  isOpen,
  onClose,
  users,
  services,
  invoices,
  tickets,
  plans,
  onSelectUser,
  onSelectInvoice,
  onSelectService,
  onSelectTicket,
  onSelectPlan
}) => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
    }
  }, [isOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const q = query.trim().toLowerCase();

  const matchingUsers = q ? users.filter(u => 
    (u.email && u.email.toLowerCase().includes(q)) ||
    (u.displayName && u.displayName.toLowerCase().includes(q)) ||
    (u.id && u.id.toLowerCase().includes(q))
  ).slice(0, 4) : [];

  const matchingInvoices = q ? invoices.filter(inv => 
    (inv.invoiceNumber && inv.invoiceNumber.toLowerCase().includes(q)) ||
    (inv.id && inv.id.toLowerCase().includes(q)) ||
    (inv.utrNumber && inv.utrNumber.toLowerCase().includes(q)) ||
    (inv.userId && inv.userId.toLowerCase().includes(q))
  ).slice(0, 4) : [];

  const matchingServices = q ? services.filter(s => 
    (s.name && s.name.toLowerCase().includes(q)) ||
    (s.id && s.id.toLowerCase().includes(q)) ||
    (s.ip && s.ip.toLowerCase().includes(q)) ||
    (s.nodeName && s.nodeName.toLowerCase().includes(q)) ||
    (s.userId && s.userId.toLowerCase().includes(q))
  ).slice(0, 4) : [];

  const matchingTickets = q ? tickets.filter(t => 
    (t.ticketNumber && t.ticketNumber.toLowerCase().includes(q)) ||
    (t.subject && t.subject.toLowerCase().includes(q)) ||
    (t.userEmail && t.userEmail.toLowerCase().includes(q)) ||
    (t.id && t.id.toLowerCase().includes(q))
  ).slice(0, 4) : [];

  const matchingPlans = q ? plans.filter(p => 
    (p.name && p.name.toLowerCase().includes(q)) ||
    (p.category && p.category.toLowerCase().includes(q)) ||
    (p.id && p.id.toLowerCase().includes(q))
  ).slice(0, 4) : [];

  const totalResults = 
    matchingUsers.length + 
    matchingInvoices.length + 
    matchingServices.length + 
    matchingTickets.length + 
    matchingPlans.length;

  return (
    <div className="fixed inset-0 z-[1300] flex items-start justify-center pt-20 px-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-2xl bg-[#0f172a] border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Search Input Bar */}
        <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center gap-3">
          <Search size={18} className="text-slate-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            placeholder="Search clients, invoices (#INV-), services, tickets (#TICK-), plans..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-transparent text-sm text-white placeholder-slate-500 outline-none"
          />
          {query && (
            <button onClick={() => setQuery('')} className="text-slate-500 hover:text-white p-1">
              <X size={16} />
            </button>
          )}
          <kbd className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-mono text-slate-400 bg-slate-800 border border-slate-700 rounded">
            ESC
          </kbd>
        </div>

        {/* Results Area */}
        <div className="max-h-[60vh] overflow-y-auto p-3 space-y-4">
          {!q ? (
            <div className="p-8 text-center text-slate-500 space-y-2">
              <p className="text-xs font-medium text-slate-400">Universal Billing & Infrastructure Search</p>
              <p className="text-[11px] text-slate-500">
                Type an invoice number (e.g. <span className="font-mono text-slate-400">INV-</span>), client email, service IP, or ticket ID.
              </p>
            </div>
          ) : totalResults === 0 ? (
            <div className="p-8 text-center text-slate-500 text-xs">
              No matching clients, invoices, services, or tickets found for "{query}".
            </div>
          ) : (
            <>
              {/* Clients */}
              {matchingUsers.length > 0 && (
                <div>
                  <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-3 mb-1.5 flex items-center gap-1.5">
                    <User size={12} className="text-blue-400" /> Clients & Users
                  </div>
                  <div className="space-y-1">
                    {matchingUsers.map(u => (
                      <button
                        key={u.id}
                        onClick={() => {
                          onSelectUser(u);
                          onClose();
                        }}
                        className="w-full p-2.5 rounded-lg hover:bg-slate-800/80 transition-colors flex items-center justify-between text-left group"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className="w-7 h-7 rounded-full bg-blue-500/20 text-blue-400 font-bold flex items-center justify-center text-xs shrink-0">
                            {(u.displayName || u.email)?.[0]?.toUpperCase() || 'U'}
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs font-semibold text-white truncate">{u.displayName || u.email}</p>
                            <p className="text-[10px] text-slate-400 font-mono truncate">{u.email} · {u.id}</p>
                          </div>
                        </div>
                        <span className="text-[11px] text-blue-400 font-medium group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                          View 360° Profile <ArrowRight size={12} />
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Invoices */}
              {matchingInvoices.length > 0 && (
                <div>
                  <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-3 mb-1.5 flex items-center gap-1.5">
                    <CreditCard size={12} className="text-emerald-400" /> Invoices
                  </div>
                  <div className="space-y-1">
                    {matchingInvoices.map(inv => (
                      <button
                        key={inv.id}
                        onClick={() => {
                          onSelectInvoice(inv);
                          onClose();
                        }}
                        className="w-full p-2.5 rounded-lg hover:bg-slate-800/80 transition-colors flex items-center justify-between text-left group"
                      >
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-white font-mono flex items-center gap-2">
                            <span>#{inv.invoiceNumber || inv.id}</span>
                            <span className="text-slate-400 font-sans font-normal truncate">({inv.userId})</span>
                          </p>
                          <p className="text-[10px] text-slate-400 mt-0.5">
                            {formatINR(inv.total, 2)} · {inv.status} {inv.utrNumber ? `· UTR: ${inv.utrNumber}` : ''}
                          </p>
                        </div>
                        <span className="text-[11px] text-emerald-400 font-medium group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                          Open Invoice <ArrowRight size={12} />
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Services */}
              {matchingServices.length > 0 && (
                <div>
                  <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-3 mb-1.5 flex items-center gap-1.5">
                    <Box size={12} className="text-indigo-400" /> Hosting Services
                  </div>
                  <div className="space-y-1">
                    {matchingServices.map(srv => (
                      <button
                        key={srv.id}
                        onClick={() => {
                          onSelectService(srv);
                          onClose();
                        }}
                        className="w-full p-2.5 rounded-lg hover:bg-slate-800/80 transition-colors flex items-center justify-between text-left group"
                      >
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-white flex items-center gap-2">
                            <Server size={13} className="text-indigo-400 shrink-0" />
                            <span className="truncate">{srv.name}</span>
                            <span className="text-[10px] font-mono text-slate-400">({srv.status})</span>
                          </p>
                          <p className="text-[10px] text-slate-400 font-mono mt-0.5 truncate">
                            IP: {srv.ip || 'Pending'} · Node: {srv.nodeName || 'Cluster-01'} · Client: {srv.userId}
                          </p>
                        </div>
                        <span className="text-[11px] text-indigo-400 font-medium group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                          Manage Service <ArrowRight size={12} />
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Tickets */}
              {matchingTickets.length > 0 && (
                <div>
                  <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-3 mb-1.5 flex items-center gap-1.5">
                    <LifeBuoy size={12} className="text-purple-400" /> Support Desk
                  </div>
                  <div className="space-y-1">
                    {matchingTickets.map(t => (
                      <button
                        key={t.id}
                        onClick={() => {
                          onSelectTicket(t.id);
                          onClose();
                        }}
                        className="w-full p-2.5 rounded-lg hover:bg-slate-800/80 transition-colors flex items-center justify-between text-left group"
                      >
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-white flex items-center gap-2">
                            <span className="font-mono text-purple-400">#{t.ticketNumber || t.id.slice(0, 8)}</span>
                            <span className="truncate">{t.subject}</span>
                          </p>
                          <p className="text-[10px] text-slate-400 mt-0.5 truncate">
                            From: {t.userEmail} · Status: {t.status}
                          </p>
                        </div>
                        <span className="text-[11px] text-purple-400 font-medium group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                          View Ticket <ArrowRight size={12} />
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Plans */}
              {matchingPlans.length > 0 && (
                <div>
                  <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-3 mb-1.5 flex items-center gap-1.5">
                    <Layers size={12} className="text-amber-400" /> Plans Catalog
                  </div>
                  <div className="space-y-1">
                    {matchingPlans.map(p => (
                      <button
                        key={p.id}
                        onClick={() => {
                          onSelectPlan(p);
                          onClose();
                        }}
                        className="w-full p-2.5 rounded-lg hover:bg-slate-800/80 transition-colors flex items-center justify-between text-left group"
                      >
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-white truncate">{p.name}</p>
                          <p className="text-[10px] text-slate-400 mt-0.5">
                            Category: {p.category} · Price: ₹{p.price_inr || p.price}/mo
                          </p>
                        </div>
                        <span className="text-[11px] text-amber-400 font-medium group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                          Edit Plan <ArrowRight size={12} />
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer shortcuts */}
        <div className="p-3 bg-slate-900 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span>Navigation:</span>
            <kbd className="px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-[10px] font-mono">↑↓</kbd>
            <kbd className="px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-[10px] font-mono">ENTER</kbd>
          </div>
          <div>Hector Omnibar · Real-time Indexing</div>
        </div>
      </div>
    </div>
  );
};
