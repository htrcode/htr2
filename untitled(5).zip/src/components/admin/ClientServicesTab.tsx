import React, { useState } from 'react';
import { 
  Box, Search, Plus, Edit3, Power, Trash2, 
  RefreshCw, Server, MapPin, ExternalLink, CheckCircle2, AlertTriangle
} from 'lucide-react';
import { UserService, UserProfile, Invoice } from '../../types';

interface ClientServicesTabProps {
  orders: UserService[];
  users: UserProfile[];
  invoices: Invoice[];
  onOpenCreateService: () => void;
  onOpenEditService: (service: UserService) => void;
  onOpenClientProfile: (userId: string) => void;
  onOpenInvoiceDoc: (invoice: Invoice) => void;
  onUpdateServiceStatus: (serviceId: string, status: UserService['status']) => Promise<void>;
  onDeleteService: (serviceId: string) => Promise<void>;
  actionLoading: string | null;
  onRefresh: () => void;
  isLoading: boolean;
}

export const ClientServicesTab: React.FC<ClientServicesTabProps> = ({
  orders,
  users,
  invoices,
  onOpenCreateService,
  onOpenEditService,
  onOpenClientProfile,
  onOpenInvoiceDoc,
  onUpdateServiceStatus,
  onDeleteService,
  actionLoading,
  onRefresh,
  isLoading
}) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'active' | 'pending' | 'suspended' | 'terminated'>('ALL');

  const filteredServices = orders.filter(srv => {
    const q = search.toLowerCase();
    const matchSearch = 
      (srv.name && srv.name.toLowerCase().includes(q)) ||
      (srv.id && srv.id.toLowerCase().includes(q)) ||
      (srv.userId && srv.userId.toLowerCase().includes(q)) ||
      (srv.ip && srv.ip.toLowerCase().includes(q)) ||
      (srv.nodeName && srv.nodeName.toLowerCase().includes(q)) ||
      (srv.location && srv.location.toLowerCase().includes(q));

    const matchStatus = statusFilter === 'ALL' || srv.status === statusFilter;
    return matchSearch && matchStatus;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner & Actions */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm">
        <div>
          <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
            <Box size={18} className="text-emerald-400" />
            Client Hosting Services & Deployments
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Paymenter-grade instance lifecycle management. Control server provisioning, suspension, IP allocations, and panel credentials.
          </p>
        </div>
        <div className="flex items-center gap-2.5">
          <button
            onClick={onOpenCreateService}
            className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <Plus size={14} />
            <span>Provision New Service</span>
          </button>
          <button
            onClick={onRefresh}
            disabled={isLoading}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded-lg transition-colors disabled:opacity-50"
            title="Refresh Services"
          >
            <RefreshCw size={14} className={isLoading ? 'animate-spin' : ''} />
          </button>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder="Search service, client, IP, node..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 outline-none focus:border-emerald-500"
          />
        </div>

        {/* Status Pills */}
        <div className="flex items-center gap-1.5 w-full sm:w-auto overflow-x-auto">
          {(['ALL', 'active', 'pending', 'suspended', 'terminated'] as const).map(st => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-colors whitespace-nowrap ${
                statusFilter === st
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {st === 'ALL' ? 'All Services' : st}
              {st !== 'ALL' && (
                <span className="ml-1.5 px-1.5 py-0.2 rounded-full text-[10px] bg-slate-800 text-slate-300 font-mono">
                  {orders.filter(o => o.status === st).length}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Services Table */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900/80 text-[10px] uppercase font-semibold text-slate-400 tracking-wider border-b border-slate-800">
              <tr>
                <th className="p-3.5">Service Details</th>
                <th className="p-3.5">Client User</th>
                <th className="p-3.5">Node & IP Allocation</th>
                <th className="p-3.5">Billing & Expiry</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5">Linked Invoice</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filteredServices.map(srv => {
                const linkedInv = srv.invoiceId ? invoices.find(i => i.id === srv.invoiceId) : null;
                return (
                  <tr key={srv.id} className="hover:bg-slate-850/40 transition-colors">
                    <td className="p-3.5">
                      <div className="font-semibold text-white flex items-center gap-1.5">
                        <Server size={14} className="text-blue-400 shrink-0" />
                        <span>{srv.name}</span>
                      </div>
                      <div className="text-[10px] text-slate-500 font-mono mt-0.5">ID: {srv.id}</div>
                    </td>
                    <td className="p-3.5">
                      <button
                        onClick={() => onOpenClientProfile(srv.userId)}
                        className="text-slate-200 hover:text-blue-400 font-medium text-left truncate max-w-[150px] block"
                        title="Click to view Client 360° Profile"
                      >
                        {srv.userId}
                      </button>
                    </td>
                    <td className="p-3.5">
                      <div className="font-mono text-emerald-400 text-[11px] font-semibold">
                        {srv.ip || 'Unallocated IP'}
                      </div>
                      <div className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
                        <MapPin size={10} className="text-slate-500" />
                        <span>{srv.nodeName || 'Node-01'} · {srv.location || 'Mumbai'}</span>
                      </div>
                    </td>
                    <td className="p-3.5">
                      <div className="text-white font-medium">₹{srv.price || 0}/mo</div>
                      <div className="text-[10px] text-slate-500">
                        Expires: {srv.expiresAt ? new Date(srv.expiresAt).toLocaleDateString() : 'Auto-renew'}
                      </div>
                    </td>
                    <td className="p-3.5">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-[11px] font-semibold capitalize ${
                        srv.status === 'active' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                        srv.status === 'pending' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                        srv.status === 'suspended' ? 'bg-orange-500/10 text-orange-400 border border-orange-500/20' :
                        'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                      }`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${
                          srv.status === 'active' ? 'bg-emerald-400' :
                          srv.status === 'pending' ? 'bg-amber-400 animate-pulse' :
                          srv.status === 'suspended' ? 'bg-orange-400' : 'bg-rose-400'
                        }`} />
                        {srv.status}
                      </span>
                    </td>
                    <td className="p-3.5">
                      {linkedInv ? (
                        <button
                          onClick={() => onOpenInvoiceDoc(linkedInv)}
                          className="font-mono text-blue-400 hover:underline text-[11px] flex items-center gap-1"
                          title="View Linked Invoice"
                        >
                          <span>#{linkedInv.invoiceNumber || linkedInv.id}</span>
                          <ExternalLink size={10} />
                        </button>
                      ) : (
                        <span className="text-[11px] text-slate-500">Manual / Legacy</span>
                      )}
                    </td>
                    <td className="p-3.5 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => onOpenEditService(srv)}
                          className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] font-medium transition-colors flex items-center gap-1"
                          title="Manage IP, Port and Credentials"
                        >
                          <Edit3 size={11} /> Credentials
                        </button>
                        {srv.status === 'active' ? (
                          <button
                            onClick={() => onUpdateServiceStatus(srv.id, 'suspended')}
                            disabled={actionLoading === srv.id}
                            className="px-2 py-1 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded text-[11px] font-medium transition-colors"
                            title="Suspend Server Instance"
                          >
                            Suspend
                          </button>
                        ) : (
                          <button
                            onClick={() => onUpdateServiceStatus(srv.id, 'active')}
                            disabled={actionLoading === srv.id}
                            className="px-2 py-1 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded text-[11px] font-medium transition-colors"
                            title="Activate Server Instance"
                          >
                            Activate
                          </button>
                        )}
                        <button
                          onClick={() => onDeleteService(srv.id)}
                          disabled={actionLoading === srv.id}
                          className="p-1 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded transition-colors"
                          title="Terminate & Delete Service"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {filteredServices.length === 0 && (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-xs text-slate-500">
                    No active hosting services found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
