import React, { useState } from 'react';
import { 
  Globe, Megaphone, Mail, QrCode, AlertTriangle, 
  Save, CheckCircle2, PhoneCall, ShieldAlert, Check
} from 'lucide-react';
import { Settings as SiteSettings, AppData } from '../../types';
import { dataService } from '../../services/dataService';
import { logService } from '../../services/logService';

interface BrandSettingsTabProps {
  data: AppData;
  setData: (data: AppData) => void;
  localData: AppData;
  setLocalData: React.Dispatch<React.SetStateAction<AppData>>;
  onShowToast: (msg: string, type?: 'success' | 'info' | 'error') => void;
}

export const BrandSettingsTab: React.FC<BrandSettingsTabProps> = ({
  data,
  setData,
  localData,
  setLocalData,
  onShowToast
}) => {
  const [savingSection, setSavingSection] = useState<string | null>(null);

  const savePartialSettings = async (sectionName: string, partial: Partial<SiteSettings>) => {
    setSavingSection(sectionName);
    try {
      await dataService.updateSettings({
        settings: {
          ...localData.settings,
          ...partial
        }
      });
      const updatedSettings = { ...localData.settings, ...partial };
      setLocalData(prev => ({ ...prev, settings: updatedSettings }));
      setData({ ...data, settings: updatedSettings });
      logService.addLog('success', `Saved ${sectionName} to Firestore.`);
      onShowToast(`${sectionName} saved successfully!`, 'success');
    } catch (err: any) {
      console.error(err);
      onShowToast(`Failed to save: ${err.message}`, 'error');
    } finally {
      setSavingSection(null);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* 1. Identity & Branding */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Globe size={15} className="text-blue-400" /> Site Identity & Brand Metadata
          </h3>
          <button
            onClick={() => savePartialSettings('Brand Identity', {
              site_name: localData.settings.site_name,
              brand_name: localData.settings.brand_name,
              tagline: localData.settings.tagline
            })}
            disabled={savingSection === 'Brand Identity'}
            className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-sm"
          >
            {savingSection === 'Brand Identity' ? (
              <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <Save size={13} />
            )}
            <span>Save Brand</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="text-[11px] font-semibold text-slate-300 block mb-1.5">Site Name</label>
            <input
              type="text"
              value={localData.settings.site_name || ''}
              onChange={(e) => setLocalData(prev => ({
                ...prev,
                settings: { ...prev.settings, site_name: e.target.value }
              }))}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white outline-none focus:border-blue-500"
              placeholder="e.g. HectorHosting"
            />
          </div>
          <div>
            <label className="text-[11px] font-semibold text-slate-300 block mb-1.5">Header Brand Text</label>
            <input
              type="text"
              value={localData.settings.brand_name || ''}
              onChange={(e) => setLocalData(prev => ({
                ...prev,
                settings: { ...prev.settings, brand_name: e.target.value }
              }))}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white outline-none focus:border-blue-500"
              placeholder="e.g. HectorHosting"
            />
          </div>
          <div className="sm:col-span-2">
            <label className="text-[11px] font-semibold text-slate-300 block mb-1.5">Hero Tagline</label>
            <input
              type="text"
              value={localData.settings.tagline || ''}
              onChange={(e) => setLocalData(prev => ({
                ...prev,
                settings: { ...prev.settings, tagline: e.target.value }
              }))}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white outline-none focus:border-blue-500"
              placeholder="e.g. High Performance Game Servers & Cloud Infrastructure"
            />
          </div>
        </div>
      </div>

      {/* 2. Announcement Alert Banner */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Megaphone size={15} className="text-amber-400" /> Announcement Alert Banner
          </h3>
          <button
            onClick={() => savePartialSettings('Announcement Banner', {
              show_announcement: localData.settings.show_announcement,
              announcement_text: localData.settings.announcement_text
            })}
            disabled={savingSection === 'Announcement Banner'}
            className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-sm"
          >
            {savingSection === 'Announcement Banner' ? (
              <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <Save size={13} />
            )}
            <span>Save Banner</span>
          </button>
        </div>

        <div className="space-y-3">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={localData.settings.show_announcement ?? true}
              onChange={(e) => setLocalData(prev => ({
                ...prev,
                settings: { ...prev.settings, show_announcement: e.target.checked }
              }))}
              className="w-4 h-4 rounded border-slate-700 bg-slate-900 text-blue-600 focus:ring-blue-500"
            />
            <span className="text-xs text-slate-300 font-medium">Display Announcement Banner at Top of Public Site</span>
          </label>
          <div>
            <label className="text-[11px] font-semibold text-slate-300 block mb-1.5">Banner Text</label>
            <input
              type="text"
              value={localData.settings.announcement_text || ''}
              onChange={(e) => setLocalData(prev => ({
                ...prev,
                settings: { ...prev.settings, announcement_text: e.target.value }
              }))}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white outline-none focus:border-blue-500"
              placeholder="e.g. ⚡ Limited Time: 20% OFF all Ryzen VPS Hosting with promo code HECTOR20"
            />
          </div>
        </div>
      </div>

      {/* 3. Contact & WhatsApp Notification Template */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <PhoneCall size={15} className="text-emerald-400" /> Contact & WhatsApp Dispatch
          </h3>
          <button
            onClick={() => savePartialSettings('Contact Details', {
              support_email: localData.settings.support_email,
              whatsapp_number: localData.settings.whatsapp_number,
              whatsapp_message: localData.settings.whatsapp_message,
              discord_url: localData.settings.discord_url
            })}
            disabled={savingSection === 'Contact Details'}
            className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-sm"
          >
            {savingSection === 'Contact Details' ? (
              <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <Save size={13} />
            )}
            <span>Save Contact</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="text-[11px] font-semibold text-slate-300 block mb-1.5">Official Support Email</label>
            <input
              type="email"
              value={localData.settings.support_email || ''}
              onChange={(e) => setLocalData(prev => ({
                ...prev,
                settings: { ...prev.settings, support_email: e.target.value }
              }))}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white font-mono outline-none focus:border-blue-500"
              placeholder="support@hectorhosting.com"
            />
          </div>
          <div>
            <label className="text-[11px] font-semibold text-slate-300 block mb-1.5">WhatsApp Number (e.g. 919876543210)</label>
            <input
              type="text"
              value={localData.settings.whatsapp_number || ''}
              onChange={(e) => setLocalData(prev => ({
                ...prev,
                settings: { ...prev.settings, whatsapp_number: e.target.value }
              }))}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white font-mono outline-none focus:border-blue-500"
              placeholder="919876543210"
            />
          </div>
          <div className="sm:col-span-2">
            <label className="text-[11px] font-semibold text-slate-300 block mb-1.5">Community Discord Invite URL</label>
            <input
              type="text"
              value={localData.settings.discord_url || ''}
              onChange={(e) => setLocalData(prev => ({
                ...prev,
                settings: { ...prev.settings, discord_url: e.target.value }
              }))}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white font-mono outline-none focus:border-blue-500"
              placeholder="https://discord.gg/hectorhosting"
            />
          </div>
          <div className="sm:col-span-2">
            <label className="text-[11px] font-semibold text-slate-300 block mb-1.5">WhatsApp Order Message Template</label>
            <textarea
              rows={2}
              value={localData.settings.whatsapp_message || ''}
              onChange={(e) => setLocalData(prev => ({
                ...prev,
                settings: { ...prev.settings, whatsapp_message: e.target.value }
              }))}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white outline-none focus:border-blue-500"
              placeholder="Hi HectorHosting team! I just made a payment via UPI for my order..."
            />
          </div>
        </div>
      </div>

      {/* 4. UPI Payment Gateway */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <QrCode size={15} className="text-indigo-400" /> UPI Merchant Payment Gateway
          </h3>
          <button
            onClick={() => savePartialSettings('UPI Gateway', {
              upi_id: localData.settings.upi_id,
              payment_instructions: localData.settings.payment_instructions
            })}
            disabled={savingSection === 'UPI Gateway'}
            className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-sm"
          >
            {savingSection === 'UPI Gateway' ? (
              <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <Save size={13} />
            )}
            <span>Save UPI Gateway</span>
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="text-[11px] font-semibold text-slate-300 block mb-1.5">Primary Merchant UPI ID (VPA)</label>
            <input
              type="text"
              value={localData.settings.upi_id || ''}
              onChange={(e) => setLocalData(prev => ({
                ...prev,
                settings: { ...prev.settings, upi_id: e.target.value }
              }))}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white font-mono outline-none focus:border-blue-500 font-bold"
              placeholder="e.g. yourbusiness@okicici or 9876543210@paytm"
            />
            <p className="text-[11px] text-slate-500 mt-1">This UPI ID is encoded into dynamic QR codes on checkout and invoices.</p>
          </div>
          <div>
            <label className="text-[11px] font-semibold text-slate-300 block mb-1.5">Payment Instructions for Client Checkout</label>
            <textarea
              rows={2}
              value={localData.settings.payment_instructions || ''}
              onChange={(e) => setLocalData(prev => ({
                ...prev,
                settings: { ...prev.settings, payment_instructions: e.target.value }
              }))}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white outline-none focus:border-blue-500"
              placeholder="Scan QR code using GPay, PhonePe, or Paytm. Submit the 12-digit UTR transaction reference for instant provisioning."
            />
          </div>
        </div>
      </div>

      {/* 5. Emergency Maintenance Mode */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-xs font-bold text-rose-400 uppercase tracking-wider flex items-center gap-2">
            <AlertTriangle size={15} /> Emergency Maintenance Mode
          </h3>
          <button
            onClick={() => savePartialSettings('Maintenance Mode', {
              maintenance_mode: localData.settings.maintenance_mode,
              maintenance_message: localData.settings.maintenance_message
            })}
            disabled={savingSection === 'Maintenance Mode'}
            className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-sm"
          >
            {savingSection === 'Maintenance Mode' ? (
              <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <Save size={13} />
            )}
            <span>Update Maintenance</span>
          </button>
        </div>

        <div className="space-y-3">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={localData.settings.maintenance_mode ?? false}
              onChange={(e) => setLocalData(prev => ({
                ...prev,
                settings: { ...prev.settings, maintenance_mode: e.target.checked }
              }))}
              className="w-4 h-4 rounded border-rose-900 bg-slate-900 text-rose-600 focus:ring-rose-500"
            />
            <span className="text-xs text-slate-200 font-semibold">Enable Global Storefront Maintenance Screen</span>
          </label>
          <div>
            <label className="text-[11px] font-semibold text-slate-300 block mb-1.5">Maintenance Notice Message</label>
            <input
              type="text"
              value={localData.settings.maintenance_message || ''}
              onChange={(e) => setLocalData(prev => ({
                ...prev,
                settings: { ...prev.settings, maintenance_message: e.target.value }
              }))}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white outline-none focus:border-rose-500"
              placeholder="Our platform is currently undergoing scheduled hardware upgrades. We will be back online shortly."
            />
          </div>
        </div>
      </div>
    </div>
  );
};
