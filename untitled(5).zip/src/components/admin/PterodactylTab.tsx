import React, { useState, useEffect } from 'react';
import { 
  Server, 
  Users, 
  Cpu, 
  HardDrive, 
  ExternalLink, 
  RefreshCw, 
  CheckCircle2, 
  AlertCircle, 
  Search, 
  ShieldCheck, 
  UserPlus, 
  Activity, 
  Zap,
  Globe,
  Radio
} from 'lucide-react';
import { motion } from 'motion/react';
import { pterodactylService, PterodactylStatusResponse } from '../../services/pterodactylService';
import { PterodactylUser, PterodactylServer, PterodactylNode, UserProfile } from '../../types';
import { adminService } from '../../services/adminService';

export const PterodactylTab: React.FC = () => {
  const [status, setStatus] = useState<PterodactylStatusResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [syncingAll, setSyncingAll] = useState(false);
  const [syncResult, setSyncResult] = useState<string | null>(null);

  const [activeSubView, setActiveSubView] = useState<'nodes' | 'servers' | 'users'>('nodes');
  const [nodes, setNodes] = useState<PterodactylNode[]>([]);
  const [servers, setServers] = useState<PterodactylServer[]>([]);
  const [pteroUsers, setPteroUsers] = useState<PterodactylUser[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  // Quick User Create Modal
  const [isCreateUserOpen, setIsCreateUserOpen] = useState(false);
  const [newEmail, setNewEmail] = useState('');
  const [newName, setNewName] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [creatingUser, setCreatingUser] = useState(false);
  const [createError, setCreateError] = useState<string | null>(null);
  const [createSuccess, setCreateSuccess] = useState<string | null>(null);

  const fetchPanelData = async () => {
    setLoading(true);
    try {
      const [statusRes, nodesRes, serversRes, usersRes] = await Promise.allSettled([
        pterodactylService.getStatus(),
        pterodactylService.getNodes(),
        pterodactylService.getServers(1, 100),
        pterodactylService.getUsers(1, 100)
      ]);

      if (statusRes.status === 'fulfilled') setStatus(statusRes.value);
      if (nodesRes.status === 'fulfilled') setNodes(nodesRes.value);
      if (serversRes.status === 'fulfilled') setServers(serversRes.value.servers || []);
      if (usersRes.status === 'fulfilled') setPteroUsers(usersRes.value.users || []);
    } catch (err) {
      console.error('Error fetching Pterodactyl panel data:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchPanelData();
  }, []);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchPanelData();
  };

  const handleSyncAllUsers = async () => {
    setSyncingAll(true);
    setSyncResult(null);
    try {
      const registeredUsers = await adminService.getAllUsers();
      let syncedCount = 0;
      let alreadyCount = 0;

      for (const u of registeredUsers) {
        if (u.email) {
          const res = await pterodactylService.createOrLinkUser({
            email: u.email,
            name: u.displayName,
            firebaseUid: u.id
          });
          if (res.success) {
            if (res.alreadyExisted) alreadyCount++;
            else syncedCount++;
          }
        }
      }

      setSyncResult(`Sync complete: ${syncedCount} new accounts created, ${alreadyCount} existing accounts linked.`);
      fetchPanelData();
    } catch (err: any) {
      setSyncResult(`Sync failed: ${err.message}`);
    } finally {
      setSyncingAll(false);
    }
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreatingUser(true);
    setCreateError(null);
    setCreateSuccess(null);

    try {
      const res = await pterodactylService.createOrLinkUser({
        email: newEmail.trim(),
        name: newName.trim(),
        password: newPassword.trim() || undefined
      });

      if (!res.success) {
        throw new Error(res.error || 'Failed to create Pterodactyl user');
      }

      setCreateSuccess(`Pterodactyl user @${res.user.username} successfully ${res.alreadyExisted ? 'linked' : 'created'}!`);
      setNewEmail('');
      setNewName('');
      setNewPassword('');
      fetchPanelData();
    } catch (err: any) {
      setCreateError(err.message || 'Creation failed');
    } finally {
      setCreatingUser(false);
    }
  };

  const filteredNodes = nodes.filter(n => 
    n.name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
    n.fqdn?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredServers = servers.filter(s => 
    s.name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
    s.identifier?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.uuid?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredUsers = pteroUsers.filter(u => 
    u.email?.toLowerCase().includes(searchTerm.toLowerCase()) || 
    u.username?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    `${u.first_name} ${u.last_name}`.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const panelUrl = status?.panelUrl || 'https://gp.hector.host';

  return (
    <div className="space-y-8">
      {/* Header Banner */}
      <div className="p-6 bg-gradient-to-r from-bg-alt via-accent/5 to-bg-alt border border-border rounded-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-accent/10 border border-accent/20 flex items-center justify-center text-accent">
            <Radio size={24} className={status?.connected ? 'animate-pulse text-emerald-400' : 'text-amber-400'} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-black uppercase tracking-wider text-foreground">Pterodactyl Game Panel API</h3>
              {status?.connected ? (
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[9px] font-black uppercase tracking-widest flex items-center gap-1">
                  <CheckCircle2 size={10} /> Online
                </span>
              ) : (
                <span className="px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-[9px] font-black uppercase tracking-widest flex items-center gap-1">
                  <AlertCircle size={10} /> Connecting
                </span>
              )}
            </div>
            <p className="text-xs text-foreground-dim mt-0.5">
              Live Application API endpoint connected to <span className="text-accent font-semibold">{panelUrl}</span>
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          <button
            onClick={handleRefresh}
            disabled={refreshing}
            className="px-4 py-2 bg-bg border border-border hover:border-accent/40 rounded-xl text-xs font-bold text-foreground hover:text-accent transition-all flex items-center gap-2 disabled:opacity-50"
          >
            <RefreshCw size={14} className={refreshing ? 'animate-spin' : ''} />
            Refresh
          </button>

          <button
            onClick={handleSyncAllUsers}
            disabled={syncingAll}
            className="px-4 py-2 bg-accent hover:bg-accent-muted text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-2 shadow-lg shadow-accent/20 disabled:opacity-50"
          >
            <Users size={14} />
            {syncingAll ? 'Syncing Users...' : 'Sync All Users'}
          </button>

          <a
            href={panelUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-4 py-2 bg-foreground text-bg hover:bg-emerald-500 hover:text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-2"
          >
            Open Panel <ExternalLink size={14} />
          </a>
        </div>
      </div>

      {syncResult && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 bg-accent/10 border border-accent/20 rounded-xl text-accent text-xs font-bold flex items-center justify-between"
        >
          <span>{syncResult}</span>
          <button onClick={() => setSyncResult(null)} className="text-foreground-dim hover:text-foreground">✕</button>
        </motion.div>
      )}

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 bg-bg-alt border border-border rounded-xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[10px] font-black uppercase tracking-widest text-foreground-dim">Panel Users</span>
            <Users size={16} className="text-accent" />
          </div>
          <div className="text-2xl font-black text-foreground">
            {status?.stats.totalUsers ?? pteroUsers.length}
          </div>
          <div className="text-[10px] text-foreground-dim mt-1">Synchronized accounts</div>
        </div>

        <div className="p-5 bg-bg-alt border border-border rounded-xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[10px] font-black uppercase tracking-widest text-foreground-dim">Game Servers</span>
            <Server size={16} className="text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-foreground">
            {status?.stats.totalServers ?? servers.length}
          </div>
          <div className="text-[10px] text-foreground-dim mt-1">Active deployed instances</div>
        </div>

        <div className="p-5 bg-bg-alt border border-border rounded-xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[10px] font-black uppercase tracking-widest text-foreground-dim">Cluster Nodes</span>
            <Activity size={16} className="text-sky-400" />
          </div>
          <div className="text-2xl font-black text-foreground">
            {status?.stats.totalNodes ?? nodes.length}
          </div>
          <div className="text-[10px] text-foreground-dim mt-1">Hosting infrastructure nodes</div>
        </div>

        <div className="p-5 bg-bg-alt border border-border rounded-xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[10px] font-black uppercase tracking-widest text-foreground-dim">API Latency</span>
            <Zap size={16} className="text-amber-400" />
          </div>
          <div className="text-2xl font-black text-foreground">
            {status?.latency || 'Connected'}
          </div>
          <div className="text-[10px] text-foreground-dim mt-1">Rest API response time</div>
        </div>
      </div>

      {/* Sub Views Navigation & Search */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
        <div className="flex p-1 bg-bg-alt border border-border rounded-xl w-fit">
          <button
            onClick={() => setActiveSubView('nodes')}
            className={`px-5 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest flex items-center gap-2 transition-all ${
              activeSubView === 'nodes' ? 'bg-accent text-white shadow-sm' : 'text-foreground-dim hover:text-foreground'
            }`}
          >
            <Activity size={12} /> Nodes ({nodes.length})
          </button>
          <button
            onClick={() => setActiveSubView('servers')}
            className={`px-5 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest flex items-center gap-2 transition-all ${
              activeSubView === 'servers' ? 'bg-accent text-white shadow-sm' : 'text-foreground-dim hover:text-foreground'
            }`}
          >
            <Server size={12} /> Servers ({servers.length})
          </button>
          <button
            onClick={() => setActiveSubView('users')}
            className={`px-5 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest flex items-center gap-2 transition-all ${
              activeSubView === 'users' ? 'bg-accent text-white shadow-sm' : 'text-foreground-dim hover:text-foreground'
            }`}
          >
            <Users size={12} /> Users ({pteroUsers.length})
          </button>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative flex-1 sm:w-64">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-foreground-dim" />
            <input
              type="text"
              placeholder={`Search ${activeSubView}...`}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-bg-alt border border-border rounded-xl text-xs text-foreground focus:outline-none focus:border-accent"
            />
          </div>

          {activeSubView === 'users' && (
            <button
              onClick={() => setIsCreateUserOpen(true)}
              className="px-3 py-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition-all shrink-0"
            >
              <UserPlus size={14} /> Add User
            </button>
          )}
        </div>
      </div>

      {/* Content Tables */}
      <div className="bg-bg-alt border border-border rounded-2xl overflow-hidden shadow-sm">
        {loading ? (
          <div className="p-12 text-center text-foreground-dim text-xs">
            <RefreshCw size={24} className="animate-spin mx-auto mb-3 text-accent" />
            Connecting to Pterodactyl API...
          </div>
        ) : activeSubView === 'nodes' ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-bg border-b border-border text-[9px] font-black uppercase tracking-widest text-foreground-dim">
                <tr>
                  <th className="p-4">ID</th>
                  <th className="p-4">Node Name</th>
                  <th className="p-4">FQDN / Host</th>
                  <th className="p-4">Memory Limit</th>
                  <th className="p-4">Disk Limit</th>
                  <th className="p-4">Daemon Ports</th>
                  <th className="p-4 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filteredNodes.length > 0 ? (
                  filteredNodes.map((node) => (
                    <tr key={node.id} className="hover:bg-bg/50 transition-colors">
                      <td className="p-4 font-mono font-bold text-foreground-dim">#{node.id}</td>
                      <td className="p-4 font-bold text-foreground flex items-center gap-2">
                        <Server size={14} className="text-accent" />
                        {node.name}
                      </td>
                      <td className="p-4 font-mono text-foreground-dim">{node.fqdn} ({node.scheme})</td>
                      <td className="p-4 font-mono">{node.memory ? `${(node.memory / 1024).toFixed(1)} GB` : 'Unlimited'}</td>
                      <td className="p-4 font-mono">{node.disk ? `${(node.disk / 1024).toFixed(1)} GB` : 'Unlimited'}</td>
                      <td className="p-4 font-mono text-foreground-dim">HTTP: {node.daemon_listen} | SFTP: {node.daemon_sftp}</td>
                      <td className="p-4 text-right">
                        {node.maintenance_mode ? (
                          <span className="px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 font-black text-[9px] uppercase tracking-wider">
                            Maintenance
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 font-black text-[9px] uppercase tracking-wider">
                            Active
                          </span>
                        )}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-foreground-dim">
                      No nodes found matching your query.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        ) : activeSubView === 'servers' ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-bg border-b border-border text-[9px] font-black uppercase tracking-widest text-foreground-dim">
                <tr>
                  <th className="p-4">Server</th>
                  <th className="p-4">Identifier</th>
                  <th className="p-4">User ID</th>
                  <th className="p-4">RAM / CPU Limits</th>
                  <th className="p-4">Disk Limit</th>
                  <th className="p-4 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filteredServers.length > 0 ? (
                  filteredServers.map((server) => (
                    <tr key={server.id} className="hover:bg-bg/50 transition-colors">
                      <td className="p-4">
                        <div className="font-bold text-foreground">{server.name}</div>
                        <div className="text-[10px] text-foreground-dim font-mono">{server.uuid}</div>
                      </td>
                      <td className="p-4 font-mono text-accent font-bold">{server.identifier}</td>
                      <td className="p-4 font-mono text-foreground-dim">User #{server.user}</td>
                      <td className="p-4 font-mono text-foreground">
                        {server.limits?.memory ? `${(server.limits.memory / 1024).toFixed(1)} GB` : '0'} / {server.limits?.cpu ?? 100}% CPU
                      </td>
                      <td className="p-4 font-mono text-foreground-dim">
                        {server.limits?.disk ? `${(server.limits.disk / 1024).toFixed(1)} GB` : '0'}
                      </td>
                      <td className="p-4 text-right">
                        {server.suspended ? (
                          <span className="px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-400 font-black text-[9px] uppercase tracking-wider">
                            Suspended
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 font-black text-[9px] uppercase tracking-wider">
                            Running
                          </span>
                        )}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="p-8 text-center text-foreground-dim">
                      No game servers found on panel.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-bg border-b border-border text-[9px] font-black uppercase tracking-widest text-foreground-dim">
                <tr>
                  <th className="p-4">ID</th>
                  <th className="p-4">Username</th>
                  <th className="p-4">Email</th>
                  <th className="p-4">Name</th>
                  <th className="p-4">2FA</th>
                  <th className="p-4">Role</th>
                  <th className="p-4 text-right">Created</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filteredUsers.length > 0 ? (
                  filteredUsers.map((user) => (
                    <tr key={user.id} className="hover:bg-bg/50 transition-colors">
                      <td className="p-4 font-mono font-bold text-foreground-dim">#{user.id}</td>
                      <td className="p-4 font-bold text-accent">@{user.username}</td>
                      <td className="p-4 text-foreground">{user.email}</td>
                      <td className="p-4 text-foreground-dim">{user.first_name} {user.last_name}</td>
                      <td className="p-4">
                        {user['2fa'] ? (
                          <span className="text-emerald-400 font-bold">Enabled</span>
                        ) : (
                          <span className="text-foreground-dim">Disabled</span>
                        )}
                      </td>
                      <td className="p-4">
                        {user.root_admin ? (
                          <span className="px-2 py-0.5 rounded-full bg-accent/10 text-accent font-black text-[9px] uppercase tracking-wider">
                            Admin
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full bg-border text-foreground-dim font-black text-[9px] uppercase tracking-wider">
                            Client
                          </span>
                        )}
                      </td>
                      <td className="p-4 text-right text-foreground-dim font-mono text-[10px]">
                        {new Date(user.created_at).toLocaleDateString()}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-foreground-dim">
                      No Pterodactyl users found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Manual Create User Modal */}
      {isCreateUserOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-md bg-bg-alt border border-border rounded-2xl p-6 shadow-2xl space-y-5"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black uppercase tracking-wider text-foreground flex items-center gap-2">
                <UserPlus size={16} className="text-accent" /> Create Pterodactyl User
              </h3>
              <button onClick={() => setIsCreateUserOpen(false)} className="text-foreground-dim hover:text-foreground">✕</button>
            </div>

            {createError && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl text-rose-400 text-xs font-bold">
                {createError}
              </div>
            )}

            {createSuccess && (
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-emerald-400 text-xs font-bold">
                {createSuccess}
              </div>
            )}

            <form onSubmit={handleCreateUser} className="space-y-4">
              <div>
                <label className="block text-[10px] font-black uppercase tracking-widest text-foreground-dim mb-1">
                  Email Address *
                </label>
                <input
                  type="email"
                  required
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  placeholder="client@example.com"
                  className="w-full px-3 py-2 bg-bg border border-border rounded-xl text-xs text-foreground focus:outline-none focus:border-accent"
                />
              </div>

              <div>
                <label className="block text-[10px] font-black uppercase tracking-widest text-foreground-dim mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="John Doe"
                  className="w-full px-3 py-2 bg-bg border border-border rounded-xl text-xs text-foreground focus:outline-none focus:border-accent"
                />
              </div>

              <div>
                <label className="block text-[10px] font-black uppercase tracking-widest text-foreground-dim mb-1">
                  Password (Optional - auto-generated if blank)
                </label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Secure password"
                  className="w-full px-3 py-2 bg-bg border border-border rounded-xl text-xs text-foreground focus:outline-none focus:border-accent"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setIsCreateUserOpen(false)}
                  className="px-4 py-2 text-xs font-bold text-foreground-dim hover:text-foreground"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={creatingUser}
                  className="px-5 py-2 bg-accent hover:bg-accent-muted text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all disabled:opacity-50"
                >
                  {creatingUser ? 'Creating...' : 'Create Account'}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
};
