import React from 'react';
import { 
  CreditCard, Box, Users, LifeBuoy, AlertCircle, CheckCircle2, 
  ArrowRight, Clock, Plus, ExternalLink, ShieldCheck, Activity,
  Server, RefreshCw, Zap
} from 'lucide-react';
import { Invoice, UserService, UserProfile, Ticket, Plan, AppData } from '../../types';
import { parseAmount, formatINR } from '../../utils/formatUtils';

interface DashboardTabProps {
  invoices: Invoice[];
  services: UserService[];
  users: UserProfile[];
  tickets: Ticket[];
  plans: Plan[];
  data: AppData;
  onNavigateTab: (tab: any) => void;
  onOpenCreateInvoice: () => void;
  onOpenCreateService: () => void;
  onOpenCreatePlan: () => void;
  onOpenClientProfile: (userId: string) => void;
  onVerifyInvoiceAndProvision: (invoiceId: string) => Promise<void>;
  actionLoading: string | null;
  onRefresh: () => void;
  isLoading: boolean;
}

export const DashboardTab: React.FC<DashboardTabProps> = ({
  invoices,
  services,
  users,
  tickets,
  plans,
  data,
  onNavigateTab,
  onOpenCreateInvoice,
  onOpenCreateService,
  onOpenCreatePlan,
  onOpenClientProfile,
  onVerifyInvoiceAndProvision,
  actionLoading,
  onRefresh,
  isLoading
}) => {
  // Financial computations
  const totalInvoiced = invoices.reduce((sum, inv) => sum + parseAmount(inv.total), 0);
  const totalCollected = invoices
    .filter(inv => inv.status === 'Paid')
    .reduce((sum, inv) => sum + parseAmount(inv.total), 0);
  
  const pendingInvoices = invoices.filter(inv => 
    inv.status === 'Unpaid' || inv.status === 'pending' || inv.status === 'UPI_PENDING_VERIFICATION'
  );
  const totalUnpaid = pendingInvoices.reduce((sum, inv) => sum + parseAmount(inv.total), 0);

  const activeServices = services.filter(s => s.status === 'active');
  const pendingServices = services.filter(s => s.status === 'pending');
  const openTickets = tickets.filter(t => t.status === 'open' || t.status === 'in_progress' || t.status === 'waiting_user');

  return (
    <div className="space-y-6">
      {/* WHMCS Top KPI Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Collected */}
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium mb-2">
            <span>Total Collected (Paid)</span>
            <span className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400">
              <CreditCard size={15} />
            </span>
          </div>
          <div className="text-2xl font-bold text-white font-mono tracking-tight">
            ₹{totalCollected.toLocaleString('en-IN')}
          </div>
          <div className="text-[11px] text-slate-400 mt-2 flex items-center gap-1.5">
            <span className="text-emerald-400 font-semibold">{invoices.filter(i => i.status === 'Paid').length} paid</span>
            <span>of {invoices.length} total invoices</span>
          </div>
        </div>

        {/* Unpaid Receivables */}
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium mb-2">
            <span>Outstanding Invoices</span>
            <span className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400">
              <Clock size={15} />
            </span>
          </div>
          <div className={`text-2xl font-bold font-mono tracking-tight ${totalUnpaid > 0 ? 'text-amber-400' : 'text-slate-300'}`}>
            ₹{totalUnpaid.toLocaleString('en-IN')}
          </div>
          <div className="text-[11px] text-slate-400 mt-2 flex items-center justify-between">
            <span>{pendingInvoices.length} invoices awaiting payment</span>
            {pendingInvoices.length > 0 && (
              <button 
                onClick={() => onNavigateTab('invoices')}
                className="text-amber-400 hover:underline font-semibold"
              >
                Review →
              </button>
            )}
          </div>
        </div>

        {/* Active Deployments */}
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium mb-2">
            <span>Active Hosting Services</span>
            <span className="p-1.5 rounded-lg bg-blue-500/10 text-blue-400">
              <Box size={15} />
            </span>
          </div>
          <div className="text-2xl font-bold text-white font-mono tracking-tight">
            {activeServices.length}
          </div>
          <div className="text-[11px] text-slate-400 mt-2 flex items-center gap-2">
            {pendingServices.length > 0 ? (
              <span className="text-amber-400 font-semibold">{pendingServices.length} pending setup</span>
            ) : (
              <span className="text-emerald-400 flex items-center gap-1">
                <CheckCircle2 size={12} /> All instances operational
              </span>
            )}
          </div>
        </div>

        {/* Open Support Desk */}
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium mb-2">
            <span>Helpdesk Tickets</span>
            <span className="p-1.5 rounded-lg bg-purple-500/10 text-purple-400">
              <LifeBuoy size={15} />
            </span>
          </div>
          <div className="text-2xl font-bold text-white font-mono tracking-tight">
            {openTickets.length}
          </div>
          <div className="text-[11px] text-slate-400 mt-2 flex items-center justify-between">
            <span>{openTickets.length === 0 ? 'No pending requests' : 'Customer action required'}</span>
            <button 
              onClick={() => onNavigateTab('tickets')}
              className="text-purple-400 hover:underline font-semibold"
            >
              Open Desk →
            </button>
          </div>
        </div>
      </div>

      {/* WHMCS Quick Action Shortcuts */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
          <Zap size={15} className="text-blue-400" />
          <span>Quick Actions:</span>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={onOpenCreateInvoice}
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <CreditCard size={13} />
            <span>+ Create Invoice</span>
          </button>
          <button
            onClick={onOpenCreateService}
            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <Box size={13} />
            <span>+ Provision Service</span>
          </button>
          <button
            onClick={onOpenCreatePlan}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5"
          >
            <Plus size={13} />
            <span>+ Add Hosting Plan</span>
          </button>
          <button
            onClick={onRefresh}
            disabled={isLoading}
            className="px-3 py-1.5 bg-slate-800/80 hover:bg-slate-800 text-slate-300 border border-slate-700/80 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 disabled:opacity-50"
          >
            <RefreshCw size={13} className={isLoading ? 'animate-spin' : ''} />
            <span>Sync Data</span>
          </button>
        </div>
      </div>

      {/* High-Priority Queue: Pending UPI & Manual Payment Verifications */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="p-4 bg-slate-900/80 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Pending Payment Verification Queue ({pendingInvoices.length})
            </h3>
          </div>
          <button
            onClick={() => onNavigateTab('invoices')}
            className="text-xs text-blue-400 hover:underline flex items-center gap-1 font-medium"
          >
            View all invoices <ArrowRight size={12} />
          </button>
        </div>

        {pendingInvoices.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-400 flex flex-col items-center justify-center space-y-2">
            <CheckCircle2 size={24} className="text-emerald-400" />
            <p className="font-semibold text-slate-300">Payment Queue Clean</p>
            <p className="text-slate-500 text-[11px]">All issued invoices and UPI transfers are fully settled.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-900/60 text-[10px] uppercase font-semibold text-slate-400 tracking-wider">
                <tr>
                  <th className="p-3.5">Invoice #</th>
                  <th className="p-3.5">Client User</th>
                  <th className="p-3.5">Amount</th>
                  <th className="p-3.5">Payment Method & UTR</th>
                  <th className="p-3.5">Date</th>
                  <th className="p-3.5 text-right">Instant Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {pendingInvoices.slice(0, 5).map(inv => (
                  <tr key={inv.id} className="hover:bg-slate-850/40">
                    <td className="p-3.5 font-mono font-bold text-blue-400">
                      #{inv.invoiceNumber || inv.id}
                    </td>
                    <td className="p-3.5">
                      <button
                        onClick={() => onOpenClientProfile(inv.userId)}
                        className="text-slate-200 hover:text-blue-400 font-medium text-left truncate max-w-xs block"
                        title="Click to view Client 360° Profile"
                      >
                        {inv.userId}
                      </button>
                    </td>
                    <td className="p-3.5 font-bold font-mono text-white">
                      {formatINR(inv.total, 2)}
                    </td>
                    <td className="p-3.5">
                      <div className="text-slate-300 font-medium">{inv.paymentMethod || inv.method || 'UPI Transfer'}</div>
                      {inv.utrNumber ? (
                        <div className="text-[10px] font-mono text-emerald-400">UTR: {inv.utrNumber}</div>
                      ) : (
                        <div className="text-[10px] text-slate-500">Awaiting UTR submission</div>
                      )}
                    </td>
                    <td className="p-3.5 text-slate-400 text-[11px]">
                      {inv.timestamp ? new Date(inv.timestamp).toLocaleDateString() : 'Recent'}
                    </td>
                    <td className="p-3.5 text-right">
                      <button
                        onClick={() => onVerifyInvoiceAndProvision(inv.id)}
                        disabled={actionLoading === inv.id}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-lg text-xs font-semibold transition-colors inline-flex items-center gap-1.5 shadow-sm"
                        title="Approve payment and automatically provision service"
                      >
                        {actionLoading === inv.id ? (
                          <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        ) : (
                          <CheckCircle2 size={13} />
                        )}
                        <span>Verify & Provision</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Two Column Grid: Infrastructure Health & Client Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Node Health & Infrastructure */}
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Server size={14} className="text-blue-400" /> Infrastructure Nodes & Health
            </h4>
            <button 
              onClick={() => onNavigateTab('status')}
              className="text-xs text-blue-400 hover:underline"
            >
              System Health Monitor →
            </button>
          </div>
          <div className="space-y-3">
            <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-white">Ryzen-KVM-Node-01 (Mumbai)</p>
                <p className="text-[11px] text-slate-400 font-mono mt-0.5">AMD Ryzen 9 7950X · 128GB DDR5 ECC · 1 Gbps Port</p>
              </div>
              <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                100% Operational
              </span>
            </div>
            <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-white">Pterodactyl Daemon API</p>
                <p className="text-[11px] text-slate-400 font-mono mt-0.5">Application & Client API Gateway</p>
              </div>
              <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Connected
              </span>
            </div>
            <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-white">Path.net L7 DDoS Scrubbing</p>
                <p className="text-[11px] text-slate-400 font-mono mt-0.5">12 Tbps+ Global Capacity Filter</p>
              </div>
              <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Active Shield
              </span>
            </div>
          </div>
        </div>

        {/* Registered Clients Snapshot */}
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Users size={14} className="text-purple-400" /> Recent Clients ({users.length})
            </h4>
            <button 
              onClick={() => onNavigateTab('users')}
              className="text-xs text-blue-400 hover:underline"
            >
              Full Client Directory →
            </button>
          </div>
          <div className="space-y-2">
            {users.slice(0, 4).map(u => (
              <div 
                key={u.id}
                onClick={() => onOpenClientProfile(u.id)}
                className="p-3 bg-slate-900 hover:bg-slate-850/80 border border-slate-800 rounded-xl flex items-center justify-between cursor-pointer transition-colors"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-8 h-8 rounded-full bg-blue-500/20 text-blue-400 font-bold flex items-center justify-center text-xs shrink-0">
                    {(u.displayName || u.email)?.[0]?.toUpperCase() || 'U'}
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-white truncate">{u.displayName || u.email}</p>
                    <p className="text-[10px] text-slate-400 font-mono truncate">{u.email}</p>
                  </div>
                </div>
                <span className="text-[11px] text-blue-400 hover:underline font-medium shrink-0 flex items-center gap-1">
                  View 360° Profile <ArrowRight size={11} />
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
