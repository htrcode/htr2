import React, { useState } from 'react';
import { 
  Plus, Edit2, Trash2, Save, X, Box, Check, 
  Layers, Gamepad2, Info, List, DollarSign,
  Monitor, Cpu, HardDrive, Users, CheckCircle2, RefreshCw,
  Image as ImageIcon, Shield, Globe, Wifi, Zap, Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Game, GameRamOption } from '../../types';
import { dataService } from '../../services/dataService';
import { logService } from '../../services/logService';

interface GamesTabProps {
  games: Game[];
  onUpdate: () => void;
}

export const GamesTab: React.FC<GamesTabProps> = ({ games, onUpdate }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingGame, setEditingGame] = useState<Game | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [deletingGame, setDeletingGame] = useState<{ id: string, title: string } | null>(null);
  const [optimisticHiddenIds, setOptimisticHiddenIds] = useState<string[]>([]);
  
  const visibleGames = games.filter(g => !optimisticHiddenIds.includes(g.id));
  
  const [form, setOrderForm] = useState<Omit<Game, 'id'>>({
    title: '',
    category: 'Sandbox',
    image: '',
    startingPriceInr: 149,
    platforms: [],
    badge: '',
    description: '',
    ramOptions: [],
    metadata: {
      recommendedRam: '',
      players: '',
      cpuType: '',
      storage: '',
      serverSoftware: []
    },
    is_active: true,
    order: games.length + 1,
    use_catalog_plans: false
  });

  const [platformInput, setPlatformInput] = useState('');
  const [softwareInput, setSoftwareInput] = useState('');

  const openAdd = () => {
    setEditingGame(null);
    setOrderForm({
      title: '',
      category: 'Sandbox',
      image: '',
      startingPriceInr: 149,
      platforms: [],
      badge: '',
      description: '',
      ramOptions: [
        { ram: '2 GB', slots: '10 Slots', priceInr: 149, cpu: '100% CPU' }
      ],
      metadata: {
        recommendedRam: '',
        players: '',
        cpuType: '',
        storage: '',
        serverSoftware: []
      },
      is_active: true,
      order: games.length + 1,
      use_catalog_plans: false
    });
    setPlatformInput('');
    setSoftwareInput('');
    setIsModalOpen(true);
  };

  const openEdit = (game: Game) => {
    setEditingGame(game);
    setOrderForm({
      title: game.title,
      category: game.category,
      image: game.image,
      startingPriceInr: game.startingPriceInr,
      platforms: game.platforms || [],
      badge: game.badge || '',
      description: game.description,
      ramOptions: game.ramOptions || [],
      metadata: {
        recommendedRam: game.metadata?.recommendedRam || '',
        players: game.metadata?.players || '',
        cpuType: game.metadata?.cpuType || '',
        storage: game.metadata?.storage || '',
        serverSoftware: game.metadata?.serverSoftware || []
      },
      is_active: game.is_active !== false,
      order: game.order || 0,
      use_catalog_plans: game.use_catalog_plans || false
    });
    setPlatformInput('');
    setSoftwareInput('');
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSaving) return;
    setIsSaving(true);

    try {
      // Ensure all ramOptions have product_id
      const enrichedRamOptions = form.ramOptions.map(opt => ({
        ...opt,
        product_id: opt.product_id || `hh-game-${Math.random().toString(36).substring(2, 7)}`
      }));
      
      const payload = { ...form, ramOptions: enrichedRamOptions };

      if (editingGame) {
        await dataService.updateGame(editingGame.id, payload);
        logService.addLog('success', `Updated game: ${form.title}`);
      } else {
        await dataService.addGame(payload);
        logService.addLog('success', `Added new game: ${form.title}`);
      }
      setIsModalOpen(false);
      onUpdate();
    } catch (err: any) {
      alert(`Save failed: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deletingGame) return;
    const { id, title } = deletingGame;
    
    console.log(`[GamesTab] Deleting game: ${title} (${id})`);
    setIsSaving(true);
    
    try {
      logService.addLog('info', `Deleting game: ${title}...`);
      
      // Optimistically hide from UI
      setOptimisticHiddenIds(prev => [...prev, id]);
      setDeletingGame(null);
      
      await dataService.deleteGame(id);
      logService.addLog('warning', `Deleted game: ${title}`);
      
      console.log(`[GamesTab] Successfully deleted game: ${title}. Triggering onUpdate.`);
      onUpdate();
    } catch (err: any) {
      // Revert optimistic hide on error
      setOptimisticHiddenIds(prev => prev.filter(hid => hid !== id));
      console.error(`[GamesTab] Error deleting game ${title}:`, err);
      alert(`Delete failed: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  const addRamOption = () => {
    setOrderForm({
      ...form,
      ramOptions: [...form.ramOptions, { 
        product_id: `hh-game-${Math.random().toString(36).substring(2, 7)}`,
        name: '',
        ram: '4 GB Dedicated RAM', 
        slots: '30 Slots Player Slots', 
        priceInr: 499, 
        cpu: '200% CPU Core',
        storage: '50GB NVMe Gen4',
        ddosProtection: 'Path.net 12 Tbps+ Anti-DDoS',
        networkSpeed: '1 Gbps Unmetered Port',
        features: ['Pterodactyl Panel Access', 'Instant 60s Deployment'],
        subcategory: 'standard',
        is_popular: false
      }]
    });
  };

  const removeRamOption = (idx: number) => {
    setOrderForm({
      ...form,
      ramOptions: form.ramOptions.filter((_, i) => i !== idx)
    });
  };

  const updateRamOption = (idx: number, field: keyof GameRamOption, val: any) => {
    const next = [...form.ramOptions];
    next[idx] = { ...next[idx], [field]: field === 'priceInr' ? Number(val) : val };
    setOrderForm({ ...form, ramOptions: next });
  };

  const addPlatform = () => {
    if (!platformInput.trim()) return;
    if (form.platforms.includes(platformInput.trim())) return;
    setOrderForm({ ...form, platforms: [...form.platforms, platformInput.trim()] });
    setPlatformInput('');
  };

  const removePlatform = (p: string) => {
    setOrderForm({ ...form, platforms: form.platforms.filter(item => item !== p) });
  };

  const addSoftware = () => {
    if (!softwareInput.trim()) return;
    const current = form.metadata?.serverSoftware || [];
    if (current.includes(softwareInput.trim())) return;
    setOrderForm({
      ...form,
      metadata: {
        ...form.metadata!,
        serverSoftware: [...current, softwareInput.trim()]
      }
    });
    setSoftwareInput('');
  };

  const removeSoftware = (s: string) => {
    const current = form.metadata?.serverSoftware || [];
    setOrderForm({
      ...form,
      metadata: {
        ...form.metadata!,
        serverSoftware: current.filter(item => item !== s)
      }
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-black text-white uppercase tracking-tight flex items-center gap-2">
            <Gamepad2 size={24} className="text-accent" />
            Game Infrastructure Catalog
          </h2>
          <p className="text-xs text-slate-400 mt-1">Manage global game server configurations and specialized pricing tiers.</p>
        </div>
        <button 
          onClick={openAdd}
          className="flex items-center gap-2 px-4 py-2 bg-accent hover:bg-accent-muted text-white rounded-lg text-xs font-bold transition-all shadow-lg shadow-purple-950/40"
        >
          <Plus size={16} />
          Register New Game
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {visibleGames.map((game) => (
          <div key={game.id} className="bg-[#110c1e] border border-[#261b3d] rounded-2xl overflow-hidden group">
            <div className="relative h-32">
              <img src={game.image} alt={game.title} className="w-full h-full object-cover opacity-60 grayscale group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#110c1e] to-transparent" />
              <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <button onClick={() => openEdit(game)} className="p-2 bg-bg/80 border border-border rounded-lg text-white hover:border-accent hover:text-accent transition-colors">
                  <Edit2 size={14} />
                </button>
                <button onClick={() => setDeletingGame({ id: game.id, title: game.title })} className="p-2 bg-bg/80 border border-border rounded-lg text-white hover:border-rose-500 hover:text-rose-500 transition-colors">
                  <Trash2 size={14} />
                </button>
              </div>
              <div className="absolute bottom-4 left-6">
                <div className="text-[10px] font-black text-accent uppercase tracking-widest mb-1">{game.category}</div>
                <h3 className="text-lg font-black text-white uppercase tracking-tight">{game.title}</h3>
              </div>
            </div>
            <div className="p-6 space-y-4">
              <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">{game.description}</p>
              
              <div className="grid grid-cols-2 gap-3">
                <div className="p-2.5 rounded-xl bg-bg border border-border">
                  <div className="text-[9px] font-bold text-slate-500 uppercase">Starting From</div>
                  <div className="text-sm font-black text-white font-mono mt-0.5">₹{game.startingPriceInr}</div>
                </div>
                <div className="p-2.5 rounded-xl bg-bg border border-border">
                  <div className="text-[9px] font-bold text-slate-500 uppercase">Tiers Active</div>
                  <div className="text-sm font-black text-white font-mono mt-0.5">{game.ramOptions.length} Plans</div>
                </div>
              </div>

              <div className="flex flex-wrap gap-1.5">
                {game.platforms.map(p => (
                  <span key={p} className="px-2 py-0.5 rounded-md bg-bg-alt border border-border text-[9px] text-slate-300 font-bold uppercase">{p}</span>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>

      <AnimatePresence>
        {deletingGame && (
          <div className="fixed inset-0 z-[1100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-card border border-rose-500/20 rounded-3xl p-8 max-w-md w-full shadow-2xl space-y-6"
            >
              <div className="w-16 h-16 rounded-2xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-500 mx-auto">
                <Trash2 size={32} />
              </div>
              
              <div className="text-center space-y-2">
                <h3 className="text-xl font-black text-white uppercase tracking-tight">Confirm Destruction</h3>
                <p className="text-sm text-slate-400">
                  Are you sure you want to permanently delete <span className="text-white font-bold">"{deletingGame.title}"</span>? 
                  All associated compute tiers and configurations will be purged from the infrastructure catalog.
                </p>
              </div>

              <div className="flex gap-3">
                <button 
                  onClick={() => setDeletingGame(null)}
                  disabled={isSaving}
                  className="flex-1 px-6 py-3 rounded-xl border border-border text-slate-300 text-xs font-bold hover:bg-border transition-colors uppercase tracking-widest disabled:opacity-50"
                >
                  Abort
                </button>
                <button 
                  onClick={handleDelete}
                  disabled={isSaving}
                  className="flex-1 px-6 py-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold uppercase tracking-widest transition-all shadow-lg shadow-rose-950/40 flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isSaving ? <RefreshCw className="animate-spin" size={14} /> : <Check size={14} />}
                  Confirm Delete
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#110c1e] border border-[#2b1b47] rounded-3xl w-full max-w-5xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl"
            >
              <div className="p-6 border-b border-border flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-accent/10 border border-accent/20 flex items-center justify-center text-accent">
                    <Gamepad2 size={20} />
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-white uppercase tracking-tight">
                      {editingGame ? `Refactor ${editingGame.title}` : 'Register New Infrastructure'}
                    </h3>
                    <p className="text-[11px] text-slate-400 font-medium">Define game binary requirements and compute allocation tiers.</p>
                  </div>
                </div>
                <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-white transition-colors">
                  <X size={20} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-8 space-y-8 custom-scrollbar">
                <form id="game-form" onSubmit={handleSave} className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                  <div className="space-y-6">
                    <section className="space-y-4">
                      <h4 className="text-[11px] font-black text-accent uppercase tracking-widest flex items-center gap-2">
                        <Info size={14} /> Basic Specification
                      </h4>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Game Title</label>
                          <input 
                            required
                            value={form.title}
                            onChange={e => setOrderForm({ ...form, title: e.target.value.toUpperCase() })}
                            className="w-full bg-bg border border-border rounded-xl px-4 py-2.5 text-xs text-white focus:border-accent outline-none"
                            placeholder="e.g. MINECRAFT"
                          />
                        </div>
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Category</label>
                          <input 
                            required
                            value={form.category}
                            onChange={e => setOrderForm({ ...form, category: e.target.value })}
                            className="w-full bg-bg border border-border rounded-xl px-4 py-2.5 text-xs text-white focus:border-accent outline-none"
                            placeholder="e.g. Sandbox"
                          />
                        </div>
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Image Source Path / URL</label>
                        <div className="relative">
                          <ImageIcon size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
                          <input 
                            required
                            value={form.image}
                            onChange={e => setOrderForm({ ...form, image: e.target.value })}
                            className="w-full bg-bg border border-border rounded-xl pl-11 pr-4 py-2.5 text-xs text-white focus:border-accent outline-none font-mono"
                            placeholder="/src/assets/images/..."
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Min Price (INR)</label>
                          <div className="relative">
                            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 text-xs">₹</span>
                            <input 
                              type="number"
                              required
                              value={form.startingPriceInr}
                              onChange={e => setOrderForm({ ...form, startingPriceInr: Number(e.target.value) })}
                              className="w-full bg-bg border border-border rounded-xl pl-8 pr-4 py-2.5 text-xs text-white focus:border-accent outline-none"
                            />
                          </div>
                        </div>
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Display Badge</label>
                          <input 
                            value={form.badge}
                            onChange={e => setOrderForm({ ...form, badge: e.target.value.toUpperCase() })}
                            className="w-full bg-bg border border-border rounded-xl px-4 py-2.5 text-xs text-white focus:border-accent outline-none"
                            placeholder="e.g. POPULAR"
                          />
                        </div>
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Technical Description</label>
                        <textarea 
                          rows={3}
                          required
                          value={form.description}
                          onChange={e => setOrderForm({ ...form, description: e.target.value })}
                          className="w-full bg-bg border border-border rounded-xl px-4 py-2.5 text-xs text-white focus:border-accent outline-none resize-none leading-relaxed"
                          placeholder="Brief technical summary of the hosting platform..."
                        />
                      </div>

                      {/* Customizable Plans Toggle */}
                      <div className="p-4 rounded-xl bg-purple-950/10 border border-purple-900/30 space-y-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="text-[10px] font-black text-purple-400 uppercase tracking-widest block">Plan Customization Mode</span>
                            <span className="text-[9px] text-slate-400">Control layout strategy for this game's plans.</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => setOrderForm(prev => ({ ...prev, use_catalog_plans: !prev.use_catalog_plans }))}
                            className={`px-3 py-1 rounded-lg font-black text-[10px] tracking-wider border transition-all ${
                              form.use_catalog_plans
                                ? 'bg-purple-500/20 text-purple-300 border-purple-500/40'
                                : 'bg-slate-900 text-slate-400 border-slate-800'
                            }`}
                          >
                            {form.use_catalog_plans ? 'CUSTOM PLANS (CATALOG)' : 'SIMPLE SLIDERS'}
                          </button>
                        </div>
                        <p className="text-[10px] text-slate-400 leading-relaxed">
                          {form.use_catalog_plans ? (
                            <span className="text-purple-300 font-medium">
                              ✨ Enabled: Manage game plans as fully customizable hosting products in the <strong className="text-white">Plans Catalog</strong> tab (edit total section of texts, features, prices, specs). Simple RAM sliders are bypassed!
                            </span>
                          ) : (
                            <span>
                              Default RAM, CPU, Slots options will be used as a simple list.
                            </span>
                          )}
                        </p>
                      </div>
                    </section>

                    <section className="space-y-4">
                      <h4 className="text-[11px] font-black text-emerald-400 uppercase tracking-widest flex items-center gap-2">
                        <Monitor size={14} /> Ecosystem & Compatibility
                      </h4>
                      
                      <div className="space-y-3">
                        <div className="flex gap-2">
                          <input 
                            value={platformInput}
                            onChange={e => setPlatformInput(e.target.value)}
                            onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), addPlatform())}
                            className="flex-1 bg-bg border border-border rounded-xl px-4 py-2 text-xs text-white focus:border-accent outline-none"
                            placeholder="Add Platform (e.g. PC, Xbox, Java)"
                          />
                          <button type="button" onClick={addPlatform} className="px-4 bg-bg border border-border hover:border-accent text-accent rounded-xl transition-all">
                            <Plus size={16} />
                          </button>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {form.platforms.map(p => (
                            <span key={p} className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-bg-alt border border-border text-[10px] font-bold text-slate-300">
                              {p}
                              <button type="button" onClick={() => removePlatform(p)} className="text-slate-500 hover:text-rose-500"><X size={10} /></button>
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="space-y-1.5 pt-2">
                        <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Supported Software / Mods</label>
                        <div className="flex gap-2">
                          <input 
                            value={softwareInput}
                            onChange={e => setSoftwareInput(e.target.value)}
                            onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), addSoftware())}
                            className="flex-1 bg-bg border border-border rounded-xl px-4 py-2 text-xs text-white focus:border-accent outline-none"
                            placeholder="e.g. Spigot, Forge, BungeeCord"
                          />
                          <button type="button" onClick={addSoftware} className="px-4 bg-bg border border-border hover:border-accent text-accent rounded-xl transition-all">
                            <Plus size={16} />
                          </button>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {form.metadata?.serverSoftware?.map(s => (
                            <span key={s} className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-[10px] font-bold text-emerald-400">
                              {s}
                              <button type="button" onClick={() => removeSoftware(s)} className="text-emerald-800 hover:text-rose-500"><X size={10} /></button>
                            </span>
                          ))}
                        </div>
                      </div>
                    </section>
                  </div>

                  <div className="space-y-8">
                    {!form.use_catalog_plans ? (
                      <section className="space-y-4">
                        <div className="flex items-center justify-between">
                          <h4 className="text-[11px] font-black text-purple-400 uppercase tracking-widest flex items-center gap-2">
                            <Layers size={14} /> Compute Tiers & Plans
                          </h4>
                          <button type="button" onClick={addRamOption} className="text-[10px] font-black text-accent uppercase hover:underline">Add Tier</button>
                        </div>

                        <div className="space-y-3">
                          {form.ramOptions.map((opt, idx) => (
                            <div key={idx} className="bg-bg-alt border border-border rounded-2xl p-4 space-y-4 relative">
                              <button 
                                type="button" 
                                onClick={() => removeRamOption(idx)}
                                className="absolute top-4 right-4 text-slate-500 hover:text-rose-500 transition-colors"
                              >
                                <Trash2 size={14} />
                              </button>
                              
                              <div className="mb-4 pb-4 border-b border-border space-y-3">
                                <div className="flex items-center justify-between">
                                  <div className="space-y-0.5">
                                    <label className="text-[9px] text-accent uppercase tracking-widest font-black block">Product SKU ID</label>
                                    <div className="text-[10px] font-mono text-slate-400">{opt.product_id || '(Generated)'}</div>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <label className="text-[9px] text-slate-400 font-bold uppercase cursor-pointer flex items-center gap-1.5">
                                      <input 
                                        type="checkbox"
                                        checked={opt.is_popular || false}
                                        onChange={e => updateRamOption(idx, 'is_popular', e.target.checked)}
                                        className="rounded bg-bg border-border text-accent focus:ring-0 focus:ring-offset-0 w-3.5 h-3.5"
                                      />
                                      Popular Badge
                                    </label>
                                  </div>
                                </div>

                                <div className="grid grid-cols-2 gap-3">
                                  <div className="space-y-1">
                                    <label className="text-[9px] font-black text-slate-500 uppercase tracking-tighter flex items-center gap-1">
                                      Plan Display Name (Optional)
                                    </label>
                                    <input 
                                      value={opt.name || ''}
                                      onChange={e => updateRamOption(idx, 'name', e.target.value)}
                                      className="w-full bg-bg border border-border rounded-lg px-2.5 py-1.5 text-xs text-white focus:border-accent outline-none"
                                      placeholder="e.g. Dirt Plan, Iron Plan"
                                    />
                                  </div>
                                  <div className="space-y-1">
                                    <label className="text-[9px] font-black text-slate-500 uppercase tracking-tighter flex items-center gap-1">
                                      Subcategory (Budget/Standard/Perf)
                                    </label>
                                    <select
                                      value={opt.subcategory || 'standard'}
                                      onChange={e => updateRamOption(idx, 'subcategory', e.target.value)}
                                      className="w-full bg-bg border border-border rounded-lg px-2 py-1 text-xs text-white focus:border-accent outline-none font-bold text-accent"
                                    >
                                      <option value="budget">Budget Tier</option>
                                      <option value="standard">Standard Tier</option>
                                      <option value="performance">Performance Tier</option>
                                    </select>
                                  </div>
                                </div>
                              </div>

                              <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-1">
                                  <label className="text-[9px] font-black text-slate-500 uppercase tracking-tighter flex items-center gap-1">
                                    <Box size={10} /> RAM Allocation
                                  </label>
                                  <input 
                                    value={opt.ram}
                                    onChange={e => updateRamOption(idx, 'ram', e.target.value)}
                                    className="w-full bg-bg border border-border rounded-lg px-3 py-1.5 text-xs text-white focus:border-accent outline-none font-mono"
                                    placeholder="e.g. 8 GB DDR5"
                                  />
                                </div>
                                <div className="space-y-1">
                                  <label className="text-[9px] font-black text-slate-500 uppercase tracking-tighter flex items-center gap-1">
                                    <Users size={10} /> Slot Capacity / Players
                                  </label>
                                  <input 
                                    value={opt.slots}
                                    onChange={e => updateRamOption(idx, 'slots', e.target.value)}
                                    className="w-full bg-bg border border-border rounded-lg px-3 py-1.5 text-xs text-white focus:border-accent outline-none"
                                    placeholder="e.g. 50 Player Slots"
                                  />
                                </div>
                              </div>

                              <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-1">
                                  <label className="text-[9px] font-black text-slate-500 uppercase tracking-tighter flex items-center gap-1">
                                    <DollarSign size={10} /> Tier Price (INR)
                                  </label>
                                  <input 
                                    type="number"
                                    value={opt.priceInr}
                                    onChange={e => updateRamOption(idx, 'priceInr', e.target.value)}
                                    className="w-full bg-bg border border-border rounded-lg px-3 py-1.5 text-xs text-white focus:border-accent outline-none font-mono font-bold"
                                  />
                                </div>
                                <div className="space-y-1">
                                  <label className="text-[9px] font-black text-slate-500 uppercase tracking-tighter flex items-center gap-1">
                                    <Cpu size={10} /> CPU Resource / Cores
                                  </label>
                                  <input 
                                    value={opt.cpu}
                                    onChange={e => updateRamOption(idx, 'cpu', e.target.value)}
                                    className="w-full bg-bg border border-border rounded-lg px-3 py-1.5 text-xs text-white focus:border-accent outline-none"
                                    placeholder="e.g. 4 vCPU Cores"
                                  />
                                </div>
                              </div>

                              <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-1">
                                  <label className="text-[9px] font-black text-slate-500 uppercase tracking-tighter flex items-center gap-1">
                                    <Zap size={10} /> Processor / CPU Model
                                  </label>
                                  <input 
                                    value={opt.processor || ''}
                                    onChange={e => updateRamOption(idx, 'processor', e.target.value)}
                                    className="w-full bg-bg border border-border rounded-lg px-3 py-1.5 text-xs text-white focus:border-accent outline-none font-mono"
                                    placeholder="e.g. AMD Ryzen 9 7950X @ 5.7GHz"
                                  />
                                </div>
                                <div className="space-y-1">
                                  <label className="text-[9px] font-black text-slate-500 uppercase tracking-tighter flex items-center gap-1">
                                    <HardDrive size={10} /> NVMe Storage
                                  </label>
                                  <input 
                                    value={opt.storage || ''}
                                    onChange={e => updateRamOption(idx, 'storage', e.target.value)}
                                    className="w-full bg-bg border border-border rounded-lg px-3 py-1.5 text-xs text-white focus:border-accent outline-none font-mono"
                                    placeholder="e.g. 100 GB Gen4 NVMe"
                                  />
                                </div>
                              </div>

                              <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-1">
                                  <label className="text-[9px] font-black text-slate-500 uppercase tracking-tighter flex items-center gap-1">
                                    <Shield size={10} /> DDoS Protection
                                  </label>
                                  <input 
                                    value={opt.ddosProtection || ''}
                                    onChange={e => updateRamOption(idx, 'ddosProtection', e.target.value)}
                                    className="w-full bg-bg border border-border rounded-lg px-3 py-1.5 text-xs text-white focus:border-accent outline-none"
                                    placeholder="e.g. Path.net 12 Tbps+ Anti-DDoS"
                                  />
                                </div>
                                <div className="space-y-1">
                                  <label className="text-[9px] font-black text-slate-500 uppercase tracking-tighter flex items-center gap-1">
                                    <Globe size={10} /> Network / Port Speed
                                  </label>
                                  <input 
                                    value={opt.networkSpeed || ''}
                                    onChange={e => updateRamOption(idx, 'networkSpeed', e.target.value)}
                                    className="w-full bg-bg border border-border rounded-lg px-3 py-1.5 text-xs text-white focus:border-accent outline-none"
                                    placeholder="e.g. 1 Gbps Unmetered Port"
                                  />
                                </div>
                              </div>

                              {/* Dynamic Key-Value Specs Manager per Game */}
                              <div className="space-y-2 border-t border-border/60 pt-3">
                                <label className="text-[9px] font-black text-purple-400 uppercase tracking-tighter flex items-center gap-1">
                                  <Sparkles size={10} /> Custom Game-Specific Specs (Key-Value Pairs)
                                </label>
                                <div className="grid grid-cols-12 gap-2">
                                  <input 
                                    id={`spec-key-${idx}`}
                                    className="col-span-5 bg-bg border border-border rounded-lg px-2.5 py-1.5 text-[11px] text-white focus:border-accent outline-none"
                                    placeholder="Spec Name (e.g. Java Version)"
                                  />
                                  <input 
                                    id={`spec-val-${idx}`}
                                    className="col-span-5 bg-bg border border-border rounded-lg px-2.5 py-1.5 text-[11px] text-white focus:border-accent outline-none"
                                    placeholder="Value (e.g. OpenJDK 21)"
                                  />
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const kInput = document.getElementById(`spec-key-${idx}`) as HTMLInputElement;
                                      const vInput = document.getElementById(`spec-val-${idx}`) as HTMLInputElement;
                                      if (kInput?.value.trim() && vInput?.value.trim()) {
                                        const currentSpecs = opt.specs || {};
                                        updateRamOption(idx, 'specs', { ...currentSpecs, [kInput.value.trim()]: vInput.value.trim() });
                                        kInput.value = '';
                                        vInput.value = '';
                                      }
                                    }}
                                    className="col-span-2 bg-accent hover:bg-accent-muted text-white text-xs font-bold rounded-lg transition-all"
                                  >
                                    + Add
                                  </button>
                                </div>

                                {/* Key-Value Display List */}
                                <div className="flex flex-wrap gap-1.5 pt-1">
                                  {Object.entries(opt.specs || {}).map(([sKey, sVal]) => (
                                    <span key={sKey} className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#1d1435] border border-accent/40 text-[10px] font-mono text-purple-200">
                                      <strong className="text-accent font-bold">{sKey}:</strong> {sVal}
                                      <button
                                        type="button"
                                        onClick={() => {
                                          const nextSpecs = { ...(opt.specs || {}) };
                                          delete nextSpecs[sKey];
                                          updateRamOption(idx, 'specs', nextSpecs);
                                        }}
                                        className="ml-1 text-slate-400 hover:text-rose-400"
                                      >
                                        <X size={10} />
                                      </button>
                                    </span>
                                  ))}
                                </div>
                              </div>

                              <div className="space-y-2 border-t border-border/60 pt-3">
                                <label className="text-[9px] font-black text-slate-500 uppercase tracking-tighter flex items-center gap-1">
                                  <List size={10} /> Bullet Feature Badges / Highlights
                                </label>
                                <div className="flex gap-2">
                                  <input 
                                    id={`feature-input-${idx}`}
                                    className="flex-1 bg-bg border border-border rounded-lg px-3 py-1.5 text-[11px] text-white focus:border-accent outline-none"
                                    placeholder="e.g. Free Subdomain, 3 MySQL DBs"
                                    onKeyDown={(e) => {
                                      if (e.key === 'Enter') {
                                        e.preventDefault();
                                        const input = e.currentTarget;
                                        if (input.value.trim()) {
                                          const currentFeatures = opt.features || [];
                                          updateRamOption(idx, 'features', [...currentFeatures, input.value.trim()]);
                                          input.value = '';
                                        }
                                      }
                                    }}
                                  />
                                  <button 
                                    type="button"
                                    onClick={() => {
                                      const input = document.getElementById(`feature-input-${idx}`) as HTMLInputElement;
                                      if (input?.value.trim()) {
                                        const currentFeatures = opt.features || [];
                                        updateRamOption(idx, 'features', [...currentFeatures, input.value.trim()]);
                                        input.value = '';
                                      }
                                    }}
                                    className="px-3 bg-bg border border-border hover:border-accent text-accent rounded-lg transition-all"
                                  >
                                    <Plus size={12} />
                                  </button>
                                </div>
                                <div className="flex flex-wrap gap-2 mt-2">
                                  {(opt.features || []).map((feature, fIdx) => (
                                    <span key={fIdx} className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-accent/10 border border-accent/20 text-[9px] font-bold text-accent">
                                      {feature}
                                      <button 
                                        type="button" 
                                        onClick={() => {
                                          const next = (opt.features || []).filter((_, i) => i !== fIdx);
                                          updateRamOption(idx, 'features', next);
                                        }}
                                        className="text-accent/60 hover:text-rose-500"
                                      >
                                        <X size={8} />
                                      </button>
                                    </span>
                                  ))}
                                </div>
                              </div>
                            </div>
                          ))}
                          {form.ramOptions.length === 0 && (
                            <div className="p-10 border border-dashed border-border rounded-2xl text-center">
                              <p className="text-xs text-slate-500 italic">No compute tiers defined for this game.</p>
                            </div>
                          )}
                        </div>
                      </section>
                    ) : (
                      <section className="space-y-4 p-6 rounded-2xl bg-[#1a1230]/20 border border-dashed border-purple-900/40 text-center space-y-3">
                        <Layers size={36} className="text-purple-400 mx-auto opacity-75 animate-pulse" />
                        <div className="space-y-2">
                          <h4 className="text-sm font-bold text-white uppercase tracking-wider">Using Customizable Catalog Plans</h4>
                          <p className="text-xs text-slate-400 max-w-sm mx-auto leading-relaxed">
                            Instead of rigid numeric sliders, go to the <strong className="text-amber-400">Plans Catalog</strong> tab to add/edit complete plans. Customize entire text sections, descriptions, prices, specifications, and individual features (just like VPS & other hosting).
                          </p>
                        </div>
                        <div className="text-[11px] text-purple-300 font-mono bg-purple-950/20 p-3 rounded-xl border border-purple-900/30 inline-block text-left space-y-1">
                          <div>• Target Category: <strong className="text-white font-mono uppercase">GAME-HOSTING</strong></div>
                          <div>• Matches: <strong className="text-white font-mono uppercase">{form.title || 'GAME TITLE'}</strong> (in plan name or description)</div>
                        </div>
                      </section>
                    )}

                    <section className="space-y-4">
                      <h4 className="text-[11px] font-black text-amber-400 uppercase tracking-widest flex items-center gap-2">
                        <Gamepad2 size={14} /> Performance Benchmarks (Recommended)
                      </h4>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-1">
                            <Cpu size={10} /> Dedicated CPU Type
                          </label>
                          <input 
                            value={form.metadata?.cpuType}
                            onChange={e => setOrderForm({ ...form, metadata: { ...form.metadata!, cpuType: e.target.value } })}
                            className="w-full bg-bg border border-border rounded-xl px-4 py-2 text-xs text-white focus:border-accent outline-none"
                            placeholder="e.g. Ryzen 9 5950X"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-1">
                            <HardDrive size={10} /> NVMe Storage
                          </label>
                          <input 
                            value={form.metadata?.storage}
                            onChange={e => setOrderForm({ ...form, metadata: { ...form.metadata!, storage: e.target.value } })}
                            className="w-full bg-bg border border-border rounded-xl px-4 py-2 text-xs text-white focus:border-accent outline-none"
                            placeholder="e.g. 50GB Gen4 NVMe"
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-1">
                            <Layers size={10} /> Recommended RAM
                          </label>
                          <input 
                            value={form.metadata?.recommendedRam}
                            onChange={e => setOrderForm({ ...form, metadata: { ...form.metadata!, recommendedRam: e.target.value } })}
                            className="w-full bg-bg border border-border rounded-xl px-4 py-2 text-xs text-white focus:border-accent outline-none"
                            placeholder="e.g. 8-16 GB"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-1">
                            <Users size={10} /> Players Guideline
                          </label>
                          <input 
                            value={form.metadata?.players}
                            onChange={e => setOrderForm({ ...form, metadata: { ...form.metadata!, players: e.target.value } })}
                            className="w-full bg-bg border border-border rounded-xl px-4 py-2 text-xs text-white focus:border-accent outline-none"
                            placeholder="e.g. Up to 100 players"
                          />
                        </div>
                      </div>
                    </section>

                    <section className="p-5 rounded-2xl bg-bg border border-border flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`w-3 h-3 rounded-full ${form.is_active ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'}`} />
                        <div>
                          <div className="text-xs font-black text-white uppercase tracking-tight">Deployment Status</div>
                          <div className="text-[10px] text-slate-500 mt-0.5">Control if this game is visible in the frontend catalog.</div>
                        </div>
                      </div>
                      <button 
                        type="button"
                        onClick={() => setOrderForm({ ...form, is_active: !form.is_active })}
                        className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${
                          form.is_active 
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30' 
                            : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                        }`}
                      >
                        {form.is_active ? 'ACTIVE' : 'INACTIVE'}
                      </button>
                    </section>
                  </div>
                </form>
              </div>

              <div className="p-6 bg-bg-alt border-t border-border flex items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Catalog Order</label>
                    <input 
                      type="number"
                      value={form.order}
                      onChange={e => setOrderForm({ ...form, order: Number(e.target.value) })}
                      className="w-16 bg-bg border border-border rounded-lg px-2 py-1 text-xs text-white text-center font-mono outline-none"
                    />
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <button 
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-6 py-2.5 rounded-xl border border-border text-slate-300 text-xs font-bold hover:bg-border transition-colors"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    form="game-form"
                    disabled={isSaving}
                    className="px-8 py-2.5 rounded-xl bg-accent hover:bg-accent-muted text-white text-xs font-bold uppercase tracking-widest transition-all shadow-lg shadow-purple-950/40 flex items-center gap-2"
                  >
                    {isSaving ? <RefreshCw className="animate-spin" size={14} /> : <Save size={14} />}
                    {editingGame ? 'Commit Changes' : 'Finalize Infrastructure'}
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
