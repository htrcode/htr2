import React, { useState } from 'react';
import { 
  Star, MessageSquare, Plus, Edit2, Trash2, Check, X, Sparkles, 
  Gamepad2, Rocket, Server, Zap, Search, Filter, Quote, RefreshCw, AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Testimonial, Feedback, AppData } from '../../types';
import { dataService } from '../../services/dataService';
import { logService } from '../../services/logService';

interface ReviewsTabProps {
  data: AppData;
  setData: (data: AppData) => void;
}

const renderLogoIcon = (logo: string) => {
  const l = (logo || '').toLowerCase();
  if (l.includes('game') || l.includes('🎮')) return <Gamepad2 className="text-accent" size={20} />;
  if (l.includes('rocket') || l.includes('🚀')) return <Rocket className="text-indigo-400" size={20} />;
  if (l.includes('server') || l.includes('🖥️')) return <Server className="text-emerald-400" size={20} />;
  return <Zap className="text-amber-400" size={20} />;
};

export const ReviewsTab: React.FC<ReviewsTabProps> = ({ data, setData }) => {
  const [activeSubTab, setActiveSubTab] = useState<'testimonials' | 'feedbacks'>('testimonials');

  // Testimonial Modal State
  const [isTestimonialModalOpen, setIsTestimonialModalOpen] = useState(false);
  const [editingTestimonial, setEditingTestimonial] = useState<Testimonial | null>(null);
  const [testimonialForm, setTestimonialForm] = useState({
    name: '',
    server: '',
    logo: 'zap',
    note: '',
  });

  // Feedback Modal State
  const [isFeedbackModalOpen, setIsFeedbackModalOpen] = useState(false);
  const [editingFeedback, setEditingFeedback] = useState<Feedback | null>(null);
  const [feedbackForm, setFeedbackForm] = useState({
    name: '',
    msg: '',
    rating: 5,
    time: '',
  });

  // Filters for feedback
  const [feedbackSearch, setFeedbackSearch] = useState('');
  const [ratingFilter, setRatingFilter] = useState<'ALL' | '5' | '4' | '3' | '1-2'>('ALL');
  const [isSaving, setIsSaving] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const showNotification = (type: 'success' | 'error', text: string) => {
    setStatusMessage({ type, text });
    setTimeout(() => setStatusMessage(null), 3500);
  };

  // --- TESTIMONIAL HANDLERS ---
  const handleOpenAddTestimonial = () => {
    setEditingTestimonial(null);
    setTestimonialForm({
      name: '',
      server: '',
      logo: 'zap',
      note: '',
    });
    setIsTestimonialModalOpen(true);
  };

  const handleOpenEditTestimonial = (t: Testimonial) => {
    setEditingTestimonial(t);
    setTestimonialForm({
      name: t.name,
      server: t.server,
      logo: t.logo || 'zap',
      note: t.note,
    });
    setIsTestimonialModalOpen(true);
  };

  const handleSaveTestimonial = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!testimonialForm.name.trim() || !testimonialForm.note.trim()) {
      alert('Client Name and Review Quote are required.');
      return;
    }

    setIsSaving(true);
    try {
      if (editingTestimonial) {
        await dataService.updateTestimonial(editingTestimonial.id, {
          name: testimonialForm.name.trim(),
          server: testimonialForm.server.trim(),
          logo: testimonialForm.logo,
          note: testimonialForm.note.trim(),
        });

        setData({
          ...data,
          testimonials: data.testimonials.map(item =>
            item.id === editingTestimonial.id
              ? { ...item, ...testimonialForm }
              : item
          ),
        });
        logService.addLog('success', `Testimonial for "${testimonialForm.name}" updated successfully.`);
        showNotification('success', 'Featured testimonial updated successfully.');
      } else {
        const payload = {
          name: testimonialForm.name.trim(),
          server: testimonialForm.server.trim() || 'Hosting Client',
          logo: testimonialForm.logo,
          note: testimonialForm.note.trim(),
        };
        const newId = await dataService.addTestimonial(payload);
        if (newId) {
          setData({
            ...data,
            testimonials: [...data.testimonials, { ...payload, id: newId }],
          });
        }
        logService.addLog('success', `New testimonial for "${testimonialForm.name}" added to Firestore.`);
        showNotification('success', 'New featured review added successfully.');
      }
      setIsTestimonialModalOpen(false);
      setEditingTestimonial(null);
    } catch (err: any) {
      console.error(err);
      logService.addLog('error', `Failed to save testimonial: ${err.message || 'Unknown error'}`);
      showNotification('error', `Failed to save review: ${err.message || 'Error'}`);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteTestimonial = async (id: string, name: string) => {
    if (!window.confirm(`Are you sure you want to delete the review by "${name}"?`)) {
      return;
    }

    try {
      await dataService.deleteTestimonial(id);
      setData({
        ...data,
        testimonials: data.testimonials.filter(t => t.id !== id),
      });
      logService.addLog('info', `Deleted testimonial by "${name}".`);
      showNotification('success', `Review by "${name}" deleted.`);
    } catch (err: any) {
      console.error(err);
      logService.addLog('error', `Failed to delete testimonial: ${err.message || 'Unknown error'}`);
      showNotification('error', 'Failed to delete review from Firestore.');
    }
  };

  // --- FEEDBACK HANDLERS ---
  const handleOpenAddFeedback = () => {
    setEditingFeedback(null);
    setFeedbackForm({
      name: '',
      msg: '',
      rating: 5,
      time: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
    });
    setIsFeedbackModalOpen(true);
  };

  const handleOpenEditFeedback = (f: Feedback) => {
    setEditingFeedback(f);
    setFeedbackForm({
      name: f.name,
      msg: f.msg,
      rating: f.rating || 5,
      time: f.time || new Date().toLocaleDateString(),
    });
    setIsFeedbackModalOpen(true);
  };

  const handleSaveFeedback = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackForm.msg.trim()) {
      alert('Feedback review message is required.');
      return;
    }

    setIsSaving(true);
    try {
      if (editingFeedback) {
        await dataService.updateFeedback(editingFeedback.id, {
          name: feedbackForm.name.trim() || 'Verified Client',
          msg: feedbackForm.msg.trim(),
          rating: Number(feedbackForm.rating),
          time: feedbackForm.time.trim() || new Date().toLocaleDateString(),
        });

        setData({
          ...data,
          feedbacks: data.feedbacks.map(item =>
            item.id === editingFeedback.id
              ? { ...item, ...feedbackForm, rating: Number(feedbackForm.rating) }
              : item
          ),
        });
        logService.addLog('success', `Customer feedback #${editingFeedback.id} updated.`);
        showNotification('success', 'Customer feedback updated successfully.');
      } else {
        const payload = {
          name: feedbackForm.name.trim() || 'Verified Client',
          msg: feedbackForm.msg.trim(),
          rating: Number(feedbackForm.rating),
          time: feedbackForm.time.trim() || new Date().toLocaleDateString(),
        };
        const newId = await dataService.addFeedback(payload);
        if (newId) {
          setData({
            ...data,
            feedbacks: [ { ...payload, id: newId }, ...data.feedbacks ],
          });
        }
        logService.addLog('success', `Added new verified feedback for "${payload.name}".`);
        showNotification('success', 'New feedback review added successfully.');
      }
      setIsFeedbackModalOpen(false);
      setEditingFeedback(null);
    } catch (err: any) {
      console.error(err);
      logService.addLog('error', `Failed to save feedback: ${err.message || 'Unknown error'}`);
      showNotification('error', `Failed to save feedback: ${err.message || 'Error'}`);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteFeedback = async (id: string, name: string) => {
    if (!window.confirm(`Are you sure you want to remove this feedback from "${name}"?`)) {
      return;
    }

    try {
      await dataService.deleteFeedback(id);
      setData({
        ...data,
        feedbacks: data.feedbacks.filter(f => f.id !== id),
      });
      logService.addLog('info', `Deleted feedback #${id}.`);
      showNotification('success', 'Feedback removed.');
    } catch (err: any) {
      console.error(err);
      logService.addLog('error', `Failed to delete feedback: ${err.message || 'Unknown error'}`);
      showNotification('error', 'Failed to delete feedback from Firestore.');
    }
  };

  // Filtered Feedbacks
  const filteredFeedbacks = data.feedbacks.filter(f => {
    const matchesSearch = 
      (f.name || '').toLowerCase().includes(feedbackSearch.toLowerCase()) ||
      (f.msg || '').toLowerCase().includes(feedbackSearch.toLowerCase());
    
    if (!matchesSearch) return false;

    if (ratingFilter === '5') return f.rating === 5;
    if (ratingFilter === '4') return f.rating === 4;
    if (ratingFilter === '3') return f.rating === 3;
    if (ratingFilter === '1-2') return f.rating <= 2;
    return true;
  });

  // Calculate rating statistics
  const totalFeedbacks = data.feedbacks.length;
  const avgRating = totalFeedbacks > 0
    ? (data.feedbacks.reduce((acc, curr) => acc + (curr.rating || 5), 0) / totalFeedbacks).toFixed(1)
    : '5.0';
  const fiveStarCount = data.feedbacks.filter(f => f.rating === 5).length;
  const satisfactionRate = totalFeedbacks > 0 
    ? Math.round((data.feedbacks.filter(f => f.rating >= 4).length / totalFeedbacks) * 100) 
    : 100;

  return (
    <div className="space-y-8 max-w-6xl">
      {/* Toast notification */}
      <AnimatePresence>
        {statusMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className={`p-4 rounded-xl flex items-center justify-between text-xs font-semibold ${
              statusMessage.type === 'success'
                ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300'
                : 'bg-rose-500/10 border border-rose-500/30 text-rose-300'
            }`}
          >
            <div className="flex items-center gap-2">
              {statusMessage.type === 'success' ? <Check size={16} /> : <AlertCircle size={16} />}
              <span>{statusMessage.text}</span>
            </div>
            <button onClick={() => setStatusMessage(null)} className="opacity-60 hover:opacity-100">
              <X size={14} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top Banner & Tab Controls */}
      <div className="bg-card border border-border rounded-3xl p-6 md:p-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-accent/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent/10 border border-accent/20 text-[10px] font-bold text-accent uppercase tracking-widest mb-3">
              <Star size={12} className="text-amber-400" />
              Reputation & Trust Management
            </div>
            <h2 className="text-2xl md:text-3xl font-black text-white tracking-tight">
              Reviews & Client Feedback
            </h2>
            <p className="text-slate-400 text-xs md:text-sm font-light mt-1 max-w-xl">
              Edit the verified client showcase testimonials displayed on the homepage, or moderate customer ratings and feedback submitted by users.
            </p>
          </div>

          <div className="flex items-center gap-3">
            {activeSubTab === 'testimonials' ? (
              <button
                onClick={handleOpenAddTestimonial}
                className="px-5 py-2.5 bg-gradient-to-r from-accent to-indigo-600 hover:opacity-90 text-white rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-accent/20 transition-all cursor-pointer"
              >
                <Plus size={14} />
                Add Featured Review
              </button>
            ) : (
              <button
                onClick={handleOpenAddFeedback}
                className="px-5 py-2.5 bg-gradient-to-r from-accent to-indigo-600 hover:opacity-90 text-white rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-accent/20 transition-all cursor-pointer"
              >
                <Plus size={14} />
                Add Verified Feedback
              </button>
            )}
          </div>
        </div>

        {/* Segmented Sub-Tab Switcher */}
        <div className="flex items-center gap-2 mt-8 p-1.5 bg-bg rounded-2xl border border-border w-fit">
          <button
            onClick={() => setActiveSubTab('testimonials')}
            className={`px-5 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-2.5 ${
              activeSubTab === 'testimonials'
                ? 'bg-accent text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Quote size={14} />
            Featured Testimonials
            <span className="px-2 py-0.5 rounded-full text-[10px] bg-black/30 text-foreground-muted">
              {data.testimonials.length}
            </span>
          </button>

          <button
            onClick={() => setActiveSubTab('feedbacks')}
            className={`px-5 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-2.5 ${
              activeSubTab === 'feedbacks'
                ? 'bg-accent text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <MessageSquare size={14} />
            Public User Feedback
            <span className="px-2 py-0.5 rounded-full text-[10px] bg-black/30 text-foreground-muted">
              {data.feedbacks.length}
            </span>
          </button>
        </div>
      </div>

      {/* --- SUB-TAB 1: FEATURED TESTIMONIALS (HOMEPAGE SHOWCASE) --- */}
      {activeSubTab === 'testimonials' && (
        <motion.div
          key="testimonials-tab"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Quick Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-5 rounded-2xl bg-card border border-border space-y-1">
              <span className="text-[10px] text-slate-400 font-mono uppercase tracking-widest block">
                Total Showcase Reviews
              </span>
              <span className="text-2xl font-black text-white font-mono">
                {data.testimonials.length}
              </span>
            </div>
            <div className="p-5 rounded-2xl bg-card border border-border space-y-1">
              <span className="text-[10px] text-slate-400 font-mono uppercase tracking-widest block">
                Homepage Placement
              </span>
              <span className="text-sm font-bold text-emerald-400 flex items-center gap-1.5 pt-1">
                <Check size={14} /> Live in "Trusted Communities"
              </span>
            </div>
            <div className="p-5 rounded-2xl bg-card border border-border space-y-1">
              <span className="text-[10px] text-slate-400 font-mono uppercase tracking-widest block">
                Storage Target
              </span>
              <span className="text-sm font-mono text-accent pt-1 block">
                Firestore: /testimonials
              </span>
            </div>
          </div>

          {/* Testimonials List */}
          {data.testimonials.length === 0 ? (
            <div className="p-12 text-center rounded-2xl bg-card border border-dashed border-border space-y-4">
              <div className="w-12 h-12 rounded-full bg-accent/10 border border-accent/20 text-accent flex items-center justify-center mx-auto">
                <Quote size={20} />
              </div>
              <div>
                <h4 className="text-white font-bold text-base">No Featured Reviews Configured</h4>
                <p className="text-xs text-slate-400 max-w-md mx-auto mt-1">
                  Add verified reviews from prominent clients, server owners, and communities to boost conversion.
                </p>
              </div>
              <button
                onClick={handleOpenAddTestimonial}
                className="px-5 py-2.5 bg-accent hover:bg-accent-muted text-white rounded-xl text-xs font-bold uppercase tracking-wider"
              >
                Create First Review
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {data.testimonials.map((t) => (
                <div
                  key={t.id}
                  className="bg-card border border-border hover:border-accent/40 rounded-2xl p-6 transition-all flex flex-col justify-between group"
                >
                  <div>
                    {/* Header */}
                    <div className="flex items-start justify-between gap-4 mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-accent/10 border border-accent/20 flex items-center justify-center">
                          {renderLogoIcon(t.logo)}
                        </div>
                        <div>
                          <h4 className="font-bold text-white text-base tracking-tight">{t.name}</h4>
                          <span className="text-[10px] font-mono font-semibold uppercase tracking-wider text-accent">
                            {t.server}
                          </span>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleOpenEditTestimonial(t)}
                          className="p-2 rounded-lg bg-white/5 hover:bg-accent/20 text-slate-400 hover:text-accent transition-colors cursor-pointer"
                          title="Edit Review"
                        >
                          <Edit2 size={14} />
                        </button>
                        <button
                          onClick={() => handleDeleteTestimonial(t.id, t.name)}
                          className="p-2 rounded-lg bg-white/5 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                          title="Delete Review"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>

                    {/* Review Body */}
                    <div className="bg-bg border border-border/60 rounded-xl p-4 my-3 text-xs md:text-sm text-slate-300 leading-relaxed italic">
                      "{t.note}"
                    </div>
                  </div>

                  {/* Footer Meta */}
                  <div className="pt-4 border-t border-border/60 flex items-center justify-between text-[10px] font-mono text-slate-500">
                    <span>Badge Icon: <strong className="text-slate-300 uppercase">{t.logo || 'zap'}</strong></span>
                    <span className="text-emerald-400 font-semibold flex items-center gap-1">
                      <Check size={11} /> Verified Badge
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </motion.div>
      )}

      {/* --- SUB-TAB 2: PUBLIC USER FEEDBACK & RATINGS --- */}
      {activeSubTab === 'feedbacks' && (
        <motion.div
          key="feedbacks-tab"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Rating Summary Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-5 rounded-2xl bg-card border border-border">
              <span className="text-[10px] text-slate-400 font-mono uppercase tracking-widest block">
                Total Submissions
              </span>
              <span className="text-2xl font-black text-white font-mono mt-1 block">
                {totalFeedbacks}
              </span>
            </div>

            <div className="p-5 rounded-2xl bg-card border border-border">
              <span className="text-[10px] text-slate-400 font-mono uppercase tracking-widest block">
                Average Rating
              </span>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-2xl font-black text-amber-400 font-mono">
                  {avgRating}
                </span>
                <div className="flex text-amber-400">
                  <Star size={16} fill="currentColor" />
                </div>
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-card border border-border">
              <span className="text-[10px] text-slate-400 font-mono uppercase tracking-widest block">
                5-Star Reviews
              </span>
              <span className="text-2xl font-black text-emerald-400 font-mono mt-1 block">
                {fiveStarCount}
              </span>
            </div>

            <div className="p-5 rounded-2xl bg-card border border-border">
              <span className="text-[10px] text-slate-400 font-mono uppercase tracking-widest block">
                Satisfaction Rate
              </span>
              <span className="text-2xl font-black text-accent font-mono mt-1 block">
                {satisfactionRate}%
              </span>
            </div>
          </div>

          {/* Search & Filter Bar */}
          <div className="p-4 bg-card border border-border rounded-2xl flex flex-col md:flex-row gap-4 items-stretch md:items-center justify-between">
            <div className="relative flex-1">
              <Search size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                placeholder="Search reviews by user name or keyword..."
                value={feedbackSearch}
                onChange={(e) => setFeedbackSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-bg border border-border rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-accent"
              />
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0">
              <span className="text-[10px] uppercase tracking-wider text-slate-500 font-mono mr-1">Filter:</span>
              {(['ALL', '5', '4', '3', '1-2'] as const).map((star) => (
                <button
                  key={star}
                  onClick={() => setRatingFilter(star)}
                  className={`px-3 py-1.5 rounded-lg text-[11px] font-bold font-mono transition-all ${
                    ratingFilter === star
                      ? 'bg-accent text-white'
                      : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {star === 'ALL' ? 'All Stars' : `${star} ★`}
                </button>
              ))}
            </div>
          </div>

          {/* Feedbacks Grid */}
          {filteredFeedbacks.length === 0 ? (
            <div className="p-12 text-center rounded-2xl bg-card border border-dashed border-border space-y-3">
              <MessageSquare size={24} className="text-slate-500 mx-auto" />
              <p className="text-slate-400 text-xs">No feedback matches your current search or rating filter.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredFeedbacks.map((f) => (
                <div
                  key={f.id}
                  className="bg-card border border-border rounded-2xl p-5 flex flex-col justify-between space-y-4 hover:border-accent/30 transition-all"
                >
                  <div>
                    {/* Header with Star Rating & Actions */}
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-1 text-amber-400 mb-1.5">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star
                              key={i}
                              size={14}
                              fill={i < (f.rating || 5) ? 'currentColor' : 'none'}
                              className={i < (f.rating || 5) ? 'text-amber-400' : 'text-slate-600'}
                            />
                          ))}
                          <span className="text-xs font-mono font-bold text-slate-400 ml-1.5">
                            {f.rating || 5}.0
                          </span>
                        </div>
                        <h4 className="font-bold text-white text-sm">
                          {f.name || 'Anonymous User'}
                        </h4>
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleOpenEditFeedback(f)}
                          className="p-1.5 rounded-lg bg-white/5 hover:bg-accent/20 text-slate-400 hover:text-accent transition-colors"
                          title="Edit Customer Feedback"
                        >
                          <Edit2 size={13} />
                        </button>
                        <button
                          onClick={() => handleDeleteFeedback(f.id, f.name || 'User')}
                          className="p-1.5 rounded-lg bg-white/5 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition-colors"
                          title="Delete Feedback"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </div>

                    {/* Review Message */}
                    <p className="text-xs md:text-sm text-slate-300 leading-relaxed mt-2 bg-bg p-3 rounded-xl border border-border/60">
                      "{f.msg}"
                    </p>
                  </div>

                  {/* Timestamp Footer */}
                  <div className="text-[10px] font-mono text-slate-500 flex justify-between items-center pt-2 border-t border-border/60">
                    <span>Submitted: <strong className="text-slate-400">{f.time || 'Recent'}</strong></span>
                    <span className="text-slate-500">ID: {f.id.slice(0, 8)}...</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </motion.div>
      )}

      {/* --- MODAL: ADD / EDIT FEATURED TESTIMONIAL --- */}
      <AnimatePresence>
        {isTestimonialModalOpen && (
          <div className="fixed inset-0 z-[1100] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-card border border-border rounded-3xl max-w-lg w-full p-6 md:p-8 space-y-6 shadow-2xl relative"
            >
              <div className="flex justify-between items-center border-b border-border pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-xl bg-accent/10 text-accent">
                    <Quote size={18} />
                  </div>
                  <h3 className="text-lg font-bold text-white">
                    {editingTestimonial ? 'Edit Featured Testimonial' : 'Add Featured Testimonial'}
                  </h3>
                </div>
                <button
                  onClick={() => setIsTestimonialModalOpen(false)}
                  className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white"
                >
                  <X size={16} />
                </button>
              </div>

              <form onSubmit={handleSaveTestimonial} className="space-y-4 text-left">
                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-slate-300 block mb-1.5">
                    Client or Organization Name <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Apex Gaming Community or Rohan Sharma"
                    value={testimonialForm.name}
                    onChange={(e) => setTestimonialForm({ ...testimonialForm, name: e.target.value })}
                    className="w-full px-4 py-2.5 bg-bg border border-border rounded-xl text-xs text-white focus:outline-none focus:border-accent"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-slate-300 block mb-1.5">
                    Server / Service Subtitle
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Minecraft AMD RYZEN 9 5950X Dedicated Server"
                    value={testimonialForm.server}
                    onChange={(e) => setTestimonialForm({ ...testimonialForm, server: e.target.value })}
                    className="w-full px-4 py-2.5 bg-bg border border-border rounded-xl text-xs text-white focus:outline-none focus:border-accent"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-slate-300 block mb-1.5">
                    Icon Badge Type
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {[
                      { id: 'zap', label: 'Ultra (⚡)', icon: Zap, color: 'text-amber-400' },
                      { id: 'game', label: 'Gaming (🎮)', icon: Gamepad2, color: 'text-accent' },
                      { id: 'rocket', label: 'Rocket (🚀)', icon: Rocket, color: 'text-indigo-400' },
                      { id: 'server', label: 'Server (🖥️)', icon: Server, color: 'text-emerald-400' },
                    ].map((iconItem) => (
                      <button
                        type="button"
                        key={iconItem.id}
                        onClick={() => setTestimonialForm({ ...testimonialForm, logo: iconItem.id })}
                        className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 text-xs transition-all ${
                          testimonialForm.logo === iconItem.id
                            ? 'bg-accent/20 border-accent text-white font-bold'
                            : 'bg-bg border-border text-slate-400 hover:border-accent/40'
                        }`}
                      >
                        <iconItem.icon size={18} className={iconItem.color} />
                        <span className="text-[10px]">{iconItem.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-slate-300 block mb-1.5">
                    Testimonial Quote / Review <span className="text-rose-400">*</span>
                  </label>
                  <textarea
                    required
                    rows={4}
                    placeholder="Write the customer's review or endorsement here..."
                    value={testimonialForm.note}
                    onChange={(e) => setTestimonialForm({ ...testimonialForm, note: e.target.value })}
                    className="w-full px-4 py-2.5 bg-bg border border-border rounded-xl text-xs text-white focus:outline-none focus:border-accent resize-none leading-relaxed"
                  />
                  <span className="text-[10px] text-slate-500 font-mono block text-right mt-1">
                    {testimonialForm.note.length} characters
                  </span>
                </div>

                <div className="flex justify-end gap-3 pt-4 border-t border-border">
                  <button
                    type="button"
                    onClick={() => setIsTestimonialModalOpen(false)}
                    className="px-5 py-2.5 rounded-xl border border-white/10 text-slate-300 hover:text-white text-xs font-bold uppercase tracking-wider"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="px-6 py-2.5 bg-gradient-to-r from-accent to-indigo-600 hover:opacity-90 text-white rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-accent/20 disabled:opacity-50"
                  >
                    {isSaving ? <RefreshCw size={14} className="animate-spin" /> : <Check size={14} />}
                    {editingTestimonial ? 'Update Review' : 'Save to Showcase'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- MODAL: ADD / EDIT PUBLIC FEEDBACK --- */}
      <AnimatePresence>
        {isFeedbackModalOpen && (
          <div className="fixed inset-0 z-[1100] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-card border border-border rounded-3xl max-w-lg w-full p-6 md:p-8 space-y-6 shadow-2xl relative"
            >
              <div className="flex justify-between items-center border-b border-border pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-xl bg-accent/10 text-accent">
                    <Star size={18} className="text-amber-400" />
                  </div>
                  <h3 className="text-lg font-bold text-white">
                    {editingFeedback ? 'Edit Customer Feedback' : 'Add Verified Feedback'}
                  </h3>
                </div>
                <button
                  onClick={() => setIsFeedbackModalOpen(false)}
                  className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white"
                >
                  <X size={16} />
                </button>
              </div>

              <form onSubmit={handleSaveFeedback} className="space-y-4 text-left">
                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-slate-300 block mb-1.5">
                    Reviewer Name
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Alex M. or Verified Client"
                    value={feedbackForm.name}
                    onChange={(e) => setFeedbackForm({ ...feedbackForm, name: e.target.value })}
                    className="w-full px-4 py-2.5 bg-bg border border-border rounded-xl text-xs text-white focus:outline-none focus:border-accent"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-slate-300 block mb-1.5">
                    Star Rating (1 to 5 Stars)
                  </label>
                  <div className="flex items-center gap-2 p-3 bg-bg border border-border rounded-xl">
                    {[1, 2, 3, 4, 5].map((starVal) => (
                      <button
                        type="button"
                        key={starVal}
                        onClick={() => setFeedbackForm({ ...feedbackForm, rating: starVal })}
                        className="p-1 hover:scale-125 transition-transform"
                      >
                        <Star
                          size={24}
                          fill={starVal <= feedbackForm.rating ? '#f59e0b' : 'none'}
                          className={starVal <= feedbackForm.rating ? 'text-amber-400' : 'text-slate-600'}
                        />
                      </button>
                    ))}
                    <span className="text-xs font-mono font-bold text-amber-400 ml-3">
                      {feedbackForm.rating} / 5 Stars
                    </span>
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-slate-300 block mb-1.5">
                    Date / Time Label
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Sep 17, 2026 or Just now"
                    value={feedbackForm.time}
                    onChange={(e) => setFeedbackForm({ ...feedbackForm, time: e.target.value })}
                    className="w-full px-4 py-2.5 bg-bg border border-border rounded-xl text-xs text-white focus:outline-none focus:border-accent font-mono"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-slate-300 block mb-1.5">
                    Feedback Message <span className="text-rose-400">*</span>
                  </label>
                  <textarea
                    required
                    rows={4}
                    placeholder="Write the customer's comment or review..."
                    value={feedbackForm.msg}
                    onChange={(e) => setFeedbackForm({ ...feedbackForm, msg: e.target.value })}
                    className="w-full px-4 py-2.5 bg-bg border border-border rounded-xl text-xs text-white focus:outline-none focus:border-accent resize-none leading-relaxed"
                  />
                </div>

                <div className="flex justify-end gap-3 pt-4 border-t border-border">
                  <button
                    type="button"
                    onClick={() => setIsFeedbackModalOpen(false)}
                    className="px-5 py-2.5 rounded-xl border border-white/10 text-slate-300 hover:text-white text-xs font-bold uppercase tracking-wider"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="px-6 py-2.5 bg-gradient-to-r from-accent to-indigo-600 hover:opacity-90 text-white rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-accent/20 disabled:opacity-50"
                  >
                    {isSaving ? <RefreshCw size={14} className="animate-spin" /> : <Check size={14} />}
                    {editingFeedback ? 'Update Feedback' : 'Save Feedback'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
