import React, { useState, useEffect } from 'react';
import { 
  Users, 
  FileText, 
  Box, 
  Settings, 
  Search, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  MoreVertical,
  ExternalLink,
  ShieldCheck,
  Loader2,
  Save,
  AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { adminService } from '../../services/adminService';
import { Invoice, UserService, UserProfile, Settings as SiteSettings } from '../../types';

export const AdminSection: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'users' | 'invoices' | 'orders' | 'config'>('users');
  const [loading, setLoading] = useState(true);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [orders, setOrders] = useState<UserService[]>([]);
  const [config, setConfig] = useState<SiteSettings | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  useEffect(() => {
    fetchData();
  }, [activeSubTab]);

  const fetchData = async () => {
    setLoading(true);
    try {
      if (activeSubTab === 'users') {
        const data = await adminService.getAllUsers();
        setUsers(data);
      } else if (activeSubTab === 'invoices') {
        const data = await adminService.getAllInvoices();
        setInvoices(data);
      } else if (activeSubTab === 'orders') {
        const data = await adminService.getAllServices();
        setOrders(data);
      } else if (activeSubTab === 'config') {
        const data = await adminService.getConfig();
        setConfig(data);
      }
    } catch (error) {
      console.error('Error fetching admin data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyInvoice = async (invoiceId: string) => {
    setActionLoading(invoiceId);
    try {
      await adminService.updateInvoiceStatus(invoiceId, 'Paid');
      // Update local state
      setInvoices(prev => prev.map(inv => inv.id === invoiceId ? { ...inv, status: 'Paid' } : inv));
    } catch (error) {
      console.error('Error verifying invoice:', error);
    } finally {
      setActionLoading(null);
    }
  };

  const handleCancelInvoice = async (invoiceId: string) => {
    setActionLoading(invoiceId);
    try {
      await adminService.updateInvoiceStatus(invoiceId, 'Cancelled');
      setInvoices(prev => prev.map(inv => inv.id === invoiceId ? { ...inv, status: 'Cancelled' } : inv));
    } catch (error) {
      console.error('Error cancelling invoice:', error);
    } finally {
      setActionLoading(null);
    }
  };

  const subTabs = [
    { id: 'users', label: 'Users', icon: Users },
    { id: 'invoices', label: 'Invoices', icon: FileText },
    { id: 'orders', label: 'Service Orders', icon: Box },
    { id: 'config', label: 'Configuration', icon: Settings },
  ];

  return (
    <div className="space-y-8">
      {/* Sub-navigation */}
      <div className="flex gap-4 p-1 bg-bg-alt border border-border rounded-xl w-fit">
        {subTabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveSubTab(tab.id as any)}
            className={`px-6 py-2.5 rounded-lg text-[10px] font-black uppercase tracking-widest flex items-center gap-3 transition-all ${
              activeSubTab === tab.id 
                ? 'bg-bg text-accent shadow-sm' 
                : 'text-foreground-dim hover:text-foreground hover:bg-bg/50'
            }`}
          >
            <tab.icon size={14} />
            {tab.label}
          </button>
        ))}
      </div>

      <div className="bg-bg-alt border border-border rounded-2xl overflow-hidden min-h-[500px]">
        {/* Toolbar */}
        <div className="p-6 border-b border-border bg-bg/30 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-foreground-dim" size={14} />
            <input 
              type="text" 
              placeholder={`Search ${activeSubTab}...`}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-bg border border-border rounded-lg text-[10px] font-bold text-foreground focus:border-accent outline-none transition-all"
            />
          </div>
          <button 
            onClick={fetchData}
            className="px-4 py-2 bg-bg border border-border rounded-lg text-[10px] font-black uppercase tracking-widest text-foreground-dim hover:text-foreground transition-all flex items-center gap-2"
          >
            <Clock size={12} /> Refresh Data
          </button>
        </div>

        {/* Content Area */}
        <div className="p-6">
          {loading ? (
            <div className="h-64 flex flex-col items-center justify-center gap-4">
              <Loader2 className="w-8 h-8 animate-spin text-accent" />
              <div className="text-[10px] font-black uppercase tracking-widest text-foreground-dim">Fetching latest data...</div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeSubTab}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                >
                  {activeSubTab === 'users' && (
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="px-4 py-4 text-[10px] font-black uppercase tracking-widest text-foreground-dim">User Info</th>
                          <th className="px-4 py-4 text-[10px] font-black uppercase tracking-widest text-foreground-dim">Role</th>
                          <th className="px-4 py-4 text-[10px] font-black uppercase tracking-widest text-foreground-dim">Created At</th>
                          <th className="px-4 py-4 text-[10px] font-black uppercase tracking-widest text-foreground-dim text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {users.filter(u => u.email.toLowerCase().includes(searchTerm.toLowerCase())).map(user => (
                          <tr key={user.id} className="hover:bg-bg/20 transition-colors">
                            <td className="px-4 py-4">
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-lg bg-accent/10 flex items-center justify-center text-accent font-black text-[10px]">
                                  {user.email[0].toUpperCase()}
                                </div>
                                <div>
                                  <div className="text-[11px] font-black text-foreground">{user.displayName || 'Anonymous'}</div>
                                  <div className="text-[10px] font-bold text-foreground-dim">{user.email}</div>
                                </div>
                              </div>
                            </td>
                            <td className="px-4 py-4">
                              <span className={`px-2 py-1 rounded text-[9px] font-black uppercase tracking-widest ${
                                user.role === 'admin' ? 'bg-amber-500/10 text-amber-500' : 'bg-bg text-foreground-dim border border-border'
                              }`}>
                                {user.role}
                              </span>
                            </td>
                            <td className="px-4 py-4 text-[11px] font-bold text-foreground-muted">
                              {new Date(user.createdAt).toLocaleDateString()}
                            </td>
                            <td className="px-4 py-4 text-right">
                              <button className="p-2 hover:bg-bg rounded-lg text-foreground-dim hover:text-foreground">
                                <MoreVertical size={16} />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}

                  {activeSubTab === 'invoices' && (
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="px-4 py-4 text-[10px] font-black uppercase tracking-widest text-foreground-dim">Invoice</th>
                          <th className="px-4 py-4 text-[10px] font-black uppercase tracking-widest text-foreground-dim">User ID</th>
                          <th className="px-4 py-4 text-[10px] font-black uppercase tracking-widest text-foreground-dim">Total</th>
                          <th className="px-4 py-4 text-[10px] font-black uppercase tracking-widest text-foreground-dim">Status</th>
                          <th className="px-4 py-4 text-[10px] font-black uppercase tracking-widest text-foreground-dim text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {invoices.filter(i => i.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase())).map(invoice => (
                          <tr key={invoice.id} className="hover:bg-bg/20 transition-colors">
                            <td className="px-4 py-4">
                              <div className="text-[11px] font-black text-foreground">{invoice.invoiceNumber}</div>
                              <div className="text-[9px] font-bold text-foreground-dim uppercase">{new Date(invoice.timestamp).toLocaleString()}</div>
                            </td>
                            <td className="px-4 py-4 text-[11px] font-bold text-foreground-muted font-mono">{invoice.userId.slice(0, 8)}...</td>
                            <td className="px-4 py-4 text-[11px] font-black text-foreground">{invoice.total}</td>
                            <td className="px-4 py-4">
                              <span className={`px-2 py-1 rounded text-[9px] font-black uppercase tracking-widest flex items-center gap-2 w-fit ${
                                invoice.status === 'Paid' ? 'bg-emerald-500/10 text-emerald-500' : 
                                invoice.status === 'Cancelled' ? 'bg-rose-500/10 text-rose-500' :
                                'bg-amber-500/10 text-amber-500 animate-pulse'
                              }`}>
                                {invoice.status === 'Paid' ? <CheckCircle2 size={10} /> : <Clock size={10} />}
                                {invoice.status === 'Unpaid' ? 'Pending Verification' : invoice.status}
                              </span>
                            </td>
                            <td className="px-4 py-4 text-right">
                              <div className="flex items-center justify-end gap-2">
                                {invoice.status === 'Unpaid' && (
                                  <>
                                    <button 
                                      onClick={() => handleVerifyInvoice(invoice.id)}
                                      disabled={!!actionLoading}
                                      className="p-2 bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500 hover:text-white rounded-lg transition-all"
                                      title="Mark as Paid & Verify"
                                    >
                                      {actionLoading === invoice.id ? <Loader2 size={14} className="animate-spin" /> : <ShieldCheck size={14} />}
                                    </button>
                                    <button 
                                      onClick={() => handleCancelInvoice(invoice.id)}
                                      disabled={!!actionLoading}
                                      className="p-2 bg-rose-500/10 text-rose-500 hover:bg-rose-500 hover:text-white rounded-lg transition-all"
                                      title="Cancel Invoice"
                                    >
                                      <XCircle size={14} />
                                    </button>
                                  </>
                                )}
                                <button className="p-2 hover:bg-bg rounded-lg text-foreground-dim hover:text-foreground">
                                  <ExternalLink size={14} />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}

                  {activeSubTab === 'orders' && (
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="px-4 py-4 text-[10px] font-black uppercase tracking-widest text-foreground-dim">Service</th>
                          <th className="px-4 py-4 text-[10px] font-black uppercase tracking-widest text-foreground-dim">User</th>
                          <th className="px-4 py-4 text-[10px] font-black uppercase tracking-widest text-foreground-dim">Status</th>
                          <th className="px-4 py-4 text-[10px] font-black uppercase tracking-widest text-foreground-dim">Expires</th>
                          <th className="px-4 py-4 text-[10px] font-black uppercase tracking-widest text-foreground-dim text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {orders.map(service => (
                          <tr key={service.id} className="hover:bg-bg/20 transition-colors">
                            <td className="px-4 py-4">
                              <div className="text-[11px] font-black text-foreground">{service.name}</div>
                              <div className="text-[9px] font-bold text-foreground-dim uppercase tracking-widest">{service.nodeName} • {service.location}</div>
                            </td>
                            <td className="px-4 py-4 text-[11px] font-bold text-foreground-muted font-mono">{service.userId.slice(0, 8)}...</td>
                            <td className="px-4 py-4">
                              <span className={`px-2 py-1 rounded text-[9px] font-black uppercase tracking-widest ${
                                service.status === 'active' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-amber-500/10 text-amber-500'
                              }`}>
                                {service.status}
                              </span>
                            </td>
                            <td className="px-4 py-4 text-[11px] font-bold text-foreground-muted">
                              {new Date(service.expiresAt).toLocaleDateString()}
                            </td>
                            <td className="px-4 py-4 text-right">
                              <button className="p-2 hover:bg-bg rounded-lg text-foreground-dim hover:text-foreground">
                                <Settings size={14} />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}

                  {activeSubTab === 'config' && config && (
                    <div className="max-w-2xl space-y-8 py-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div className="space-y-4">
                          <label className="text-[10px] font-black uppercase tracking-widest text-foreground-dim">Site Name</label>
                          <input 
                            type="text" 
                            value={config.site_name}
                            onChange={(e) => setConfig({...config, site_name: e.target.value})}
                            className="w-full px-4 py-3 bg-bg border border-border rounded-xl text-[12px] font-bold text-foreground focus:border-accent outline-none"
                          />
                        </div>
                        <div className="space-y-4">
                          <label className="text-[10px] font-black uppercase tracking-widest text-foreground-dim">Primary UPI ID</label>
                          <input 
                            type="text" 
                            value={config.upi_id || ''}
                            onChange={(e) => setConfig({...config, upi_id: e.target.value})}
                            className="w-full px-4 py-3 bg-bg border border-border rounded-xl text-[12px] font-bold text-foreground focus:border-accent outline-none"
                          />
                        </div>
                      </div>

                      <div className="space-y-4">
                        <label className="text-[10px] font-black uppercase tracking-widest text-foreground-dim">Announcement Text</label>
                        <textarea 
                          value={config.announcement_text || ''}
                          onChange={(e) => setConfig({...config, announcement_text: e.target.value})}
                          className="w-full px-4 py-3 bg-bg border border-border rounded-xl text-[12px] font-bold text-foreground focus:border-accent outline-none h-24 resize-none"
                        />
                      </div>

                      <div className="flex items-center justify-between p-6 bg-bg border border-border rounded-2xl">
                        <div>
                          <div className="text-[11px] font-black uppercase tracking-widest text-foreground">Maintenance Mode</div>
                          <div className="text-[10px] font-bold text-foreground-dim uppercase">Enable to disable public access to the storefront</div>
                        </div>
                        <button 
                          onClick={() => setConfig({...config, maintenance_mode: !config.maintenance_mode})}
                          className={`w-12 h-6 rounded-full transition-all relative ${config.maintenance_mode ? 'bg-accent' : 'bg-border'}`}
                        >
                          <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${config.maintenance_mode ? 'right-1' : 'left-1'}`} />
                        </button>
                      </div>

                      <button 
                        onClick={() => adminService.updateConfig(config)}
                        className="px-8 py-4 bg-accent text-white text-[11px] font-black uppercase tracking-[0.2em] rounded-xl shadow-xl shadow-accent/20 hover:bg-accent-muted transition-all flex items-center gap-3"
                      >
                        <Save size={16} /> Save Configuration
                      </button>
                    </div>
                  )}
                </motion.div>
              </AnimatePresence>
            </div>
          )}
        </div>
      </div>

      {activeSubTab === 'invoices' && invoices.some(i => i.status === 'Unpaid') && (
        <div className="p-6 bg-amber-500/10 border border-amber-500/20 rounded-2xl flex items-start gap-4">
          <AlertCircle className="text-amber-500 mt-1" size={20} />
          <div>
            <div className="text-[11px] font-black uppercase tracking-widest text-amber-500 mb-1">Attention Required</div>
            <p className="text-[10px] font-bold text-foreground-dim uppercase tracking-widest leading-relaxed">
              There are pending UPI payments that require manual verification. Please check your bank statements and verify the transaction references before marking an invoice as paid.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
