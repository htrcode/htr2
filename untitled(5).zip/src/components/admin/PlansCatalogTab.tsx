import React, { useState } from 'react';
import { 
  Layers, Plus, Edit2, Trash2, ArrowUp, ArrowDown, 
  MapPin, CheckCircle2, AlertTriangle, ExternalLink, Box, Eye
} from 'lucide-react';
import { Plan, AppData, UserService, Invoice } from '../../types';

interface PlansCatalogTabProps {
  localData: AppData;
  setLocalData: React.Dispatch<React.SetStateAction<AppData>>;
  orders: UserService[];
  invoices: Invoice[];
  onOpenCreatePlan: () => void;
  onOpenEditPlan: (plan: Plan) => void;
  onMovePlan: (planId: string, direction: 'up' | 'down') => Promise<void>;
  onDeletePlan: (planId: string) => Promise<void>;
  onAddCategory: (categoryName: string) => Promise<void>;
  onDeleteCategory: (categoryName: string) => Promise<void>;
  onAddLocation: (locationName: string) => Promise<void>;
  onDeleteLocation: (locationName: string) => Promise<void>;
  onNavigateToOrders: (planName: string) => void;
  isSaving: boolean;
}

export const PlansCatalogTab: React.FC<PlansCatalogTabProps> = ({
  localData,
  setLocalData,
  orders,
  invoices,
  onOpenCreatePlan,
  onOpenEditPlan,
  onMovePlan,
  onDeletePlan,
  onAddCategory,
  onDeleteCategory,
  onAddLocation,
  onDeleteLocation,
  onNavigateToOrders,
  isSaving
}) => {
  const [newCat, setNewCat] = useState('');
  const [newLoc, setNewLoc] = useState('');

  // Check how many orders are linked to a plan
  const getLinkedOrdersCount = (plan: Plan) => {
    return orders.filter(o => o.planId === plan.id || o.name === plan.name).length;
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm">
        <div>
          <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
            <Layers size={18} className="text-amber-400" />
            Hosting Products & Catalog Plans
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Configure server tiers, hardware specifications, and live pricing. Product deletions are protected to prevent orphaning active client servers.
          </p>
        </div>
        <button
          onClick={onOpenCreatePlan}
          className="px-3.5 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-sm"
        >
          <Plus size={14} />
          <span>+ Add Hosting Plan</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Sidebar: Categories & Datacenters (4 cols) */}
        <div className="lg:col-span-4 space-y-6">
          {/* Categories Manager */}
          <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 space-y-4 shadow-sm">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              1. Product Categories
            </h3>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="e.g. RYZEN-VPS"
                value={newCat}
                onChange={(e) => setNewCat(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && newCat.trim()) {
                    onAddCategory(newCat.trim());
                    setNewCat('');
                  }
                }}
                className="flex-1 px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white uppercase outline-none focus:border-amber-500"
              />
              <button
                onClick={() => {
                  if (newCat.trim()) {
                    onAddCategory(newCat.trim());
                    setNewCat('');
                  }
                }}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold"
              >
                Add
              </button>
            </div>
            <div className="flex flex-wrap gap-1.5 pt-1">
              {localData.categories?.map(cat => (
                <span
                  key={cat}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-[11px] font-mono text-slate-300"
                >
                  <span>{cat}</span>
                  <button
                    onClick={() => onDeleteCategory(cat)}
                    className="text-slate-500 hover:text-rose-400 p-0.5"
                    title="Delete Category"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          </div>

          {/* Datacenters Manager */}
          <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 space-y-4 shadow-sm">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              2. Datacenter Locations
            </h3>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="e.g. India (Mumbai)"
                value={newLoc}
                onChange={(e) => setNewLoc(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && newLoc.trim()) {
                    onAddLocation(newLoc.trim());
                    setNewLoc('');
                  }
                }}
                className="flex-1 px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white outline-none focus:border-amber-500"
              />
              <button
                onClick={() => {
                  if (newLoc.trim()) {
                    onAddLocation(newLoc.trim());
                    setNewLoc('');
                  }
                }}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold"
              >
                Add
              </button>
            </div>
            <div className="flex flex-wrap gap-1.5 pt-1">
              {localData.locations?.map(loc => (
                <span
                  key={loc}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-[11px] font-mono text-slate-300"
                >
                  <MapPin size={10} className="text-amber-400" />
                  <span>{loc}</span>
                  <button
                    onClick={() => onDeleteLocation(loc)}
                    className="text-slate-500 hover:text-rose-400 p-0.5"
                    title="Delete Location"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Plans List Grouped by Category (8 cols) */}
        <div className="lg:col-span-8 space-y-6">
          {localData.categories?.map(categoryName => {
            const plansInCategory = (localData.plans?.filter(p => (p.category || '').toUpperCase() === categoryName.toUpperCase()) || [])
              .sort((a, b) => (a.order || 0) - (b.order || 0));

            return (
              <div key={categoryName} className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden shadow-sm">
                {/* Category Header */}
                <div className="p-4 bg-slate-900/80 border-b border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white text-xs uppercase tracking-wider">{categoryName}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300 font-mono">
                      {plansInCategory.length} plans
                    </span>
                  </div>
                </div>

                {/* Plans List */}
                <div className="divide-y divide-slate-800">
                  {plansInCategory.map((plan, idx) => {
                    const linkedOrders = getLinkedOrdersCount(plan);
                    const isActive = plan.is_active !== false && !plan.archived;

                    return (
                      <div key={plan.id} className="p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:bg-slate-850/40 transition-colors">
                        <div className="min-w-0 flex-1 space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <h4 className="text-sm font-bold text-white">{plan.name}</h4>
                            <span className="font-mono text-xs font-bold text-amber-400">
                              ₹{plan.price_inr || plan.price}/mo
                            </span>
                            {plan.badge && (
                              <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                                {plan.badge}
                              </span>
                            )}
                            {isActive ? (
                              <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                                Active
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-800 text-slate-400">
                                Archived
                              </span>
                            )}
                            {linkedOrders > 0 ? (
                              <button
                                onClick={() => onNavigateToOrders(plan.name)}
                                className="px-2 py-0.5 rounded text-[10px] font-semibold bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/20 flex items-center gap-1 transition-colors"
                                title="Click to view client services linked to this plan"
                              >
                                <Box size={10} />
                                <span>{linkedOrders} {linkedOrders === 1 ? 'Service' : 'Services'}</span>
                                <ExternalLink size={9} />
                              </button>
                            ) : (
                              <span className="text-[10px] text-slate-500">0 Services</span>
                            )}
                          </div>

                          <div className="text-xs text-slate-400 flex flex-wrap items-center gap-x-3 gap-y-1 font-mono text-[11px]">
                            {plan.cpu && <span>CPU: {plan.cpu}</span>}
                            {plan.ram && <span>RAM: {plan.ram}</span>}
                            {plan.storage && <span>Disk: {plan.storage}</span>}
                            {plan.location && (
                              <span className="flex items-center gap-1">
                                <MapPin size={10} className="text-slate-500" />
                                {plan.location}
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-1.5 self-end sm:self-auto shrink-0">
                          <button
                            onClick={() => onMovePlan(plan.id, 'up')}
                            disabled={idx === 0 || isSaving}
                            className="p-1.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-30 text-slate-300 rounded transition-colors"
                            title="Move Up"
                          >
                            <ArrowUp size={12} />
                          </button>
                          <button
                            onClick={() => onMovePlan(plan.id, 'down')}
                            disabled={idx === plansInCategory.length - 1 || isSaving}
                            className="p-1.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-30 text-slate-300 rounded transition-colors"
                            title="Move Down"
                          >
                            <ArrowDown size={12} />
                          </button>
                          <button
                            onClick={() => onOpenEditPlan(plan)}
                            className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs font-medium transition-colors flex items-center gap-1"
                          >
                            <Edit2 size={12} /> Edit
                          </button>
                          <button
                            onClick={() => onDeletePlan(plan.id)}
                            disabled={isSaving}
                            className="p-1 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded transition-colors"
                            title={linkedOrders > 0 ? 'Protected from deletion: active orders linked' : 'Delete Plan'}
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                  {plansInCategory.length === 0 && (
                    <div className="p-6 text-center text-xs text-slate-500">
                      No plans configured in this category. Click "+ Add Hosting Plan" to create one.
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
