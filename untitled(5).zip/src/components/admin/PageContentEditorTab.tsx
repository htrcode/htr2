import React, { useState, useEffect, useRef } from 'react';
import { 
  FileText, Shield, RotateCcw, Building2, Server, Scale, 
  Plus, Trash2, ArrowUp, ArrowDown, Sparkles, Layers
} from 'lucide-react';
import { 
  parsePolicyMarkdown, serializePolicyMarkdown,
  parseAboutMarkdown, serializeAboutMarkdown, ParsedAbout,
  parseInfrastructureMarkdown, serializeInfrastructureMarkdown, ParsedInfrastructure,
  parseLegalMarkdown, serializeLegalMarkdown, ParsedLegal
} from '../../lib/policyParser';
import { DEFAULT_DATA } from '../../constants';
import { FormattedMarkdown } from '../FormattedMarkdown';

interface PageContentEditorTabProps {
  pageType: 'tos' | 'privacy' | 'refund' | 'about' | 'infrastructure' | 'legal';
  value: string;
  onChange: (newValue: string) => void;
}

export const PageContentEditorTab: React.FC<PageContentEditorTabProps> = ({ 
  pageType, 
  value, 
  onChange
}) => {
  // Policy pages state (tos, privacy, refund)
  const [policyTitle, setPolicyTitle] = useState('');
  const [policySubtitle, setPolicySubtitle] = useState('');
  const [policySections, setPolicySections] = useState<{ title: string; content: string }[]>([]);

  // About page state
  const [aboutState, setAboutState] = useState<ParsedAbout>({
    title: '',
    subtitle: '',
    mission: '',
    philosophy: '',
    values: [],
    milestones: []
  });

  // Infrastructure page state
  const [infraState, setInfraState] = useState<ParsedInfrastructure>({
    title: '',
    subtitle: '',
    datacenter: '',
    peering: '',
    latencyTarget: '',
    specs: [],
    hardwareStack: [],
    sections: []
  });

  // Legal page state
  const [legalState, setLegalState] = useState<ParsedLegal>({
    title: '',
    subtitle: '',
    entityName: '',
    jurisdiction: '',
    complianceList: [],
    sections: []
  });

  const lastPageTypeRef = useRef<string | null>(null);
  const isSyncingRef = useRef(false);

  // Sync state when pageType changes or initial load
  useEffect(() => {
    if (lastPageTypeRef.current !== pageType) {
      lastPageTypeRef.current = pageType;
      isSyncingRef.current = true;

      if (pageType === 'tos' || pageType === 'privacy' || pageType === 'refund') {
        const defaultTitles: Record<string, string> = {
          tos: 'Terms of Service',
          privacy: 'Privacy Policy',
          refund: 'Refund Policy'
        };
        const parsed = parsePolicyMarkdown(value, defaultTitles[pageType]);
        setPolicyTitle(parsed.title);
        setPolicySubtitle(parsed.subtitle);
        setPolicySections(parsed.sections.map(s => ({ title: s.title, content: s.content })));
      } else if (pageType === 'about') {
        setAboutState(parseAboutMarkdown(value));
      } else if (pageType === 'infrastructure') {
        setInfraState(parseInfrastructureMarkdown(value));
      } else if (pageType === 'legal') {
        setLegalState(parseLegalMarkdown(value));
      }

      setTimeout(() => {
        isSyncingRef.current = false;
      }, 50);
    }
  }, [pageType, value]);

  // Auto-emit changes up to parent localData whenever fields change
  useEffect(() => {
    if (isSyncingRef.current) return;

    let serialized = '';
    if (pageType === 'tos' || pageType === 'privacy' || pageType === 'refund') {
      serialized = serializePolicyMarkdown(policyTitle, policySubtitle, policySections);
    } else if (pageType === 'about') {
      serialized = serializeAboutMarkdown(aboutState);
    } else if (pageType === 'infrastructure') {
      serialized = serializeInfrastructureMarkdown(infraState);
    } else if (pageType === 'legal') {
      serialized = serializeLegalMarkdown(legalState);
    }

    if (serialized) {
      onChange(serialized);
    }
  }, [policyTitle, policySubtitle, policySections, aboutState, infraState, legalState, pageType]);

  // Section helper functions for Policy/Infra/Legal pages
  const addPolicySection = () => {
    setPolicySections(prev => [...prev, { title: 'New Section Title', content: 'Enter section content details here...' }]);
  };

  const updatePolicySection = (index: number, field: 'title' | 'content', val: string) => {
    setPolicySections(prev => {
      const updated = [...prev];
      updated[index][field] = val;
      return updated;
    });
  };

  const removePolicySection = (index: number) => {
    setPolicySections(prev => prev.filter((_, i) => i !== index));
  };

  const movePolicySection = (index: number, direction: 'up' | 'down') => {
    setPolicySections(prev => {
      const updated = [...prev];
      const targetIndex = direction === 'up' ? index - 1 : index + 1;
      if (targetIndex < 0 || targetIndex >= updated.length) return prev;
      const temp = updated[index];
      updated[index] = updated[targetIndex];
      updated[targetIndex] = temp;
      return updated;
    });
  };

  const pageMeta = {
    tos: { title: 'Terms of Service (/tos)', icon: FileText, color: 'text-accent' },
    privacy: { title: 'Privacy Policy (/privacy)', icon: Shield, color: 'text-indigo-400' },
    refund: { title: 'Refund Policy (/refund)', icon: RotateCcw, color: 'text-emerald-400' },
    about: { title: 'About Us (/about)', icon: Building2, color: 'text-amber-400' },
    infrastructure: { title: 'Infrastructure (/infrastructure)', icon: Server, color: 'text-cyan-400' },
    legal: { title: 'Legal Notices (/legal)', icon: Scale, color: 'text-rose-400' }
  }[pageType];

  const IconComp = pageMeta.icon;

  return (
    <div className="space-y-8 max-w-5xl">
      
      {/* Top Banner Header */}
      <div className="bg-card border border-border p-6 sm:p-8 rounded-3xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 shadow-xl relative overflow-hidden">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-accent/20 border border-accent/30 rounded-2xl flex items-center justify-center text-accent">
            <IconComp size={24} className={pageMeta.color} />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white uppercase tracking-tight">{pageMeta.title}</h3>
            <p className="text-xs text-slate-400 mt-0.5">Edit page fields below. Click "SAVE ALL CONFIG" in top right header to save changes to database.</p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0 bg-purple-950/40 border border-border/40 px-3.5 py-2 rounded-xl text-xs text-accent font-mono font-bold">
          <Sparkles size={14} className="text-accent animate-pulse" />
          <span>Use "SAVE ALL CONFIG" to Save</span>
        </div>
      </div>

      {/* POLICY PAGES (TOS, PRIVACY, REFUND) */}
      {(pageType === 'tos' || pageType === 'privacy' || pageType === 'refund') && (
        <div className="space-y-8">
          {/* Main Info Card */}
          <div className="bg-card border border-border p-6 sm:p-8 rounded-2xl space-y-6">
            <h4 className="text-xs font-bold text-accent uppercase tracking-widest border-b border-border pb-3">
              1. Main Page Header & Description
            </h4>
            <div className="space-y-4">
              <div>
                <label className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mb-1.5 block">
                  Page Headline Title
                </label>
                <input
                  type="text"
                  value={policyTitle}
                  onChange={e => setPolicyTitle(e.target.value)}
                  className="w-full bg-bg-alt border border-border rounded-xl p-3 text-xs text-white focus:border-accent outline-none font-medium"
                />
              </div>

              <div>
                <label className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mb-1.5 block">
                  Header Subtitle / Governance Summary
                </label>
                <textarea
                  rows={3}
                  value={policySubtitle}
                  onChange={e => setPolicySubtitle(e.target.value)}
                  className="w-full bg-bg-alt border border-border rounded-xl p-3 text-xs text-white focus:border-accent outline-none leading-relaxed"
                />
              </div>
            </div>
          </div>

          {/* Policy Sections Manager */}
          <div className="bg-card border border-border p-6 sm:p-8 rounded-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-border pb-3">
              <h4 className="text-xs font-bold text-accent uppercase tracking-widest">
                2. Policy Content Sections ({policySections.length})
              </h4>
              <button
                type="button"
                onClick={addPolicySection}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-accent/30 border border-accent/30 hover:bg-accent text-foreground-muted text-xs font-bold rounded-lg transition-all"
              >
                <Plus size={14} /> Add New Section
              </button>
            </div>

            <div className="space-y-6">
              {policySections.map((sec, idx) => (
                <div key={idx} className="bg-bg-alt border border-border p-6 rounded-2xl space-y-4">
                  <div className="flex items-center justify-between gap-4 border-b border-border/60 pb-3">
                    <span className="text-xs font-bold font-mono text-accent">Section {idx + 1}</span>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => movePolicySection(idx, 'up')}
                        disabled={idx === 0}
                        className="p-1 text-slate-400 hover:text-white disabled:opacity-30"
                      >
                        <ArrowUp size={14} />
                      </button>
                      <button
                        type="button"
                        onClick={() => movePolicySection(idx, 'down')}
                        disabled={idx === policySections.length - 1}
                        className="p-1 text-slate-400 hover:text-white disabled:opacity-30"
                      >
                        <ArrowDown size={14} />
                      </button>
                      <button
                        type="button"
                        onClick={() => removePolicySection(idx)}
                        className="p-1 text-red-400 hover:text-red-300 ml-2"
                        title="Delete Section"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mb-1 block">
                      Section Heading Title
                    </label>
                    <input
                      type="text"
                      value={sec.title}
                      onChange={e => updatePolicySection(idx, 'title', e.target.value)}
                      className="w-full bg-card border border-border rounded-xl p-3 text-xs text-white focus:border-accent outline-none font-bold"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-[10px] text-slate-400 uppercase tracking-widest font-bold block">
                        Section Content Text
                      </label>
                      <span className="text-[10px] text-accent font-mono font-normal">
                        Markdown Supported (* **Bold:** list items)
                      </span>
                    </div>
                    <textarea
                      rows={5}
                      value={sec.content}
                      onChange={e => updatePolicySection(idx, 'content', e.target.value)}
                      className="w-full bg-card border border-border rounded-xl p-3 text-xs text-slate-200 focus:border-accent outline-none leading-relaxed font-sans mb-3"
                    />

                    {sec.content && (
                      <div className="bg-card border border-border rounded-xl p-4 space-y-2">
                        <span className="text-[9px] font-mono font-bold uppercase tracking-widest text-accent block border-b border-border/60 pb-1">
                          Live Rendered Preview:
                        </span>
                        <div className="text-xs">
                          <FormattedMarkdown content={sec.content} />
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ABOUT US PAGE EDITOR */}
      {pageType === 'about' && (
        <div className="space-y-8">
          {/* Main Info */}
          <div className="bg-card border border-border p-6 sm:p-8 rounded-2xl space-y-6">
            <h4 className="text-xs font-bold text-accent uppercase tracking-widest border-b border-border pb-3">
              1. Hero Title & Subtitle
            </h4>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mb-1.5 block">Organization Title</label>
                <input
                  type="text"
                  value={aboutState.title}
                  onChange={e => setAboutState(prev => ({ ...prev, title: e.target.value }))}
                  className="w-full bg-bg-alt border border-border rounded-xl p-3 text-xs text-white focus:border-accent outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mb-1.5 block">Tagline / Subtitle</label>
                <input
                  type="text"
                  value={aboutState.subtitle}
                  onChange={e => setAboutState(prev => ({ ...prev, subtitle: e.target.value }))}
                  className="w-full bg-bg-alt border border-border rounded-xl p-3 text-xs text-white focus:border-accent outline-none"
                />
              </div>
            </div>
          </div>

          {/* Mission & Philosophy */}
          <div className="bg-card border border-border p-6 sm:p-8 rounded-2xl space-y-6">
            <h4 className="text-xs font-bold text-accent uppercase tracking-widest border-b border-border pb-3">
              2. Corporate Mission & Operating Philosophy
            </h4>
            <div className="space-y-4">
              <div>
                <label className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mb-1.5 block">Strategic Objective (Mission)</label>
                <textarea
                  rows={3}
                  value={aboutState.mission}
                  onChange={e => setAboutState(prev => ({ ...prev, mission: e.target.value }))}
                  className="w-full bg-bg-alt border border-border rounded-xl p-3 text-xs text-white focus:border-accent outline-none leading-relaxed"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mb-1.5 block">Operating Philosophy</label>
                <textarea
                  rows={3}
                  value={aboutState.philosophy}
                  onChange={e => setAboutState(prev => ({ ...prev, philosophy: e.target.value }))}
                  className="w-full bg-bg-alt border border-border rounded-xl p-3 text-xs text-white focus:border-accent outline-none leading-relaxed"
                />
              </div>
            </div>
          </div>

          {/* Core Values */}
          <div className="bg-card border border-border p-6 sm:p-8 rounded-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-border pb-3">
              <h4 className="text-xs font-bold text-accent uppercase tracking-widest">
                3. Foundational Pillars / Core Values ({aboutState.values.length})
              </h4>
              <button
                type="button"
                onClick={() => setAboutState(prev => ({ ...prev, values: [...prev.values, { title: 'New Value', desc: 'Description of pillar...' }] }))}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-accent/30 border border-accent/30 text-foreground-muted text-xs font-bold rounded-lg"
              >
                <Plus size={14} /> Add Pillar
              </button>
            </div>
            <div className="grid md:grid-cols-3 gap-4">
              {aboutState.values.map((val, idx) => (
                <div key={idx} className="bg-bg-alt border border-border p-4 rounded-xl space-y-3 relative">
                  <button
                    type="button"
                    onClick={() => setAboutState(prev => ({ ...prev, values: prev.values.filter((_, i) => i !== idx) }))}
                    className="absolute top-3 right-3 text-red-400 hover:text-red-300"
                  >
                    <Trash2 size={13} />
                  </button>
                  <input
                    type="text"
                    value={val.title}
                    onChange={e => {
                      const updated = [...aboutState.values];
                      updated[idx].title = e.target.value;
                      setAboutState(prev => ({ ...prev, values: updated }));
                    }}
                    className="w-full bg-card border border-border rounded-lg p-2 text-xs text-white font-bold"
                  />
                  <textarea
                    rows={3}
                    value={val.desc}
                    onChange={e => {
                      const updated = [...aboutState.values];
                      updated[idx].desc = e.target.value;
                      setAboutState(prev => ({ ...prev, values: updated }));
                    }}
                    className="w-full bg-card border border-border rounded-lg p-2 text-xs text-slate-300 leading-relaxed"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Growth Milestones */}
          <div className="bg-card border border-border p-6 sm:p-8 rounded-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-border pb-3">
              <h4 className="text-xs font-bold text-accent uppercase tracking-widest">
                4. Institutional Growth Timeline ({aboutState.milestones.length})
              </h4>
              <button
                type="button"
                onClick={() => setAboutState(prev => ({ ...prev, milestones: [...prev.milestones, { year: '2025', title: 'New Era', desc: 'Milestone description...' }] }))}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-accent/30 border border-accent/30 text-foreground-muted text-xs font-bold rounded-lg"
              >
                <Plus size={14} /> Add Milestone
              </button>
            </div>
            <div className="space-y-4">
              {aboutState.milestones.map((m, idx) => (
                <div key={idx} className="bg-bg-alt border border-border p-4 rounded-xl flex items-start gap-4">
                  <input
                    type="text"
                    value={m.year}
                    onChange={e => {
                      const updated = [...aboutState.milestones];
                      updated[idx].year = e.target.value;
                      setAboutState(prev => ({ ...prev, milestones: updated }));
                    }}
                    className="w-20 bg-card border border-border rounded-lg p-2 text-xs text-accent font-mono font-bold text-center"
                  />
                  <div className="flex-1 space-y-2">
                    <input
                      type="text"
                      value={m.title}
                      onChange={e => {
                        const updated = [...aboutState.milestones];
                        updated[idx].title = e.target.value;
                        setAboutState(prev => ({ ...prev, milestones: updated }));
                      }}
                      className="w-full bg-card border border-border rounded-lg p-2 text-xs text-white font-bold"
                    />
                    <input
                      type="text"
                      value={m.desc}
                      onChange={e => {
                        const updated = [...aboutState.milestones];
                        updated[idx].desc = e.target.value;
                        setAboutState(prev => ({ ...prev, milestones: updated }));
                      }}
                      className="w-full bg-card border border-border rounded-lg p-2 text-xs text-slate-300"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => setAboutState(prev => ({ ...prev, milestones: prev.milestones.filter((_, i) => i !== idx) }))}
                    className="text-red-400 hover:text-red-300 p-1"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* INFRASTRUCTURE PAGE EDITOR */}
      {pageType === 'infrastructure' && (
        <div className="space-y-8">
          <div className="bg-card border border-border p-6 sm:p-8 rounded-2xl space-y-6">
            <h4 className="text-xs font-bold text-accent uppercase tracking-widest border-b border-border pb-3">
              1. Infrastructure Title & Details
            </h4>
            <div className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mb-1.5 block">Main Title</label>
                  <input
                    type="text"
                    value={infraState.title}
                    onChange={e => setInfraState(prev => ({ ...prev, title: e.target.value }))}
                    className="w-full bg-bg-alt border border-border rounded-xl p-3 text-xs text-white focus:border-accent outline-none"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mb-1.5 block">Datacenter Location</label>
                  <input
                    type="text"
                    value={infraState.datacenter}
                    onChange={e => setInfraState(prev => ({ ...prev, datacenter: e.target.value }))}
                    className="w-full bg-bg-alt border border-border rounded-xl p-3 text-xs text-white focus:border-accent outline-none"
                  />
                </div>
              </div>
              <div>
                <label className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mb-1.5 block">Infrastructure Summary</label>
                <textarea
                  rows={3}
                  value={infraState.subtitle}
                  onChange={e => setInfraState(prev => ({ ...prev, subtitle: e.target.value }))}
                  className="w-full bg-bg-alt border border-border rounded-xl p-3 text-xs text-white focus:border-accent outline-none leading-relaxed"
                />
              </div>
            </div>
          </div>

          <div className="bg-card border border-border p-6 sm:p-8 rounded-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-border pb-3">
              <h4 className="text-xs font-bold text-accent uppercase tracking-widest">
                2. Additional Infrastructure Sections ({infraState.sections.length})
              </h4>
              <button
                type="button"
                onClick={() => setInfraState(prev => ({ ...prev, sections: [...prev.sections, { id: `sec-${Date.now()}`, title: 'New Network Section', content: 'Section details...' }] }))}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-accent/30 border border-accent/30 text-foreground-muted text-xs font-bold rounded-lg"
              >
                <Plus size={14} /> Add Section
              </button>
            </div>
            <div className="space-y-4">
              {infraState.sections.map((sec, idx) => (
                <div key={idx} className="bg-bg-alt border border-border p-4 rounded-xl space-y-3 relative">
                  <button
                    type="button"
                    onClick={() => setInfraState(prev => ({ ...prev, sections: prev.sections.filter((_, i) => i !== idx) }))}
                    className="absolute top-3 right-3 text-red-400 hover:text-red-300"
                  >
                    <Trash2 size={13} />
                  </button>
                  <input
                    type="text"
                    value={sec.title}
                    onChange={e => {
                      const updated = [...infraState.sections];
                      updated[idx].title = e.target.value;
                      setInfraState(prev => ({ ...prev, sections: updated }));
                    }}
                    className="w-full bg-card border border-border rounded-lg p-2.5 text-xs text-white font-bold"
                  />
                  <textarea
                    rows={4}
                    value={sec.content}
                    onChange={e => {
                      const updated = [...infraState.sections];
                      updated[idx].content = e.target.value;
                      setInfraState(prev => ({ ...prev, sections: updated }));
                    }}
                    className="w-full bg-card border border-border rounded-lg p-2.5 text-xs text-slate-300 leading-relaxed"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* LEGAL NOTICES PAGE EDITOR */}
      {pageType === 'legal' && (
        <div className="space-y-8">
          <div className="bg-card border border-border p-6 sm:p-8 rounded-2xl space-y-6">
            <h4 className="text-xs font-bold text-accent uppercase tracking-widest border-b border-border pb-3">
              1. Legal & Corporate Identity
            </h4>
            <div className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mb-1.5 block">Incorporated Entity Name</label>
                  <input
                    type="text"
                    value={legalState.entityName}
                    onChange={e => setLegalState(prev => ({ ...prev, entityName: e.target.value }))}
                    className="w-full bg-bg-alt border border-border rounded-xl p-3 text-xs text-white focus:border-accent outline-none"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mb-1.5 block">Legal Court Jurisdiction</label>
                  <input
                    type="text"
                    value={legalState.jurisdiction}
                    onChange={e => setLegalState(prev => ({ ...prev, jurisdiction: e.target.value }))}
                    className="w-full bg-bg-alt border border-border rounded-xl p-3 text-xs text-white focus:border-accent outline-none"
                  />
                </div>
              </div>
              <div>
                <label className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mb-1.5 block">Legal Overview / Governance Summary</label>
                <textarea
                  rows={3}
                  value={legalState.subtitle}
                  onChange={e => setLegalState(prev => ({ ...prev, subtitle: e.target.value }))}
                  className="w-full bg-bg-alt border border-border rounded-xl p-3 text-xs text-white focus:border-accent outline-none leading-relaxed"
                />
              </div>
            </div>
          </div>

          <div className="bg-card border border-border p-6 sm:p-8 rounded-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-border pb-3">
              <h4 className="text-xs font-bold text-accent uppercase tracking-widest">
                2. Legal Clauses & Statutory Notices ({legalState.sections.length})
              </h4>
              <button
                type="button"
                onClick={() => setLegalState(prev => ({ ...prev, sections: [...prev.sections, { id: `sec-${Date.now()}`, title: 'New Legal Clause', content: 'Clause content...' }] }))}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-accent/30 border border-accent/30 text-foreground-muted text-xs font-bold rounded-lg"
              >
                <Plus size={14} /> Add Clause
              </button>
            </div>
            <div className="space-y-4">
              {legalState.sections.map((sec, idx) => (
                <div key={idx} className="bg-bg-alt border border-border p-4 rounded-xl space-y-3 relative">
                  <button
                    type="button"
                    onClick={() => setLegalState(prev => ({ ...prev, sections: prev.sections.filter((_, i) => i !== idx) }))}
                    className="absolute top-3 right-3 text-red-400 hover:text-red-300"
                  >
                    <Trash2 size={13} />
                  </button>
                  <input
                    type="text"
                    value={sec.title}
                    onChange={e => {
                      const updated = [...legalState.sections];
                      updated[idx].title = e.target.value;
                      setLegalState(prev => ({ ...prev, sections: updated }));
                    }}
                    className="w-full bg-card border border-border rounded-lg p-2.5 text-xs text-white font-bold"
                  />
                  <textarea
                    rows={4}
                    value={sec.content}
                    onChange={e => {
                      const updated = [...legalState.sections];
                      updated[idx].content = e.target.value;
                      setLegalState(prev => ({ ...prev, sections: updated }));
                    }}
                    className="w-full bg-card border border-border rounded-lg p-2.5 text-xs text-slate-300 leading-relaxed"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
