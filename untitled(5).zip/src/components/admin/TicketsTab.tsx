import React, { useState, useEffect, useRef } from 'react';
import { 
  LifeBuoy, 
  MessageSquare, 
  Search, 
  Filter, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  AlertCircle, 
  Send, 
  X, 
  Trash2, 
  User, 
  ShieldCheck, 
  Tag, 
  Server, 
  ChevronRight, 
  RefreshCw,
  ExternalLink,
  Lock,
  Mail,
  HelpCircle,
  Sparkles,
  Check
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Ticket, TicketMessage, TicketStatus, TicketPriority, TicketDepartment } from '../../types';
import { ticketService } from '../../services/ticketService';
import { logService } from '../../services/logService';

interface TicketsTabProps {
  currentUserEmail?: string;
  currentUserId?: string;
}

export const TicketsTab: React.FC<TicketsTabProps> = ({ 
  currentUserEmail = 'admin@hectorhosting.com',
  currentUserId = 'admin'
}) => {
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [messages, setMessages] = useState<TicketMessage[]>([]);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [replyText, setReplyText] = useState('');
  const [isSendingReply, setIsSendingReply] = useState(false);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [priorityFilter, setPriorityFilter] = useState<string>('ALL');
  const [departmentFilter, setDepartmentFilter] = useState<string>('ALL');

  // Confirmation modal state
  const [deleteConfirmTicket, setDeleteConfirmTicket] = useState<Ticket | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Subscribe to all tickets in real-time
  useEffect(() => {
    setLoading(true);
    const unsubscribe = ticketService.subscribeToAllTickets((data) => {
      setTickets(data);
      setLoading(false);

      if (selectedTicket) {
        const updated = data.find(t => t.id === selectedTicket.id);
        if (updated) {
          setSelectedTicket(updated);
        }
      }
    });

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);

  // Subscribe to messages when a ticket is opened
  useEffect(() => {
    if (!selectedTicket) {
      setMessages([]);
      return;
    }

    setLoadingMessages(true);
    ticketService.markTicketRead(selectedTicket.id, 'admin');

    const unsubscribe = ticketService.subscribeToTicketMessages(selectedTicket.id, (msgs) => {
      setMessages(msgs);
      setLoadingMessages(false);
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    });

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [selectedTicket?.id]);

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicket || !replyText.trim() || isSendingReply) return;

    setIsSendingReply(true);
    try {
      await ticketService.addReply(
        selectedTicket.id,
        selectedTicket.userId,
        {
          uid: currentUserId,
          email: currentUserEmail,
          name: 'Hector Support Staff',
          role: 'admin'
        },
        replyText.trim()
      );
      setReplyText('');
      logService.addLog('success', `Replied to ticket #${selectedTicket.ticketNumber}`);
    } catch (err: any) {
      console.error('Error replying as admin:', err);
      logService.addLog('error', `Failed to reply to ticket: ${err.message}`);
      alert(`Failed to send reply: ${err.message}`);
    } finally {
      setIsSendingReply(false);
    }
  };

  const handleStatusChange = async (ticketId: string, status: TicketStatus) => {
    setActionLoading(ticketId);
    try {
      await ticketService.updateTicketStatus(ticketId, status);
      setTickets(prev => prev.map(t => t.id === ticketId ? { ...t, status, updatedAt: new Date().toISOString() } : t));
      if (selectedTicket?.id === ticketId) {
        setSelectedTicket(prev => prev ? { ...prev, status } : null);
      }
      logService.addLog('info', `Ticket ${ticketId} status updated to ${status}`);
    } catch (err: any) {
      alert(`Failed to update status: ${err.message}`);
    } finally {
      setActionLoading(null);
    }
  };

  const handlePriorityChange = async (ticketId: string, priority: TicketPriority) => {
    setActionLoading(ticketId);
    try {
      await ticketService.updateTicketPriority(ticketId, priority);
      setTickets(prev => prev.map(t => t.id === ticketId ? { ...t, priority, updatedAt: new Date().toISOString() } : t));
      if (selectedTicket?.id === ticketId) {
        setSelectedTicket(prev => prev ? { ...prev, priority } : null);
      }
      logService.addLog('info', `Ticket ${ticketId} priority updated to ${priority}`);
    } catch (err: any) {
      alert(`Failed to update priority: ${err.message}`);
    } finally {
      setActionLoading(null);
    }
  };

  const handleDeleteTicket = async () => {
    if (!deleteConfirmTicket) return;
    const ticketId = deleteConfirmTicket.id;
    setActionLoading(ticketId);
    try {
      await ticketService.deleteTicket(ticketId);
      setTickets(prev => prev.filter(t => t.id !== ticketId));
      if (selectedTicket?.id === ticketId) {
        setSelectedTicket(null);
      }
      logService.addLog('warning', `Deleted ticket #${deleteConfirmTicket.ticketNumber} (${ticketId})`);
      setDeleteConfirmTicket(null);
    } catch (err: any) {
      alert(`Failed to delete ticket: ${err.message}`);
    } finally {
      setActionLoading(null);
    }
  };

  // Canned response insertion helper
  const insertCannedResponse = (text: string) => {
    setReplyText(prev => prev ? `${prev}\n\n${text}` : text);
  };

  // Filtered tickets
  const filteredTickets = tickets.filter(t => {
    const matchesStatus = 
      statusFilter === 'ALL' ? true :
      statusFilter === 'needs_attention' ? (t.status === 'open' || t.status === 'in_progress') :
      t.status === statusFilter;

    const matchesPriority = priorityFilter === 'ALL' ? true : t.priority === priorityFilter;
    const matchesDepartment = departmentFilter === 'ALL' ? true : t.department === departmentFilter;

    const matchesSearch = 
      !searchQuery.trim() ? true :
      t.ticketNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.userEmail.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (t.userName && t.userName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (t.lastMessage && t.lastMessage.toLowerCase().includes(searchQuery.toLowerCase()));

    return matchesStatus && matchesPriority && matchesDepartment && matchesSearch;
  });

  const openTickets = tickets.filter(t => t.status === 'open' || t.status === 'in_progress').length;
  const waitingUserTickets = tickets.filter(t => t.status === 'waiting_user').length;
  const resolvedTickets = tickets.filter(t => t.status === 'resolved' || t.status === 'closed').length;

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-xl font-bold text-white tracking-wide flex items-center gap-2.5">
              <LifeBuoy className="text-accent" size={24} />
              Support & Helpdesk Desk
            </h2>
            {openTickets > 0 && (
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30 animate-pulse">
                {openTickets} Require Attention
              </span>
            )}
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Real-time customer ticketing station, live technical assistance, and inquiries.
          </p>
        </div>
      </div>

      {/* Metrics Header */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 bg-card border border-border rounded-2xl flex items-center justify-between">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-1">Total Inquiries</p>
            <p className="text-2xl font-bold text-white">{tickets.length}</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-accent/10 border border-accent/20 flex items-center justify-center text-accent">
            <MessageSquare size={20} />
          </div>
        </div>

        <div className="p-5 bg-card border border-border rounded-2xl flex items-center justify-between">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-1">Awaiting Staff</p>
            <p className="text-2xl font-bold text-rose-400">{openTickets}</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400">
            <AlertCircle size={20} />
          </div>
        </div>

        <div className="p-5 bg-card border border-border rounded-2xl flex items-center justify-between">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-1">Waiting on Client</p>
            <p className="text-2xl font-bold text-amber-400">{waitingUserTickets}</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
            <Clock size={20} />
          </div>
        </div>

        <div className="p-5 bg-card border border-border rounded-2xl flex items-center justify-between">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-1">Resolved / Closed</p>
            <p className="text-2xl font-bold text-emerald-400">{resolvedTickets}</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
            <CheckCircle2 size={20} />
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-card border border-border rounded-2xl space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Search */}
          <div className="relative">
            <Search size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search Ticket #, email, subject..."
              className="w-full pl-9 pr-4 py-2 bg-bg-alt border border-border rounded-xl text-xs text-white placeholder:text-slate-500 focus:border-accent outline-none transition-all"
            />
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-3.5 py-2 bg-bg-alt border border-border rounded-xl text-xs text-white focus:border-accent outline-none transition-all"
            >
              <option value="ALL">All Statuses</option>
              <option value="needs_attention">Needs Staff Reply (Open / In Progress)</option>
              <option value="open">Open</option>
              <option value="in_progress">In Progress</option>
              <option value="waiting_user">Waiting on User</option>
              <option value="resolved">Resolved</option>
              <option value="closed">Closed</option>
            </select>
          </div>

          {/* Department Filter */}
          <div>
            <select
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value)}
              className="w-full px-3.5 py-2 bg-bg-alt border border-border rounded-xl text-xs text-white focus:border-accent outline-none transition-all"
            >
              <option value="ALL">All Departments</option>
              <option value="Technical Support">Technical Support</option>
              <option value="Billing & Payments">Billing & Payments</option>
              <option value="Server Inquiry">Server Inquiry</option>
              <option value="General">General Inquiry</option>
              <option value="Abuse/Security">Abuse & Security</option>
            </select>
          </div>

          {/* Priority Filter */}
          <div>
            <select
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
              className="w-full px-3.5 py-2 bg-bg-alt border border-border rounded-xl text-xs text-white focus:border-accent outline-none transition-all"
            >
              <option value="ALL">All Priorities</option>
              <option value="urgent">Urgent</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>
          </div>
        </div>
      </div>

      {/* Tickets Table / List */}
      <div className="bg-card border border-border rounded-2xl overflow-hidden shadow-xl">
        {loading ? (
          <div className="p-16 text-center">
            <div className="w-8 h-8 border-2 border-accent border-t-transparent rounded-full animate-spin mx-auto mb-3" />
            <p className="text-xs text-slate-400 uppercase tracking-widest font-bold">Synchronizing Tickets...</p>
          </div>
        ) : filteredTickets.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-border bg-bg-alt/60 text-[10px] uppercase tracking-wider text-slate-400 font-bold">
                  <th className="py-3.5 px-4">Ticket</th>
                  <th className="py-3.5 px-4">Customer</th>
                  <th className="py-3.5 px-4">Subject & Department</th>
                  <th className="py-3.5 px-4">Priority</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4">Last Activity</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-purple-900/20 text-xs text-slate-300">
                {filteredTickets.map((ticket) => (
                  <tr 
                    key={ticket.id} 
                    className="hover:bg-bg-alt transition-colors group cursor-pointer"
                    onClick={() => setSelectedTicket(ticket)}
                  >
                    {/* Ticket # */}
                    <td className="py-4 px-4 font-mono font-bold text-accent whitespace-nowrap">
                      <div className="flex items-center gap-2">
                        <span>#{ticket.ticketNumber}</span>
                        {ticket.unreadByAdmin && (
                          <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" title="Unread message from customer" />
                        )}
                      </div>
                    </td>

                    {/* Customer */}
                    <td className="py-4 px-4">
                      <div className="font-bold text-white truncate max-w-[180px]">{ticket.userName || 'Client'}</div>
                      <div className="text-[11px] text-slate-400 font-mono truncate max-w-[180px]">{ticket.userEmail}</div>
                    </td>

                    {/* Subject & Dept */}
                    <td className="py-4 px-4 max-w-xs">
                      <div className="font-bold text-white truncate group-hover:text-accent transition-colors">
                        {ticket.subject}
                      </div>
                      <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                        <span className="text-accent font-medium">{ticket.department}</span>
                        {ticket.serviceName && <span className="truncate">• {ticket.serviceName}</span>}
                      </div>
                    </td>

                    {/* Priority */}
                    <td className="py-4 px-4" onClick={(e) => e.stopPropagation()}>
                      <select
                        value={ticket.priority}
                        disabled={actionLoading === ticket.id}
                        onChange={(e) => handlePriorityChange(ticket.id, e.target.value as TicketPriority)}
                        className={`text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-lg border outline-none bg-bg-alt cursor-pointer ${
                          ticket.priority === 'urgent' 
                            ? 'text-red-400 border-red-500/30'
                            : ticket.priority === 'high'
                            ? 'text-orange-400 border-orange-500/30'
                            : ticket.priority === 'medium'
                            ? 'text-amber-400 border-amber-500/30'
                            : 'text-sky-400 border-sky-500/30'
                        }`}
                      >
                        <option value="low">Low</option>
                        <option value="medium">Medium</option>
                        <option value="high">High</option>
                        <option value="urgent">Urgent</option>
                      </select>
                    </td>

                    {/* Status */}
                    <td className="py-4 px-4" onClick={(e) => e.stopPropagation()}>
                      <select
                        value={ticket.status}
                        disabled={actionLoading === ticket.id}
                        onChange={(e) => handleStatusChange(ticket.id, e.target.value as TicketStatus)}
                        className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-lg border outline-none bg-bg-alt cursor-pointer ${
                          ticket.status === 'open'
                            ? 'text-emerald-400 border-emerald-500/30'
                            : ticket.status === 'in_progress'
                            ? 'text-accent border-accent/30'
                            : ticket.status === 'waiting_user'
                            ? 'text-amber-400 border-amber-500/30'
                            : ticket.status === 'resolved'
                            ? 'text-blue-400 border-blue-500/30'
                            : 'text-zinc-400 border-zinc-500/30'
                        }`}
                      >
                        <option value="open">Open</option>
                        <option value="in_progress">In Progress</option>
                        <option value="waiting_user">Waiting on User</option>
                        <option value="resolved">Resolved</option>
                        <option value="closed">Closed</option>
                      </select>
                    </td>

                    {/* Last Activity */}
                    <td className="py-4 px-4 text-slate-400 text-[11px] whitespace-nowrap">
                      {new Date(ticket.updatedAt).toLocaleDateString()}
                      <div className="text-[9px] text-slate-500">
                        {ticket.lastReplyBy === 'admin' ? 'Replied by Staff' : 'Customer Reply'}
                      </div>
                    </td>

                    {/* Actions */}
                    <td className="py-4 px-4 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => setSelectedTicket(ticket)}
                          className="p-2 bg-accent/20 hover:bg-accent border border-accent/30 hover:border-accent text-accent hover:text-white rounded-lg transition-all"
                          title="Open Ticket Conversation"
                        >
                          <MessageSquare size={14} />
                        </button>
                        <button
                          onClick={() => setDeleteConfirmTicket(ticket)}
                          className="p-2 bg-rose-500/10 hover:bg-rose-600 border border-rose-500/20 hover:border-rose-500 text-rose-400 hover:text-white rounded-lg transition-all"
                          title="Delete Ticket Record"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-16 text-center">
            <div className="w-14 h-14 rounded-2xl bg-purple-950/40 border border-border flex items-center justify-center mx-auto mb-4 text-accent">
              <LifeBuoy size={28} />
            </div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-1">No Tickets Found</h4>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              {searchQuery || statusFilter !== 'ALL' || priorityFilter !== 'ALL' 
                ? 'No inquiries match your current search query and filters.'
                : 'There are currently no customer support tickets in the database.'}
            </p>
          </div>
        )}
      </div>

      {/* Interactive Conversation Modal / Drawer */}
      <AnimatePresence>
        {selectedTicket && (
          <div className="fixed inset-0 z-[1050] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 font-sans">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-card border border-border rounded-2xl w-full max-w-4xl h-[85vh] flex flex-col shadow-2xl overflow-hidden"
            >
              {/* Modal Header */}
              <div className="p-5 border-b border-border bg-bg-alt flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-accent/20 border border-accent/30 flex items-center justify-center text-accent">
                    <LifeBuoy size={20} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="text-xs font-mono font-bold text-accent">#{selectedTicket.ticketNumber}</span>
                      <h3 className="text-sm font-bold text-white truncate max-w-md">{selectedTicket.subject}</h3>
                    </div>
                    <div className="flex items-center gap-3 text-[10px] text-slate-400 font-medium">
                      <span>Customer: <strong className="text-white">{selectedTicket.userEmail}</strong></span>
                      <span>• Dept: <strong className="text-accent">{selectedTicket.department}</strong></span>
                      {selectedTicket.serviceName && <span>• Node: <strong className="text-white">{selectedTicket.serviceName}</strong></span>}
                    </div>
                  </div>
                </div>

                {/* Status & Priority Controls */}
                <div className="flex items-center gap-3">
                  <select
                    value={selectedTicket.status}
                    onChange={(e) => handleStatusChange(selectedTicket.id, e.target.value as TicketStatus)}
                    className="px-3 py-1.5 bg-card border border-border rounded-xl text-xs font-bold text-accent outline-none focus:border-accent"
                  >
                    <option value="open">Open</option>
                    <option value="in_progress">In Progress</option>
                    <option value="waiting_user">Waiting on User</option>
                    <option value="resolved">Resolved</option>
                    <option value="closed">Closed</option>
                  </select>

                  <select
                    value={selectedTicket.priority}
                    onChange={(e) => handlePriorityChange(selectedTicket.id, e.target.value as TicketPriority)}
                    className="px-3 py-1.5 bg-card border border-border rounded-xl text-xs font-bold text-slate-300 outline-none focus:border-accent"
                  >
                    <option value="low">Low Priority</option>
                    <option value="medium">Medium Priority</option>
                    <option value="high">High Priority</option>
                    <option value="urgent">Urgent</option>
                  </select>

                  <button
                    onClick={() => setSelectedTicket(null)}
                    className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors"
                  >
                    <X size={20} />
                  </button>
                </div>
              </div>

              {/* Messages Scroll Area */}
              <div className="flex-1 p-6 overflow-y-auto space-y-4 custom-scrollbar bg-bg-alt">
                {loadingMessages ? (
                  <div className="h-64 flex items-center justify-center">
                    <div className="w-8 h-8 border-2 border-accent border-t-transparent rounded-full animate-spin" />
                  </div>
                ) : messages.length > 0 ? (
                  messages.map((msg) => {
                    const isAdmin = msg.senderRole === 'admin';
                    return (
                      <motion.div
                        key={msg.id}
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={`flex gap-3.5 p-4 rounded-xl border ${
                          isAdmin 
                            ? 'bg-bg-alt border-accent/20 ml-6' 
                            : 'bg-card border-border mr-6'
                        }`}
                      >
                        <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                          isAdmin 
                            ? 'bg-accent text-white shadow-lg shadow-accent/20' 
                            : 'bg-white/10 text-slate-300'
                        }`}>
                          {isAdmin ? <ShieldCheck size={18} /> : <User size={18} />}
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-2 mb-1.5">
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-bold text-white">
                                {isAdmin ? 'Hector Staff (You)' : msg.senderName}
                              </span>
                              {isAdmin ? (
                                <span className="px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-wider bg-purple-500/20 text-accent border border-accent/30">
                                  Staff Response
                                </span>
                              ) : (
                                <span className="text-[10px] text-slate-400 font-mono">
                                  ({msg.senderEmail})
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] text-slate-500 font-mono">
                              {new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} • {new Date(msg.createdAt).toLocaleDateString()}
                            </span>
                          </div>

                          <div className="text-xs text-slate-300 whitespace-pre-wrap leading-relaxed">
                            {msg.message}
                          </div>
                        </div>
                      </motion.div>
                    );
                  })
                ) : (
                  <div className="text-center py-12 text-slate-500 text-xs">
                    No messages found for this ticket.
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Quick Canned Responses Bar */}
              <div className="px-5 py-2.5 bg-bg-alt border-t border-border flex items-center gap-2 overflow-x-auto text-[10px] custom-scrollbar">
                <span className="text-slate-400 font-bold uppercase tracking-wider shrink-0 flex items-center gap-1">
                  <Sparkles size={12} className="text-accent" /> Canned:
                </span>
                <button
                  type="button"
                  onClick={() => insertCannedResponse("Hello! Thank you for contacting Hector Hosting Support. We are actively investigating your issue and will update you shortly.")}
                  className="px-2.5 py-1 bg-white/5 hover:bg-purple-900/30 text-slate-300 hover:text-white rounded-lg border border-border whitespace-nowrap transition-colors"
                >
                  Investigating Issue
                </button>
                <button
                  type="button"
                  onClick={() => insertCannedResponse("Your server node has been refreshed and service is confirmed operational. Please restart your client/game and let us know if everything works.")}
                  className="px-2.5 py-1 bg-white/5 hover:bg-purple-900/30 text-slate-300 hover:text-white rounded-lg border border-border whitespace-nowrap transition-colors"
                >
                  Node Refreshed
                </button>
                <button
                  type="button"
                  onClick={() => insertCannedResponse("Your payment and invoice have been verified. The associated hosting plan is now activated in your dashboard fleet.")}
                  className="px-2.5 py-1 bg-white/5 hover:bg-purple-900/30 text-slate-300 hover:text-white rounded-lg border border-border whitespace-nowrap transition-colors"
                >
                  Payment Verified
                </button>
                <button
                  type="button"
                  onClick={() => insertCannedResponse("We have resolved this inquiry. If you encounter any other difficulties, feel free to reply or open a new ticket anytime.")}
                  className="px-2.5 py-1 bg-white/5 hover:bg-purple-900/30 text-slate-300 hover:text-white rounded-lg border border-border whitespace-nowrap transition-colors"
                >
                  Issue Resolved
                </button>
              </div>

              {/* Reply Box */}
              <form onSubmit={handleSendReply} className="p-4 bg-card border-t border-border flex gap-3">
                <textarea
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
                      handleSendReply(e);
                    }
                  }}
                  placeholder="Type official staff reply... (Ctrl+Enter to send)"
                  rows={2}
                  className="flex-1 p-3 bg-bg-alt border border-border rounded-xl text-xs text-white focus:border-accent outline-none resize-none transition-all placeholder:text-slate-500"
                />
                <button
                  type="submit"
                  disabled={!replyText.trim() || isSendingReply}
                  className="px-6 bg-accent hover:bg-accent-muted disabled:opacity-50 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-lg shadow-accent/20 flex items-center justify-center gap-2"
                >
                  {isSendingReply ? (
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <Send size={14} />
                      Send Reply
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {deleteConfirmTicket && (
          <div className="fixed inset-0 z-[1100] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-card border border-rose-900/40 rounded-2xl max-w-md w-full p-6 text-center shadow-2xl space-y-4"
            >
              <div className="w-12 h-12 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center mx-auto text-rose-400">
                <AlertTriangle size={24} />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Delete Ticket Record</h3>
                <p className="text-xs text-slate-400 mt-1">
                  Are you sure you want to permanently delete ticket <strong className="text-white">#{deleteConfirmTicket.ticketNumber}</strong> and its full message history?
                </p>
              </div>
              <div className="flex gap-3 pt-2">
                <button
                  onClick={() => setDeleteConfirmTicket(null)}
                  className="flex-1 py-2.5 bg-white/5 hover:bg-white/10 text-slate-300 font-bold rounded-xl text-xs transition-all"
                >
                  Cancel
                </button>
                <button
                  onClick={handleDeleteTicket}
                  className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl text-xs shadow-lg shadow-rose-600/30 transition-all"
                >
                  Delete Ticket
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
