import React, { useState } from 'react';
import { 
  CreditCard, Search, Plus, CheckCircle2, Clock, 
  Trash2, RefreshCw, FileText, ArrowRight, Eye, ShieldCheck 
} from 'lucide-react';
import { Invoice, UserService, UserProfile } from '../../types';
import { formatINR } from '../../utils/formatUtils';

interface BillingInvoicesTabProps {
  invoices: Invoice[];
  orders: UserService[];
  users: UserProfile[];
  onOpenCreateInvoice: () => void;
  onOpenClientProfile: (userId: string) => void;
  onOpenInvoiceDoc: (invoice: Invoice) => void;
  onVerifyInvoiceAndProvision: (invoiceId: string) => Promise<void>;
  onDeleteInvoice: (invoiceId: string) => Promise<void>;
  actionLoading: string | null;
  onRefresh: () => void;
  isLoading: boolean;
}

export const BillingInvoicesTab: React.FC<BillingInvoicesTabProps> = ({
  invoices,
  orders,
  users,
  onOpenCreateInvoice,
  onOpenClientProfile,
  onOpenInvoiceDoc,
  onVerifyInvoiceAndProvision,
  onDeleteInvoice,
  actionLoading,
  onRefresh,
  isLoading
}) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'Unpaid' | 'Paid' | 'Cancelled'>('ALL');

  const filteredInvoices = invoices.filter(inv => {
    const q = search.toLowerCase();
    const matchSearch = 
      (inv.invoiceNumber && inv.invoiceNumber.toLowerCase().includes(q)) ||
      (inv.id && inv.id.toLowerCase().includes(q)) ||
      (inv.userId && inv.userId.toLowerCase().includes(q)) ||
      (inv.utrNumber && inv.utrNumber.toLowerCase().includes(q)) ||
      (inv.items && inv.items.some(i => i.name.toLowerCase().includes(q)));

    const isUnpaid = inv.status === 'Unpaid' || inv.status === 'pending' || inv.status === 'UPI_PENDING_VERIFICATION';
    const matchStatus = 
      statusFilter === 'ALL' ||
      (statusFilter === 'Unpaid' && isUnpaid) ||
      (statusFilter === 'Paid' && inv.status === 'Paid') ||
      (statusFilter === 'Cancelled' && inv.status === 'Cancelled');

    return matchSearch && matchStatus;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner & Action */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm">
        <div>
          <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
            <CreditCard size={18} className="text-blue-400" />
            Billing & Invoices Management
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time WHMCS billing ledger. Manage customer payments, UPI verification queues, and linked service provisioning.
          </p>
        </div>
        <div className="flex items-center gap-2.5">
          <button
            onClick={onOpenCreateInvoice}
            className="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <Plus size={14} />
            <span>Create Manual Invoice</span>
          </button>
          <button
            onClick={onRefresh}
            disabled={isLoading}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded-lg transition-colors disabled:opacity-50"
            title="Refresh Invoices"
          >
            <RefreshCw size={14} className={isLoading ? 'animate-spin' : ''} />
          </button>
        </div>
      </div>

      {/* Search and Filters Bar */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder="Search invoice #, client, UTR, item..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 outline-none focus:border-blue-500"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 w-full sm:w-auto overflow-x-auto">
          {(['ALL', 'Unpaid', 'Paid', 'Cancelled'] as const).map(st => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
                statusFilter === st
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {st === 'ALL' ? 'All Invoices' : st}
              {st === 'Unpaid' && invoices.filter(i => i.status === 'Unpaid').length > 0 && (
                <span className="ml-1.5 px-1.5 py-0.2 rounded-full text-[10px] bg-amber-500/20 text-amber-300 font-mono">
                  {invoices.filter(i => i.status === 'Unpaid').length}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Invoices Data Table */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900/80 text-[10px] uppercase font-semibold text-slate-400 tracking-wider border-b border-slate-800">
              <tr>
                <th className="p-3.5">Invoice #</th>
                <th className="p-3.5">Client User</th>
                <th className="p-3.5">Items & Plan</th>
                <th className="p-3.5">Total Amount</th>
                <th className="p-3.5">Payment Method & UTR</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5">Date</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filteredInvoices.map(inv => {
                const isUnpaid = inv.status === 'Unpaid' || inv.status === 'pending' || inv.status === 'UPI_PENDING_VERIFICATION';
                return (
                  <tr key={inv.id} className="hover:bg-slate-850/40 transition-colors">
                    <td className="p-3.5 font-mono font-bold text-blue-400">
                      <button 
                        onClick={() => onOpenInvoiceDoc(inv)} 
                        className="hover:underline flex items-center gap-1"
                        title="Click to view full Invoice Document"
                      >
                        #{inv.invoiceNumber || inv.id}
                      </button>
                    </td>
                    <td className="p-3.5">
                      <button
                        onClick={() => onOpenClientProfile(inv.userId)}
                        className="text-slate-200 hover:text-blue-400 font-medium text-left truncate max-w-[160px] block"
                        title="Click to open Client 360° Profile"
                      >
                        {inv.userId}
                      </button>
                    </td>
                    <td className="p-3.5 text-slate-300 max-w-[200px] truncate">
                      {inv.items?.map(i => `${i.name}${i.quantity > 1 ? ` (x${i.quantity})` : ''}`).join(', ') || 'Hosting Service'}
                    </td>
                    <td className="p-3.5 font-bold font-mono text-white">
                      {formatINR(inv.total, 2)}
                    </td>
                    <td className="p-3.5">
                      <div className="text-slate-300 font-medium">{inv.paymentMethod || inv.method || 'UPI Transfer'}</div>
                      {inv.utrNumber ? (
                        <div className="text-[10px] font-mono text-emerald-400">UTR: {inv.utrNumber}</div>
                      ) : (
                        <div className="text-[10px] text-slate-500">No UTR Reference</div>
                      )}
                    </td>
                    <td className="p-3.5">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-[11px] font-semibold ${
                        inv.status === 'Paid' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                        isUnpaid ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                        'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                      }`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${
                          inv.status === 'Paid' ? 'bg-emerald-400' :
                          isUnpaid ? 'bg-amber-400' : 'bg-rose-400'
                        }`} />
                        {inv.status}
                      </span>
                    </td>
                    <td className="p-3.5 text-slate-400 text-[11px]">
                      {inv.timestamp ? new Date(inv.timestamp).toLocaleDateString() : 'Recent'}
                    </td>
                    <td className="p-3.5 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {isUnpaid && (
                          <button
                            onClick={() => onVerifyInvoiceAndProvision(inv.id)}
                            disabled={actionLoading === inv.id}
                            className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded text-[11px] font-semibold transition-colors flex items-center gap-1 shadow-sm"
                            title="Verify UPI payment and auto-activate client service"
                          >
                            {actionLoading === inv.id ? (
                              <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
                            ) : (
                              <CheckCircle2 size={12} />
                            )}
                            <span>Verify & Provision</span>
                          </button>
                        )}
                        <button
                          onClick={() => onOpenInvoiceDoc(inv)}
                          className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] font-medium transition-colors"
                          title="View Official Receipt"
                        >
                          <Eye size={12} />
                        </button>
                        <button
                          onClick={() => onDeleteInvoice(inv.id)}
                          disabled={actionLoading === inv.id}
                          className="p-1 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded transition-colors"
                          title="Delete Invoice Record"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {filteredInvoices.length === 0 && (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-xs text-slate-500">
                    No matching invoices found in billing ledger.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
