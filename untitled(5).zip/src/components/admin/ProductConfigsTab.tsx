import React, { useState } from 'react';
import { 
  Settings, Plus, Trash2, Edit2, Check, Save, RotateCcw, AlertCircle, Layers, 
  Cpu, Server, Globe, Shield, Terminal, Sparkles, Box, CheckCircle2, ChevronDown,
  RefreshCw, Cloud, CloudCheck, Gamepad2
} from 'lucide-react';
import { AppData, ProductSoftwareOption, ProductAddon, Settings as SettingsType } from '../../types';
import { DEFAULT_SOFTWARE_PRESETS, DEFAULT_ADDON_PRESETS } from '../../constants';
import { dataService } from '../../services/dataService';

interface ProductConfigsTabProps {
  localData: AppData;
  setLocalData: React.Dispatch<React.SetStateAction<AppData>>;
  onSave?: () => void;
  isSaving?: boolean;
}

export const ProductConfigsTab: React.FC<ProductConfigsTabProps> = ({
  localData,
  setLocalData,
  onSave,
  isSaving: externalIsSaving
}) => {
  const currentOptions = localData.settings.productConfigs?.softwareOptions || DEFAULT_SOFTWARE_PRESETS;
  const currentAddons = localData.settings.productConfigs?.addons || DEFAULT_ADDON_PRESETS;

  const [activeCategory, setActiveCategory] = useState<string>('game');
  const [selectedGameType, setSelectedGameType] = useState<string>('minecraft');
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncToast, setSyncToast] = useState<string | null>(null);

  // New Software Form Modal
  const [isSoftwareModalOpen, setIsSoftwareModalOpen] = useState(false);
  const [editingSoftware, setEditingSoftware] = useState<ProductSoftwareOption | null>(null);
  const [softwareForm, setSoftwareForm] = useState<Partial<ProductSoftwareOption>>({
    category: 'game',
    gameType: 'minecraft',
    name: '',
    desc: '',
    recommended: false
  });

  // New Addon Form Modal
  const [isAddonModalOpen, setIsAddonModalOpen] = useState(false);
  const [editingAddon, setEditingAddon] = useState<ProductAddon | null>(null);
  const [addonForm, setAddonForm] = useState<Partial<ProductAddon>>({
    name: '',
    desc: '',
    priceInr: 100,
    category: 'all',
    badge: 'Popular'
  });

  const showToast = (msg: string) => {
    setSyncToast(msg);
    setTimeout(() => {
      setSyncToast(null);
    }, 3000);
  };

  const persistConfigs = async (updatedOptions: ProductSoftwareOption[], updatedAddons: ProductAddon[], toastMsg: string) => {
    setIsSyncing(true);
    const updatedConfigs = {
      softwareOptions: updatedOptions,
      addons: updatedAddons
    };

    setLocalData(prev => ({
      ...prev,
      settings: {
        ...prev.settings,
        productConfigs: updatedConfigs
      }
    }));

    try {
      await dataService.updateSettings({
        productConfigs: updatedConfigs,
        settings: {
          ...localData.settings,
          productConfigs: updatedConfigs
        }
      });
      showToast(toastMsg);
    } catch (err: any) {
      console.error('Failed to sync product configs to Firestore:', err);
      showToast(`Error: ${err.message || 'Failed to sync'}`);
    } finally {
      setIsSyncing(false);
    }
  };

  const handleSaveSoftware = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!softwareForm.name?.trim()) return;

    let updatedOptions = [...currentOptions];
    if (editingSoftware) {
      updatedOptions = updatedOptions.map(opt => 
        opt.id === editingSoftware.id 
          ? { ...opt, ...softwareForm } as ProductSoftwareOption 
          : opt
      );
    } else {
      const newOpt: ProductSoftwareOption = {
        id: `opt-${Date.now()}`,
        category: softwareForm.category || activeCategory,
        gameType: softwareForm.gameType || selectedGameType,
        name: softwareForm.name.trim(),
        desc: softwareForm.desc?.trim() || '',
        recommended: !!softwareForm.recommended
      };
      updatedOptions.push(newOpt);
    }

    await persistConfigs(
      updatedOptions, 
      currentAddons, 
      editingSoftware ? `Software "${softwareForm.name}" updated` : `Software "${softwareForm.name}" added`
    );

    setIsSoftwareModalOpen(false);
    setEditingSoftware(null);
  };

  const handleDeleteSoftware = async (id: string) => {
    const target = currentOptions.find(opt => opt.id === id);
    const updatedOptions = currentOptions.filter(opt => opt.id !== id);
    await persistConfigs(updatedOptions, currentAddons, `Software "${target?.name || ''}" removed`);
  };

  const handleSaveAddon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!addonForm.name?.trim()) return;

    let updatedAddons = [...currentAddons];
    if (editingAddon) {
      updatedAddons = updatedAddons.map(ad => 
        ad.id === editingAddon.id 
          ? { ...ad, ...addonForm } as ProductAddon 
          : ad
      );
    } else {
      const newAddon: ProductAddon = {
        id: `addon-${Date.now()}`,
        name: addonForm.name.trim(),
        desc: addonForm.desc?.trim() || '',
        priceInr: Number(addonForm.priceInr) || 0,
        category: addonForm.category || 'all',
        badge: addonForm.badge || ''
      };
      updatedAddons.push(newAddon);
    }

    await persistConfigs(
      currentOptions, 
      updatedAddons, 
      editingAddon ? `Addon "${addonForm.name}" updated` : `Addon "${addonForm.name}" created`
    );

    setIsAddonModalOpen(false);
    setEditingAddon(null);
  };

  const handleDeleteAddon = async (id: string) => {
    const target = currentAddons.find(ad => ad.id === id);
    const updatedAddons = currentAddons.filter(ad => ad.id !== id);
    await persistConfigs(currentOptions, updatedAddons, `Addon "${target?.name || ''}" deleted from checkout`);
  };

  const handleResetToDefaults = async () => {
    if (confirm("Reset all software options and product addons back to official default presets? This will write to Firestore immediately.")) {
      await persistConfigs(DEFAULT_SOFTWARE_PRESETS, DEFAULT_ADDON_PRESETS, "Configurations reset to default presets");
    }
  };

  const filteredSoftware = currentOptions.filter(opt => {
    if (opt.category !== activeCategory) return false;
    if (activeCategory === 'game' && selectedGameType && selectedGameType !== 'all') {
      return (opt.gameType || 'minecraft').toLowerCase() === selectedGameType.toLowerCase();
    }
    return true;
  });

  return (
    <div className="space-y-8 font-sans text-foreground">
      
      {/* Toast Notification */}
      {syncToast && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-xl text-xs flex items-center gap-2 shadow-lg">
          <CheckCircle2 size={16} />
          <span className="font-semibold">{syncToast}</span>
        </div>
      )}

      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 bg-bg-alt border border-border rounded-3xl">
        <div>
          <div className="flex items-center gap-2.5 mb-1">
            <Settings className="text-accent" size={20} />
            <h2 className="text-base font-black uppercase tracking-wider text-foreground">Product Addons & Custom Configurations</h2>
          </div>
          <p className="text-xs text-foreground-dim">
            Configure custom game engines, operating system templates, and checkout addons per product category.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={handleResetToDefaults}
            disabled={isSyncing}
            className="px-3.5 py-2 bg-bg hover:bg-bg-alt text-foreground-dim hover:text-foreground border border-border rounded-xl text-xs font-bold transition-all flex items-center gap-1.5"
            title="Reset options to defaults"
          >
            <RotateCcw size={13} />
            <span>Reset Defaults</span>
          </button>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-border">
        {[
          { id: 'game', label: 'Game Engines & Software', icon: Gamepad2 },
          { id: 'vps', label: 'VPS OS Templates', icon: Server },
          { id: 'bot', label: 'Discord Bot Runtimes', icon: Terminal },
          { id: 'web', label: 'Web Stacks & Control Panels', icon: Globe },
          { id: 'addons', label: 'Product Addons & Upgrades', icon: Sparkles }
        ].map(cat => {
          const isSelected = activeCategory === cat.id;
          const Icon = cat.icon;
          return (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-2 whitespace-nowrap ${
                isSelected 
                  ? 'bg-accent text-white shadow-md shadow-accent/20' 
                  : 'bg-bg-alt text-foreground-dim hover:text-foreground border border-border'
              }`}
            >
              <Icon size={15} />
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* SECTION 1: Software & Engine Manager */}
      {activeCategory !== 'addons' && (
        <div className="space-y-6">
          
          {/* Game Type Sub-Selector if Game category */}
          {activeCategory === 'game' && (
            <div className="flex items-center justify-between flex-wrap gap-3 p-4 bg-bg border border-border rounded-2xl">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-foreground-dim uppercase tracking-wider">Select Game Type:</span>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    { id: 'minecraft', label: 'Minecraft' },
                    { id: 'rust', label: 'Rust' },
                    { id: 'fivem', label: 'FiveM / GTAV' },
                    { id: 'palworld', label: 'Palworld' },
                    { id: 'ark', label: 'ARK' },
                    { id: 'cs2', label: 'Counter-Strike 2' },
                    { id: 'general', label: 'General Steam Games' }
                  ].map(g => (
                    <button
                      key={g.id}
                      onClick={() => setSelectedGameType(g.id)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                        selectedGameType === g.id 
                          ? 'bg-purple-600/20 text-accent border border-accent/40' 
                          : 'bg-bg-alt text-foreground-dim hover:text-foreground border border-border'
                      }`}
                    >
                      {g.label}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={() => {
                  setEditingSoftware(null);
                  setSoftwareForm({
                    category: 'game',
                    gameType: selectedGameType,
                    name: '',
                    desc: '',
                    recommended: false
                  });
                  setIsSoftwareModalOpen(true);
                }}
                className="px-4 py-2 bg-accent/10 border border-accent/30 text-accent hover:bg-accent hover:text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-2"
              >
                <Plus size={14} />
                <span>Add Game Software Engine</span>
              </button>
            </div>
          )}

          {activeCategory !== 'game' && (
            <div className="flex justify-end">
              <button
                onClick={() => {
                  setEditingSoftware(null);
                  setSoftwareForm({
                    category: activeCategory,
                    gameType: 'general',
                    name: '',
                    desc: '',
                    recommended: false
                  });
                  setIsSoftwareModalOpen(true);
                }}
                className="px-4 py-2 bg-accent/10 border border-accent/30 text-accent hover:bg-accent hover:text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-2"
              >
                <Plus size={14} />
                <span>Add {activeCategory.toUpperCase()} Template / Runtime</span>
              </button>
            </div>
          )}

          {/* Software Items Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredSoftware.length > 0 ? (
              filteredSoftware.map((opt) => (
                <div
                  key={opt.id}
                  className="p-5 bg-bg-alt border border-border rounded-2xl flex items-start justify-between gap-4 group hover:border-accent/40 transition-all"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h4 className="text-xs font-black text-foreground uppercase tracking-wider">{opt.name}</h4>
                      {opt.recommended && (
                        <span className="px-2 py-0.5 rounded text-[8px] font-black uppercase bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                          Recommended
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-foreground-dim leading-relaxed">{opt.desc}</p>
                    <div className="pt-1 text-[10px] font-mono text-purple-300">
                      Category: {opt.category.toUpperCase()} {opt.gameType ? `• ${opt.gameType.toUpperCase()}` : ''}
                    </div>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => {
                        setEditingSoftware(opt);
                        setSoftwareForm(opt);
                        setIsSoftwareModalOpen(true);
                      }}
                      className="p-2 hover:bg-bg rounded-lg text-foreground-dim hover:text-accent transition-colors"
                      title="Edit Option"
                    >
                      <Edit2 size={15} />
                    </button>
                    <button
                      onClick={() => handleDeleteSoftware(opt.id)}
                      className="p-2 hover:bg-bg rounded-lg text-foreground-dim hover:text-rose-400 transition-colors"
                      title="Delete Option"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <div className="col-span-2 p-12 text-center bg-bg-alt border border-dashed border-border rounded-2xl">
                <p className="text-xs text-foreground-dim">No software options configured for this category.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SECTION 2: Product Addons Manager */}
      {activeCategory === 'addons' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-black uppercase tracking-wider text-foreground">Checkout Addons & Upgrades</h3>
              <p className="text-xs text-foreground-dim">Optional services offered to clients during server customization.</p>
            </div>

            <button
              onClick={() => {
                setEditingAddon(null);
                setAddonForm({ name: '', desc: '', priceInr: 100, category: 'all', badge: 'Popular' });
                setIsAddonModalOpen(true);
              }}
              className="px-4 py-2 bg-accent/10 border border-accent/30 text-accent hover:bg-accent hover:text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-2"
            >
              <Plus size={14} />
              <span>Create Product Addon</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {currentAddons.map((ad) => (
              <div
                key={ad.id}
                className="p-5 bg-bg-alt border border-border rounded-2xl flex items-start justify-between gap-4 group hover:border-accent/40 transition-all"
              >
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <h4 className="text-xs font-black text-foreground uppercase tracking-wider">{ad.name}</h4>
                    {ad.badge && (
                      <span className="px-2 py-0.5 rounded text-[8px] font-black uppercase bg-accent/10 text-accent border border-accent/20">
                        {ad.badge}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-foreground-dim leading-relaxed">{ad.desc}</p>
                  <div className="flex items-center gap-3 pt-1 text-xs">
                    <span className="font-mono font-bold text-emerald-400">+₹{ad.priceInr} / month</span>
                    <span className="text-[10px] text-foreground-dim uppercase tracking-wider font-mono">
                      Category: {ad.category || 'all'}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => {
                      setEditingAddon(ad);
                      setAddonForm(ad);
                      setIsAddonModalOpen(true);
                    }}
                    className="p-2 hover:bg-bg rounded-lg text-foreground-dim hover:text-accent transition-colors"
                  >
                    <Edit2 size={15} />
                  </button>
                  <button
                    onClick={() => handleDeleteAddon(ad.id)}
                    className="p-2 hover:bg-bg rounded-lg text-foreground-dim hover:text-rose-400 transition-colors"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* --- SOFTWARE MODAL --- */}
      {isSoftwareModalOpen && (
        <div className="fixed inset-0 z-[1200] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form onSubmit={handleSaveSoftware} className="max-w-md w-full bg-bg border border-border rounded-3xl p-6 space-y-4 shadow-2xl">
            <h3 className="text-sm font-black uppercase tracking-wider text-foreground">
              {editingSoftware ? 'Edit Software Option' : 'Add Software Option'}
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-foreground-dim block mb-1">Option Name</label>
                <input
                  type="text"
                  required
                  value={softwareForm.name || ''}
                  onChange={e => setSoftwareForm({ ...softwareForm, name: e.target.value })}
                  placeholder="e.g. Purpur 1.20, Oxide Modded, Ubuntu 24.04"
                  className="w-full bg-bg-alt border border-border rounded-xl px-3 py-2 text-foreground focus:border-accent outline-none"
                />
              </div>

              <div>
                <label className="text-foreground-dim block mb-1">Description</label>
                <textarea
                  rows={2}
                  value={softwareForm.desc || ''}
                  onChange={e => setSoftwareForm({ ...softwareForm, desc: e.target.value })}
                  placeholder="Brief explanation shown at checkout"
                  className="w-full bg-bg-alt border border-border rounded-xl p-3 text-foreground focus:border-accent outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-foreground-dim block mb-1">Category</label>
                  <select
                    value={softwareForm.category || 'game'}
                    onChange={e => setSoftwareForm({ ...softwareForm, category: e.target.value })}
                    className="w-full bg-bg-alt border border-border rounded-xl p-2 text-foreground outline-none"
                  >
                    <option value="game">Game Hosting</option>
                    <option value="vps">VPS Hosting</option>
                    <option value="bot">Discord Bot</option>
                    <option value="web">Web Hosting</option>
                  </select>
                </div>

                {softwareForm.category === 'game' && (
                  <div>
                    <label className="text-foreground-dim block mb-1">Game Type</label>
                    <select
                      value={softwareForm.gameType || 'minecraft'}
                      onChange={e => setSoftwareForm({ ...softwareForm, gameType: e.target.value })}
                      className="w-full bg-bg-alt border border-border rounded-xl p-2 text-foreground outline-none"
                    >
                      <option value="minecraft">Minecraft</option>
                      <option value="rust">Rust</option>
                      <option value="fivem">FiveM / GTAV</option>
                      <option value="palworld">Palworld</option>
                      <option value="ark">ARK</option>
                      <option value="cs2">Counter-Strike 2</option>
                      <option value="general">General Steam</option>
                    </select>
                  </div>
                )}
              </div>

              <label className="flex items-center gap-2 pt-1 cursor-pointer">
                <input
                  type="checkbox"
                  checked={!!softwareForm.recommended}
                  onChange={e => setSoftwareForm({ ...softwareForm, recommended: e.target.checked })}
                  className="rounded border-border text-accent focus:ring-accent"
                />
                <span>Set as Recommended Badge</span>
              </label>
            </div>

            <div className="pt-3 flex gap-2">
              <button
                type="button"
                onClick={() => setIsSoftwareModalOpen(false)}
                className="flex-1 py-2.5 bg-bg-alt border border-border text-foreground-dim rounded-xl font-bold uppercase tracking-wider text-[10px]"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 py-2.5 bg-accent text-white rounded-xl font-bold uppercase tracking-wider text-[10px] shadow-lg shadow-accent/20"
              >
                Save Software
              </button>
            </div>
          </form>
        </div>
      )}

      {/* --- ADDON MODAL --- */}
      {isAddonModalOpen && (
        <div className="fixed inset-0 z-[1200] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form onSubmit={handleSaveAddon} className="max-w-md w-full bg-bg border border-border rounded-3xl p-6 space-y-4 shadow-2xl">
            <h3 className="text-sm font-black uppercase tracking-wider text-foreground">
              {editingAddon ? 'Edit Product Addon' : 'Create Product Addon'}
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-foreground-dim block mb-1">Addon Name</label>
                <input
                  type="text"
                  required
                  value={addonForm.name || ''}
                  onChange={e => setAddonForm({ ...addonForm, name: e.target.value })}
                  placeholder="e.g. Dedicated Static IPv4 Address"
                  className="w-full bg-bg-alt border border-border rounded-xl px-3 py-2 text-foreground focus:border-accent outline-none"
                />
              </div>

              <div>
                <label className="text-foreground-dim block mb-1">Description</label>
                <textarea
                  rows={2}
                  value={addonForm.desc || ''}
                  onChange={e => setAddonForm({ ...addonForm, desc: e.target.value })}
                  placeholder="Features included with this addon"
                  className="w-full bg-bg-alt border border-border rounded-xl p-3 text-foreground focus:border-accent outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-foreground-dim block mb-1">Price (₹ / month)</label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={addonForm.priceInr || 0}
                    onChange={e => setAddonForm({ ...addonForm, priceInr: Number(e.target.value) })}
                    className="w-full bg-bg-alt border border-border rounded-xl px-3 py-2 text-foreground focus:border-accent outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="text-foreground-dim block mb-1">Badge Tag</label>
                  <input
                    type="text"
                    value={addonForm.badge || ''}
                    onChange={e => setAddonForm({ ...addonForm, badge: e.target.value })}
                    placeholder="Popular, Recommended"
                    className="w-full bg-bg-alt border border-border rounded-xl px-3 py-2 text-foreground focus:border-accent outline-none"
                  />
                </div>
              </div>
            </div>

            <div className="pt-3 flex gap-2">
              <button
                type="button"
                onClick={() => setIsAddonModalOpen(false)}
                className="flex-1 py-2.5 bg-bg-alt border border-border text-foreground-dim rounded-xl font-bold uppercase tracking-wider text-[10px]"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 py-2.5 bg-accent text-white rounded-xl font-bold uppercase tracking-wider text-[10px] shadow-lg shadow-accent/20"
              >
                Save Addon
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
};

const Gamepad2Icon = ({ size }: { size: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="6" y1="12" x2="10" y2="12"></line>
    <line x1="8" y1="10" x2="8" y2="14"></line>
    <circle cx="15" cy="13" r="1"></circle>
    <circle cx="18" cy="11" r="1"></circle>
    <rect x="2" y="6" width="20" height="12" rx="6"></rect>
  </svg>
);
