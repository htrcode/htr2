import React from 'react';
import Markdown from 'react-markdown';

interface FormattedMarkdownProps {
  content: string;
  className?: string;
}

export const FormattedMarkdown: React.FC<FormattedMarkdownProps> = ({ content, className = '' }) => {
  return (
    <div className={`markdown-content text-foreground-muted text-sm sm:text-base leading-relaxed ${className}`}>
      <Markdown
        components={{
          p: ({ children }) => <p className="mb-3 leading-relaxed last:mb-0">{children}</p>,
          strong: ({ children }) => <strong className="font-bold text-foreground">{children}</strong>,
          em: ({ children }) => <em className="italic text-foreground">{children}</em>,
          ul: ({ children }) => <ul className="list-disc list-outside my-3 space-y-1.5 pl-5">{children}</ul>,
          ol: ({ children }) => <ol className="list-decimal list-outside my-3 space-y-1.5 pl-5">{children}</ol>,
          li: ({ children }) => <li className="leading-relaxed marker:text-accent">{children}</li>,
          h1: ({ children }) => <h1 className="text-xl font-black text-foreground uppercase tracking-tight my-4">{children}</h1>,
          h2: ({ children }) => <h2 className="text-lg font-bold text-foreground uppercase tracking-tight my-3">{children}</h2>,
          h3: ({ children }) => <h3 className="text-base font-bold text-foreground uppercase tracking-tight my-2">{children}</h3>,
          a: ({ href, children }) => (
            <a href={href} target="_blank" rel="noopener noreferrer" className="text-accent underline hover:opacity-80 transition-opacity">
              {children}
            </a>
          ),
          table: ({ children }) => (
            <div className="overflow-x-auto my-4 border border-border rounded-lg shadow-sm">
              <table className="w-full text-left border-collapse text-xs sm:text-sm">{children}</table>
            </div>
          ),
          thead: ({ children }) => <thead className="bg-bg-alt border-b border-border">{children}</thead>,
          th: ({ children }) => <th className="p-3 font-bold uppercase tracking-wider text-foreground text-[11px]">{children}</th>,
          td: ({ children }) => <td className="p-3 border-b border-border/50 text-foreground-muted">{children}</td>,
          code: ({ children }) => (
            <code className="bg-bg-alt border border-border px-1.5 py-0.5 rounded text-xs font-mono text-accent">
              {children}
            </code>
          ),
          blockquote: ({ children }) => (
            <blockquote className="border-l-4 border-accent pl-4 italic text-foreground-muted my-3">
              {children}
            </blockquote>
          ),
        }}
      >
        {content}
      </Markdown>
    </div>
  );
};
