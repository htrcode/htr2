import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, ChevronRight, Star, Server, Cpu, Box, Bot, Code, Globe, ShieldCheck, Shield, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Settings } from '../types';
import minecraftSteveImg from '../assets/images/minecraft_steve_cutout_1789666763786.jpg';

interface HeroProps {
  settings: Settings;
  activeCurrency?: 'USD' | 'INR' | 'EUR';
}

export const Hero: React.FC<HeroProps> = ({ settings, activeCurrency = 'INR' }) => {
  const getPrice = (inrVal: number) => {
    return `₹${inrVal}`;
  };

  const brandName = settings.site_name && settings.site_name !== 'Untitled' ? settings.site_name : 'HectorHosting';

  return (
    <section className="relative min-h-[90vh] bg-bg text-foreground pt-36 pb-20 px-6 overflow-hidden flex flex-col justify-center">
      {/* Precision Background - Subtle Radial Gradient for Depth */}
      <div className="absolute inset-0 pointer-events-none z-0">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full bg-[radial-gradient(circle_at_center,rgba(139,92,246,0.03)_0%,transparent_70%)]" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10 w-full">
        <div className="grid lg:grid-cols-12 gap-16 items-center">
          {/* Left Column: Focused Content */}
          <div className="lg:col-span-8 space-y-10">
            <div className="space-y-6">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4 }}
                className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-bg-alt border border-border text-[11px] font-semibold tracking-wide text-foreground-muted shadow-sm"
              >
                <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>Next-Gen Infrastructure in India & Global</span>
              </motion.div>

              <motion.h1
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="text-5xl sm:text-7xl lg:text-8xl font-extrabold tracking-tight text-foreground leading-[0.95] font-display text-balance"
              >
                Enterprise Hosting <br />
                <span className="text-foreground-muted">Redefined.</span>
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="text-foreground-muted text-base md:text-lg font-normal leading-relaxed max-w-2xl text-balance"
              >
                High-performance Minecraft, VPS, and Web hosting powered by AMD RYZEN™ 9 5950X processors and 10Gbps unmetered networking. Precision-engineered for low latency and maximum uptime.
              </motion.p>
            </div>

            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="flex flex-wrap items-center gap-4"
            >
              <Link 
                to="/plans"
                className="px-8 py-4 bg-accent hover:bg-accent-muted text-white font-bold text-sm rounded-md transition-all flex items-center gap-2"
              >
                View Infrastructure
                <ArrowRight size={18} />
              </Link>

              <a 
                href={settings.discord_url || 'https://discord.gg/hectorhosting'}
                target="_blank"
                rel="noopener noreferrer"
                className="px-8 py-4 bg-bg-alt hover:bg-border border border-border text-foreground font-bold text-sm rounded-md transition-all"
              >
                Documentation
              </a>
            </motion.div>
          </div>

          {/* Right Column: Minecraft Steve Hero Cutout */}
          <div className="lg:col-span-4 lg:pt-0">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="relative group bg-bg-alt border border-border rounded-2xl overflow-hidden shadow-2xl p-4 transition-all hover:border-accent/50"
            >
              {/* Background Accent Ambient Glow */}
              <div className="absolute inset-0 bg-gradient-to-b from-accent/10 via-transparent to-emerald-500/10 opacity-60 pointer-events-none" />

              {/* Character Image Frame */}
              <div className="relative rounded-xl overflow-hidden aspect-[3/4] bg-bg border border-border/60">
                <img 
                  src={minecraftSteveImg} 
                  alt="Minecraft Steve Cutout" 
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-center transform group-hover:scale-105 transition-transform duration-700"
                />

                {/* Overlaid Badges */}
                <div className="absolute top-3 left-3 flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/70 backdrop-blur-md border border-white/10 text-white text-[10px] font-bold tracking-widest uppercase">
                  <Sparkles size={12} className="text-emerald-400" />
                  <span>Minecraft Ready</span>
                </div>

                <div className="absolute bottom-3 left-3 right-3 p-3.5 rounded-xl bg-black/80 backdrop-blur-md border border-white/10 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-black uppercase text-white tracking-wider">Steve Edition</div>
                    <div className="text-[10px] text-emerald-400 font-mono font-medium">99.99% Guaranteed Uptime</div>
                  </div>
                  <Link 
                    to="/games"
                    className="p-2 rounded-lg bg-accent text-white hover:bg-accent-muted transition-colors shrink-0"
                    title="Deploy Minecraft Server"
                  >
                    <ArrowRight size={16} />
                  </Link>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};
