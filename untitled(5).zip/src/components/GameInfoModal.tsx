import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Gamepad2, 
  Cpu, 
  HardDrive, 
  ShieldCheck, 
  Zap, 
  Server, 
  Layers, 
  Users, 
  Terminal, 
  Clock, 
  CheckCircle2, 
  ArrowRight,
  Info,
  Globe,
  Download
} from 'lucide-react';
import { Game } from '../types';

interface GameInfoModalProps {
  game: Game | null;
  onClose: () => void;
  onDeploy: (game: Game) => void;
}

// Game specific detailed knowledge base fallback for extra descriptions
const GAME_DESCRIPTIONS: Record<string, {
  tagline: string;
  overview: string;
}> = {
  'game-minecraft': {
    tagline: 'World’s #1 Sandbox Multiplayer Protocol',
    overview: 'Minecraft dedicated server hosting provides deterministic performance for Java and Bedrock editions. Fully compatible with Spigot, Paper, Purpur, Fabric, Forge, and NeoForge modding APIs, alongside GeyserMC Bedrock crossplay bridge.',
  },
  'game-palworld': {
    tagline: 'High-Performance Open-World Survival Crafting',
    overview: 'Palworld server hosting engineered specifically to mitigate Unreal Engine 5 memory footprint issues with automated RAM garbage collection, dedicated high-frequency CPU cores, and seamless Steam/Xbox GamePass multi-tenancy.',
  },
  'game-rust': {
    tagline: 'Brutal Hardcore Multiplayer Survival',
    overview: 'Ultra high-frequency Rust hosting built for fast wipe load times and stable 100+ tick rates. Supports uMod (Oxide), Carbon, and custom plugins with high entity counts and large procedural map seeds.',
  },
  'game-fivem': {
    tagline: 'GTA V Multiplayer Roleplay & Custom Server Platform',
    overview: 'Complete FiveM server environment pre-equipped with TxAdmin web console, MySQL database integration, and OneSync support for ESX, QBCore, and custom Lua script frameworks.',
  },
};

export const GameInfoModal: React.FC<GameInfoModalProps> = ({
  game,
  onClose,
  onDeploy,
}) => {
  if (!game) return null;

  const gameIdClean = game.id.toLowerCase();
  const gameSlug = game.id.toLowerCase().replace('game-', '');
  const descFallback = GAME_DESCRIPTIONS[gameIdClean] || GAME_DESCRIPTIONS[`game-${gameSlug}`];

  const details = {
    tagline: descFallback?.tagline || game.badge || `${game.title} Dedicated Infrastructure`,
    overview: game.description || descFallback?.overview || `High-performance ${game.title} dedicated server hosting provisioned on AMD Ryzen hardware with low-latency Indian routing, automated backups, and Pterodactyl panel control.`,
    serverSoftware: game.metadata?.serverSoftware || ['Dedicated Server Engine', 'Pterodactyl Game Panel v1.11', 'SFTP File Access'],
    recommendedSpecs: {
      minimumRam: game.ramOptions?.[0]?.ram || '4 GB',
      recommendedRam: game.metadata?.recommendedRam || game.ramOptions?.[Math.floor(game.ramOptions.length / 2)]?.ram || '16 GB',
      cpuType: game.metadata?.cpuType || 'AMD Ryzen 9 5950X (High Single-Thread Clock)',
      players: game.metadata?.players || '10 to 100+ Players',
      storage: game.metadata?.storage || 'Enterprise Gen4 NVMe RAID',
    },
    features: [
      'Pterodactyl Game Panel with full web-based terminal and live console',
      'Sub-15ms Indian latency with Tier 4 Mumbai data center routing',
      'Layer 7 DDoS protection specifically tuned for multiplayer game traffic',
      'Automated daily backups and one-click snapshot restorations',
      'Full root SFTP file access for custom configurations and files',
      '24/7 technical helpdesk support from real hosting specialists'
    ],
    adminHighlights: [
      'Dedicated compute resources with zero noisy neighbor throttling',
      'Instant automated provisioning within 60 seconds of invoice payment'
    ]
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/85 backdrop-blur-md"
        />

        {/* Modal Content */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative w-full max-w-3xl bg-[#0c0916] border border-purple-900/50 rounded-2xl shadow-2xl overflow-hidden z-10 text-slate-100 my-8 flex flex-col max-h-[90vh]"
        >
          {/* Cover Header */}
          <div className="relative h-52 sm:h-64 overflow-hidden shrink-0">
            <img
              src={game.image}
              alt={game.title}
              className="w-full h-full object-cover object-center scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0c0916] via-[#0c0916]/70 to-black/40" />

            {/* Close Button */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 rounded-full bg-black/60 hover:bg-black text-slate-300 hover:text-white border border-white/10 transition-all z-20 cursor-pointer"
              title="Close modal"
            >
              <X size={18} />
            </button>

            {/* Info Badge & Title */}
            <div className="absolute bottom-4 left-6 right-6">
              <div className="flex flex-wrap items-center gap-2 mb-2">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-purple-600/80 border border-purple-400/40 text-white text-[10px] font-mono font-bold uppercase tracking-widest shadow-md">
                  <Gamepad2 size={12} />
                  {game.category}
                </span>
                {game.badge && (
                  <span className="inline-flex items-center px-2.5 py-1 rounded-md bg-indigo-600/80 border border-indigo-400/40 text-white text-[10px] font-mono font-bold uppercase tracking-widest shadow-md">
                    {game.badge}
                  </span>
                )}
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-black/50 border border-white/10 text-emerald-400 text-[10px] font-mono font-bold uppercase tracking-widest">
                  <CheckCircle2 size={11} />
                  Pterodactyl v1.11 Ready
                </span>
              </div>

              <h2 className="text-2xl sm:text-4xl font-extrabold text-white uppercase tracking-tight font-sans drop-shadow-md">
                {game.title}
              </h2>
              <p className="text-xs sm:text-sm text-purple-300 font-medium mt-1">
                {details.tagline}
              </p>
            </div>
          </div>

          {/* Modal Scrollable Body */}
          <div className="p-6 sm:p-8 space-y-6 overflow-y-auto custom-scrollbar flex-1">
            
            {/* Overview Section */}
            <div className="space-y-2">
              <div className="text-[11px] font-mono uppercase font-bold text-slate-400 tracking-wider flex items-center gap-2">
                <Info size={14} className="text-purple-400" />
                <span>Game Server Overview</span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed bg-[#120e20] border border-purple-900/30 p-4 rounded-xl">
                {details.overview}
              </p>
            </div>

            {/* Platforms Supported */}
            <div className="space-y-2">
              <div className="text-[11px] font-mono uppercase font-bold text-slate-400 tracking-wider flex items-center gap-2">
                <Layers size={14} className="text-purple-400" />
                <span>Supported Client Platforms & Editions</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {game.platforms.map((plat) => (
                  <span
                    key={plat}
                    className="px-3 py-1.5 rounded-lg bg-[#140e25] border border-purple-900/40 text-xs font-mono font-bold text-slate-200 flex items-center gap-2"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-purple-400" />
                    {plat}
                  </span>
                ))}
              </div>
            </div>

            {/* Hardware & Server Spec Recommendations */}
            <div className="space-y-3">
              <div className="text-[11px] font-mono uppercase font-bold text-slate-400 tracking-wider flex items-center gap-2">
                <Cpu size={14} className="text-purple-400" />
                <span>Recommended Hardware Specifications</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3.5 rounded-xl bg-[#120e20] border border-purple-900/30 space-y-1">
                  <span className="text-[10px] font-mono uppercase text-slate-400 block">Memory (RAM) Footprint</span>
                  <div className="text-xs font-bold text-white">Min: {details.recommendedSpecs.minimumRam}</div>
                  <div className="text-[11px] text-purple-300 font-medium">Rec: {details.recommendedSpecs.recommendedRam}</div>
                </div>

                <div className="p-3.5 rounded-xl bg-[#120e20] border border-purple-900/30 space-y-1">
                  <span className="text-[10px] font-mono uppercase text-slate-400 block">Processor Architecture</span>
                  <div className="text-xs font-bold text-white">{details.recommendedSpecs.cpuType}</div>
                  <div className="text-[11px] text-emerald-400 font-medium">Sub-15ms Indian Jitter</div>
                </div>

                <div className="p-3.5 rounded-xl bg-[#120e20] border border-purple-900/30 space-y-1">
                  <span className="text-[10px] font-mono uppercase text-slate-400 block">Supported Player Slots</span>
                  <div className="text-xs font-bold text-white">{details.recommendedSpecs.players}</div>
                  <div className="text-[11px] text-slate-400">Unmetered concurrent connections</div>
                </div>

                <div className="p-3.5 rounded-xl bg-[#120e20] border border-purple-900/30 space-y-1">
                  <span className="text-[10px] font-mono uppercase text-slate-400 block">Storage Technology</span>
                  <div className="text-xs font-bold text-white">{details.recommendedSpecs.storage}</div>
                  <div className="text-[11px] text-purple-300">Fast map chunk rendering</div>
                </div>
              </div>
            </div>

            {/* Server Software & Frameworks */}
            <div className="space-y-2">
              <div className="text-[11px] font-mono uppercase font-bold text-slate-400 tracking-wider flex items-center gap-2">
                <Terminal size={14} className="text-purple-400" />
                <span>Compatible Software Engines & Mod Loaders</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {details.serverSoftware.map((sw, i) => (
                  <div key={i} className="flex items-center gap-2 p-2.5 rounded-lg bg-[#0e0a1a] border border-purple-900/20 text-xs text-slate-300">
                    <CheckCircle2 size={13} className="text-emerald-400 shrink-0" />
                    <span>{sw}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Key Features Included */}
            <div className="space-y-2">
              <div className="text-[11px] font-mono uppercase font-bold text-slate-400 tracking-wider flex items-center gap-2">
                <ShieldCheck size={14} className="text-purple-400" />
                <span>Platform Infrastructure & Included Capabilities</span>
              </div>
              <ul className="space-y-2 text-xs text-slate-300">
                {details.features.map((feat, idx) => (
                  <li key={idx} className="flex items-start gap-2.5 p-2 rounded-lg bg-[#120e20]/60">
                    <Zap size={14} className="text-amber-400 shrink-0 mt-0.5" />
                    <span>{feat}</span>
                  </li>
                ))}
              </ul>
            </div>

          </div>

          {/* Modal Footer Actions */}
          <div className="p-4 sm:p-6 bg-[#07050d] border-t border-purple-900/40 flex flex-col sm:flex-row items-center justify-between gap-4 shrink-0">
            <div className="text-xs text-slate-400 font-mono text-center sm:text-left">
              <span>Looking to start this server? </span>
              <strong className="text-white">Choose from admin-configured hosting plans</strong>
            </div>

            <div className="flex items-center gap-3 w-full sm:w-auto">
              <button
                onClick={onClose}
                className="flex-1 sm:flex-initial px-5 py-3 rounded-xl border border-white/10 text-slate-300 hover:text-white text-xs font-bold uppercase tracking-wider hover:bg-white/5 transition-all cursor-pointer"
              >
                Close
              </button>
              <button
                onClick={() => {
                  onClose();
                  onDeploy(game);
                }}
                className="flex-1 sm:flex-initial px-6 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2 shadow-lg shadow-purple-600/30 transition-all cursor-pointer"
              >
                <span>View & Deploy Plans</span>
                <ArrowRight size={14} />
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
