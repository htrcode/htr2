import React, { useState, useEffect } from 'react';
import { 
  X, Layout, Shield, LogOut, ChevronRight, Check, UserPlus, Globe, Cpu,
  FileText, ShieldAlert, RotateCcw, Megaphone, AlertTriangle, Mail, QrCode, 
  PhoneCall, Chrome, Lock, Plus, Layers, Trash2, Edit2, Server, MapPin, 
  Database, Terminal, Clock, Activity, Wifi, RefreshCw, Users, CreditCard, 
  Box, CheckCircle2, Search, ExternalLink, ShieldCheck, LifeBuoy, Star, 
  Gamepad2, Settings, Zap, ArrowRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AppData, Plan, ServiceStatus, Invoice, UserService, UserProfile, Ticket } from '../types';
import { dataService } from '../services/dataService';
import { authService, ROOT_ADMIN_EMAILS } from '../services/authService';
import { adminService } from '../services/adminService';
import { ticketService } from '../services/ticketService';
import { logService, LogEntry } from '../services/logService';
import { User as FirebaseUser } from 'firebase/auth';
import { TicketsTab } from './admin/TicketsTab';
import { PterodactylTab } from './admin/PterodactylTab';
import { PageContentEditorTab } from './admin/PageContentEditorTab';
import { ReviewsTab } from './admin/ReviewsTab';
import { GamesTab } from './admin/GamesTab';
import { ProductConfigsTab } from './admin/ProductConfigsTab';
import { InvoiceDocumentModal } from './InvoiceDocumentModal';
import { ClientProfileModal } from './admin/ClientProfileModal';
import { AdminOmnibar } from './admin/AdminOmnibar';
import { DashboardTab } from './admin/DashboardTab';
import { BillingInvoicesTab } from './admin/BillingInvoicesTab';
import { ClientServicesTab } from './admin/ClientServicesTab';
import { ClientsUsersTab } from './admin/ClientsUsersTab';
import { BrandSettingsTab } from './admin/BrandSettingsTab';
import { PlansCatalogTab } from './admin/PlansCatalogTab';
import { SystemHealthTab } from './admin/SystemHealthTab';
import { betterStackService } from '../services/betterStackService';
import { parseAmount, formatINR } from '../utils/formatUtils';

interface AdminPanelProps {
  data: AppData;
  setData: (data: AppData) => void;
  onClose: () => void;
  user: FirebaseUser | null;
  isAdmin: boolean;
}

type Tab = 
  | 'dashboard' 
  | 'users'
  | 'admins'
  | 'invoices'
  | 'orders'
  | 'plans'
  | 'games'
  | 'productConfigs'
  | 'pterodactyl'
  | 'tickets'
  | 'reviews'
  | 'status'
  | 'settings'
  | 'cms'
  | 'logs';

export const AdminPanel: React.FC<AdminPanelProps> = ({ 
  data, 
  setData, 
  onClose, 
  user, 
  isAdmin 
}) => {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [localData, setLocalData] = useState<AppData>(data);
  const [cmsPageType, setCmsPageType] = useState<'tos' | 'privacy' | 'refund' | 'about' | 'infrastructure' | 'legal'>('tos');

  // Core Management Data
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [orders, setOrders] = useState<UserService[]>([]);
  const [usersList, setUsersList] = useState<UserProfile[]>([]);
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [admins, setAdmins] = useState<{ uid: string, email: string }[]>([]);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [isLoadingManagement, setIsLoadingManagement] = useState(false);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  // Status / Better Stack
  const [betterStackData, setBetterStackData] = useState<any>(null);
  const [isBetterStackLoading, setIsBetterStackLoading] = useState(false);

  // Toast System
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);

  // Modals
  const [isOmnibarOpen, setIsOmnibarOpen] = useState(false);
  const [selectedClientForProfile, setSelectedClientForProfile] = useState<UserProfile | null>(null);
  const [isClientProfileOpen, setIsClientProfileOpen] = useState(false);
  const [selectedInvoiceForDoc, setSelectedInvoiceForDoc] = useState<Invoice | null>(null);
  const [isManualInvoiceModalOpen, setIsManualInvoiceModalOpen] = useState(false);
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [editingOrder, setEditingOrder] = useState<UserService | null>(null);
  const [isPlanModalOpen, setIsPlanModalOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState<Plan | null>(null);
  const [verifyingInvoice, setVerifyingInvoice] = useState<Invoice | null>(null);

  // Helper to resolve product specs for payment verification review
  const getProductSpecsForReview = (item: any) => {
    const planId = item?.planId || item?.product_id;
    if (!planId) return null;

    // 1. Look up in general hosting plans
    const plan = localData.plans?.find(p => p.id === planId || p.product_id === planId);
    if (plan) {
      return {
        name: plan.name,
        subcategory: plan.subcategory || 'Standard',
        ram: plan.ram || 'N/A',
        slots: plan.slots || 'N/A',
        price: plan.price_inr || plan.price,
        cpu: plan.cpu || 'N/A',
        processor: plan.processor || 'N/A',
        storage: plan.storage || 'N/A',
        ddos: plan.ddosProtection || 'N/A'
      };
    }

    // 2. Look up in game server configurations
    for (const game of localData.games || []) {
      if (game.ramOptions) {
        for (let idx = 0; idx < game.ramOptions.length; idx++) {
          const opt = game.ramOptions[idx];
          const tierId = `${game.id}-tier-${idx}`;
          if (opt.product_id === planId || opt.id === planId || tierId === planId || tierId.toLowerCase() === planId.toLowerCase()) {
            return {
              name: opt.name || `${game.title} - ${opt.ram} (${opt.slots})`,
              subcategory: opt.subcategory || 'Standard',
              ram: opt.ram || 'N/A',
              slots: opt.slots || 'N/A',
              price: opt.priceInr,
              cpu: opt.cpu || 'N/A',
              processor: opt.processor || game.metadata?.cpuType || 'N/A',
              storage: opt.storage || game.metadata?.storage || 'N/A',
              ddos: opt.ddosProtection || 'N/A'
            };
          }
        }
      }
    }

    return {
      name: item.name,
      subcategory: 'Standard',
      ram: 'N/A',
      slots: 'N/A',
      price: item.price,
      cpu: 'N/A',
      processor: 'N/A',
      storage: 'N/A',
      ddos: 'N/A'
    };
  };

  const parseNotesForReview = (notesText?: string) => {
    if (!notesText) return null;
    const parts = notesText.split(' | ');
    const configs: { label: string; value: string }[] = [];
    parts.forEach(part => {
      const idx = part.indexOf(': ');
      if (idx !== -1) {
        const label = part.slice(0, idx).trim();
        const value = part.slice(idx + 2).trim();
        if (label && value && !label.toLowerCase().includes('utr') && !label.toLowerCase().includes('payment')) {
          configs.push({ label, value });
        }
      }
    });
    return configs.length > 0 ? configs : null;
  };

  // Confirm Modal
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    confirmText?: string;
    confirmVariant?: 'primary' | 'danger' | 'warning' | 'success';
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {}
  });

  // Manual Invoice Form
  const [manualInvoiceForm, setManualInvoiceForm] = useState({
    userId: '',
    customUserEmail: '',
    invoiceNumber: '',
    paymentMethod: 'UPI / Manual Transfer (Outside)',
    utrNumber: '',
    status: 'Paid' as 'Paid' | 'Unpaid' | 'Cancelled',
    notes: '',
    itemName: 'Game Hosting Plan',
    itemPrice: '299',
    itemQuantity: 1,
    category: 'Game Server',
    planId: '',
    autoCreateService: true,
    serviceLocation: 'India (Mumbai)',
    serviceNodeName: 'Ryzen-KVM-Node-01'
  });

  // Service Edit Form
  const [orderForm, setOrderForm] = useState({
    name: '',
    nodeName: '',
    location: '',
    ip: '',
    status: 'active' as UserService['status'],
    expiresAt: '',
    panelLink: '',
    panelEmail: '',
    panelPassword: '',
    serverId: '',
    sshPort: '22',
    sshUsername: 'root',
    port: '22',
    rootPassword: '',
    serverType: 'panel' as 'panel' | 'vps_dedicated'
  });

  // Plan Edit Form
  const [planForm, setPlanForm] = useState({
    name: '',
    price: '',
    price_inr: '',
    price_eur: '',
    badge: '',
    category: 'RYZEN-VPS',
    location: 'India (Mumbai)',
    node: 'Ryzen-KVM-Node-01',
    desc: '',
    ram: '',
    cpu: '',
    processor: '',
    storage: '',
    ddosProtection: '',
    networkSpeed: '',
    slots: '',
    featuresText: '',
    is_active: true
  });

  // Provisioning Fields
  const [provisionType, setProvisionType] = useState<'panel' | 'vps_dedicated'>('panel');
  const [provisionServerId, setProvisionServerId] = useState('');
  const [provisionPanelLink, setProvisionPanelLink] = useState('https://gp.hector.host');
  const [provisionPanelEmail, setProvisionPanelEmail] = useState('');
  const [provisionIp, setProvisionIp] = useState('');
  const [provisionSshPort, setProvisionSshPort] = useState('22');
  const [provisionSshUsername, setProvisionSshUsername] = useState('root');
  const [provisionSshPassword, setProvisionSshPassword] = useState('');

  const isInvoiceVpsOrDedicated = (inv: Invoice): boolean => {
    const category = inv.items?.[0]?.category || '';
    const name = inv.items?.[0]?.name || '';
    const text = `${category} ${name}`.toLowerCase();
    return text.includes('vps') || text.includes('dedicated') || text.includes('kvm') || text.includes('bare metal') || text.includes('intel') || text.includes('ryzen vps');
  };

  useEffect(() => {
    if (verifyingInvoice) {
      const isVps = isInvoiceVpsOrDedicated(verifyingInvoice);
      setProvisionType(isVps ? 'vps_dedicated' : 'panel');
      setProvisionServerId('');
      setProvisionPanelLink('https://gp.hector.host');
      setProvisionPanelEmail(verifyingInvoice.userId.includes('@') ? verifyingInvoice.userId : '');
      setProvisionIp('194.26.183.' + Math.floor(10 + Math.random() * 200));
      setProvisionSshPort('22');
      setProvisionSshUsername('root');
      setProvisionSshPassword(Math.random().toString(36).substring(2, 10) + '!');
    }
  }, [verifyingInvoice]);

  // Hotkey listener for Omnibar (Ctrl+K or /)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        setIsOmnibarOpen(true);
      }
      if (e.key === '/' && document.activeElement?.tagName !== 'INPUT' && document.activeElement?.tagName !== 'TEXTAREA') {
        e.preventDefault();
        setIsOmnibarOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  };

  // Load Management Data
  const loadManagementData = async () => {
    setIsLoadingManagement(true);
    try {
      const [invs, srvs, usrs, tkts] = await Promise.all([
        adminService.getAllInvoices(),
        adminService.getAllServices(),
        adminService.getAllUsers(),
        ticketService.getAllTickets().catch(() => [])
      ]);
      setInvoices(invs);
      setOrders(srvs);
      setUsersList(usrs);
      setTickets(tkts);
      logService.addLog('info', 'Loaded management data from Firestore.');
    } catch (err: any) {
      console.error('Error fetching admin data:', err);
    } finally {
      setIsLoadingManagement(false);
    }
  };

  useEffect(() => {
    if (user && isAdmin) {
      loadManagementData();
      setLogs(logService.getLogs());
    }
  }, [user, isAdmin]);

  // Sync with prop data
  useEffect(() => {
    setLocalData(data);
  }, [data]);

  // Connected Action: Verify Invoice & Auto-Provision Service (WHMCS standard)
  const handleVerifyInvoiceAndProvision = async (invoiceId: string) => {
    const inv = invoices.find(i => i.id === invoiceId);
    if (!inv) return;
    setVerifyingInvoice(inv);
  };

  const executeVerifyInvoiceAndProvision = async (invoiceId: string) => {
    setActionLoading(invoiceId);
    try {
      const inv = invoices.find(i => i.id === invoiceId);
      if (!inv) return;

      // 1. Mark Invoice Paid in Firestore
      await adminService.updateInvoiceStatus(invoiceId, 'Paid');
      setInvoices(prev => prev.map(i => i.id === invoiceId ? { ...i, status: 'Paid' } : i));

      // 2. Check for linked pending service
      const linkedService = orders.find(o => 
        o.invoiceId === invoiceId || 
        (o.userId === inv.userId && o.status === 'pending')
      );

      const item = (inv.items?.[0] || { name: 'Hosting Plan', price: inv.total, category: 'Hosting' }) as any;
      const isVps = provisionType === 'vps_dedicated';

      const commonFields = {
        status: 'active' as const,
        serverType: provisionType,
      };

      const panelFields = {
        serverId: provisionServerId,
        panelLink: provisionPanelLink || 'https://gp.hector.host',
        panelEmail: provisionPanelEmail || (inv.userId.includes('@') ? inv.userId : ''),
        panelPassword: '', // Uses user's primary account password
        ip: '',
        sshPort: '',
        sshUsername: '',
        rootPassword: ''
      };

      const sshFields = {
        ip: provisionIp,
        sshPort: provisionSshPort,
        sshUsername: provisionSshUsername,
        rootPassword: provisionSshPassword,
        panelPassword: provisionSshPassword, // fallback as access password
        serverId: '',
        panelLink: '',
        panelEmail: ''
      };

      const finalServiceFields = {
        ...commonFields,
        ...(isVps ? sshFields : panelFields)
      };

      if (linkedService) {
        await adminService.updateService(linkedService.id, finalServiceFields);
        setOrders(prev => prev.map(o => o.id === linkedService.id ? { ...o, ...finalServiceFields } : o));
        logService.addLog('success', `Activated existing service "${linkedService.name}" with custom credentials for Invoice #${inv.invoiceNumber || invoiceId}`);
      } else {
        // 3. Auto-provision a new service for the client
        const newServiceData: Omit<UserService, 'id'> = {
          userId: inv.userId,
          planId: item.planId || 'auto-plan',
          name: item.name,
          location: 'India (Mumbai)',
          nodeName: localData.nodes?.[0] || 'Ryzen-KVM-Node-01',
          createdAt: new Date().toISOString(),
          expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
          autoRenew: true,
          price: inv.total,
          category: item.category || 'Hosting Plan',
          invoiceId: invoiceId,
          ...finalServiceFields
        };
        const newId = await adminService.addService(newServiceData);
        setOrders(prev => [{ ...newServiceData, id: newId }, ...prev]);
        logService.addLog('success', `Auto-provisioned new active service with custom credentials for Invoice #${inv.invoiceNumber || invoiceId}`);
      }

      showToast(`Invoice #${inv.invoiceNumber || invoiceId} marked Paid & Service provisioned!`, 'success');
      setVerifyingInvoice(null);
    } catch (err: any) {
      console.error(err);
      alert(`Failed to verify payment: ${err.message}`);
    } finally {
      setActionLoading(null);
    }
  };

  // Connected Action: Update Service Status (Suspend / Activate)
  const handleUpdateServiceStatus = async (serviceId: string, status: UserService['status']) => {
    setActionLoading(serviceId);
    try {
      await adminService.updateService(serviceId, { status });
      setOrders(prev => prev.map(o => o.id === serviceId ? { ...o, status } : o));
      logService.addLog('success', `Service ${serviceId} status updated to ${status}.`);
      showToast(`Service status updated to ${status}.`, 'success');
    } catch (err: any) {
      alert(`Failed to update service: ${err.message}`);
    } finally {
      setActionLoading(null);
    }
  };

  // Delete Service
  const handleDeleteService = async (serviceId: string) => {
    setConfirmModal({
      isOpen: true,
      title: 'Terminate & Delete Service',
      message: 'Are you sure you want to terminate and delete this hosting service? Client access will be revoked.',
      confirmText: 'Terminate Service',
      confirmVariant: 'danger',
      onConfirm: async () => {
        setActionLoading(serviceId);
        try {
          await adminService.deleteService(serviceId);
          setOrders(prev => prev.filter(o => o.id !== serviceId));
          logService.addLog('warning', `Service ${serviceId} deleted.`);
          showToast('Service deleted successfully.', 'info');
        } catch (err: any) {
          alert(`Failed to delete service: ${err.message}`);
        } finally {
          setActionLoading(null);
        }
      }
    });
  };

  // Delete Invoice
  const handleDeleteInvoice = async (invoiceId: string) => {
    setConfirmModal({
      isOpen: true,
      title: 'Delete Invoice Record',
      message: 'Are you sure you want to delete this invoice record from the database?',
      confirmText: 'Delete Record',
      confirmVariant: 'danger',
      onConfirm: async () => {
        setActionLoading(invoiceId);
        try {
          await adminService.deleteInvoice(invoiceId);
          setInvoices(prev => prev.filter(i => i.id !== invoiceId));
          logService.addLog('warning', `Invoice ${invoiceId} deleted.`);
          showToast('Invoice deleted.', 'info');
        } catch (err: any) {
          alert(`Failed to delete invoice: ${err.message}`);
        } finally {
          setActionLoading(null);
        }
      }
    });
  };

  // Toggle User Role (Admin / User)
  const handleToggleUserRole = async (userId: string, currentRole: 'admin' | 'user') => {
    const newRole = currentRole === 'admin' ? 'user' : 'admin';
    try {
      await adminService.updateUserRole(userId, newRole);
      setUsersList(prev => prev.map(u => u.id === userId ? { ...u, role: newRole } : u));
      if (selectedClientForProfile && selectedClientForProfile.id === userId) {
        setSelectedClientForProfile({ ...selectedClientForProfile, role: newRole });
      }
      logService.addLog('success', `User ${userId} role changed to ${newRole}.`);
      showToast(`User role changed to ${newRole}.`, 'success');
    } catch (err: any) {
      alert(`Failed to update role: ${err.message}`);
    }
  };

  // Delete User Account
  const handleDeleteUser = async (userId: string) => {
    setConfirmModal({
      isOpen: true,
      title: 'Delete Client Account',
      message: 'Are you sure you want to permanently delete this user account from the database?',
      confirmText: 'Delete Account',
      confirmVariant: 'danger',
      onConfirm: async () => {
        try {
          await adminService.deleteUser(userId);
          setUsersList(prev => prev.filter(u => u.id !== userId));
          setIsClientProfileOpen(false);
          logService.addLog('warning', `User ${userId} deleted.`);
          showToast('Client account deleted.', 'info');
        } catch (err: any) {
          alert(`Failed to delete user: ${err.message}`);
        }
      }
    });
  };

  // Plan Management Actions
  const openCreatePlan = () => {
    setEditingPlan(null);
    setPlanForm({
      name: '',
      price: '299',
      price_inr: '299',
      price_eur: '4',
      badge: '',
      category: localData.categories?.[0] || 'RYZEN-VPS',
      location: localData.locations?.[0] || 'India (Mumbai)',
      node: localData.nodes?.[0] || 'Ryzen-KVM-Node-01',
      desc: '',
      ram: '4 GB DDR5',
      cpu: '2 vCPU Cores',
      processor: 'AMD Ryzen 9 7950X',
      storage: '50 GB NVMe Gen4',
      ddosProtection: 'Path.net 12 Tbps+ Anti-DDoS',
      networkSpeed: '1 Gbps Unmetered',
      slots: '',
      featuresText: 'High Performance Gen4 NVMe\nDDoS Protection by Path.net\n24/7 Priority Support',
      is_active: true
    });
    setIsPlanModalOpen(true);
  };

  const openEditPlan = (plan: Plan) => {
    setEditingPlan(plan);
    setPlanForm({
      name: plan.name,
      price: plan.price || '',
      price_inr: plan.price_inr || '',
      price_eur: plan.price_eur || '',
      badge: plan.badge || '',
      category: plan.category || 'RYZEN-VPS',
      location: plan.location || 'India (Mumbai)',
      node: plan.node || 'Ryzen-KVM-Node-01',
      desc: plan.desc || '',
      ram: plan.ram || '',
      cpu: plan.cpu || '',
      processor: plan.processor || '',
      storage: plan.storage || '',
      ddosProtection: plan.ddosProtection || '',
      networkSpeed: plan.networkSpeed || '',
      slots: plan.slots || '',
      featuresText: plan.features?.join('\n') || '',
      is_active: plan.is_active !== false && !plan.archived
    });
    setIsPlanModalOpen(true);
  };

  const handleSavePlan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!planForm.name || !planForm.price_inr) {
      alert('Please fill in plan name and price in INR.');
      return;
    }
    setActionLoading('save-plan');
    try {
      const featuresArray = planForm.featuresText.split('\n').map(f => f.trim()).filter(Boolean);
      const planPayload: Plan = {
        id: editingPlan?.id || `plan-${Date.now()}`,
        name: planForm.name,
        price: planForm.price_inr,
        price_inr: planForm.price_inr,
        price_eur: planForm.price_eur || '4',
        badge: planForm.badge,
        category: planForm.category,
        location: planForm.location,
        node: planForm.node,
        desc: planForm.desc,
        ram: planForm.ram,
        cpu: planForm.cpu,
        processor: planForm.processor,
        storage: planForm.storage,
        ddosProtection: planForm.ddosProtection,
        networkSpeed: planForm.networkSpeed,
        slots: planForm.slots,
        features: featuresArray,
        order: editingPlan?.order ?? localData.plans.length,
        is_active: planForm.is_active
      };

      if (editingPlan) {
        await dataService.updatePlan(editingPlan.id, planPayload);
        setLocalData(prev => ({
          ...prev,
          plans: prev.plans.map(p => p.id === editingPlan.id ? { ...p, ...planPayload } : p)
        }));
        setData({
          ...data,
          plans: data.plans.map(p => p.id === editingPlan.id ? { ...p, ...planPayload } : p)
        });
      } else {
        const newId = await dataService.addPlan(planPayload);
        if (newId) {
          setLocalData(prev => ({ ...prev, plans: [...prev.plans, { ...planPayload, id: newId }] }));
          setData({ ...data, plans: [...data.plans, { ...planPayload, id: newId }] });
        }
      }
      setIsPlanModalOpen(false);
      showToast('Hosting plan saved to Firestore.', 'success');
    } catch (err: any) {
      alert(`Failed to save plan: ${err.message}`);
    } finally {
      setActionLoading(null);
    }
  };

  const handleMovePlan = async (planId: string, direction: 'up' | 'down') => {
    const targetPlan = (localData.plans || []).find(pl => pl.id === planId);
    if (!targetPlan) return;
    const plansInCategory = (localData.plans || [])
      .filter(p => p.category === targetPlan.category)
      .sort((a, b) => (a.order || 0) - (b.order || 0));
    const index = plansInCategory.findIndex(p => p.id === planId);
    if (index === -1) return;
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= plansInCategory.length) return;

    const otherPlan = plansInCategory[newIndex];
    const currentOrder = targetPlan.order || index;
    const otherOrder = otherPlan.order || newIndex;

    try {
      await dataService.updatePlan(targetPlan.id, { order: otherOrder });
      await dataService.updatePlan(otherPlan.id, { order: currentOrder });
      setLocalData(prev => ({
        ...prev,
        plans: prev.plans.map(p => {
          if (p.id === targetPlan.id) return { ...p, order: otherOrder };
          if (p.id === otherPlan.id) return { ...p, order: currentOrder };
          return p;
        })
      }));
    } catch (err: any) {
      console.error(err);
    }
  };

  const handleDeletePlan = async (planId: string) => {
    const targetPlan = localData.plans.find(p => p.id === planId);
    if (!targetPlan) return;

    // Check if active services linked
    const linkedOrders = orders.filter(o => o.planId === planId || o.name === targetPlan.name);
    if (linkedOrders.length > 0) {
      alert(`Cannot delete plan "${targetPlan.name}": There are ${linkedOrders.length} active or pending client services linked to this product. Deactivate or archive it instead to protect client servers.`);
      return;
    }

    setConfirmModal({
      isOpen: true,
      title: 'Delete Hosting Plan',
      message: `Are you sure you want to permanently delete "${targetPlan.name}"? It has 0 linked orders.`,
      confirmText: 'Delete Plan',
      confirmVariant: 'danger',
      onConfirm: async () => {
        try {
          await dataService.deletePlan(planId);
          setLocalData(prev => ({ ...prev, plans: prev.plans.filter(p => p.id !== planId) }));
          setData({ ...data, plans: data.plans.filter(p => p.id !== planId) });
          showToast('Plan deleted from catalog.', 'info');
        } catch (err: any) {
          alert(`Failed to delete plan: ${err.message}`);
        }
      }
    });
  };

  const handleAddCategory = async (catName: string) => {
    const clean = catName.trim().toUpperCase().replace(/\s+/g, '-');
    if (localData.categories.includes(clean)) return;
    const updated = [...localData.categories, clean];
    try {
      await dataService.updateSettings({ categories: updated });
      setLocalData(prev => ({ ...prev, categories: updated }));
      setData({ ...data, categories: updated });
      showToast(`Category ${clean} added.`, 'success');
    } catch (err: any) {
      alert(`Failed to add category: ${err.message}`);
    }
  };

  const handleDeleteCategory = async (catName: string) => {
    const plansInCategory = localData.plans.filter(p => p.category === catName);
    const linkedOrders = orders.filter(o => plansInCategory.some(p => p.id === o.planId || p.name === o.name));
    if (linkedOrders.length > 0) {
      alert(`Cannot delete category "${catName}": Active client orders belong to plans in this category.`);
      return;
    }

    const updated = localData.categories.filter(c => c !== catName);
    try {
      await dataService.updateSettings({ categories: updated });
      setLocalData(prev => ({ ...prev, categories: updated }));
      setData({ ...data, categories: updated });
      showToast(`Category ${catName} removed.`, 'info');
    } catch (err: any) {
      alert(`Failed to remove category: ${err.message}`);
    }
  };

  const handleAddLocation = async (locName: string) => {
    const clean = locName.trim();
    if (localData.locations.includes(clean)) return;
    const updated = [...localData.locations, clean];
    try {
      await dataService.updateSettings({ locations: updated });
      setLocalData(prev => ({ ...prev, locations: updated }));
      setData({ ...data, locations: updated });
      showToast(`Location ${clean} added.`, 'success');
    } catch (err: any) {
      alert(`Failed to add location: ${err.message}`);
    }
  };

  const handleDeleteLocation = async (locName: string) => {
    const updated = localData.locations.filter(l => l !== locName);
    try {
      await dataService.updateSettings({ locations: updated });
      setLocalData(prev => ({ ...prev, locations: updated }));
      setData({ ...data, locations: updated });
      showToast(`Location ${locName} removed.`, 'info');
    } catch (err: any) {
      alert(`Failed to remove location: ${err.message}`);
    }
  };

  // Open Edit Service Modal
  const openEditOrder = (order: UserService) => {
    setEditingOrder(order);
    const userEmail = usersList.find(u => u.id === order.userId)?.email || '';
    setOrderForm({
      name: order.name,
      nodeName: order.nodeName || 'Ryzen-KVM-Node-01',
      location: order.location || 'India (Mumbai)',
      ip: order.ip || '',
      status: order.status,
      expiresAt: order.expiresAt ? order.expiresAt.split('T')[0] : '',
      panelLink: order.panelLink || 'https://gp.hector.host',
      panelEmail: order.panelEmail || userEmail,
      panelPassword: order.panelPassword || '',
      serverId: order.serverId || '',
      sshPort: String(order.sshPort || '22'),
      sshUsername: order.sshUsername || 'root',
      port: String(order.port || '22'),
      rootPassword: order.rootPassword || '',
      serverType: order.serverType || 'panel'
    });
    setIsOrderModalOpen(true);
  };

  const handleSaveOrderForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingOrder) return;
    setActionLoading('save-order');
    try {
      const updatedData: Partial<UserService> = {
        name: orderForm.name,
        nodeName: orderForm.nodeName,
        location: orderForm.location,
        ip: orderForm.ip,
        status: orderForm.status,
        expiresAt: orderForm.expiresAt ? new Date(orderForm.expiresAt).toISOString() : editingOrder.expiresAt,
        panelLink: orderForm.panelLink,
        panelEmail: orderForm.panelEmail,
        panelPassword: orderForm.panelPassword,
        serverId: orderForm.serverId,
        sshPort: orderForm.sshPort,
        sshUsername: orderForm.sshUsername,
        port: orderForm.port,
        rootPassword: orderForm.rootPassword,
        serverType: orderForm.serverType
      };

      await adminService.updateService(editingOrder.id, updatedData);
      setOrders(prev => prev.map(o => o.id === editingOrder.id ? { ...o, ...updatedData } : o));
      setIsOrderModalOpen(false);
      logService.addLog('success', `Updated credentials for service "${orderForm.name}".`);
      showToast('Service credentials updated successfully!', 'success');
    } catch (err: any) {
      alert(`Failed to save service: ${err.message}`);
    } finally {
      setActionLoading(null);
    }
  };

  // Open Manual Invoice Generator
  const openManualInvoiceGenerator = (prefillUserId?: string, prefillUserEmail?: string) => {
    const randomInvNum = `INV-OUT-${Math.floor(100000 + Math.random() * 900000)}`;
    const randomUtr = `OUT-${Math.floor(10000000 + Math.random() * 90000000)}`;
    const defaultUser = prefillUserId || usersList[0]?.id || usersList[0]?.email || user?.uid || '';
    const defaultPlan = localData.plans?.[0];

    setManualInvoiceForm({
      userId: defaultUser,
      customUserEmail: prefillUserEmail || '',
      invoiceNumber: randomInvNum,
      paymentMethod: 'UPI / Manual Transfer (Outside)',
      utrNumber: randomUtr,
      status: 'Paid',
      notes: 'Manual payment recorded by Administrator.',
      itemName: defaultPlan?.name || 'Standard Hosting Plan',
      itemPrice: defaultPlan?.price_inr || defaultPlan?.price || '299',
      itemQuantity: 1,
      category: defaultPlan?.category || 'Game Server',
      planId: defaultPlan?.id || '',
      autoCreateService: true,
      serviceLocation: localData.locations?.[0] || 'India (Mumbai)',
      serviceNodeName: localData.nodes?.[0] || 'Ryzen-KVM-Node-01'
    });
    setIsManualInvoiceModalOpen(true);
  };

  const handleSaveManualInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    const finalUserId = (manualInvoiceForm.userId === 'CUSTOM' ? manualInvoiceForm.customUserEmail : manualInvoiceForm.userId).trim();
    if (!finalUserId) {
      alert('Please enter or select a Client User ID or Email.');
      return;
    }
    if (!manualInvoiceForm.planId || !manualInvoiceForm.itemName) {
      alert('Please select a Product / Plan from the dropdown list.');
      return;
    }
    setActionLoading('create-manual-invoice');
    try {
      const invId = manualInvoiceForm.invoiceNumber.trim() || `INV-${Date.now().toString().slice(-6)}`;
      const priceNum = parseFloat(manualInvoiceForm.itemPrice) || 0;
      const qtyNum = manualInvoiceForm.itemQuantity || 1;
      const totalAmount = priceNum * qtyNum;

      const newInvoice: Invoice = {
        id: invId,
        invoiceNumber: invId,
        userId: finalUserId,
        items: [{
          name: manualInvoiceForm.itemName.trim(),
          price: priceNum,
          quantity: qtyNum,
          category: manualInvoiceForm.category,
          planId: manualInvoiceForm.planId
        }],
        total: totalAmount,
        status: manualInvoiceForm.status,
        paymentMethod: manualInvoiceForm.paymentMethod,
        timestamp: new Date().toISOString(),
        utrNumber: manualInvoiceForm.utrNumber.trim() || undefined,
        notes: manualInvoiceForm.notes.trim() || 'Manual Invoice Recorded by Admin'
      };

      await adminService.createInvoice(newInvoice);
      setInvoices(prev => [newInvoice, ...prev]);

      if (manualInvoiceForm.autoCreateService) {
        const isPending = manualInvoiceForm.status === 'Unpaid';
        const newServiceData: Omit<UserService, 'id'> = {
          userId: finalUserId,
          planId: manualInvoiceForm.planId || 'manual-plan',
          name: manualInvoiceForm.itemName.trim(),
          status: isPending ? 'pending' : 'active',
          location: manualInvoiceForm.serviceLocation,
          nodeName: manualInvoiceForm.serviceNodeName,
          createdAt: new Date().toISOString(),
          expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
          autoRenew: true,
          price: totalAmount,
          category: manualInvoiceForm.category,
          invoiceId: invId,
          panelLink: 'https://gp.hector.host',
          panelEmail: finalUserId.includes('@') ? finalUserId : '',
          panelPassword: Math.random().toString(36).substring(2, 10),
          ip: '194.26.183.' + Math.floor(10 + Math.random() * 200)
        };
        const srvId = await adminService.addService(newServiceData);
        setOrders(prev => [{ ...newServiceData, id: srvId }, ...prev]);
      }

      setIsManualInvoiceModalOpen(false);
      logService.addLog('success', `Created manual invoice #${invId} for ${finalUserId}`);
      showToast(`Invoice #${invId} generated successfully!`, 'success');
    } catch (err: any) {
      alert(`Failed to create manual invoice: ${err.message}`);
    } finally {
      setActionLoading(null);
    }
  };

  // Open Client 360° Profile
  const handleOpenClientProfile = (userId: string) => {
    const foundUser = usersList.find(u => u.id === userId || u.email === userId);
    const clientObj: UserProfile = foundUser || {
      id: userId,
      email: userId.includes('@') ? userId : 'client@hector.host',
      displayName: userId.split('@')[0],
      role: 'user',
      createdAt: new Date().toISOString()
    };
    setSelectedClientForProfile(clientObj);
    setIsClientProfileOpen(true);
  };

  // Auth gate checks
  if (!user || !isAdmin) {
    return (
      <div className="fixed inset-0 z-[1000] bg-[#090d16] flex items-center justify-center p-6 font-sans text-slate-200">
        <div className="max-w-md w-full bg-[#111827] border border-slate-800 rounded-2xl p-8 text-center shadow-2xl space-y-5">
          <div className="w-14 h-14 bg-rose-500/10 border border-rose-500/20 rounded-2xl flex items-center justify-center mx-auto text-rose-400">
            <ShieldAlert size={28} />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white tracking-tight">Administrative Privileges Required</h3>
            <p className="text-xs text-slate-400 mt-2 leading-relaxed">
              You are currently signed in as <span className="font-mono text-slate-300">{user?.email || 'Guest'}</span>. 
              This portal requires verified Administrator credentials.
            </p>
          </div>
          <div className="pt-2 flex flex-col gap-2.5">
            <button
              onClick={onClose}
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-lg text-xs transition-colors"
            >
              Return to Storefront
            </button>
            {user && (
              <button
                onClick={() => authService.logout()}
                className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white font-medium rounded-lg text-xs transition-colors"
              >
                Sign Out
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Sidebar Groupings (WHMCS / Paymenter Standard)
  const sidebarNav = [
    {
      title: 'OPERATIONS',
      items: [
        { id: 'dashboard', label: 'Executive Dashboard', icon: Layout, badge: null },
        { id: 'status', label: 'System Health & Uptime', icon: Activity, badge: null }
      ]
    },
    {
      title: 'CLIENTS & USERS',
      items: [
        { id: 'users', label: 'Client Management', icon: Users, badge: usersList.length },
        { id: 'admins', label: 'Staff & Privileges', icon: ShieldCheck, badge: null }
      ]
    },
    {
      title: 'BILLING & FINANCE',
      items: [
        { 
          id: 'invoices', 
          label: 'Invoices & Payments', 
          icon: CreditCard, 
          badge: invoices.filter(i => i.status === 'Unpaid').length || null,
          badgeColor: 'bg-amber-500/20 text-amber-300'
        }
      ]
    },
    {
      title: 'HOSTING & SERVICES',
      items: [
        { 
          id: 'orders', 
          label: 'Client Services (Active)', 
          icon: Box, 
          badge: orders.filter(o => o.status === 'pending').length ? `${orders.filter(o => o.status === 'pending').length} pending` : null,
          badgeColor: 'bg-blue-500/20 text-blue-300'
        },
        { id: 'plans', label: 'Hosting Plans Catalog', icon: Layers, badge: localData.plans?.length },
        { id: 'games', label: 'Game Server Catalog', icon: Gamepad2, badge: localData.games?.length },
        { id: 'productConfigs', label: 'Software Options & Addons', icon: Settings, badge: null },
        { id: 'pterodactyl', label: 'Pterodactyl Daemon API', icon: Server, badge: null }
      ]
    },
    {
      title: 'SUPPORT & FEEDBACK',
      items: [
        { 
          id: 'tickets', 
          label: 'Support Tickets Desk', 
          icon: LifeBuoy, 
          badge: tickets.filter(t => t.status === 'open' || t.status === 'in_progress' || t.status === 'waiting_user').length || null,
          badgeColor: 'bg-purple-500/20 text-purple-300'
        },
        { id: 'reviews', label: 'Client Testimonials', icon: Star, badge: null }
      ]
    },
    {
      title: 'SYSTEM & SETTINGS',
      items: [
        { id: 'settings', label: 'Branding & Gateways', icon: Globe, badge: null },
        { id: 'cms', label: 'CMS Legal & Policy Pages', icon: FileText, badge: null },
        { id: 'logs', label: 'Audit & Activity Logs', icon: Terminal, badge: null }
      ]
    }
  ];

  return (
    <div className="fixed inset-0 z-[1000] bg-[#090d16] flex overflow-hidden font-sans text-slate-200">
      {/* 1. Left Sidebar Navigation */}
      <aside className="w-64 bg-[#0c111d] border-r border-slate-800 flex flex-col pt-5 shrink-0 select-none">
        {/* Top Branding */}
        <div className="px-5 pb-5 border-b border-slate-800/80">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-600/30">
              <Shield size={20} />
            </div>
            <div>
              <h1 className="text-sm font-bold text-white tracking-tight">Hector Admin</h1>
              <p className="text-[10px] text-slate-400 font-medium">Billing & Hosting Control</p>
            </div>
          </div>
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-5 custom-scrollbar">
          {sidebarNav.map(group => (
            <div key={group.title} className="space-y-1">
              <h3 className="px-3 text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                {group.title}
              </h3>
              {group.items.map(item => {
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id as Tab)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
                      isActive
                        ? 'bg-blue-600 text-white font-semibold shadow-sm'
                        : 'text-slate-300 hover:bg-slate-800/70 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <item.icon size={15} className={isActive ? 'text-white' : 'text-slate-400'} />
                      <span className="truncate">{item.label}</span>
                    </div>
                    {item.badge !== null && item.badge !== undefined && (
                      <span className={`px-1.5 py-0.2 rounded text-[10px] font-mono font-semibold ${
                        item.badgeColor || (isActive ? 'bg-blue-700 text-white' : 'bg-slate-800 text-slate-400')
                      }`}>
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </nav>

        {/* User Card & Logout Footer */}
        <div className="p-4 border-t border-slate-800/80 bg-[#0a0e1a]">
          <div className="flex items-center gap-2.5 px-2 py-2 mb-2 rounded-lg bg-slate-900 border border-slate-800">
            <div className="w-7 h-7 rounded-full bg-blue-600/30 text-blue-400 font-bold flex items-center justify-center text-xs">
              {user?.email?.[0]?.toUpperCase() || 'A'}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-semibold text-white truncate">{user?.email}</p>
              <p className="text-[10px] text-slate-400">Root Administrator</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={onClose}
              className="flex-1 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px] font-medium transition-colors text-center"
            >
              Storefront Preview
            </button>
            <button
              onClick={() => authService.logout()}
              className="p-1.5 bg-slate-800 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 rounded transition-colors"
              title="Sign Out"
            >
              <LogOut size={14} />
            </button>
          </div>
        </div>
      </aside>

      {/* 2. Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 bg-[#090d16]">
        {/* Top Header Bar */}
        <header className="h-16 border-b border-slate-800 bg-[#0c111d] px-6 flex items-center justify-between gap-4 shrink-0">
          {/* Left: Omnibar Quick Search Trigger */}
          <div className="flex items-center gap-4 flex-1 max-w-xl">
            <button
              onClick={() => setIsOmnibarOpen(true)}
              className="w-full max-w-md px-3.5 py-2 bg-slate-900 hover:bg-slate-850 border border-slate-800 rounded-lg text-xs text-slate-400 flex items-center justify-between transition-colors shadow-sm"
            >
              <div className="flex items-center gap-2">
                <Search size={14} className="text-slate-500" />
                <span>Search clients, invoices (#INV-), services, tickets...</span>
              </div>
              <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-mono text-slate-400 bg-slate-800 border border-slate-700 rounded">
                Ctrl+K or /
              </kbd>
            </button>
          </div>

          {/* Right: Close Action Button */}
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
              title="Close Admin Station"
            >
              <X size={18} />
            </button>
          </div>
        </header>

        {/* Toast Feedback */}
        {toast && (
          <div className={`mx-6 mt-4 p-3 rounded-lg text-xs font-semibold flex items-center gap-2 border shadow-lg ${
            toast.type === 'error' ? 'bg-rose-950/80 border-rose-800 text-rose-300' :
            toast.type === 'info' ? 'bg-slate-800 border-slate-700 text-slate-200' :
            'bg-emerald-950/80 border-emerald-800 text-emerald-300'
          }`}>
            <CheckCircle2 size={15} />
            <span>{toast.message}</span>
          </div>
        )}

        {/* Tab Body Content */}
        <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
          <AnimatePresence mode="wait">
            {/* 1. DASHBOARD OVERVIEW */}
            {activeTab === 'dashboard' && (
              <DashboardTab
                invoices={invoices}
                services={orders}
                users={usersList}
                tickets={tickets}
                plans={localData.plans || []}
                data={localData}
                onNavigateTab={setActiveTab}
                onOpenCreateInvoice={() => openManualInvoiceGenerator()}
                onOpenCreateService={() => openManualInvoiceGenerator()}
                onOpenCreatePlan={openCreatePlan}
                onOpenClientProfile={handleOpenClientProfile}
                onVerifyInvoiceAndProvision={handleVerifyInvoiceAndProvision}
                actionLoading={actionLoading}
                onRefresh={loadManagementData}
                isLoading={isLoadingManagement}
              />
            )}

            {/* 2. INVOICES */}
            {activeTab === 'invoices' && (
              <BillingInvoicesTab
                invoices={invoices}
                orders={orders}
                users={usersList}
                onOpenCreateInvoice={() => openManualInvoiceGenerator()}
                onOpenClientProfile={handleOpenClientProfile}
                onOpenInvoiceDoc={(inv) => setSelectedInvoiceForDoc(inv)}
                onVerifyInvoiceAndProvision={handleVerifyInvoiceAndProvision}
                onDeleteInvoice={handleDeleteInvoice}
                actionLoading={actionLoading}
                onRefresh={loadManagementData}
                isLoading={isLoadingManagement}
              />
            )}

            {/* 3. ACTIVE SERVICES */}
            {activeTab === 'orders' && (
              <ClientServicesTab
                orders={orders}
                users={usersList}
                invoices={invoices}
                onOpenCreateService={() => openManualInvoiceGenerator()}
                onOpenEditService={openEditOrder}
                onOpenClientProfile={handleOpenClientProfile}
                onOpenInvoiceDoc={(inv) => setSelectedInvoiceForDoc(inv)}
                onUpdateServiceStatus={handleUpdateServiceStatus}
                onDeleteService={handleDeleteService}
                actionLoading={actionLoading}
                onRefresh={loadManagementData}
                isLoading={isLoadingManagement}
              />
            )}

            {/* 4. CLIENTS & USERS */}
            {activeTab === 'users' && (
              <ClientsUsersTab
                users={usersList}
                services={orders}
                invoices={invoices}
                onOpenClientProfile={handleOpenClientProfile}
                onToggleUserRole={handleToggleUserRole}
                onDeleteUser={handleDeleteUser}
                onRefresh={loadManagementData}
                isLoading={isLoadingManagement}
              />
            )}

            {/* 5. PLANS CATALOG */}
            {activeTab === 'plans' && (
              <PlansCatalogTab
                localData={localData}
                setLocalData={setLocalData}
                orders={orders}
                invoices={invoices}
                onOpenCreatePlan={openCreatePlan}
                onOpenEditPlan={openEditPlan}
                onMovePlan={handleMovePlan}
                onDeletePlan={handleDeletePlan}
                onAddCategory={handleAddCategory}
                onDeleteCategory={handleDeleteCategory}
                onAddLocation={handleAddLocation}
                onDeleteLocation={handleDeleteLocation}
                onNavigateToOrders={(planName) => {
                  setActiveTab('orders');
                }}
                isSaving={actionLoading === 'save-plan'}
              />
            )}

            {/* 6. GAMES CATALOG */}
            {activeTab === 'games' && (
              <div className="space-y-6">
                <GamesTab
                  games={localData.games || []}
                  onUpdate={() => {
                    dataService.getSettings().then(s => {
                      if (s?.games) {
                        setLocalData(prev => ({ ...prev, games: s.games }));
                        setData({ ...data, games: s.games });
                      }
                    });
                  }}
                />
              </div>
            )}

            {/* 7. SOFTWARE & ADDONS */}
            {activeTab === 'productConfigs' && (
              <ProductConfigsTab
                localData={localData}
                setLocalData={setLocalData}
              />
            )}

            {/* 8. PTERODACTYL DAEMON */}
            {activeTab === 'pterodactyl' && (
              <PterodactylTab />
            )}

            {/* 9. SUPPORT TICKETS */}
            {activeTab === 'tickets' && (
              <TicketsTab
                currentUserEmail={user.email || 'admin@hectorhosting.com'}
                currentUserId={user.uid || 'admin'}
              />
            )}

            {/* 10. REVIEWS */}
            {activeTab === 'reviews' && (
              <ReviewsTab data={localData} setData={setLocalData} />
            )}

            {/* 11. BRAND & PAYMENT SETTINGS */}
            {activeTab === 'settings' && (
              <BrandSettingsTab
                data={data}
                setData={setData}
                localData={localData}
                setLocalData={setLocalData}
                onShowToast={showToast}
              />
            )}

            {/* 12. CMS LEGAL & POLICY PAGES */}
            {activeTab === 'cms' && (
              <div className="space-y-6 max-w-5xl">
                {/* CMS Sub-Selector */}
                <div className="bg-[#111827] border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-sm">
                  <div className="flex items-center gap-2">
                    <FileText size={16} className="text-blue-400" />
                    <span className="text-xs font-bold text-white uppercase tracking-wider">CMS Policy Editor:</span>
                  </div>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {(['tos', 'privacy', 'refund', 'about', 'infrastructure', 'legal'] as const).map(pt => (
                      <button
                        key={pt}
                        onClick={() => setCmsPageType(pt)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-colors ${
                          cmsPageType === pt
                            ? 'bg-blue-600 text-white shadow-sm'
                            : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                        }`}
                      >
                        {pt === 'tos' ? 'Terms of Service' : pt === 'infrastructure' ? 'Datacenters' : pt}
                      </button>
                    ))}
                  </div>
                </div>

                <PageContentEditorTab
                  pageType={cmsPageType}
                  value={localData[cmsPageType] || ''}
                  onChange={async (newVal) => {
                    const updateObj = { [cmsPageType]: newVal };
                    await dataService.updateSettings(updateObj);
                    setLocalData(prev => ({ ...prev, ...updateObj }));
                    setData({ ...data, ...updateObj });
                    showToast(`${cmsPageType.toUpperCase()} content saved!`, 'success');
                  }}
                />
              </div>
            )}

            {/* 13. SYSTEM HEALTH / BETTERSTACK */}
            {activeTab === 'status' && (
              <SystemHealthTab onShowToast={showToast} />
            )}

            {/* 14. ADMIN STAFF */}
            {activeTab === 'admins' && (
              <div className="space-y-6 max-w-4xl">
                <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 shadow-sm">
                  <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
                    <ShieldCheck size={18} className="text-purple-400" />
                    Verified System Administrators & Staff
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Users granted Root Administrator permissions across Hector Control Panel.
                  </p>
                </div>

                <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden shadow-sm">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-900 text-[10px] uppercase font-semibold text-slate-400 tracking-wider">
                      <tr>
                        <th className="p-3.5">Administrator</th>
                        <th className="p-3.5">UID</th>
                        <th className="p-3.5">Permission Level</th>
                        <th className="p-3.5 text-right">Access</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {usersList.filter(u => u.role === 'admin' || ROOT_ADMIN_EMAILS.includes(u.email.toLowerCase())).map(adminUser => (
                        <tr key={adminUser.id} className="hover:bg-slate-850/40">
                          <td className="p-3.5 font-semibold text-white flex items-center gap-2">
                            <ShieldCheck size={14} className="text-purple-400" />
                            <span>{adminUser.email}</span>
                          </td>
                          <td className="p-3.5 font-mono text-[11px] text-slate-400">{adminUser.id}</td>
                          <td className="p-3.5">
                            <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-purple-500/10 text-purple-300 border border-purple-500/20">
                              Root Admin
                            </span>
                          </td>
                          <td className="p-3.5 text-right">
                            <button
                              onClick={() => handleOpenClientProfile(adminUser.id)}
                              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs"
                            >
                              Manage
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* 15. AUDIT LOGS */}
            {activeTab === 'logs' && (
              <div className="space-y-6 max-w-5xl">
                <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 flex items-center justify-between shadow-sm">
                  <div>
                    <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
                      <Terminal size={18} className="text-slate-400" />
                      Security & Administrative Audit Trail
                    </h2>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Immutable activity logs for billing operations, service provisions, and credential modifications.
                    </p>
                  </div>
                  <button
                    onClick={() => setLogs(logService.getLogs())}
                    className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs"
                    title="Refresh Logs"
                  >
                    <RefreshCw size={14} />
                  </button>
                </div>

                <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden shadow-sm">
                  <div className="p-3 bg-slate-900 border-b border-slate-800 font-mono text-[11px] text-slate-400">
                    Showing latest {logs.length} system audit entries
                  </div>
                  <div className="divide-y divide-slate-800/80 max-h-[600px] overflow-y-auto font-mono text-xs">
                    {logs.map((log, idx) => (
                      <div key={idx} className="p-3 flex items-start gap-3 hover:bg-slate-850/40">
                        <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold uppercase shrink-0 ${
                          log.type === 'error' ? 'bg-rose-500/20 text-rose-300' :
                          log.type === 'warning' ? 'bg-amber-500/20 text-amber-300' :
                          log.type === 'success' ? 'bg-emerald-500/20 text-emerald-300' :
                          'bg-blue-500/20 text-blue-300'
                        }`}>
                          {log.type}
                        </span>
                        <div className="flex-1 min-w-0">
                          <p className="text-slate-200">{log.message}</p>
                          <p className="text-[10px] text-slate-500 mt-0.5">{log.timestamp instanceof Date ? log.timestamp.toLocaleString() : new Date(log.timestamp).toLocaleString()}</p>
                        </div>
                      </div>
                    ))}
                    {logs.length === 0 && (
                      <div className="p-8 text-center text-xs text-slate-500">
                        No recent log entries recorded.
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* --- MODAL 1: WHMCS 360° CLIENT PROFILE --- */}
      <ClientProfileModal
        isOpen={isClientProfileOpen}
        onClose={() => setIsClientProfileOpen(false)}
        client={selectedClientForProfile}
        services={orders}
        invoices={invoices}
        tickets={tickets}
        onUpdateServiceStatus={handleUpdateServiceStatus}
        onVerifyInvoice={handleVerifyInvoiceAndProvision}
        onOpenEditService={openEditOrder}
        onOpenInvoiceDoc={(inv) => setSelectedInvoiceForDoc(inv)}
        onOpenCreateInvoiceForClient={(clientId, clientEmail) => {
          setIsClientProfileOpen(false);
          openManualInvoiceGenerator(clientId, clientEmail);
        }}
        onOpenCreateServiceForClient={(clientId, clientEmail) => {
          setIsClientProfileOpen(false);
          openManualInvoiceGenerator(clientId, clientEmail);
        }}
        onToggleUserRole={handleToggleUserRole}
        onDeleteUser={handleDeleteUser}
        onNavigateToTicket={(ticketId) => {
          setIsClientProfileOpen(false);
          setActiveTab('tickets');
        }}
      />

      {/* --- MODAL 2: WHMCS UNIVERSAL OMNIBAR SEARCH --- */}
      <AdminOmnibar
        isOpen={isOmnibarOpen}
        onClose={() => setIsOmnibarOpen(false)}
        users={usersList}
        services={orders}
        invoices={invoices}
        tickets={tickets}
        plans={localData.plans || []}
        onSelectUser={(u) => handleOpenClientProfile(u.id)}
        onSelectInvoice={(inv) => setSelectedInvoiceForDoc(inv)}
        onSelectService={(srv) => openEditOrder(srv)}
        onSelectTicket={(tId) => setActiveTab('tickets')}
        onSelectPlan={(p) => openEditPlan(p)}
      />

      {/* --- MODAL 3: INVOICE DOCUMENT MODAL --- */}
      {selectedInvoiceForDoc && (
        <InvoiceDocumentModal
          isOpen={!!selectedInvoiceForDoc}
          invoice={selectedInvoiceForDoc}
          onClose={() => setSelectedInvoiceForDoc(null)}
          settings={localData.settings}
        />
      )}

      {/* --- MODAL 4: MANUAL INVOICE GENERATOR --- */}
      {isManualInvoiceModalOpen && (
        <div className="fixed inset-0 z-[1200] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-xl bg-[#0f172a] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden p-6 space-y-5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <CreditCard size={16} className="text-blue-400" />
                Issue Manual Billing Invoice
              </h3>
              <button onClick={() => setIsManualInvoiceModalOpen(false)} className="text-slate-400 hover:text-white">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSaveManualInvoice} className="space-y-4 text-xs">
              <div>
                <label className="text-[11px] font-semibold text-slate-300 block mb-1">Target Client Account</label>
                <select
                  value={manualInvoiceForm.userId}
                  onChange={(e) => setManualInvoiceForm(prev => ({ ...prev, userId: e.target.value }))}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white"
                >
                  <option value="CUSTOM">-- Enter Custom Email Address --</option>
                  {usersList.map(u => (
                    <option key={u.id} value={u.id}>
                      {u.email} ({u.displayName || u.id})
                    </option>
                  ))}
                </select>
              </div>

              {manualInvoiceForm.userId === 'CUSTOM' && (
                <div>
                  <label className="text-[11px] font-semibold text-slate-300 block mb-1">Customer Email</label>
                  <input
                    type="email"
                    required
                    placeholder="client@gmail.com"
                    value={manualInvoiceForm.customUserEmail}
                    onChange={(e) => setManualInvoiceForm(prev => ({ ...prev, customUserEmail: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white"
                  />
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-semibold text-slate-300 block mb-1">Invoice Number</label>
                  <input
                    type="text"
                    value={manualInvoiceForm.invoiceNumber}
                    onChange={(e) => setManualInvoiceForm(prev => ({ ...prev, invoiceNumber: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-300 block mb-1">UTR / Ref # (Optional)</label>
                  <input
                    type="text"
                    value={manualInvoiceForm.utrNumber}
                    onChange={(e) => setManualInvoiceForm(prev => ({ ...prev, utrNumber: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-300 block mb-1">Select Product / Plan (Autofills ID & Price)</label>
                <select
                  value={manualInvoiceForm.planId}
                  onChange={(e) => {
                    const selectedId = e.target.value;
                    if (!selectedId) {
                      setManualInvoiceForm(prev => ({
                        ...prev,
                        planId: '',
                        itemName: '',
                        itemPrice: '',
                        category: ''
                      }));
                      return;
                    }

                    // Find in general plans
                    const generalPlan = localData.plans?.find(p => p.id === selectedId || p.product_id === selectedId);
                    if (generalPlan) {
                      setManualInvoiceForm(prev => ({
                        ...prev,
                        planId: generalPlan.product_id || generalPlan.id,
                        itemName: generalPlan.name,
                        itemPrice: String(generalPlan.price_inr || generalPlan.price),
                        category: generalPlan.category || 'Hosting Plan'
                      }));
                      return;
                    }
                    
                    // Find in game plans
                    for (const game of localData.games || []) {
                      const opt = game.ramOptions?.find(o => o.product_id === selectedId || o.id === selectedId);
                      if (opt) {
                        const displayName = opt.name || `${game.title} - ${opt.ram} (${opt.slots})`;
                        setManualInvoiceForm(prev => ({
                          ...prev,
                          planId: opt.product_id || opt.id || 'game-plan',
                          itemName: displayName,
                          itemPrice: String(opt.priceInr),
                          category: `Game: ${game.title}`
                        }));
                        return;
                      }
                    }
                  }}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white"
                >
                  <option value="">-- Select a registered product --</option>
                  <optgroup label="General Hosting Plans">
                    {localData.plans?.map(p => (
                      <option key={p.id} value={p.product_id || p.id}>
                        {p.name} [ID: {p.product_id || p.id}] (₹{p.price_inr || p.price}/mo)
                      </option>
                    ))}
                  </optgroup>
                  <optgroup label="Game Server Tiers">
                    {localData.games?.flatMap(g => 
                      (g.ramOptions || []).map((opt, oIdx) => {
                        const pId = opt.product_id || opt.id || `${g.id}-opt-${oIdx}`;
                        const displayName = opt.name || `${g.title} - ${opt.ram} (${opt.slots})`;
                        return (
                          <option key={pId} value={pId}>
                            {g.title} - {displayName} [ID: {pId}] (₹{opt.priceInr}/mo)
                          </option>
                        );
                      })
                    )}
                  </optgroup>
                </select>
              </div>

              {/* Selected Product Summary Card */}
              {manualInvoiceForm.itemName ? (
                <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between">
                  <div className="min-w-0 pr-3">
                    <div className="font-bold text-white text-xs truncate">{manualInvoiceForm.itemName}</div>
                    <div className="text-[11px] text-slate-400 font-mono mt-0.5 flex items-center gap-2">
                      <span>SKU: {manualInvoiceForm.planId}</span>
                      <span>·</span>
                      <span className="text-purple-400">{manualInvoiceForm.category}</span>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-[10px] text-slate-500 uppercase font-semibold">Price</div>
                    <div className="font-mono font-bold text-emerald-400 text-sm">
                      ₹{manualInvoiceForm.itemPrice}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-3 bg-slate-900/40 border border-dashed border-slate-800 rounded-xl text-center text-slate-500 text-[11px]">
                  Select a product above to automatically bind SKU, category, and pricing.
                </div>
              )}

              <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={manualInvoiceForm.autoCreateService}
                    onChange={(e) => setManualInvoiceForm(prev => ({ ...prev, autoCreateService: e.target.checked }))}
                    className="w-4 h-4 rounded text-blue-600 bg-slate-800 border-slate-700"
                  />
                  <span className="text-xs font-semibold text-white">Automatically Provision Active Service</span>
                </label>
                <p className="text-[11px] text-slate-400">
                  When enabled, creates an active hosting instance in the client's service portal immediately.
                </p>
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsManualInvoiceModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={actionLoading === 'create-manual-invoice'}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-semibold flex items-center gap-1.5"
                >
                  {actionLoading === 'create-manual-invoice' ? 'Generating...' : 'Issue Invoice & Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL 5: SERVICE CREDENTIALS & EDIT MODAL --- */}
      {isOrderModalOpen && editingOrder && (
        <div className="fixed inset-0 z-[1200] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-xl bg-[#0f172a] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden p-6 space-y-5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Server size={16} className="text-emerald-400" />
                Manage Instance Credentials: {editingOrder.name}
              </h3>
              <button onClick={() => setIsOrderModalOpen(false)} className="text-slate-400 hover:text-white">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSaveOrderForm} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-semibold text-slate-300 block mb-1">Server Instance Name</label>
                  <input
                    type="text"
                    required
                    value={orderForm.name}
                    onChange={(e) => setOrderForm(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-300 block mb-1">Instance Status</label>
                  <select
                    value={orderForm.status}
                    onChange={(e) => setOrderForm(prev => ({ ...prev, status: e.target.value as any }))}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white capitalize font-semibold"
                  >
                    <option value="active">Active</option>
                    <option value="pending">Pending</option>
                    <option value="suspended">Suspended</option>
                    <option value="terminated">Terminated</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-semibold text-slate-300 block mb-1">Allocated IP Address</label>
                  <input
                    type="text"
                    value={orderForm.ip}
                    onChange={(e) => setOrderForm(prev => ({ ...prev, ip: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white font-mono"
                    placeholder="194.26.183.10"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-300 block mb-1">Node Cluster</label>
                  <input
                    type="text"
                    value={orderForm.nodeName}
                    onChange={(e) => setOrderForm(prev => ({ ...prev, nodeName: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-semibold text-slate-300 block mb-1">Panel Access URL</label>
                  <input
                    type="text"
                    value={orderForm.panelLink}
                    onChange={(e) => setOrderForm(prev => ({ ...prev, panelLink: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white font-mono"
                    placeholder="https://gp.hector.host"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-300 block mb-1">Panel / Root Password</label>
                  <input
                    type="text"
                    value={orderForm.panelPassword}
                    onChange={(e) => setOrderForm(prev => ({ ...prev, panelPassword: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white font-mono"
                    placeholder="Password for client"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsOrderModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={actionLoading === 'save-order'}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-semibold flex items-center gap-1.5"
                >
                  {actionLoading === 'save-order' ? 'Saving...' : 'Save Credentials'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL 6: PLAN CREATE / EDIT MODAL --- */}
      {isPlanModalOpen && (
        <div className="fixed inset-0 z-[1200] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-xl bg-[#0f172a] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Layers size={16} className="text-amber-400" />
                {editingPlan ? 'Edit Hosting Plan' : 'Create New Hosting Plan'}
              </h3>
              <button onClick={() => setIsPlanModalOpen(false)} className="text-slate-400 hover:text-white">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSavePlan} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="text-[11px] font-semibold text-slate-300 block mb-1">Plan Name</label>
                  <input
                    type="text"
                    required
                    value={planForm.name}
                    onChange={(e) => setPlanForm(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white"
                    placeholder="e.g. Ryzen KVM Extreme"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-300 block mb-1">Category</label>
                  <select
                    value={planForm.category}
                    onChange={(e) => setPlanForm(prev => ({ ...prev, category: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white font-mono uppercase"
                  >
                    {localData.categories?.map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-300 block mb-1">Badge (Optional)</label>
                  <input
                    type="text"
                    value={planForm.badge}
                    onChange={(e) => setPlanForm(prev => ({ ...prev, badge: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white"
                    placeholder="e.g. POPULAR, BEST VALUE"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-semibold text-slate-300 block mb-1">Price (₹ INR / month)</label>
                  <input
                    type="number"
                    required
                    value={planForm.price_inr}
                    onChange={(e) => setPlanForm(prev => ({ ...prev, price_inr: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white font-mono font-bold"
                    placeholder="299"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-300 block mb-1">Price ($ USD / month)</label>
                  <input
                    type="number"
                    value={planForm.price}
                    onChange={(e) => setPlanForm(prev => ({ ...prev, price: e.target.value, price_eur: String(Math.round(Number(e.target.value) * 0.95)) }))}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white font-mono"
                    placeholder="4"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-semibold text-slate-300 block mb-1">Datacenter Location</label>
                  <select
                    value={planForm.location}
                    onChange={(e) => setPlanForm(prev => ({ ...prev, location: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white"
                  >
                    {localData.locations?.map(l => (
                      <option key={l} value={l}>{l}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-300 block mb-1">Host Node</label>
                  <select
                    value={planForm.node}
                    onChange={(e) => setPlanForm(prev => ({ ...prev, node: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white font-mono"
                  >
                    {localData.nodes?.map(n => (
                      <option key={n} value={n}>{n}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-300 block mb-1">Short Description</label>
                <textarea
                  rows={2}
                  value={planForm.desc}
                  onChange={(e) => setPlanForm(prev => ({ ...prev, desc: e.target.value }))}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white outline-none resize-none leading-relaxed"
                  placeholder="e.g. High-performance gaming node with specialized Layer 7 protection..."
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-300 block mb-1">Bullet Features (One per line)</label>
                <textarea
                  rows={3}
                  value={planForm.featuresText}
                  onChange={(e) => setPlanForm(prev => ({ ...prev, featuresText: e.target.value }))}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white outline-none"
                  placeholder="Path.net 12 Tbps+ Anti-DDoS&#10;1 Gbps Port&#10;Instant Provisioning"
                />
              </div>

              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="text-[11px] font-bold text-white uppercase tracking-tight">Catalog Deployment</div>
                  <p className="text-[10px] text-slate-400 mt-0.5">Control if this plan is actively purchasable.</p>
                </div>
                <button
                  type="button"
                  onClick={() => setPlanForm(prev => ({ ...prev, is_active: !prev.is_active }))}
                  className={`px-3 py-1.5 rounded-lg font-black uppercase text-[10px] tracking-wider border transition-all ${
                    planForm.is_active
                      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                      : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                  }`}
                >
                  {planForm.is_active ? 'ACTIVE' : 'ARCHIVED'}
                </button>
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsPlanModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={actionLoading === 'save-plan'}
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-lg font-semibold flex items-center gap-1.5"
                >
                  {actionLoading === 'save-plan' ? 'Saving...' : 'Save Plan'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- CONFIRMATION MODAL --- */}
      {confirmModal.isOpen && (
        <div className="fixed inset-0 z-[1500] flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="w-full max-w-md bg-[#0f172a] border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-white tracking-tight">{confirmModal.title}</h3>
            <p className="text-xs text-slate-400 leading-relaxed">{confirmModal.message}</p>
            <div className="pt-2 flex justify-end gap-2">
              <button
                onClick={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
                className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  confirmModal.onConfirm();
                  setConfirmModal(prev => ({ ...prev, isOpen: false }));
                }}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold text-white ${
                  confirmModal.confirmVariant === 'danger' ? 'bg-rose-600 hover:bg-rose-500' : 'bg-blue-600 hover:bg-blue-500'
                }`}
              >
                {confirmModal.confirmText || 'Confirm'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* --- INVOICE VERIFICATION & SPEC REVIEW MODAL --- */}
      {verifyingInvoice && (
        <div className="fixed inset-0 z-[1500] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="w-full max-w-2xl bg-[#0f172a] border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <ShieldCheck size={18} className="text-emerald-400" />
                  Order Verification & Provisioning Review
                </h3>
                <p className="text-[10px] text-slate-400 mt-1">
                  Double check client transaction UTR and order specifications before server activation.
                </p>
              </div>
              <button 
                onClick={() => setVerifyingInvoice(null)} 
                className="text-slate-400 hover:text-white p-1 hover:bg-slate-800 rounded-lg"
              >
                <X size={18} />
              </button>
            </div>

            {/* Client and Ledger Meta */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-900/60 p-4 border border-slate-800 rounded-xl text-xs">
              <div className="space-y-1">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Client Identity</span>
                <p className="font-bold text-white truncate">{verifyingInvoice.userId}</p>
                <p className="text-[10px] text-slate-400">Account status active, awaiting service deployment.</p>
              </div>
              <div className="sm:text-right space-y-1">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Billing Record</span>
                <p className="font-mono text-blue-400 font-bold">#{verifyingInvoice.invoiceNumber || verifyingInvoice.id}</p>
                <p className="text-[10px] font-mono text-emerald-400 font-bold">
                  {verifyingInvoice.utrNumber ? `UTR: ${verifyingInvoice.utrNumber}` : 'Manual Verification Pending'}
                </p>
              </div>
            </div>

            {/* Itemized Products Specs Review */}
            <div className="space-y-4">
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 block">
                Itemized Product Tiers & Specifications
              </span>

              <div className="space-y-3">
                {verifyingInvoice.items?.map((item, idx) => {
                  const specs = getProductSpecsForReview(item);
                  return (
                    <div key={idx} className="border border-slate-800 rounded-xl overflow-hidden bg-slate-950/60">
                      {/* Item Main Header */}
                      <div className="p-3.5 bg-slate-900/40 border-b border-slate-800 flex items-center justify-between">
                        <div>
                          <div className="font-bold text-slate-200 text-xs flex items-center gap-2">
                            <Server size={14} className="text-purple-400" />
                            <span>{item.name}</span>
                          </div>
                          <p className="text-[10px] text-slate-500 font-mono mt-0.5">Category: {item.category || 'Hosting'}</p>
                        </div>
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-purple-500/10 text-purple-400 border border-purple-500/20 uppercase tracking-widest">
                          {specs?.subcategory || 'Standard'}
                        </span>
                      </div>

                      {/* Specs Grid */}
                      {specs && (
                        <div className="p-4 grid grid-cols-2 gap-x-6 gap-y-3 text-xs text-slate-300">
                          {specs.name && (
                            <div>
                              <span className="text-[10px] text-slate-500 uppercase block">Plan Display Name</span>
                              <span className="font-bold text-slate-200">{specs.name}</span>
                            </div>
                          )}
                          {specs.subcategory && (
                            <div>
                              <span className="text-[10px] text-slate-500 uppercase block">Subcategory</span>
                              <span className="font-bold text-slate-200 capitalize">{specs.subcategory}</span>
                            </div>
                          )}
                          {specs.ram && (
                            <div>
                              <span className="text-[10px] text-slate-500 uppercase block">RAM Allocation</span>
                              <span className="font-mono font-bold text-slate-200">{specs.ram}</span>
                            </div>
                          )}
                          {specs.slots && (
                            <div>
                              <span className="text-[10px] text-slate-500 uppercase block">Slot Capacity / Players</span>
                              <span className="font-bold text-slate-200">{specs.slots}</span>
                            </div>
                          )}
                          {specs.price && (
                            <div>
                              <span className="text-[10px] text-slate-500 uppercase block">Tier Price (INR)</span>
                              <span className="font-mono font-bold text-emerald-400">₹{specs.price}/mo</span>
                            </div>
                          )}
                          {specs.cpu && (
                            <div>
                              <span className="text-[10px] text-slate-500 uppercase block">CPU Resource / Cores</span>
                              <span className="font-bold text-slate-200">{specs.cpu}</span>
                            </div>
                          )}
                          {specs.processor && (
                            <div>
                              <span className="text-[10px] text-slate-500 uppercase block">Processor / CPU Model</span>
                              <span className="font-mono text-slate-200">{specs.processor}</span>
                            </div>
                          )}
                          {specs.storage && (
                            <div>
                              <span className="text-[10px] text-slate-500 uppercase block">NVMe Storage</span>
                              <span className="font-bold text-slate-200">{specs.storage}</span>
                            </div>
                          )}
                          {specs.ddos && (
                            <div className="col-span-2">
                              <span className="text-[10px] text-slate-500 uppercase block">DDoS Protection</span>
                              <span className="font-bold text-slate-200">{specs.ddos}</span>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Custom Options and Upgrades review */}
            {parseNotesForReview(verifyingInvoice.notes) && (
              <div className="space-y-3">
                <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 block">
                  Product Addons & Custom Configurations
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {parseNotesForReview(verifyingInvoice.notes)?.map((config, cIdx) => (
                    <div 
                      key={cIdx} 
                      className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between gap-3"
                    >
                      <span className="font-bold text-[10px] text-blue-400 uppercase tracking-tight">
                        {config.label}
                      </span>
                      <span className="font-mono text-[11px] text-slate-300 truncate max-w-[150px]">
                        {config.value}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Admin Provisioning & Credentials Input Form */}
            <div className="p-4 bg-slate-900/90 border border-purple-500/30 rounded-xl space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-purple-500/10 text-purple-400 border border-purple-500/20">
                    <Server size={16} />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white uppercase tracking-wide">
                      Service Provisioning & Credential Dispatch
                    </h4>
                    <p className="text-[10px] text-slate-400">Configure connection details dispatched to the client dashboard</p>
                  </div>
                </div>

                {/* Provision Type Toggle */}
                <div className="flex items-center p-0.5 bg-slate-950 border border-slate-800 rounded-lg text-[10px] font-bold uppercase">
                  <button
                    type="button"
                    onClick={() => setProvisionType('panel')}
                    className={`px-3 py-1 rounded-md transition-colors ${
                      provisionType === 'panel' 
                        ? 'bg-purple-600 text-white shadow-sm' 
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    🎮 Game / Bot / Web Panel
                  </button>
                  <button
                    type="button"
                    onClick={() => setProvisionType('vps_dedicated')}
                    className={`px-3 py-1 rounded-md transition-colors ${
                      provisionType === 'vps_dedicated' 
                        ? 'bg-purple-600 text-white shadow-sm' 
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    🖥️ VPS / Dedicated SSH
                  </button>
                </div>
              </div>

              {provisionType === 'panel' ? (
                /* --- GAME / BOT / WEB PANEL INPUTS --- */
                <div className="space-y-3 text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                        Assigned Server ID / Identifier *
                      </label>
                      <input
                        type="text"
                        value={provisionServerId}
                        onChange={(e) => setProvisionServerId(e.target.value)}
                        placeholder="Enter server ID / UUID"
                        required
                        className="w-full px-3 py-2 bg-slate-950 border border-slate-800 focus:border-purple-500 rounded-lg font-mono text-xs text-purple-300 outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                        Panel URL Link
                      </label>
                      <input
                        type="text"
                        value={provisionPanelLink}
                        onChange={(e) => setProvisionPanelLink(e.target.value)}
                        placeholder="https://gp.hector.host"
                        className="w-full px-3 py-2 bg-slate-950 border border-slate-800 focus:border-purple-500 rounded-lg font-mono text-xs text-slate-200 outline-none"
                      />
                    </div>
                  </div>

                  <div className="p-3 bg-purple-950/40 border border-purple-800/40 rounded-lg text-[11px] text-purple-300/90 flex items-center gap-2">
                    <span className="text-sm">ℹ️</span>
                    <span>The client automatically receives this Server ID with their registered account email and password to log in.</span>
                  </div>
                </div>
              ) : (
                /* --- VPS / DEDICATED SSH INPUTS --- */
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                      Server Public IP Address *
                    </label>
                    <input
                      type="text"
                      value={provisionIp}
                      onChange={(e) => setProvisionIp(e.target.value)}
                      placeholder="e.g. 194.26.183.105"
                      required
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 focus:border-purple-500 rounded-lg font-mono text-xs text-emerald-400 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                      SSH Port
                    </label>
                    <input
                      type="text"
                      value={provisionSshPort}
                      onChange={(e) => setProvisionSshPort(e.target.value)}
                      placeholder="22"
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 focus:border-purple-500 rounded-lg font-mono text-xs text-slate-200 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                      SSH Username
                    </label>
                    <input
                      type="text"
                      value={provisionSshUsername}
                      onChange={(e) => setProvisionSshUsername(e.target.value)}
                      placeholder="root"
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 focus:border-purple-500 rounded-lg font-mono text-xs text-slate-200 outline-none"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                        SSH / Root Password *
                      </label>
                      <button
                        type="button"
                        onClick={() => setProvisionSshPassword(Math.random().toString(36).substring(2, 10) + '!')}
                        className="text-[10px] text-purple-400 hover:text-purple-300 font-bold"
                      >
                        ⚡ Generate New
                      </button>
                    </div>
                    <input
                      type="text"
                      value={provisionSshPassword}
                      onChange={(e) => setProvisionSshPassword(e.target.value)}
                      placeholder="Root Password"
                      required
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 focus:border-purple-500 rounded-lg font-mono text-xs text-purple-300 outline-none"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Total Due & Confirm Trigger */}
            <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <span className="text-[10px] text-slate-500 uppercase block">Ledger Grand Total Due</span>
                <span className="text-xl font-mono font-black text-emerald-400">
                  {formatINR(verifyingInvoice.total, 2)}
                </span>
              </div>

              <div className="flex items-center gap-2.5 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={() => setVerifyingInvoice(null)}
                  className="flex-1 sm:flex-none px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => executeVerifyInvoiceAndProvision(verifyingInvoice.id)}
                  disabled={actionLoading === verifyingInvoice.id}
                  className="flex-1 sm:flex-none px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-colors flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-950/20"
                >
                  {actionLoading === verifyingInvoice.id ? (
                    <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <CheckCircle2 size={14} />
                  )}
                  <span>Verify & Provision Order</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
