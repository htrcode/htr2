import React, { useState, useEffect } from 'react';
import { Menu, X, Sun, Moon, ChevronDown, Shield, Server, Gamepad2, Cpu, Building2, Scale, Home, Zap, Bot, Box, LayoutGrid, Globe, Layers, Headphones, RotateCcw, FileText, Activity, User, LogOut, Settings as SettingsIcon, LayoutDashboard, ShoppingCart, ExternalLink } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Settings } from '../types';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Logo } from './Logo';
import { GAME_CATALOG } from '../data/games';
import { authService } from '../services/authService';
import { User as FirebaseUser } from 'firebase/auth';
import { MobileMenuDrawer } from './MobileMenuDrawer';

interface NavbarProps {
  settings: Settings;
  categories: string[];
  toggleTheme: () => void;
  user: FirebaseUser | null;
  isAdmin: boolean;
  setIsAdminMode: (val: boolean) => void;
  cartCount?: number;
  onOpenCart?: () => void;
  activeCurrency?: 'INR' | 'USD';
  setActiveCurrency?: (c: 'INR' | 'USD') => void;
}

export const Navbar: React.FC<NavbarProps> = ({ 
  settings, 
  categories = [],
  toggleTheme,
  user,
  isAdmin,
  setIsAdminMode,
  cartCount = 0,
  onOpenCart,
  activeCurrency = 'INR',
  setActiveCurrency
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    let ticking = false;
    const handleScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          setScrolled(window.scrollY > 50);
          ticking = false;
        });
        ticking = true;
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close dropdowns and mobile menu on route change
  useEffect(() => {
    setIsOpen(false);
    setActiveDropdown(null);
  }, [location.pathname]);

  const handleLogout = async () => {
    await authService.logout();
    navigate('/auth/login');
  };

  const siteTitle = settings.site_name && settings.site_name !== 'Untitled' ? settings.site_name : 'HectorHosting';

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-[100] w-full flex flex-col">
        {/* Maintenance Mode Banner */}
        {settings.maintenance_mode && (
          <div className="bg-amber-600/90 text-white text-[11px] font-bold py-2.5 px-4 text-center border-b border-amber-500/30 flex items-center justify-center gap-2 uppercase tracking-wider w-full">
            <Shield className="text-amber-200" size={14} />
            <span>{settings.maintenance_message || 'System scheduled maintenance is currently active.'}</span>
          </div>
        )}

        {/* Top Announcement Alert Bar */}
        {settings.show_announcement && settings.announcement_text && !settings.maintenance_mode && (
          <div className="bg-accent text-white text-[11px] py-2.5 px-4 text-center border-b border-white/10 font-bold flex items-center justify-center gap-2 uppercase tracking-widest w-full">
            <Zap className="text-white" size={13} />
            <span>{settings.announcement_text}</span>
          </div>
        )}

        <nav 
          className={`w-full transition-all duration-300 ${
            scrolled 
              ? 'bg-[#07060b]/95 backdrop-blur-xl py-4 border-b border-white/10 shadow-md shadow-black/40' 
              : 'bg-[#07060b]/40 backdrop-blur-sm py-4 border-b border-white/5'
          }`}
        >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between">
          {/* Brand Logo */}
          <Link to="/" className="flex items-center gap-2.5 sm:gap-3 group shrink-0">
            <Logo size={36} className="sm:hidden group-hover:scale-105 transition-transform duration-200" />
            <Logo size={42} className="hidden sm:block group-hover:scale-105 transition-transform duration-200" />
            <span className="text-lg sm:text-xl font-black tracking-tight sm:tracking-tighter text-foreground font-sans flex items-center">
              HECTOR<span className="text-accent font-black ml-0.5">HOSTING</span>
            </span>
          </Link>

          {/* Desktop Links with Dropdowns */}
          <div className="hidden lg:flex items-center gap-8">
            <Link 
              to="/" 
              className="text-[11px] font-bold uppercase tracking-widest text-foreground hover:text-accent transition-colors"
            >
              Home
            </Link>

            {/* Game Hosting Dropdown */}
            <div 
              className="relative"
              onMouseEnter={() => setActiveDropdown('game')}
              onMouseLeave={() => setActiveDropdown(null)}
            >
              <Link to="/game-servers" className="text-[11px] font-bold uppercase tracking-widest text-foreground-muted hover:text-foreground transition-colors flex items-center gap-1.5 py-2">
                Game Servers
                <ChevronDown size={12} className="text-foreground-dim" />
              </Link>

              <AnimatePresence>
                {activeDropdown === 'game' && (
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 5 }}
                    className="absolute top-full -left-20 w-[600px] p-2 bg-bg-alt border border-border rounded-lg shadow-2xl z-50 grid grid-cols-3 gap-1"
                  >
                    {GAME_CATALOG.slice(0, 8).map((game) => (
                      <Link 
                        key={game.id}
                        to={`/game/${game.id.replace('game-', '')}`}
                        className="flex items-center gap-3 p-3 rounded-md hover:bg-bg text-left transition-all group"
                      >
                        <img 
                          src={game.image} 
                          alt={game.title}
                          className="w-10 h-10 object-cover rounded border border-border group-hover:border-accent/30 shrink-0"
                        />
                        <div className="min-w-0">
                          <div className="font-bold text-[10px] text-foreground uppercase tracking-wider group-hover:text-accent truncate">
                            {game.title}
                          </div>
                          <div className="text-[9px] text-foreground-dim mt-0.5">
                            From <span className="text-foreground">₹{game.startingPriceInr}</span>
                          </div>
                        </div>
                      </Link>
                    ))}
                    
                    <Link 
                      to="/game-servers"
                      className="flex items-center gap-3 p-3 rounded-md hover:bg-bg text-left transition-all group"
                    >
                      <div className="w-10 h-10 rounded bg-accent/10 flex items-center justify-center text-accent shrink-0">
                        <LayoutGrid size={16} />
                      </div>
                      <div className="min-w-0">
                        <div className="font-bold text-[10px] text-foreground uppercase tracking-wider group-hover:text-accent truncate">
                          ALL GAMES
                        </div>
                        <div className="text-[9px] text-foreground-dim mt-0.5">
                          Browse 100+ titles
                        </div>
                      </div>
                    </Link>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Other Services Dropdown */}
            <div 
              className="relative"
              onMouseEnter={() => setActiveDropdown('other')}
              onMouseLeave={() => setActiveDropdown(null)}
            >
              <button className="text-[11px] font-bold uppercase tracking-widest text-foreground-muted hover:text-foreground transition-colors flex items-center gap-1.5 py-2">
                Other Services
                <ChevronDown size={12} className="text-foreground-dim" />
              </button>

              <AnimatePresence>
                {activeDropdown === 'other' && (
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 5 }}
                    className="absolute top-full left-0 w-64 p-2 bg-bg-alt border border-border rounded-lg shadow-2xl space-y-1 z-50"
                  >
                    {categories
                      .filter((cat) => !cat.toUpperCase().includes('GAME'))
                      .map((cat) => {
                        const id = cat.toLowerCase().replace(/\s+/g, '-');
                        let Icon = Server;
                        let label = cat.replace(/-/g, ' ');

                        if (cat === 'VPS') { Icon = Cpu; label = "KVM VPS"; }
                        else if (cat === 'WEB-HOSTING') { Icon = Globe; label = "Web Hosting"; }
                        else if (cat === 'BOT-HOSTING') { Icon = Bot; label = "Bot Hosting"; }
                        else if (cat === 'DED-SERVERS' || cat.toUpperCase().includes('DED')) { Icon = Server; label = "Dedicated Servers"; }

                        return (
                          <Link 
                            key={cat} 
                            to={`/${id}`} 
                            className="flex items-center gap-3 p-3 rounded-md hover:bg-bg text-[10px] text-foreground-muted hover:text-accent transition-all group"
                          >
                            <div className="w-8 h-8 rounded bg-bg border border-border flex items-center justify-center text-foreground-dim group-hover:text-accent group-hover:border-accent/30">
                              <Icon size={14} />
                            </div>
                            <span className="font-bold uppercase tracking-widest">{label}</span>
                          </Link>
                        );
                      })}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Company Dropdown */}
            <div 
              className="relative"
              onMouseEnter={() => setActiveDropdown('company')}
              onMouseLeave={() => setActiveDropdown(null)}
            >
              <button className="text-[11px] font-bold uppercase tracking-widest text-foreground-muted hover:text-foreground transition-colors flex items-center gap-1.5 py-2">
                Company
                <ChevronDown size={12} className="text-foreground-dim" />
              </button>

              <AnimatePresence>
                {activeDropdown === 'company' && (
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 5 }}
                    className="absolute top-full left-0 w-64 p-2 bg-bg-alt border border-border rounded-lg shadow-2xl space-y-1 z-50"
                  >
                    {[
                      { to: '/about', label: 'About Enterprise', icon: Building2 },
                      { to: '/infrastructure', label: 'Infrastructure', icon: Globe },
                      { to: '/status', label: 'System Status', icon: Activity },
                      { to: '/contact', label: 'Contact Center', icon: Headphones },
                    ].map((item) => (
                      <Link 
                        key={item.to} 
                        to={item.to} 
                        className="flex items-center gap-3 p-3 rounded-md hover:bg-bg text-[10px] text-foreground-muted hover:text-accent transition-all group"
                      >
                        <div className="w-8 h-8 rounded bg-bg border border-border flex items-center justify-center text-foreground-dim group-hover:text-accent group-hover:border-accent/30">
                          <item.icon size={14} />
                        </div>
                        <span className="font-bold uppercase tracking-widest">{item.label}</span>
                      </Link>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            
            {/* Legal Dropdown */}
            <div 
              className="relative"
              onMouseEnter={() => setActiveDropdown('legal')}
              onMouseLeave={() => setActiveDropdown(null)}
            >
              <button className="text-[11px] font-bold uppercase tracking-widest text-foreground-muted hover:text-foreground transition-colors flex items-center gap-1.5 py-2">
                Legal
                <ChevronDown size={12} className="text-foreground-dim" />
              </button>

              <AnimatePresence>
                {activeDropdown === 'legal' && (
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 5 }}
                    className="absolute top-full left-0 w-64 p-2 bg-bg-alt border border-border rounded-lg shadow-2xl space-y-1 z-50"
                  >
                    {[
                      { to: '/tos', label: 'Terms of Service', icon: Scale },
                      { to: '/privacy', label: 'Privacy Policy', icon: Shield },
                      { to: '/refund', label: 'Refund Policy', icon: RotateCcw },
                      { to: '/legal', label: 'Legal Notices', icon: FileText },
                    ].map((item) => (
                      <Link 
                        key={item.to} 
                        to={item.to} 
                        className="flex items-center gap-3 p-3 rounded-md hover:bg-bg text-[10px] text-foreground-muted hover:text-accent transition-all group"
                      >
                        <div className="w-8 h-8 rounded bg-bg border border-border flex items-center justify-center text-foreground-dim group-hover:text-accent group-hover:border-accent/30">
                          {item.icon ? <item.icon size={14} /> : <Scale size={14} />}
                        </div>
                        <span className="font-bold uppercase tracking-widest">{item.label}</span>
                      </Link>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* Right Controls */}
          <div className="hidden sm:flex items-center gap-6">
            {user ? (
              <div 
                className="relative"
                onMouseEnter={() => setActiveDropdown('user')}
                onMouseLeave={() => setActiveDropdown(null)}
              >
                <button 
                  onClick={() => setActiveDropdown(activeDropdown === 'user' ? null : 'user')}
                  className="flex items-center gap-3 focus:outline-none p-1 rounded-lg hover:bg-bg-alt transition-colors"
                >
                  <div className="w-8 h-8 rounded-full bg-bg-alt border border-border flex items-center justify-center text-accent overflow-hidden">
                    {user.photoURL ? (
                      <img src={user.photoURL} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <User size={16} />
                    )}
                  </div>
                  <div className="text-left hidden xl:block">
                    <div className="text-[10px] font-black uppercase tracking-widest text-foreground truncate max-w-[100px]">
                      {user.displayName || 'Account'}
                    </div>
                    <div className="text-[9px] text-foreground-dim font-bold uppercase tracking-widest">
                      {isAdmin ? 'Administrator' : 'Client'}
                    </div>
                  </div>
                  <ChevronDown size={12} className={`text-foreground-dim transition-transform duration-200 ${activeDropdown === 'user' ? 'rotate-180 text-accent' : ''}`} />
                </button>

                <AnimatePresence>
                  {activeDropdown === 'user' && (
                    <motion.div
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 5 }}
                      className="absolute top-full right-0 w-60 p-2 bg-bg-alt border border-border rounded-xl shadow-2xl space-y-1 z-50 mt-2"
                    >
                      <Link 
                        to="/dashboard"
                        onClick={() => setActiveDropdown(null)}
                        className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-bg text-[10px] text-foreground-muted hover:text-accent transition-all group"
                      >
                        <div className="w-8 h-8 rounded bg-bg border border-border flex items-center justify-center text-foreground-dim group-hover:text-accent group-hover:border-accent/30">
                          <LayoutDashboard size={14} />
                        </div>
                        <span className="font-bold uppercase tracking-widest">Enter Dashboard</span>
                      </Link>

                      <a
                        href="https://gp.hector.host"
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={() => setActiveDropdown(null)}
                        className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-bg text-[10px] text-foreground-muted hover:text-emerald-400 transition-all group"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded bg-bg border border-border flex items-center justify-center text-foreground-dim group-hover:text-emerald-400 group-hover:border-emerald-400/30">
                            <Server size={14} />
                          </div>
                          <span className="font-bold uppercase tracking-widest">Game Panel</span>
                        </div>
                        <ExternalLink size={12} className="text-foreground-dim group-hover:text-emerald-400" />
                      </a>

                      {isAdmin && (
                        <button 
                          onClick={() => {
                            setActiveDropdown(null);
                            setIsAdminMode(true);
                          }}
                          className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-bg text-[10px] text-foreground-muted hover:text-accent transition-all group"
                        >
                          <div className="w-8 h-8 rounded bg-bg border border-border flex items-center justify-center text-foreground-dim group-hover:text-accent group-hover:border-accent/30">
                            <SettingsIcon size={14} />
                          </div>
                          <span className="font-bold uppercase tracking-widest">Admin Control</span>
                        </button>
                      )}

                      <div className="my-1 border-t border-border" />

                      <button 
                        onClick={() => {
                          setActiveDropdown(null);
                          handleLogout();
                        }}
                        className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-rose-500/10 text-[10px] text-foreground-muted hover:text-rose-400 transition-all group"
                      >
                        <div className="w-8 h-8 rounded bg-bg border border-border flex items-center justify-center text-foreground-dim group-hover:text-rose-400 group-hover:border-rose-400/30">
                          <LogOut size={14} />
                        </div>
                        <span className="font-bold uppercase tracking-widest">Sign Out</span>
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              <div className="flex items-center gap-4">
                <Link 
                  to="/auth/login" 
                  className="text-[10px] font-black uppercase tracking-widest text-foreground-muted hover:text-foreground transition-colors"
                >
                  Login
                </Link>
                <Link 
                  to="/plans"
                  className="px-6 py-2.5 bg-accent hover:bg-accent-muted text-white font-bold text-[10px] uppercase tracking-widest rounded transition-all shadow-lg shadow-accent/20"
                >
                  Get Started
                </Link>
              </div>
            )}
          </div>

          {/* Mobile Right Controls */}
          <div className="lg:hidden flex items-center gap-1.5 sm:gap-2">
            {user ? (
              <Link
                to="/dashboard"
                className="min-w-[44px] min-h-[44px] p-2.5 text-accent hover:bg-accent/10 rounded-lg transition-colors flex items-center justify-center active:scale-95"
                title="Client Dashboard"
                aria-label="Dashboard"
              >
                <LayoutDashboard size={20} />
              </Link>
            ) : (
              <Link
                to="/auth/login"
                className="hidden xs:inline-flex px-3 py-2 text-[10px] font-black uppercase tracking-wider text-foreground-muted hover:text-foreground border border-border rounded-lg active:scale-95 transition-all"
              >
                Login
              </Link>
            )}

            <button 
              className="min-w-[44px] min-h-[44px] p-2.5 text-foreground bg-bg-alt/80 border border-border hover:border-accent/40 rounded-lg flex items-center justify-center transition-all active:scale-95"
              onClick={() => setIsOpen(!isOpen)}
              aria-label={isOpen ? "Close menu" : "Open menu"}
            >
              {isOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </nav>
    </header>

      {/* Modern High-Standard Mobile Navigation Drawer */}
      <MobileMenuDrawer
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        user={user}
        isAdmin={isAdmin}
        setIsAdminMode={setIsAdminMode}
        settings={settings}
        cartCount={cartCount}
        onOpenCart={onOpenCart}
        activeCurrency={activeCurrency}
        setActiveCurrency={setActiveCurrency}
      />
    </>
  );
};


