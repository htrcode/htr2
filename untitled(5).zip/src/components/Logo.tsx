import React from 'react';
import trademarkLogo from '../assets/images/hector_logo_transparent.png';

interface LogoProps {
  className?: string;
  size?: number;
}

export const Logo: React.FC<LogoProps> = ({ className = '', size = 40 }) => {
  return (
    <img 
      src={trademarkLogo} 
      alt="HectorHosting Trademark Logo"
      className={`shrink-0 object-contain drop-shadow-[0_2px_12px_rgba(147,51,234,0.3)] transition-all ${className}`}
      style={{ height: `${size}px`, width: 'auto', maxHeight: `${size}px` }}
      loading="eager"
    />
  );
};
