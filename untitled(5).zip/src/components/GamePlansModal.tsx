import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Server, 
  Cpu, 
  HardDrive, 
  ShieldCheck, 
  CheckCircle2, 
  ArrowRight, 
  Layers, 
  Sparkles, 
  Globe, 
  Clock,
  Info,
  ChevronRight,
  Filter
} from 'lucide-react';
import { Game, Plan } from '../types';

interface GamePlansModalProps {
  game: Game | null;
  plans: Plan[];
  onClose: () => void;
  onOrderPlan: (plan: Plan) => void;
}

export const GamePlansModal: React.FC<GamePlansModalProps> = ({
  game,
  plans = [],
  onClose,
  onOrderPlan,
}) => {
  if (!game) return null;

  const gameTitle = (game.title || '').toLowerCase();
  const gameIdClean = game.id.toLowerCase().replace('game-', '');

  // Convert ramOptions into Plan structure
  const gameSpecificTiers: Plan[] = (game.ramOptions || []).map((opt, idx) => ({
    id: `${game.id}-tier-${idx}`,
    name: `${game.title} ${opt.ram} (${opt.slots})`,
    price: String(Math.round(opt.priceInr / 83)),
    price_inr: String(opt.priceInr),
    price_eur: String(Math.round(opt.priceInr / 90)),
    badge: idx === 1 ? 'Best Value' : '',
    category: 'GAME-HOSTING',
    location: 'Mumbai, India',
    node: opt.cpu || game.metadata?.cpuType || 'AMD RYZEN 9 5950X',
    desc: `High-performance ${game.title} node with ${opt.ram} RAM and ${opt.slots} capacity.`,
    features: [
      `${opt.ram} Dedicated DDR4 RAM`,
      `${opt.slots} Player Slots`,
      `${opt.cpu || 'High-Clock CPU'}`,
      game.metadata?.storage || '50GB NVMe Storage',
      'Pterodactyl Panel Access',
      'Instant 60s Deployment'
    ],
    is_active: true
  }));

  // 1. Find plans configured specifically matching this game in the Admin Panel
  const specificGamePlans = useMemo(() => {
    const matched = plans.filter(p => {
      const name = (p.name || '').toLowerCase();
      const id = (p.id || '').toLowerCase();
      const category = (p.category || '').toLowerCase();
      
      const matchesTitle = name.includes(gameTitle) || category.includes(gameTitle);
      const matchesId = name.includes(gameIdClean) || id.includes(gameIdClean) || category.includes(gameIdClean);
      const matchesMinecraft = (gameTitle.includes('minecraft') || gameIdClean.includes('minecraft')) && 
        (name.includes('mc-') || name.includes('minecraft') || category.includes('minecraft'));
      const matchesFiveM = (gameTitle.includes('fivem') || gameTitle.includes('gta')) && 
        (name.includes('fivem') || name.includes('gta') || category.includes('fivem') || category.includes('gta'));

      return matchesTitle || matchesId || matchesMinecraft || matchesFiveM;
    });

    return [...gameSpecificTiers, ...matched];
  }, [plans, gameTitle, gameIdClean, gameSpecificTiers]);

  // 2. Find all game hosting plans in the Admin Panel
  const allGameHostingPlans = useMemo(() => {
    return plans.filter(p => {
      const category = (p.category || '').toLowerCase();
      const name = (p.name || '').toLowerCase();
      return (
        category.includes('game') || 
        category.includes('gaming') || 
        name.includes('node') || 
        name.includes('server') ||
        category.includes('minecraft') ||
        category.includes('palworld') ||
        category.includes('rust')
      );
    });
  }, [plans]);

  // Determine initial filter view
  const [filterMode, setFilterMode] = useState<'specific' | 'all-game' | 'all'>(
    specificGamePlans.length > 0 ? 'specific' : (allGameHostingPlans.length > 0 ? 'all-game' : 'all')
  );

  const displayedPlans = useMemo(() => {
    if (filterMode === 'specific') {
      return specificGamePlans.length > 0 ? specificGamePlans : allGameHostingPlans;
    }
    if (filterMode === 'all-game') {
      return allGameHostingPlans.length > 0 ? allGameHostingPlans : plans;
    }
    return plans;
  }, [filterMode, specificGamePlans, allGameHostingPlans, plans]);

  const handleSelectPlan = (plan: Plan) => {
    onClose();
    onOrderPlan(plan);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/85 backdrop-blur-md"
        />

        {/* Modal Dialog */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative w-full max-w-4xl bg-[#0c0916] border border-purple-900/50 rounded-2xl shadow-2xl overflow-hidden z-10 text-slate-100 my-8 flex flex-col max-h-[90vh]"
        >
          {/* Header Bar */}
          <div className="p-6 bg-gradient-to-r from-[#140e26] via-[#0f0a1d] to-[#0c0818] border-b border-purple-900/40 relative shrink-0">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-xl overflow-hidden border border-purple-500/30 shrink-0 shadow-lg relative">
                  <img
                    src={game.image}
                    alt={game.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-purple-950/20" />
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="px-2 py-0.5 rounded bg-purple-600/80 border border-purple-400/40 text-[9px] font-mono font-bold uppercase tracking-widest text-white">
                      Admin Configured Plans
                    </span>
                    <span className="px-2 py-0.5 rounded bg-black/40 border border-white/10 text-[9px] font-mono text-slate-400 uppercase tracking-widest">
                      {game.category}
                    </span>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-black text-white uppercase tracking-tight font-sans">
                    Deploy {game.title} Server
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Select any hosting plan configured in your Admin Panel to deploy this node.
                  </p>
                </div>
              </div>

              <button
                onClick={onClose}
                className="p-2 rounded-full bg-black/50 hover:bg-black text-slate-400 hover:text-white border border-white/10 transition-all cursor-pointer shrink-0"
                title="Close modal"
              >
                <X size={18} />
              </button>
            </div>

            {/* Filter Tabs */}
            <div className="flex items-center gap-2 mt-5 pt-4 border-t border-purple-900/30 overflow-x-auto">
              <span className="text-[10px] font-mono uppercase font-bold text-slate-400 flex items-center gap-1 shrink-0 mr-2">
                <Filter size={11} /> Filter:
              </span>

              {specificGamePlans.length > 0 && (
                <button
                  onClick={() => setFilterMode('specific')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold uppercase tracking-wider transition-all whitespace-nowrap cursor-pointer ${
                    filterMode === 'specific'
                      ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                      : 'bg-[#18112e] text-slate-300 hover:bg-purple-900/40'
                  }`}
                >
                  {game.title} Plans ({specificGamePlans.length})
                </button>
              )}

              <button
                onClick={() => setFilterMode('all-game')}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold uppercase tracking-wider transition-all whitespace-nowrap cursor-pointer ${
                  filterMode === 'all-game'
                    ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                    : 'bg-[#18112e] text-slate-300 hover:bg-purple-900/40'
                }`}
              >
                All Game Hosting ({allGameHostingPlans.length})
              </button>

              <button
                onClick={() => setFilterMode('all')}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold uppercase tracking-wider transition-all whitespace-nowrap cursor-pointer ${
                  filterMode === 'all'
                    ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                    : 'bg-[#18112e] text-slate-300 hover:bg-purple-900/40'
                }`}
              >
                All Admin Plans ({plans.length})
              </button>
            </div>
          </div>

          {/* Modal Scrollable Plans List */}
          <div className="p-6 space-y-4 overflow-y-auto custom-scrollbar flex-1">
            {displayedPlans.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {displayedPlans.map((plan) => {
                  const price = plan.price_inr || plan.price;
                  const isPopular = plan.badge?.toLowerCase().includes('popular') || plan.badge?.toLowerCase().includes('best');

                  return (
                    <div
                      key={plan.id}
                      className={`relative p-5 rounded-2xl border transition-all flex flex-col justify-between ${
                        isPopular
                          ? 'bg-gradient-to-b from-[#181030] to-[#0e0a1c] border-purple-500/60 ring-1 ring-purple-500/30 shadow-lg shadow-purple-900/20'
                          : 'bg-[#120e20] border-purple-900/40 hover:border-purple-600/60'
                      }`}
                    >
                      {/* Badge */}
                      {plan.badge && (
                        <div className="absolute top-4 right-4">
                          <span className="px-2.5 py-1 rounded-md bg-purple-600/80 border border-purple-400/40 text-[10px] font-mono font-bold uppercase tracking-wider text-white shadow-sm">
                            {plan.badge}
                          </span>
                        </div>
                      )}

                      <div className="space-y-3">
                        {/* Title & Category */}
                        <div>
                          <span className="text-[10px] font-mono uppercase text-purple-400 font-bold tracking-widest block">
                            {plan.category || 'HOSTING'}
                          </span>
                          <h3 className="text-lg font-black text-white uppercase tracking-tight font-sans mt-0.5">
                            {plan.name}
                          </h3>
                        </div>

                        {/* Price Display */}
                        <div className="flex items-baseline gap-1 py-1 border-y border-purple-900/30">
                          <span className="text-2xl sm:text-3xl font-black text-white font-mono">
                            ₹{price}
                          </span>
                          <span className="text-xs text-slate-400 font-mono">/month</span>
                          {plan.price && plan.price !== plan.price_inr && (
                            <span className="text-xs text-slate-500 font-mono ml-2">
                              (${plan.price} USD)
                            </span>
                          )}
                        </div>

                        {/* Node & Location specs */}
                        <div className="grid grid-cols-2 gap-2 text-xs">
                          {plan.node && (
                            <div className="p-2 rounded-lg bg-[#18122a] border border-purple-900/30 text-slate-300 flex items-center gap-1.5">
                              <Cpu size={12} className="text-purple-400 shrink-0" />
                              <span className="truncate font-mono text-[11px]">{plan.node}</span>
                            </div>
                          )}
                          {plan.location && (
                            <div className="p-2 rounded-lg bg-[#18122a] border border-purple-900/30 text-slate-300 flex items-center gap-1.5">
                              <Globe size={12} className="text-indigo-400 shrink-0" />
                              <span className="truncate font-mono text-[11px]">{plan.location}</span>
                            </div>
                          )}
                        </div>

                        {/* Description */}
                        {plan.desc && (
                          <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                            {plan.desc}
                          </p>
                        )}

                        {/* Features checklist from Admin Panel */}
                        {plan.features && plan.features.length > 0 && (
                          <div className="space-y-1.5 pt-2">
                            <span className="text-[10px] font-mono uppercase font-bold text-slate-400 tracking-wider block">
                              Plan Features:
                            </span>
                            <ul className="space-y-1">
                              {plan.features.slice(0, 4).map((feat, fIdx) => (
                                <li key={fIdx} className="text-xs text-slate-300 flex items-center gap-2">
                                  <CheckCircle2 size={12} className="text-emerald-400 shrink-0" />
                                  <span className="line-clamp-1">{feat}</span>
                                </li>
                              ))}
                              {plan.features.length > 4 && (
                                <li className="text-[10px] text-purple-300 font-mono pl-5">
                                  + {plan.features.length - 4} more specs configured in admin
                                </li>
                              )}
                            </ul>
                          </div>
                        )}
                      </div>

                      {/* Order Action Button */}
                      <div className="pt-4 mt-4 border-t border-purple-900/30">
                        <button
                          onClick={() => handleSelectPlan(plan)}
                          className={`w-full py-3 rounded-xl text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md ${
                            isPopular
                              ? 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-purple-600/30'
                              : 'bg-[#18122a] hover:bg-purple-600 hover:text-white text-slate-200 border border-purple-900/50'
                          }`}
                        >
                          <span>Deploy With This Plan</span>
                          <ArrowRight size={14} />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="p-12 text-center bg-[#120e20] border border-purple-900/30 rounded-2xl space-y-4">
                <Server size={40} className="mx-auto text-purple-400 opacity-40" />
                <h4 className="text-base font-bold text-white uppercase">No Hosting Plans Found</h4>
                <p className="text-xs text-slate-400 max-w-md mx-auto">
                  There are currently no active hosting plans in this category. You can add or configure new plans anytime directly in the <strong className="text-purple-300">Admin Panel &gt; Hosting Plans Panel</strong>.
                </p>
                <button
                  onClick={() => setFilterMode('all')}
                  className="px-4 py-2 bg-purple-600/80 hover:bg-purple-600 text-white rounded-lg text-xs font-mono uppercase tracking-wider transition-all"
                >
                  View All Admin Plans ({plans.length})
                </button>
              </div>
            )}
          </div>

          {/* Modal Footer */}
          <div className="p-4 bg-[#07050d] border-t border-purple-900/40 flex items-center justify-between text-xs text-slate-400 font-mono shrink-0">
            <span className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              Live Admin Database Sync Active
            </span>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white text-xs underline cursor-pointer"
            >
              Cancel
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
