import React from 'react';
import { Check, ArrowRight, MapPin, Cpu, Zap } from 'lucide-react';
import { motion } from 'motion/react';
import { Plan } from '../types';

interface PlanCardProps {
  plan: Plan;
  currency?: 'USD' | 'INR' | 'EUR';
  onOrder: (plan: Plan) => void;
}

export const PlanCard: React.FC<PlanCardProps> = ({ plan, onOrder }) => {
  const badgeLower = (plan.badge || '').toLowerCase();
  const isPopular = badgeLower.includes('popular') || badgeLower.includes('best') || badgeLower.includes('ultimate');

  const getPrice = () => {
    return { symbol: '₹', value: plan.price_inr || plan.price };
  };

  const { symbol, value } = getPrice();

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className={`relative flex flex-col p-7 rounded-2xl border transition-all duration-300 group ${
        isPopular 
          ? 'bg-bg-alt border-accent/60 shadow-xl shadow-accent/10' 
          : 'bg-card border-border hover:border-border-hover hover:bg-bg-alt shadow-sm'
      }`}
    >
      {plan.badge && (
        <div className={`absolute -top-3.5 left-6 px-3 py-1 text-[10px] font-extrabold uppercase tracking-widest rounded-md shadow-md flex items-center gap-1.5 ${
          isPopular
            ? 'bg-accent text-white border border-accent-muted'
            : 'bg-bg-alt text-foreground-muted border border-border'
        }`}>
          <Zap size={10} className="text-white" />
          {plan.badge}
        </div>
      )}

      <div className="mb-6 pt-2">
        <h3 className="text-2xl font-bold font-display tracking-tight mb-2 text-foreground group-hover:text-white transition-colors">
          {plan.name}
        </h3>
        <p className="text-xs text-foreground-muted font-normal h-10 line-clamp-2 mb-4 leading-relaxed">
          {plan.desc}
        </p>
        
        <div className="flex flex-wrap gap-2 pt-3 border-t border-border/60">
           <div className="flex items-center gap-1.5 text-[10px] font-mono font-medium text-foreground-muted bg-bg px-2.5 py-1 rounded border border-border">
              <MapPin size={10} className="text-accent" />
              {plan.location || 'Global Node'}
           </div>
           <div className="flex items-center gap-1.5 text-[10px] font-mono font-medium text-foreground-muted bg-bg px-2.5 py-1 rounded border border-border">
              <Cpu size={10} className="text-foreground-dim" />
              {plan.node || 'High Frequency'}
           </div>
        </div>
      </div>

      <div className="flex items-baseline gap-1 mb-6 pb-6 border-b border-border/60">
        <span className="text-xl text-foreground-muted font-bold">{symbol}</span>
        <span className="text-4xl font-extrabold font-mono text-foreground tracking-tight">{value}</span>
        <span className="text-foreground-dim text-xs font-mono ml-1">/month</span>
      </div>

      <div className="flex-1 space-y-3 mb-8">
        {plan.features.map((feature, idx) => (
          <div key={idx} className="flex items-start gap-2.5">
            <div className="mt-0.5 w-4 h-4 rounded-full bg-accent/10 border border-accent/30 flex items-center justify-center shrink-0">
              <Check size={10} className="text-accent" />
            </div>
            <span className="text-xs text-foreground-muted font-normal leading-snug">{feature}</span>
          </div>
        ))}
      </div>

      <button
        onClick={() => onOrder(plan)}
        className={`w-full py-3.5 rounded-lg font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 group/btn ${
          isPopular 
            ? 'bg-accent hover:bg-accent-muted text-white shadow-lg shadow-accent/20' 
            : 'bg-bg border border-border text-foreground hover:bg-accent hover:border-accent hover:text-white'
        }`}
      >
        Order Now
        <ArrowRight size={14} className="transition-transform group-hover/btn:translate-x-1" />
      </button>
    </motion.div>
  );
};
