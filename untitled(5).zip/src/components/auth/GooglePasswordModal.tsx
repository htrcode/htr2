import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Lock, Eye, EyeOff, Server, Chrome, AlertCircle, ShieldCheck, X } from 'lucide-react';

interface GooglePasswordModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (password: string) => Promise<void>;
  title?: string;
  subtitle?: string;
}

export const GooglePasswordModal: React.FC<GooglePasswordModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  title = "Set Game Panel Password",
  subtitle = "Pterodactyl Game Panel (gp.hector.host) requires a dedicated password for SFTP and game console access alongside Google Sign-In."
}) => {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (password.length < 8) {
      setError('Password must be at least 8 characters long for Pterodactyl Game Panel.');
      return;
    }

    if (password !== confirmPassword) {
      setError('Passwords do not match. Please re-enter.');
      return;
    }

    setLoading(true);
    try {
      await onSubmit(password);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Authentication failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const isLengthValid = password.length >= 8;
  const isMatchValid = confirmPassword.length > 0 && password === confirmPassword;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[1100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="relative w-full max-w-md bg-bg-alt border border-border rounded-3xl p-6 sm:p-8 shadow-2xl overflow-hidden font-sans"
        >
          {/* Top Decorative Glow */}
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-emerald-500 via-accent to-purple-500" />

          {/* Close button */}
          <button
            type="button"
            onClick={onClose}
            disabled={loading}
            className="absolute top-5 right-5 p-2 text-foreground-dim hover:text-foreground rounded-full hover:bg-border transition-colors disabled:opacity-50"
          >
            <X size={18} />
          </button>

          {/* Header */}
          <div className="text-center mb-6">
            <div className="w-12 h-12 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl flex items-center justify-center mx-auto mb-4 text-emerald-400">
              <Server size={24} />
            </div>
            <h3 className="text-xl font-black text-foreground uppercase tracking-tight">
              {title}
            </h3>
            <p className="text-xs text-foreground-dim mt-2 leading-relaxed px-2">
              {subtitle}
            </p>
          </div>

          {/* Error Message */}
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -5 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-4 p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl text-rose-400 text-xs font-semibold flex items-center gap-2"
            >
              <AlertCircle size={16} className="shrink-0" />
              <span>{error}</span>
            </motion.div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-[10px] font-black text-foreground-dim uppercase tracking-widest mb-1.5 px-1">
                Pterodactyl Panel Password
              </label>
              <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-foreground-dim/50 group-focus-within:text-accent">
                  <Lock size={15} />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Min 8 characters"
                  className="block w-full pl-10 pr-10 py-3 bg-bg border border-border rounded-xl text-sm text-foreground focus:ring-2 focus:ring-accent focus:border-accent outline-none transition-all placeholder:text-foreground-dim/30"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-foreground-dim/50 hover:text-foreground"
                >
                  {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-black text-foreground-dim uppercase tracking-widest mb-1.5 px-1">
                Confirm Panel Password
              </label>
              <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-foreground-dim/50 group-focus-within:text-accent">
                  <Lock size={15} />
                </div>
                <input
                  type={showConfirm ? 'text' : 'password'}
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Re-enter password"
                  className="block w-full pl-10 pr-10 py-3 bg-bg border border-border rounded-xl text-sm text-foreground focus:ring-2 focus:ring-accent focus:border-accent outline-none transition-all placeholder:text-foreground-dim/30"
                />
                <button
                  type="button"
                  onClick={() => setShowConfirm(!showConfirm)}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-foreground-dim/50 hover:text-foreground"
                >
                  {showConfirm ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            {/* Password Validation Guidance */}
            <div className="py-2 px-3 bg-bg border border-border/60 rounded-xl space-y-1 text-[11px]">
              <div className={`flex items-center gap-2 ${isLengthValid ? 'text-emerald-400 font-bold' : 'text-foreground-dim'}`}>
                <div className={`w-1.5 h-1.5 rounded-full ${isLengthValid ? 'bg-emerald-400' : 'bg-foreground-dim/40'}`} />
                <span>At least 8 characters length</span>
              </div>
              <div className={`flex items-center gap-2 ${isMatchValid ? 'text-emerald-400 font-bold' : 'text-foreground-dim'}`}>
                <div className={`w-1.5 h-1.5 rounded-full ${isMatchValid ? 'bg-emerald-400' : 'bg-foreground-dim/40'}`} />
                <span>Passwords match</span>
              </div>
            </div>

            {/* Note badge */}
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex items-start gap-2.5 text-[11px] text-foreground-dim leading-relaxed">
              <ShieldCheck size={16} className="text-emerald-400 shrink-0 mt-0.5" />
              <span>
                You will be able to log in to <strong className="text-foreground">gp.hector.host</strong> using your Google email and this password.
              </span>
            </div>

            {/* Submit button */}
            <div className="pt-2 space-y-2">
              <button
                type="submit"
                disabled={loading || !isLengthValid || !isMatchValid}
                className="w-full flex items-center justify-center gap-2.5 py-3.5 px-4 bg-accent hover:bg-accent-dim text-white font-black uppercase tracking-widest text-xs rounded-xl transition-all shadow-lg shadow-accent/25 disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <Chrome size={16} />
                {loading ? 'Authenticating with Google...' : 'Continue with Google'}
              </button>

              <button
                type="button"
                onClick={onClose}
                disabled={loading}
                className="w-full py-2.5 text-[11px] font-bold text-foreground-dim hover:text-foreground uppercase tracking-widest transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
