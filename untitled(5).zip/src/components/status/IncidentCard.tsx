import React from 'react';
import { AlertTriangle, CheckCircle2, Clock, Info, Wrench } from 'lucide-react';
import { StatusIncident } from '../../types';

interface IncidentCardProps {
  incident: StatusIncident;
}

export const IncidentCard: React.FC<IncidentCardProps> = ({ incident }) => {
  const getSeverityBadge = () => {
    switch (incident.severity) {
      case 'critical':
        return <span className="px-2 py-0.5 rounded bg-rose-500/10 border border-rose-500/30 text-rose-400 text-[10px] font-bold uppercase">Critical Outage</span>;
      case 'major':
        return <span className="px-2 py-0.5 rounded bg-orange-500/10 border border-orange-500/30 text-orange-400 text-[10px] font-bold uppercase">Major Outage</span>;
      case 'minor':
        return <span className="px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/30 text-amber-400 text-[10px] font-bold uppercase">Partial Outage</span>;
      case 'maintenance':
        return <span className="px-2 py-0.5 rounded bg-blue-500/10 border border-blue-500/30 text-blue-400 text-[10px] font-bold uppercase">Maintenance</span>;
      default:
        return null;
    }
  };

  const getStatusBadge = () => {
    switch (incident.status) {
      case 'investigating':
        return <span className="flex items-center gap-1.5 text-amber-400 font-bold text-xs uppercase"><AlertTriangle size={14} /> Investigating</span>;
      case 'identified':
        return <span className="flex items-center gap-1.5 text-orange-400 font-bold text-xs uppercase"><Info size={14} /> Cause Identified</span>;
      case 'monitoring':
        return <span className="flex items-center gap-1.5 text-blue-400 font-bold text-xs uppercase"><Clock size={14} /> Monitoring Fix</span>;
      case 'resolved':
        return <span className="flex items-center gap-1.5 text-emerald-400 font-bold text-xs uppercase"><CheckCircle2 size={14} /> Resolved</span>;
      default:
        return null;
    }
  };

  return (
    <div className="bg-bg-alt border border-border rounded-xl p-6 space-y-4 hover:border-border/80 transition-all">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-border/60 pb-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            {getSeverityBadge()}
            {incident.serviceName && (
              <span className="text-[10px] font-mono text-foreground-dim uppercase tracking-wider">
                • {incident.serviceName}
              </span>
            )}
          </div>
          <h3 className="text-base font-extrabold text-foreground tracking-tight">{incident.title}</h3>
        </div>
        <div>{getStatusBadge()}</div>
      </div>

      <p className="text-sm text-foreground-muted leading-relaxed">{incident.description}</p>

      {/* Timeline Updates */}
      {incident.updates && incident.updates.length > 0 && (
        <div className="space-y-3 pt-2">
          <h4 className="text-[10px] font-bold uppercase tracking-widest text-foreground-dim">Incident Timeline</h4>
          <div className="relative pl-4 space-y-3 border-l-2 border-border/80">
            {incident.updates.map((update, idx) => (
              <div key={update.id || idx} className="relative">
                <div className="absolute -left-[21px] top-1.5 w-2.5 h-2.5 rounded-full bg-border border border-bg" />
                <div className="flex items-center gap-2 text-[10px] font-mono text-foreground-dim mb-0.5">
                  <span className="font-bold text-foreground capitalize">{update.status}</span>
                  <span>•</span>
                  <span>{new Date(update.timestamp).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
                </div>
                <p className="text-xs text-foreground/90">{update.message}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="text-[10px] text-foreground-dim font-mono pt-2 border-t border-border/40 flex items-center justify-between">
        <span>Reported: {new Date(incident.createdAt).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}</span>
        {incident.resolvedAt && (
          <span className="text-emerald-400 font-bold">Resolved: {new Date(incident.resolvedAt).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}</span>
        )}
      </div>
    </div>
  );
};
