import React, { useState } from 'react';
import { CheckCircle2, AlertTriangle, AlertCircle, Clock, Database, Wifi } from 'lucide-react';
import { ServiceStatus, StatusHistoryItem } from '../../types';

interface UptimeBarProps {
  service: ServiceStatus;
  days?: number;
  sessionUptime?: string;
  variant?: 'card' | 'minimal';
}

export interface DayBarItem {
  date: string;
  status: 'operational' | 'degraded' | 'outage' | 'maintenance' | 'unmonitored';
  uptimePercent?: number;
  latencyMs?: number;
  isToday?: boolean;
}

export const UptimeBar: React.FC<UptimeBarProps> = ({ service, days = 60, sessionUptime, variant = 'card' }) => {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  // Build authentic day-by-day history without fake data.
  // Days prior to service monitoring or without recorded metrics remain 'unmonitored' (gray).
  const buildHistory = (): DayBarItem[] => {
    const items: DayBarItem[] = [];
    const today = new Date();
    
    // Parse service creation timestamp if available, or treat today as monitored
    const createdAtTime = service.lastChecked ? new Date(service.lastChecked).getTime() : Date.now();
    const createdDateStr = new Date(createdAtTime).toISOString().split('T')[0];

    for (let i = days - 1; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      const isToday = i === 0;

      // Check if service explicitly has custom history recorded for dateStr
      const customRecord = service.history?.find(h => h.date === dateStr);

      if (customRecord) {
        items.push({
          date: dateStr,
          status: customRecord.status,
          uptimePercent: customRecord.uptimePercent,
          latencyMs: customRecord.latencyMs,
          isToday
        });
      } else if (isToday) {
        // Today is actively monitored live
        const latVal = parseInt(service.latency || '0') || undefined;
        items.push({
          date: dateStr,
          status: service.status || 'operational',
          uptimePercent: service.status === 'operational' ? 100 : service.status === 'degraded' ? 95 : service.status === 'outage' ? 0 : 99,
          latencyMs: latVal,
          isToday
        });
      } else {
        // Truthful unmonitored day - no fake history!
        items.push({
          date: dateStr,
          status: 'unmonitored',
          isToday: false
        });
      }
    }
    return items;
  };

  const history = buildHistory();

  // Calculate actual monitored uptime percentage
  const monitoredDays = history.filter(h => h.status !== 'unmonitored');
  const uptimeVal = sessionUptime || (monitoredDays.length > 0 
    ? (monitoredDays.reduce((acc, curr) => acc + (curr.uptimePercent ?? (curr.status === 'operational' ? 100 : 0)), 0) / monitoredDays.length).toFixed(3) + '%'
    : '100.0%');

  const getBarColor = (item: DayBarItem) => {
    switch (item.status) {
      case 'operational': return 'bg-emerald-500 hover:bg-emerald-400';
      case 'degraded': return 'bg-amber-400 hover:bg-amber-300';
      case 'outage': return 'bg-rose-500 hover:bg-rose-400';
      case 'maintenance': return 'bg-blue-400 hover:bg-blue-300';
      case 'unmonitored': default: return 'bg-[#1d2433] opacity-30 hover:opacity-70';
    }
  };

  const getStatusIcon = (status: ServiceStatus['status']) => {
    switch (status) {
      case 'operational': return <CheckCircle2 size={16} className="text-emerald-400 shrink-0" />;
      case 'degraded': return <AlertTriangle size={16} className="text-amber-400 shrink-0" />;
      case 'outage': return <AlertCircle size={16} className="text-rose-400 shrink-0" />;
      case 'maintenance': return <Clock size={16} className="text-blue-400 shrink-0" />;
      default: return <CheckCircle2 size={16} className="text-emerald-400 shrink-0" />;
    }
  };

  return (
    <div className={variant === 'minimal' ? 'w-full space-y-3 font-sans' : 'w-full bg-[#121621] border border-[#222938] rounded-2xl p-6 space-y-4 shadow-sm hover:border-[#2d364a] transition-all font-sans'}>
      {/* Top Bar: Title on Left, Uptime % on Right */}
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-2.5">
          {getStatusIcon(service.status)}
          <h3 className={`font-bold text-foreground tracking-tight ${variant === 'minimal' ? 'text-sm' : 'text-base'}`}>{service.name}</h3>
          {service.category && variant !== 'minimal' && (
            <span className="px-2 py-0.5 rounded bg-[#1c2230] text-[10px] font-mono text-foreground-dim uppercase border border-[#2b3346]">
              {service.category}
            </span>
          )}
        </div>

        <div className="flex items-center gap-3">
          <span className="font-mono text-xs font-bold text-emerald-400">
            {uptimeVal} uptime
          </span>
        </div>
      </div>

      {/* 90-Day Bar Timeline Container */}
      <div className="space-y-2">
        <div className="relative flex items-center justify-between gap-[2.5px] h-9 p-1 bg-[#0b0e14] border border-[#1b212f] rounded-xl overflow-visible">
          {history.map((item, idx) => (
            <div
              key={idx}
              onMouseEnter={() => setHoveredIdx(idx)}
              onMouseLeave={() => setHoveredIdx(null)}
              className={`flex-1 h-full rounded-[2px] transition-all duration-150 cursor-pointer ${getBarColor(item)} ${
                hoveredIdx === idx ? 'scale-y-125 z-30 brightness-125 shadow-lg' : ''
              }`}
            >
              {/* Tooltip */}
              {hoveredIdx === idx && (
                <div className="absolute bottom-12 left-1/2 -translate-x-1/2 z-50 pointer-events-none min-w-[170px] p-3 rounded-xl bg-[#181e2b] border border-[#2b3447] shadow-2xl text-left font-sans">
                  <div className="text-[10px] text-foreground-dim uppercase tracking-wider font-bold mb-1">
                    {new Date(item.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                    {item.isToday && <span className="ml-1 text-accent font-bold">(Today)</span>}
                  </div>
                  
                  {item.status === 'unmonitored' ? (
                    <div className="text-xs text-foreground-dim font-medium italic">
                      No telemetry recorded (Not monitored)
                    </div>
                  ) : (
                    <>
                      <div className="flex items-center justify-between gap-2">
                        <span className={`text-[11px] font-black uppercase tracking-wider ${
                          item.status === 'operational' ? 'text-emerald-400' :
                          item.status === 'degraded' ? 'text-amber-400' :
                          item.status === 'outage' ? 'text-rose-400' : 'text-blue-400'
                        }`}>
                          {item.status}
                        </span>
                        {item.uptimePercent !== undefined && (
                          <span className="text-[11px] font-mono text-foreground font-bold">{item.uptimePercent}%</span>
                        )}
                      </div>
                      {item.latencyMs && (
                        <div className="text-[10px] font-mono text-foreground-dim mt-1 flex items-center gap-1">
                          <Wifi size={10} /> Ping: {item.latencyMs}ms
                        </div>
                      )}
                    </>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Timeline Footer Labels */}
        <div className="flex items-center justify-between text-[11px] text-foreground-dim font-mono px-0.5">
          <span>{days} days ago</span>
          <span>Today</span>
        </div>
      </div>
    </div>
  );
};
