import React from 'react';
import { Box, Clock, ChevronRight, LifeBuoy, ArrowRight, Server, ExternalLink, Zap, Activity, Globe, ShieldCheck } from 'lucide-react';
import { motion } from 'motion/react';
import { UserService, UserActivity } from '../../types';

interface OverviewProps {
  services: UserService[];
  activities: UserActivity[];
  onTabChange: (tab: string) => void;
}

export const Overview: React.FC<OverviewProps> = ({ services, activities, onTabChange }) => {
  const activeCount = services.filter(s => s.status === 'active').length;
  const pendingCount = services.filter(s => s.status !== 'active').length;
  const locationsCount = Array.from(new Set(services.map(s => s.location))).length || 1;

  const stats = [
    { label: 'Active Compute Nodes', value: `${activeCount} Active`, sub: pendingCount > 0 ? `${pendingCount} Pending Order` : 'All Systems Operational', icon: Box, color: 'text-accent', border: 'border-accent/20 bg-accent/5' },
    { label: 'Deployed Datacenters', value: `${locationsCount} Region(s)`, sub: 'India & Global IX', icon: Globe, color: 'text-emerald-400', border: 'border-emerald-500/20 bg-emerald-500/5' },
    { label: 'DDoS Protection', value: '100% Filtered', sub: 'L3/L4/L7 Hardware Shield', icon: ShieldCheck, color: 'text-sky-400', border: 'border-sky-500/20 bg-sky-500/5' },
    { label: 'Infrastructure Uptime', value: '99.99%', sub: 'SLA Guaranteed', icon: Zap, color: 'text-amber-400', border: 'border-amber-500/20 bg-amber-500/5' },
  ];

  const formatActivity = (desc: string) => {
    if (!desc) return 'Account activity updated';
    if (desc.includes('ORDERED') || desc.includes('Ordered') || desc.includes('INV-')) {
      const invMatch = desc.match(/INV-\d+/i);
      const invNum = invMatch ? invMatch[0].toUpperCase() : 'Invoice';
      return `Order ${invNum} placed (Payment Verification Pending)`;
    }
    return desc;
  };

  return (
    <div className="space-y-8">
      {/* Enterprise Infrastructure Stats Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, idx) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.05 }}
            className={`p-5 rounded-2xl border ${stat.border} backdrop-blur-md flex items-center justify-between group hover:scale-[1.01] transition-all`}
          >
            <div>
              <div className="text-[9px] font-black uppercase tracking-[0.2em] text-foreground-dim mb-1">{stat.label}</div>
              <div className="text-xl font-black text-foreground tracking-tight mb-0.5">{stat.value}</div>
              <div className="text-[9px] font-bold uppercase tracking-widest text-foreground-dim/80">{stat.sub}</div>
            </div>
            <div className={`p-3 rounded-xl bg-bg border border-border group-hover:border-accent/30 transition-colors ${stat.color}`}>
              <stat.icon size={20} />
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Services List (Active & Pending Verification) */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black uppercase tracking-[0.2em] text-foreground">Recent Services & Orders</h3>
            <button 
              onClick={() => onTabChange('services')}
              className="text-[10px] font-black uppercase tracking-widest text-accent hover:text-accent-muted flex items-center gap-1.5 transition-colors"
            >
              View All Services <ChevronRight size={12} />
            </button>
          </div>
          
          <div className="space-y-3">
            {services.length > 0 ? (
              services.slice(0, 5).map((service) => {
                const isActive = service.status === 'active';
                return (
                  <div 
                    key={service.id} 
                    onClick={() => onTabChange('services')}
                    className="p-4 bg-bg-alt border border-border hover:border-accent/40 rounded-2xl flex items-center justify-between group transition-all cursor-pointer"
                  >
                    <div className="flex items-center gap-4">
                      <div className={`w-11 h-11 rounded-xl bg-bg border flex items-center justify-center transition-colors ${
                        isActive ? 'border-border text-foreground-dim group-hover:text-accent' : 'border-amber-500/30 text-amber-400'
                      }`}>
                        <Box size={22} />
                      </div>
                      <div>
                        <div className="text-xs font-black uppercase tracking-widest text-foreground flex items-center gap-2 mb-1">
                          {service.name}
                          {!isActive && (
                            <span className="px-2 py-0.5 rounded-full text-[8px] font-black uppercase tracking-wider bg-amber-500/10 text-amber-400 border border-amber-500/20">
                              Verification Pending
                            </span>
                          )}
                        </div>
                        <div className="text-[10px] font-mono text-foreground-dim flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-border inline-block" />
                          {isActive ? (service.ip || 'Assigning Public IP...') : 'Payment Under Verification (2-4 Hours)'}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-6">
                      <div className="text-right hidden sm:block">
                        <div className="text-[9px] font-black uppercase tracking-widest text-foreground-dim mb-1">Status</div>
                        <div className="flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full ${isActive ? 'bg-emerald-500 shadow-sm shadow-emerald-500' : 'bg-amber-400 animate-pulse'}`} />
                          <span className={`text-[10px] font-black uppercase tracking-widest ${isActive ? 'text-emerald-400' : 'text-amber-400'}`}>
                            {isActive ? 'Active' : 'Pending Verification'}
                          </span>
                        </div>
                      </div>
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          onTabChange('services');
                        }}
                        className="p-2 hover:bg-bg rounded-xl border border-transparent hover:border-border transition-all text-foreground-dim group-hover:text-accent"
                        title="Go to My Services"
                      >
                        <ChevronRight size={18} />
                      </button>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="p-12 text-center bg-bg-alt border border-dashed border-border rounded-2xl">
                <div className="text-[11px] font-bold uppercase tracking-widest text-foreground-dim">No services found</div>
                <button 
                  onClick={() => window.location.href = '/plans'}
                  className="mt-4 text-[10px] font-black uppercase tracking-widest text-accent hover:underline"
                >
                  Deploy your first node
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Activity Feed & Quick Support */}
        <div className="space-y-6">
          <div className="space-y-4">
            <h3 className="text-xs font-black uppercase tracking-[0.2em] text-foreground">Account Activity</h3>
            <div className="p-5 bg-bg-alt border border-border rounded-2xl space-y-5">
              {activities.length > 0 ? (
                activities.slice(0, 4).map((activity, idx) => (
                  <div key={activity.id} className="relative pl-6 pb-5 last:pb-0 group">
                    {idx !== Math.min(activities.length, 4) - 1 && (
                      <div className="absolute left-[3px] top-[14px] bottom-0 w-[1px] bg-border group-hover:bg-accent/20 transition-colors" />
                    )}
                    <div className="absolute left-0 top-[6px] w-1.5 h-1.5 rounded-full bg-border group-hover:bg-accent transition-all ring-4 ring-bg-alt" />
                    <div className="space-y-1">
                      <div className="text-[10px] font-semibold text-foreground group-hover:text-accent transition-colors leading-snug">
                        {formatActivity(activity.description)}
                      </div>
                      <div className="flex items-center gap-2 text-[9px] font-medium text-foreground-dim">
                        <Clock size={10} />
                        {new Date(activity.timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-4">
                  <div className="text-[10px] font-medium text-foreground-dim">No recent activity registered</div>
                </div>
              )}
            </div>
          </div>

          {/* Pterodactyl Game Panel Access Card */}
          <div className="p-5 bg-gradient-to-br from-emerald-500/10 via-bg-alt to-bg-alt border border-emerald-500/20 rounded-2xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  <Server size={18} />
                </div>
                <div>
                  <h4 className="text-[11px] font-black uppercase tracking-widest text-foreground">Game Panel</h4>
                  <p className="text-[9px] font-mono text-emerald-400">gp.hector.host</p>
                </div>
              </div>
              <span className="px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Live Console
              </span>
            </div>
            <p className="text-[10px] text-foreground-dim leading-relaxed">
              Manage your game servers, console output, SFTP credentials, and file manager directly.
            </p>
            <a
              href="https://gp.hector.host/"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white text-[10px] font-black uppercase tracking-widest rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20"
            >
              Open Game Panel <ExternalLink size={12} />
            </a>
          </div>

          {/* Quick Support Card */}
          <div className="p-5 bg-gradient-to-br from-accent/10 via-bg-alt to-purple-950/20 border border-accent/20 rounded-2xl space-y-3">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-accent/20 text-accent border border-accent/30">
                <LifeBuoy size={18} />
              </div>
              <div>
                <h4 className="text-[11px] font-black uppercase tracking-widest text-foreground">Need Technical Help?</h4>
                <p className="text-[9px] font-bold uppercase tracking-widest text-foreground-dim">24/7 Support Desk</p>
              </div>
            </div>
            <button
              onClick={() => onTabChange('tickets')}
              className="w-full py-2.5 bg-accent hover:bg-accent-muted text-white text-[10px] font-black uppercase tracking-widest rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-accent/20"
            >
              Open Support Tickets <ArrowRight size={12} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
