import React, { useState } from 'react';
import { 
  Box, Server, Globe, Cpu, RotateCw, Power, Terminal, Settings, 
  X, Eye, EyeOff, Copy, Check, ExternalLink, Lock, Mail, Key, Hash, Shield, Network,
  RefreshCw, CheckCircle2, AlertCircle, KeyRound
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { UserService } from '../../types';
import { adminService } from '../../services/adminService';
import { pterodactylService } from '../../services/pterodactylService';
import { User as FirebaseUser } from 'firebase/auth';

interface ServicesProps {
  services: UserService[];
  user?: FirebaseUser | null;
}

export const Services: React.FC<ServicesProps> = ({ services: initialServices, user }) => {
  const [servicesList, setServicesList] = useState<UserService[]>(initialServices);
  const [selectedService, setSelectedService] = useState<UserService | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  // Password Change State
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [passwordLoading, setPasswordLoading] = useState(false);
  const [passwordSuccess, setPasswordSuccess] = useState<string | null>(null);
  const [passwordError, setPasswordError] = useState<string | null>(null);

  React.useEffect(() => {
    setServicesList(initialServices);
  }, [initialServices]);

  const handleCopy = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const isVpsOrDedicated = (service: UserService): boolean => {
    if (service.serverType === 'vps_dedicated') return true;
    if (service.serverType === 'panel') return false;
    const text = `${service.category || ''} ${service.name || ''}`.toLowerCase();
    return text.includes('vps') || text.includes('dedicated') || text.includes('kvm') || text.includes('bare metal');
  };

  const handleUpdateServicePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedService) return;
    setPasswordError(null);
    setPasswordSuccess(null);

    if (newPassword.length < 8) {
      setPasswordError('Password must be at least 8 characters for security.');
      return;
    }

    if (newPassword !== confirmNewPassword) {
      setPasswordError('Passwords do not match. Please verify both fields.');
      return;
    }

    setPasswordLoading(true);
    try {
      const isVps = isVpsOrDedicated(selectedService);
      const targetEmail = (selectedService.panelEmail || user?.email || '').trim().toLowerCase();

      // 1. If Game / Bot / Web hosting (Pterodactyl Panel), update the actual user password on Pterodactyl Panel
      if (!isVps) {
        if (!targetEmail) {
          throw new Error('User email not found for Pterodactyl panel account synchronization.');
        }

        const pteroRes = await pterodactylService.updatePassword({
          email: targetEmail,
          password: newPassword,
          firebaseUid: user?.uid || selectedService.userId
        });

        if (!pteroRes.success && pteroRes.error) {
          throw new Error(pteroRes.error || 'Failed to update password on Pterodactyl Panel');
        }
      }

      // 2. Update service records in Firestore (do not store plaintext panel password)
      const updateData: Partial<UserService> = isVps 
        ? { rootPassword: newPassword }
        : { panelEmail: targetEmail || selectedService.panelEmail };

      await adminService.updateService(selectedService.id, updateData);

      // 3. Update local state
      const updated = { ...selectedService, ...updateData };
      setSelectedService(updated);
      setServicesList(prev => prev.map(s => s.id === selectedService.id ? updated : s));
      setPasswordSuccess(
        isVps 
          ? 'SSH & Root access password updated successfully!'
          : 'Pterodactyl panel password updated successfully on gp.hector.host!'
      );
      setNewPassword('');
      setConfirmNewPassword('');
      setTimeout(() => {
        setIsChangingPassword(false);
        setPasswordSuccess(null);
      }, 3000);
    } catch (err: any) {
      setPasswordError(err.message || 'Failed to update password. Please try again.');
    } finally {
      setPasswordLoading(false);
    }
  };

  const activeServices = servicesList.filter(s => s.status === 'active');
  const pendingServices = servicesList.filter(s => s.status !== 'active');
  const [filter, setFilter] = useState<'all' | 'active' | 'pending'>('all');

  const filteredServices = servicesList.filter(s => {
    if (filter === 'active') return s.status === 'active';
    if (filter === 'pending') return s.status !== 'active';
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Fleet Filter Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 bg-bg-alt border border-border rounded-2xl">
        <div>
          <h2 className="text-sm font-black uppercase tracking-[0.2em] text-foreground mb-1">Your Server Fleet</h2>
          <p className="text-[10px] font-medium text-foreground-dim">Manage active instances, IP allocations, and panel credentials</p>
        </div>

        <div className="flex items-center gap-2">
          <div className="p-1 bg-bg border border-border rounded-xl flex gap-1">
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${
                filter === 'all' ? 'bg-accent text-white shadow-md' : 'text-foreground-dim hover:text-foreground'
              }`}
            >
              All ({servicesList.length})
            </button>
            <button
              onClick={() => setFilter('active')}
              className={`px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${
                filter === 'active' ? 'bg-emerald-500 text-white shadow-md' : 'text-foreground-dim hover:text-foreground'
              }`}
            >
              Active ({activeServices.length})
            </button>
            {pendingServices.length > 0 && (
              <button
                onClick={() => setFilter('pending')}
                className={`px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${
                  filter === 'pending' ? 'bg-amber-500 text-white shadow-md' : 'text-foreground-dim hover:text-amber-400'
                }`}
              >
                Pending ({pendingServices.length})
              </button>
            )}
          </div>

          <button 
            onClick={() => window.location.href = '/game-servers'}
            className="px-5 py-2.5 bg-accent hover:bg-accent-muted text-white text-[10px] font-black uppercase tracking-widest rounded-xl transition-all shadow-lg shadow-accent/20 shrink-0"
          >
            Deploy Node
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {filteredServices.length > 0 ? (
          filteredServices.map((service, idx) => {
            const isActive = service.status === 'active';
            return (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.04 }}
                className={`p-6 bg-bg-alt border rounded-2xl transition-all ${
                  isActive ? 'border-border hover:border-accent/40' : 'border-amber-500/30 bg-amber-950/10 hover:border-amber-500/50'
                }`}
              >
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                  {/* Basic Info */}
                  <div className="flex items-center gap-5">
                    <div className={`w-14 h-14 rounded-2xl bg-bg border flex items-center justify-center transition-colors shrink-0 ${
                      isActive ? 'border-border text-foreground-dim group-hover:text-accent' : 'border-amber-500/30 text-amber-400'
                    }`}>
                      <Box size={28} />
                    </div>
                    <div>
                      <div className="flex flex-wrap items-center gap-2.5 mb-1.5">
                        <h3 className="text-xs font-black uppercase tracking-widest text-foreground">{service.name}</h3>
                        <span className={`px-2.5 py-0.5 rounded-full text-[8px] font-black uppercase tracking-widest ${
                          isActive 
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                            : 'bg-amber-500/10 text-amber-400 border border-amber-500/20 animate-pulse'
                        }`}>
                          {isActive ? 'Active' : 'Verification Pending'}
                        </span>
                      </div>
                      <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-[10px]">
                        <div className="flex items-center gap-1.5 font-bold uppercase tracking-widest text-foreground-dim">
                          <Globe size={13} className="text-foreground-dim" /> {service.location || 'India (Mumbai)'}
                        </div>
                        <div className="flex items-center gap-1.5 font-bold uppercase tracking-widest text-foreground-dim">
                          <Server size={13} className="text-foreground-dim" /> {service.nodeName || 'Node-01'}
                        </div>
                        <div className="flex items-center gap-1.5 font-mono text-foreground">
                          <Terminal size={13} className={isActive ? 'text-accent' : 'text-amber-400'} /> {isActive ? (service.ip || 'Assigning IP...') : 'IP Allocating (2-4h Verification)'}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Service Details */}
                  {isActive ? (
                    <div className="flex items-center gap-6 px-6 border-l border-border hidden xl:flex">
                      <div>
                        <div className="text-[9px] font-black uppercase tracking-widest text-foreground-dim mb-1">Access Method</div>
                        <div className="text-[10px] font-mono font-bold text-accent">
                          {isVpsOrDedicated(service) ? 'SSH / Root Access' : 'Pterodactyl Panel'}
                        </div>
                      </div>
                      <div>
                        <div className="text-[9px] font-black uppercase tracking-widest text-foreground-dim mb-1">Port / Allocation</div>
                        <div className="text-[10px] font-mono text-foreground font-bold">
                          {service.port || (isVpsOrDedicated(service) ? (service.sshPort || '22') : 'Assigned')}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center gap-3 px-6 border-l border-amber-500/20 hidden xl:flex">
                      <RotateCw size={14} className="text-amber-400 animate-spin" />
                      <div>
                        <div className="text-[9px] font-black uppercase tracking-widest text-amber-400">Payment Verification</div>
                        <div className="text-[10px] font-mono text-foreground-dim">ETA: 2-4 Hours</div>
                      </div>
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex items-center gap-2 pt-4 lg:pt-0 border-t lg:border-t-0 border-border">
                    {isActive && !isVpsOrDedicated(service) && (
                      <a 
                        href={service.panelLink || 'https://gp.hector.host'}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="hidden sm:inline-flex items-center gap-1.5 px-4 py-3 bg-bg border border-border rounded-xl text-[10px] font-black uppercase tracking-widest text-foreground-dim hover:text-accent hover:border-accent/40 transition-all"
                        title="Open Control Panel"
                      >
                        <ExternalLink size={13} /> Panel
                      </a>
                    )}
                    <button 
                      onClick={() => {
                        setSelectedService(service);
                        setIsModalOpen(true);
                        setShowPassword(false);
                      }}
                      className={`flex-1 lg:flex-none px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-md ${
                        isActive 
                          ? 'bg-accent/10 border border-accent/20 text-accent hover:bg-accent hover:text-white'
                          : 'bg-amber-500/10 border border-amber-500/30 text-amber-300 hover:bg-amber-500/20'
                      }`}
                    >
                      {isActive ? 'Manage & Credentials' : 'View Order Details'}
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })
        ) : (
          <div className="p-20 text-center bg-bg-alt border border-dashed border-border rounded-2xl">
            <div className="w-20 h-20 bg-bg border border-border rounded-full flex items-center justify-center mx-auto mb-6 text-foreground-dim">
              <Box size={40} />
            </div>
            <h3 className="text-[14px] font-black uppercase tracking-widest text-foreground mb-2">No Services Found</h3>
            <p className="text-[11px] font-bold uppercase tracking-widest text-foreground-dim mb-8">You haven't deployed any nodes yet. Browse our plans to get started.</p>
            <button 
              onClick={() => window.location.href = '/plans'}
              className="px-8 py-4 bg-accent hover:bg-accent-muted text-white text-[11px] font-black uppercase tracking-widest rounded-lg transition-all shadow-xl shadow-accent/20"
            >
              Explore Infrastructure
            </button>
          </div>
        )}
      </div>

      {/* --- SERVER MANAGEMENT DETAIL MODAL --- */}
      <AnimatePresence>
        {isModalOpen && selectedService && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 backdrop-blur-xl bg-black/80">
            <motion.div
              initial={{ opacity: 0, scale: 0.96, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 15 }}
              transition={{ duration: 0.2 }}
              className="max-w-2xl w-full bg-[#0d081d] border border-purple-500/20 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden text-slate-100 max-h-[90vh] overflow-y-auto custom-scrollbar"
            >
              {/* Decorative Glow */}
              <div className="absolute -top-24 -left-24 w-60 h-60 bg-accent/20 rounded-full blur-3xl pointer-events-none" />
              <div className="absolute -bottom-24 -right-24 w-60 h-60 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

              {/* Modal Header */}
              <div className="flex items-start justify-between pb-6 border-b border-border/80 relative z-10">
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-2xl bg-bg border flex items-center justify-center shrink-0 ${
                    selectedService.status === 'active' 
                      ? 'border-accent/30 text-accent bg-accent/10 shadow-lg shadow-accent/10' 
                      : 'border-amber-500/30 text-amber-400 bg-amber-500/10'
                  }`}>
                    {isVpsOrDedicated(selectedService) ? <Terminal size={24} /> : <Server size={24} />}
                  </div>
                  <div>
                    <div className="flex items-center gap-2.5 mb-1">
                      <h3 className="text-base font-black text-white tracking-tight">{selectedService.name}</h3>
                      <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-widest ${
                        selectedService.status === 'active'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : 'bg-amber-500/10 text-amber-400 border border-amber-500/20 animate-pulse'
                      }`}>
                        {selectedService.status === 'active' ? 'Active • Operational' : 'Payment Verification Pending'}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-foreground-dim font-mono">
                      <span>Server ID: <strong className="text-accent">{selectedService.serverId || selectedService.id.substring(0, 12)}</strong></span>
                      <span>•</span>
                      <span>{selectedService.category || 'Hosting Node'}</span>
                    </div>
                  </div>
                </div>

                <button 
                  onClick={() => setIsModalOpen(false)}
                  className="p-2 hover:bg-bg-alt rounded-xl text-foreground-dim hover:text-white transition-colors border border-transparent hover:border-border"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Body Content */}
              <div className="py-6 space-y-6 relative z-10">
                
                {/* Infrastructure Metadata Bar */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 bg-bg/60 border border-border/80 rounded-2xl text-xs">
                  <div>
                    <span className="text-[9px] font-bold uppercase tracking-widest text-foreground-dim block mb-0.5">Datacenter Region</span>
                    <span className="font-semibold text-white truncate block">{selectedService.location || 'India (Mumbai)'}</span>
                  </div>
                  <div>
                    <span className="text-[9px] font-bold uppercase tracking-widest text-foreground-dim block mb-0.5">Assigned Node</span>
                    <span className="font-semibold text-white truncate block">{selectedService.nodeName || 'Ryzen-EPYC-01'}</span>
                  </div>
                  <div>
                    <span className="text-[9px] font-bold uppercase tracking-widest text-foreground-dim block mb-0.5">Access Type</span>
                    <span className="font-semibold text-accent truncate block">
                      {isVpsOrDedicated(selectedService) ? 'SSH Root Terminal' : 'Pterodactyl Control Panel'}
                    </span>
                  </div>
                  <div>
                    <span className="text-[9px] font-bold uppercase tracking-widest text-foreground-dim block mb-0.5">Public IP</span>
                    <span className="font-mono font-bold text-emerald-400 truncate block">
                      {selectedService.status === 'active' ? (selectedService.ip || '103.195.xx.xx') : 'Allocating...'}
                    </span>
                  </div>
                </div>

                {/* Conditional View: Pending Verification vs Active Console */}
                {selectedService.status !== 'active' ? (
                  /* --- PENDING VERIFICATION PIPELINE --- */
                  <div className="p-6 bg-amber-950/20 border border-amber-500/20 rounded-2xl space-y-6">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
                        <RotateCw size={20} className="animate-spin" />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-white">Payment Verification in Progress</h4>
                        <p className="text-xs text-amber-300/80">Estimated Processing Time: <strong>2 - 4 Hours</strong></p>
                      </div>
                    </div>

                    {/* Order Dispatch Pipeline Steps */}
                    <div className="space-y-3 pt-2">
                      <div className="text-[10px] font-bold uppercase tracking-widest text-foreground-dim">Dispatch Status Pipeline</div>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
                        <div className="p-3 bg-bg/80 border border-emerald-500/30 rounded-xl text-center space-y-1">
                          <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                            <Check size={12} />
                          </div>
                          <span className="text-[10px] font-bold text-white block">Order Placed</span>
                          <span className="text-[9px] text-emerald-400 block font-mono">Completed</span>
                        </div>

                        <div className="p-3 bg-bg/80 border border-emerald-500/30 rounded-xl text-center space-y-1">
                          <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                            <Check size={12} />
                          </div>
                          <span className="text-[10px] font-bold text-white block">UPI Logged</span>
                          <span className="text-[9px] text-emerald-400 block font-mono">Confirmed</span>
                        </div>

                        <div className="p-3 bg-amber-500/10 border border-amber-500/40 rounded-xl text-center space-y-1 ring-2 ring-amber-500/20">
                          <div className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto animate-pulse">
                            <RotateCw size={12} className="animate-spin" />
                          </div>
                          <span className="text-[10px] font-bold text-amber-300 block">Bank Verification</span>
                          <span className="text-[9px] text-amber-400 block font-mono">2-4 Hours</span>
                        </div>

                        <div className="p-3 bg-bg/40 border border-border/50 rounded-xl text-center space-y-1 opacity-60">
                          <div className="w-5 h-5 rounded-full bg-bg border border-border text-foreground-dim flex items-center justify-center mx-auto">
                            <Server size={10} />
                          </div>
                          <span className="text-[10px] font-bold text-foreground-dim block">Instant Provision</span>
                          <span className="text-[9px] text-foreground-dim block font-mono">Pending</span>
                        </div>
                      </div>
                    </div>

                    <p className="text-xs text-foreground-dim leading-relaxed bg-bg/40 p-4 rounded-xl border border-border/50">
                      Your payment confirmation has been transmitted to our NOC team. Server credentials, IP allocations, and control panel credentials will unlock automatically as soon as verification completes.
                    </p>
                  </div>
                ) : (
                  /* --- ACTIVE INSTANCE CREDENTIALS CONSOLE --- */
                  <div className="space-y-5">
                    {!isVpsOrDedicated(selectedService) ? (
                      /* --- GAME / BOT / WEB HOSTING PANEL CREDENTIALS --- */
                      <div className="space-y-4">
                        {/* Primary Control Panel Launcher */}
                        <div className="p-5 bg-gradient-to-r from-accent/20 via-purple-900/10 to-bg-alt border border-accent/30 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <Shield size={16} className="text-accent" />
                              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Pterodactyl Control Panel</h4>
                            </div>
                            <p className="text-[11px] text-foreground-dim">Manage console logs, mods, files, SFTP, and instance power states.</p>
                          </div>

                          <a
                            href={selectedService.panelLink || 'https://gp.hector.host'}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-5 py-3 bg-accent hover:bg-accent-muted text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-all shadow-lg shadow-accent/20 flex items-center justify-center gap-2 shrink-0"
                          >
                            Launch Panel <ExternalLink size={14} />
                          </a>
                        </div>

                        {/* Credentials Fields Grid */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          {/* Server ID */}
                          <div className="p-3.5 bg-bg/80 border border-border/80 rounded-xl space-y-1">
                            <div className="flex justify-between items-center text-[10px] text-foreground-dim font-bold uppercase tracking-wider">
                              <span>Assigned Server ID / UUID</span>
                              <span className="text-emerald-400 font-mono">Active</span>
                            </div>
                            <div className="flex items-center justify-between gap-2 font-mono text-xs text-purple-300 font-bold">
                              <span className="truncate">{selectedService.serverId || selectedService.id}</span>
                              <button
                                onClick={() => handleCopy(selectedService.serverId || selectedService.id, 'uuid')}
                                className="p-1 hover:bg-bg-alt rounded text-foreground-dim hover:text-white transition-colors"
                                title="Copy Server ID"
                              >
                                {copiedField === 'uuid' ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                              </button>
                            </div>
                          </div>

                          {/* Control Panel URL */}
                          <div className="p-3.5 bg-bg/80 border border-border/80 rounded-xl space-y-1">
                            <div className="flex justify-between items-center text-[10px] text-foreground-dim font-bold uppercase tracking-wider">
                              <span>Control Panel URL</span>
                              <span className="text-accent font-mono">Pterodactyl</span>
                            </div>
                            <div className="flex items-center justify-between gap-2 font-mono text-xs text-white">
                              <span className="truncate">{selectedService.panelLink || 'https://gp.hector.host'}</span>
                              <div className="flex items-center gap-1">
                                <a
                                  href={selectedService.panelLink || 'https://gp.hector.host'}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="p-1 hover:bg-bg-alt rounded text-accent hover:text-accent-muted transition-colors"
                                  title="Open Panel"
                                >
                                  <ExternalLink size={14} />
                                </a>
                                <button
                                  onClick={() => handleCopy(selectedService.panelLink || 'https://gp.hector.host', 'panelUrl')}
                                  className="p-1 hover:bg-bg-alt rounded text-foreground-dim hover:text-white transition-colors"
                                  title="Copy URL"
                                >
                                  {copiedField === 'panelUrl' ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                                </button>
                              </div>
                            </div>
                          </div>

                          {/* Account Login Email */}
                          <div className="p-3.5 bg-bg/80 border border-border/80 rounded-xl space-y-1">
                            <div className="flex justify-between items-center text-[10px] text-foreground-dim font-bold uppercase tracking-wider">
                              <span>Panel Account Email</span>
                              <span className="text-blue-400 font-mono text-[9px]">Linked Account Email</span>
                            </div>
                            <div className="flex items-center justify-between gap-2 font-mono text-xs text-white">
                              <span className="truncate">{selectedService.panelEmail || user?.email || 'Registered Account Email'}</span>
                              <button
                                onClick={() => handleCopy(selectedService.panelEmail || user?.email || '', 'panelEmail')}
                                className="p-1 hover:bg-bg-alt rounded text-foreground-dim hover:text-white transition-colors"
                                title="Copy Email"
                              >
                                {copiedField === 'panelEmail' ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                              </button>
                            </div>
                          </div>

                          {/* Password Management Card */}
                          <div className="p-3.5 bg-bg/80 border border-border/80 rounded-xl flex items-center justify-between">
                            <div>
                              <div className="text-[10px] text-foreground-dim font-bold uppercase tracking-wider">Panel Password</div>
                              <div className="text-[11px] font-medium text-slate-300">Same as Account Password</div>
                            </div>
                            <button
                              type="button"
                              onClick={() => {
                                setIsChangingPassword(!isChangingPassword);
                                setPasswordError(null);
                                setPasswordSuccess(null);
                              }}
                              className="px-3 py-1.5 bg-accent/20 hover:bg-accent text-accent hover:text-white border border-accent/30 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 shrink-0"
                            >
                              <KeyRound size={13} />
                              <span>{isChangingPassword ? 'Cancel' : 'Change Password'}</span>
                            </button>
                          </div>
                        </div>

                        {/* Interactive Password Change Form for Panel */}
                        <AnimatePresence>
                          {isChangingPassword && (
                            <motion.form 
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: 'auto' }}
                              exit={{ opacity: 0, height: 0 }}
                              onSubmit={handleUpdateServicePassword} 
                              className="p-4 bg-bg border border-accent/30 rounded-2xl space-y-3"
                            >
                              <div className="flex items-center gap-2 pb-2 border-b border-border">
                                <KeyRound size={16} className="text-accent" />
                                <h5 className="text-xs font-bold text-white uppercase tracking-wider">Update Panel Password</h5>
                              </div>

                              {passwordSuccess && (
                                <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-lg text-emerald-400 text-xs font-bold flex items-center gap-2">
                                  <CheckCircle2 size={15} /> {passwordSuccess}
                                </div>
                              )}

                              {passwordError && (
                                <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-lg text-rose-400 text-xs font-bold flex items-center gap-2">
                                  <AlertCircle size={15} /> {passwordError}
                                </div>
                              )}

                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                                <div>
                                  <label className="block text-[10px] font-bold text-foreground-dim uppercase mb-1">New Password</label>
                                  <input
                                    type="text"
                                    required
                                    value={newPassword}
                                    onChange={(e) => setNewPassword(e.target.value)}
                                    placeholder="Enter new password"
                                    className="w-full px-3 py-2 bg-bg-alt border border-border focus:border-accent rounded-lg font-mono text-xs text-white outline-none"
                                  />
                                </div>
                                <div>
                                  <label className="block text-[10px] font-bold text-foreground-dim uppercase mb-1">Confirm New Password</label>
                                  <input
                                    type="text"
                                    required
                                    value={confirmNewPassword}
                                    onChange={(e) => setConfirmNewPassword(e.target.value)}
                                    placeholder="Confirm new password"
                                    className="w-full px-3 py-2 bg-bg-alt border border-border focus:border-accent rounded-lg font-mono text-xs text-white outline-none"
                                  />
                                </div>
                              </div>

                              <div className="flex items-center justify-end gap-2 pt-2">
                                <button
                                  type="button"
                                  onClick={() => setIsChangingPassword(false)}
                                  className="px-4 py-2 bg-bg-alt text-foreground-dim hover:text-white rounded-lg text-xs font-bold"
                                >
                                  Cancel
                                </button>
                                <button
                                  type="submit"
                                  disabled={passwordLoading}
                                  className="px-5 py-2 bg-accent hover:bg-accent-muted text-white rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-2 disabled:opacity-50"
                                >
                                  {passwordLoading ? <RefreshCw size={14} className="animate-spin" /> : <Check size={14} />}
                                  <span>Save New Password</span>
                                </button>
                              </div>
                            </motion.form>
                          )}
                        </AnimatePresence>
                      </div>
                    ) : (
                      /* --- VPS / DEDICATED SERVERS (SSH / ROOT ACCESS) --- */
                      <div className="space-y-4">
                        {/* SSH Command Quick Launcher */}
                        <div className="p-4 bg-bg border border-border rounded-xl space-y-2">
                          <div className="flex justify-between items-center text-[10px] text-foreground-dim font-bold uppercase tracking-wider">
                            <span className="flex items-center gap-1.5"><Terminal size={12} className="text-accent" /> Quick SSH Terminal Command</span>
                            <span className="text-emerald-400 font-mono">Root Access</span>
                          </div>
                          <div className="flex items-center justify-between gap-3 p-3 bg-bg-alt border border-border/80 rounded-lg font-mono text-xs">
                            <span className="text-emerald-400 font-bold truncate">
                              ssh {selectedService.sshUsername || 'root'}@{selectedService.ip || '127.0.0.1'} -p {selectedService.sshPort || '22'}
                            </span>
                            <button
                              onClick={() => handleCopy(`ssh ${selectedService.sshUsername || 'root'}@${selectedService.ip || '127.0.0.1'} -p ${selectedService.sshPort || '22'}`, 'sshCmd')}
                              className="px-3 py-1.5 bg-accent/10 border border-accent/20 hover:bg-accent text-accent hover:text-white rounded-md text-[10px] font-bold uppercase tracking-wider transition-all shrink-0 flex items-center gap-1.5"
                            >
                              {copiedField === 'sshCmd' ? <Check size={12} /> : <Copy size={12} />}
                              {copiedField === 'sshCmd' ? 'Copied' : 'Copy'}
                            </button>
                          </div>
                        </div>

                        {/* Network & Root Password Grid */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div className="p-3.5 bg-bg/80 border border-border/80 rounded-xl space-y-1">
                            <span className="text-[10px] text-foreground-dim font-bold uppercase tracking-wider block">Server Public IP</span>
                            <div className="flex items-center justify-between font-mono text-xs text-white">
                              <span className="truncate">{selectedService.ip || 'Pending Allocation'}</span>
                              <button onClick={() => handleCopy(selectedService.ip || '', 'vpsIp')} className="p-1 hover:bg-bg-alt rounded text-foreground-dim hover:text-white">
                                {copiedField === 'vpsIp' ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                              </button>
                            </div>
                          </div>

                          <div className="p-3.5 bg-bg/80 border border-border/80 rounded-xl space-y-1">
                            <span className="text-[10px] text-foreground-dim font-bold uppercase tracking-wider block">SSH Port</span>
                            <div className="flex items-center justify-between font-mono text-xs text-white">
                              <span>{selectedService.sshPort || '22'}</span>
                              <button onClick={() => handleCopy(String(selectedService.sshPort || '22'), 'sshPort')} className="p-1 hover:bg-bg-alt rounded text-foreground-dim hover:text-white">
                                {copiedField === 'sshPort' ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                              </button>
                            </div>
                          </div>

                          <div className="p-3.5 bg-bg/80 border border-border/80 rounded-xl space-y-1">
                            <span className="text-[10px] text-foreground-dim font-bold uppercase tracking-wider block">SSH User</span>
                            <div className="flex items-center justify-between font-mono text-xs text-white">
                              <span>{selectedService.sshUsername || 'root'}</span>
                              <button onClick={() => handleCopy(selectedService.sshUsername || 'root', 'sshUser')} className="p-1 hover:bg-bg-alt rounded text-foreground-dim hover:text-white">
                                {copiedField === 'sshUser' ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                              </button>
                            </div>
                          </div>

                          {/* Root Password */}
                          <div className="p-3.5 bg-bg/80 border border-border/80 rounded-xl space-y-1">
                            <div className="flex justify-between items-center text-[10px] text-foreground-dim font-bold uppercase tracking-wider">
                              <span>Root Password</span>
                              <button
                                onClick={() => {
                                  setIsChangingPassword(!isChangingPassword);
                                  setPasswordError(null);
                                  setPasswordSuccess(null);
                                }}
                                className="text-[10px] text-accent hover:underline font-bold"
                              >
                                {isChangingPassword ? 'Cancel' : 'Change Password'}
                              </button>
                            </div>
                            <div className="flex items-center justify-between font-mono text-xs text-purple-300 font-bold">
                              <input
                                type={showPassword ? 'text' : 'password'}
                                value={selectedService.rootPassword || selectedService.panelPassword || '••••••••••••'}
                                readOnly
                                className="bg-transparent border-0 outline-none w-28 truncate font-mono text-purple-300 p-0"
                              />
                              <div className="flex items-center gap-1">
                                <button onClick={() => setShowPassword(!showPassword)} className="p-1 hover:bg-bg-alt rounded text-foreground-dim hover:text-white">
                                  {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                                </button>
                                <button onClick={() => handleCopy(selectedService.rootPassword || selectedService.panelPassword || '', 'rootPass')} className="p-1 hover:bg-bg-alt rounded text-foreground-dim hover:text-white">
                                  {copiedField === 'rootPass' ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Interactive Password Change Form for VPS / Dedicated */}
                        <AnimatePresence>
                          {isChangingPassword && (
                            <motion.form 
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: 'auto' }}
                              exit={{ opacity: 0, height: 0 }}
                              onSubmit={handleUpdateServicePassword} 
                              className="p-4 bg-bg border border-accent/30 rounded-2xl space-y-3"
                            >
                              <div className="flex items-center gap-2 pb-2 border-b border-border">
                                <KeyRound size={16} className="text-accent" />
                                <h5 className="text-xs font-bold text-white uppercase tracking-wider">Update Server Root Password</h5>
                              </div>

                              {passwordSuccess && (
                                <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-lg text-emerald-400 text-xs font-bold flex items-center gap-2">
                                  <CheckCircle2 size={15} /> {passwordSuccess}
                                </div>
                              )}

                              {passwordError && (
                                <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-lg text-rose-400 text-xs font-bold flex items-center gap-2">
                                  <AlertCircle size={15} /> {passwordError}
                                </div>
                              )}

                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                                <div>
                                  <label className="block text-[10px] font-bold text-foreground-dim uppercase mb-1">New Root Password</label>
                                  <input
                                    type="text"
                                    required
                                    value={newPassword}
                                    onChange={(e) => setNewPassword(e.target.value)}
                                    placeholder="Enter new root password"
                                    className="w-full px-3 py-2 bg-bg-alt border border-border focus:border-accent rounded-lg font-mono text-xs text-white outline-none"
                                  />
                                </div>
                                <div>
                                  <label className="block text-[10px] font-bold text-foreground-dim uppercase mb-1">Confirm New Password</label>
                                  <input
                                    type="text"
                                    required
                                    value={confirmNewPassword}
                                    onChange={(e) => setConfirmNewPassword(e.target.value)}
                                    placeholder="Confirm new root password"
                                    className="w-full px-3 py-2 bg-bg-alt border border-border focus:border-accent rounded-lg font-mono text-xs text-white outline-none"
                                  />
                                </div>
                              </div>

                              <div className="flex items-center justify-end gap-2 pt-2">
                                <button
                                  type="button"
                                  onClick={() => setIsChangingPassword(false)}
                                  className="px-4 py-2 bg-bg-alt text-foreground-dim hover:text-white rounded-lg text-xs font-bold"
                                >
                                  Cancel
                                </button>
                                <button
                                  type="submit"
                                  disabled={passwordLoading}
                                  className="px-5 py-2 bg-accent hover:bg-accent-muted text-white rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-2 disabled:opacity-50"
                                >
                                  {passwordLoading ? <RefreshCw size={14} className="animate-spin" /> : <Check size={14} />}
                                  <span>Save Root Password</span>
                                </button>
                              </div>
                            </motion.form>
                          )}
                        </AnimatePresence>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Modal Footer */}
              <div className="pt-4 border-t border-border/80 flex items-center justify-between gap-3 relative z-10 text-xs">
                <span className="text-foreground-dim text-[11px]">
                  {selectedService.status === 'active' ? 'Enterprise Node SLA Active' : 'Dispatch Queue Active'}
                </span>

                <button
                  onClick={() => setIsModalOpen(false)}
                  className="px-6 py-2.5 bg-bg-alt hover:bg-bg border border-border hover:border-accent/40 text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-all"
                >
                  Close Console
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
