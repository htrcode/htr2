import React, { useState } from 'react';
import { 
  User, 
  Shield, 
  Key, 
  Smartphone, 
  Save, 
  UserX, 
  Server, 
  CheckCircle2, 
  AlertCircle, 
  Eye, 
  EyeOff, 
  Mail, 
  RefreshCw,
  Lock,
  ChevronUp,
  ChevronDown
} from 'lucide-react';
import { pterodactylService } from '../../services/pterodactylService';
import { authService } from '../../services/authService';

interface SettingsProps {
  user: any;
}

export const Settings: React.FC<SettingsProps> = ({ user }) => {
  // Profile State
  const [displayName, setDisplayName] = useState(user?.displayName || '');
  const [email] = useState(user?.email || '');
  const [profileLoading, setProfileLoading] = useState(false);
  const [profileMsg, setProfileMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Password Change State
  const [isChangingPass, setIsChangingPass] = useState(false);
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [showCurrentPass, setShowCurrentPass] = useState(false);
  const [showNewPass, setShowNewPass] = useState(false);
  const [passLoading, setPassLoading] = useState(false);
  const [passMsg, setPassMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Pterodactyl Game Panel Password State
  const [pteroPass, setPteroPass] = useState('');
  const [pteroLoading, setPteroLoading] = useState(false);
  const [pteroMsg, setPteroMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const isGoogleUser = user?.providerData?.some((p: any) => p.providerId === 'google.com');

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!displayName.trim()) {
      setProfileMsg({ type: 'error', text: 'Please enter a valid display name.' });
      return;
    }
    setProfileLoading(true);
    setProfileMsg(null);
    try {
      await authService.updateDisplayName(displayName.trim());
      setProfileMsg({ type: 'success', text: 'Display name updated successfully.' });
    } catch (err: any) {
      setProfileMsg({ type: 'error', text: err.message || 'Failed to update profile.' });
    } finally {
      setProfileLoading(false);
    }
  };

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassMsg(null);

    if (!newPass || newPass.length < 6) {
      setPassMsg({ type: 'error', text: 'New password must be at least 6 characters long.' });
      return;
    }

    if (newPass !== confirmPass) {
      setPassMsg({ type: 'error', text: 'New passwords do not match. Please verify and retry.' });
      return;
    }

    setPassLoading(true);
    try {
      const res = await authService.changePassword(currentPass, newPass);
      setPassMsg({ type: 'success', text: res.message || 'Password successfully updated!' });
      setCurrentPass('');
      setNewPass('');
      setConfirmPass('');
      setTimeout(() => {
        setIsChangingPass(false);
      }, 2500);
    } catch (err: any) {
      setPassMsg({ type: 'error', text: err.message || 'Failed to update password.' });
    } finally {
      setPassLoading(false);
    }
  };

  const handleSendResetEmail = async () => {
    setPassLoading(true);
    setPassMsg(null);
    try {
      await authService.sendPasswordResetForCurrentUser();
      setPassMsg({ 
        type: 'success', 
        text: `Password reset email sent to ${user?.email || 'your address'}. Please check your inbox or spam folder.` 
      });
    } catch (err: any) {
      setPassMsg({ type: 'error', text: err.message || 'Failed to send password reset email.' });
    } finally {
      setPassLoading(false);
    }
  };

  const handleUpdatePteroPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pteroPass || pteroPass.length < 8) {
      setPteroMsg({ type: 'error', text: 'Password must be at least 8 characters long for Pterodactyl Panel.' });
      return;
    }
    setPteroLoading(true);
    setPteroMsg(null);
    try {
      const res = await pterodactylService.createOrLinkUser({
        email: user.email,
        name: user.displayName || user.email?.split('@')[0] || 'User',
        password: pteroPass,
        firebaseUid: user.uid
      });
      if (res.success) {
        setPteroMsg({ type: 'success', text: 'Pterodactyl Game Panel password updated successfully!' });
        setPteroPass('');
      } else {
        throw new Error(res.error || 'Failed to update panel password');
      }
    } catch (err: any) {
      setPteroMsg({ type: 'error', text: err.message || 'Error updating password' });
    } finally {
      setPteroLoading(false);
    }
  };

  return (
    <div className="max-w-4xl space-y-8">
      {/* Profile Section */}
      <section className="space-y-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-accent/10 rounded-lg text-accent">
            <User size={18} />
          </div>
          <div>
            <h3 className="text-[12px] font-black uppercase tracking-[0.2em] text-foreground">Profile Information</h3>
            <p className="text-[11px] text-foreground-dim font-medium">Manage your personal identification details.</p>
          </div>
        </div>

        <form onSubmit={handleUpdateProfile} className="p-8 bg-bg-alt border border-border rounded-2xl space-y-6">
          {profileMsg && (
            <div className={`p-4 rounded-xl text-xs font-bold flex items-center gap-3 ${
              profileMsg.type === 'success' 
                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
            }`}>
              {profileMsg.type === 'success' ? <CheckCircle2 size={16} /> : <AlertCircle size={16} />}
              {profileMsg.text}
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-foreground-dim">Full Name</label>
              <input 
                type="text" 
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="Enter your full name"
                className="w-full px-4 py-3 bg-bg border border-border rounded-lg text-[11px] font-bold text-foreground focus:border-accent outline-none transition-all"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-foreground-dim">Email Address</label>
              <input 
                type="email" 
                value={email}
                disabled
                className="w-full px-4 py-3 bg-bg border border-border rounded-lg text-[11px] font-bold text-foreground-muted cursor-not-allowed opacity-80"
              />
              <span className="text-[9px] text-foreground-dim font-medium">Email address is permanently bound to this account.</span>
            </div>
          </div>

          <div className="pt-2 flex items-center justify-between">
            <button 
              type="submit"
              disabled={profileLoading}
              className="px-8 py-3 bg-accent hover:bg-accent-muted text-white text-[10px] font-black uppercase tracking-widest rounded-lg transition-all flex items-center gap-2 shadow-lg shadow-accent/20 disabled:opacity-50"
            >
              {profileLoading ? <RefreshCw size={14} className="animate-spin" /> : <Save size={14} />}
              {profileLoading ? 'Saving...' : 'Save Profile Changes'}
            </button>

            {isGoogleUser && (
              <span className="text-[10px] font-bold uppercase tracking-widest text-foreground-dim flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-blue-500 inline-block" />
                Google Single Sign-On Active
              </span>
            )}
          </div>
        </form>
      </section>

      {/* Security Section */}
      <section className="space-y-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-emerald-400/10 rounded-lg text-emerald-400">
            <Shield size={18} />
          </div>
          <div>
            <h3 className="text-[12px] font-black uppercase tracking-[0.2em] text-foreground">Security & Authentication</h3>
            <p className="text-[11px] text-foreground-dim font-medium">Manage your portal password and secure access credentials.</p>
          </div>
        </div>

        <div className="space-y-4">
          {/* Main Account Password Card */}
          <div className="bg-bg-alt border border-border rounded-2xl overflow-hidden transition-all">
            <div className="p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-bg border border-border rounded-xl text-accent">
                  <Key size={20} />
                </div>
                <div>
                  <div className="text-[11px] font-black uppercase tracking-widest text-foreground mb-1 flex items-center gap-2">
                    Client Portal Password
                    <span className="px-2 py-0.5 rounded text-[8px] font-black uppercase bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      Active
                    </span>
                  </div>
                  <div className="text-[10px] font-bold uppercase tracking-widest text-foreground-dim">
                    {isGoogleUser 
                      ? 'Connected via Google SSO (Set password for direct login)' 
                      : 'Used to access client billing, support, and infrastructure'}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button 
                  type="button"
                  onClick={() => {
                    setIsChangingPass(!isChangingPass);
                    setPassMsg(null);
                  }}
                  className="px-6 py-2.5 bg-bg border border-border hover:border-accent/40 rounded-lg text-[10px] font-black uppercase tracking-widest text-foreground hover:text-accent transition-all flex items-center gap-2"
                >
                  {isChangingPass ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                  {isChangingPass ? 'Close' : 'Change Password'}
                </button>
              </div>
            </div>

            {/* Change Password Form (Collapsible) */}
            {isChangingPass && (
              <div className="p-6 border-t border-border bg-bg/50">
                <form onSubmit={handleUpdatePassword} className="space-y-5 max-w-xl">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black uppercase tracking-widest text-foreground">
                      Update Your Credentials
                    </span>
                    <button
                      type="button"
                      onClick={handleSendResetEmail}
                      disabled={passLoading}
                      className="text-[10px] font-bold text-accent hover:underline flex items-center gap-1.5"
                    >
                      <Mail size={12} />
                      Forgot password? Send reset email
                    </button>
                  </div>

                  {passMsg && (
                    <div className={`p-4 rounded-xl text-xs font-bold flex items-center gap-3 ${
                      passMsg.type === 'success' 
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                        : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                    }`}>
                      {passMsg.type === 'success' ? <CheckCircle2 size={16} /> : <AlertCircle size={16} />}
                      {passMsg.text}
                    </div>
                  )}

                  {!isGoogleUser && (
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black uppercase tracking-widest text-foreground-dim">
                        Current Password
                      </label>
                      <div className="relative">
                        <input 
                          type={showCurrentPass ? "text" : "password"}
                          value={currentPass}
                          onChange={(e) => setCurrentPass(e.target.value)}
                          placeholder="Enter current password"
                          className="w-full px-4 py-3 bg-bg border border-border rounded-lg text-[11px] font-bold text-foreground focus:border-accent outline-none pr-10"
                        />
                        <button
                          type="button"
                          onClick={() => setShowCurrentPass(!showCurrentPass)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-foreground-dim hover:text-foreground"
                        >
                          {showCurrentPass ? <EyeOff size={16} /> : <Eye size={16} />}
                        </button>
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black uppercase tracking-widest text-foreground-dim">
                        New Password
                      </label>
                      <div className="relative">
                        <input 
                          type={showNewPass ? "text" : "password"}
                          value={newPass}
                          onChange={(e) => setNewPass(e.target.value)}
                          placeholder="At least 6 characters"
                          className="w-full px-4 py-3 bg-bg border border-border rounded-lg text-[11px] font-bold text-foreground focus:border-accent outline-none pr-10"
                        />
                        <button
                          type="button"
                          onClick={() => setShowNewPass(!showNewPass)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-foreground-dim hover:text-foreground"
                        >
                          {showNewPass ? <EyeOff size={16} /> : <Eye size={16} />}
                        </button>
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black uppercase tracking-widest text-foreground-dim">
                        Confirm New Password
                      </label>
                      <input 
                        type="password"
                        value={confirmPass}
                        onChange={(e) => setConfirmPass(e.target.value)}
                        placeholder="Re-type new password"
                        className="w-full px-4 py-3 bg-bg border border-border rounded-lg text-[11px] font-bold text-foreground focus:border-accent outline-none"
                      />
                    </div>
                  </div>

                  <div className="flex items-center gap-3 pt-2">
                    <button
                      type="submit"
                      disabled={passLoading || !newPass}
                      className="px-6 py-2.5 bg-accent hover:bg-accent-muted text-white text-[10px] font-black uppercase tracking-widest rounded-lg transition-all flex items-center gap-2 disabled:opacity-50 shadow-md shadow-accent/20"
                    >
                      {passLoading ? <RefreshCw size={14} className="animate-spin" /> : <Lock size={14} />}
                      {passLoading ? 'Updating Password...' : 'Save New Password'}
                    </button>

                    <button
                      type="button"
                      onClick={() => setIsChangingPass(false)}
                      className="px-6 py-2.5 border border-border hover:bg-bg rounded-lg text-[10px] font-black uppercase tracking-widest text-foreground-dim hover:text-foreground transition-all"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              </div>
            )}
          </div>

          {/* Pterodactyl Game Server Panel Password */}
          <div className="p-6 bg-bg-alt border border-border rounded-2xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-bg border border-border rounded-xl text-accent">
                  <Server size={20} />
                </div>
                <div>
                  <div className="text-[11px] font-black uppercase tracking-widest text-foreground mb-1">
                    Game Control Panel Password (Pterodactyl)
                  </div>
                  <div className="text-[10px] font-bold uppercase tracking-widest text-foreground-dim">
                    Direct credentials to access https://gp.hector.host game console
                  </div>
                </div>
              </div>
            </div>

            <form onSubmit={handleUpdatePteroPassword} className="space-y-4 pt-2">
              {pteroMsg && (
                <div className={`p-4 rounded-xl text-xs font-bold flex items-center gap-3 ${
                  pteroMsg.type === 'success' 
                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                    : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                }`}>
                  {pteroMsg.type === 'success' ? <CheckCircle2 size={16} /> : <AlertCircle size={16} />}
                  {pteroMsg.text}
                </div>
              )}

              <div className="flex flex-col sm:flex-row items-center gap-3">
                <input 
                  type="password"
                  value={pteroPass}
                  onChange={(e) => setPteroPass(e.target.value)}
                  placeholder="Set Game Panel Password (min 8 chars)"
                  className="w-full sm:flex-1 px-4 py-2.5 bg-bg border border-border rounded-lg text-[11px] font-bold text-foreground focus:border-accent outline-none"
                />
                <button
                  type="submit"
                  disabled={pteroLoading || !pteroPass}
                  className="w-full sm:w-auto px-6 py-2.5 bg-accent hover:bg-accent-muted text-white text-[10px] font-black uppercase tracking-widest rounded-lg transition-all flex items-center justify-center gap-2 disabled:opacity-50 shadow-md shadow-accent/20"
                >
                  {pteroLoading ? <RefreshCw size={14} className="animate-spin" /> : <Save size={14} />}
                  {pteroLoading ? 'Syncing...' : 'Update Panel Password'}
                </button>
              </div>
            </form>
          </div>

          {/* Two-Factor Authentication Info */}
          <div className="p-6 bg-bg-alt border border-border rounded-2xl flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-bg border border-border rounded-xl text-emerald-400">
                <Smartphone size={20} />
              </div>
              <div>
                <div className="text-[11px] font-black uppercase tracking-widest text-foreground mb-1">
                  Multi-Factor Authentication (MFA)
                </div>
                <div className="text-[10px] font-bold uppercase tracking-widest text-emerald-500">
                  Firebase Enterprise Authentication Protection Active
                </div>
              </div>
            </div>
            <div className="px-4 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-full text-[9px] font-black uppercase tracking-widest text-emerald-400">
              Active
            </div>
          </div>
        </div>
      </section>

      {/* Danger Zone */}
      <section className="pt-8 border-t border-border space-y-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-rose-500/10 rounded-lg text-rose-500">
            <UserX size={18} />
          </div>
          <h3 className="text-[12px] font-black uppercase tracking-[0.2em] text-foreground">Account Lifecycle</h3>
        </div>

        <div className="p-8 bg-rose-500/5 border border-rose-500/20 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div>
            <div className="text-[11px] font-black uppercase tracking-widest text-rose-500 mb-1">Sign Out Everywhere</div>
            <p className="text-[10px] font-bold uppercase tracking-widest text-foreground-dim max-w-md">
              Terminate all active sessions across desktop and mobile devices.
            </p>
          </div>
          <button 
            type="button"
            onClick={() => authService.logout()}
            className="px-8 py-3 bg-rose-500 hover:bg-rose-600 text-white text-[10px] font-black uppercase tracking-widest rounded-lg transition-all"
          >
            Sign Out
          </button>
        </div>
      </section>
    </div>
  );
};
