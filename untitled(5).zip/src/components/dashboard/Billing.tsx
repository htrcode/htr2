import React, { useState, useEffect } from 'react';
import { CreditCard, Download, FileText, ExternalLink, Calendar, CheckCircle2, Loader2, Clock, X, Printer, Receipt, ShieldCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { billingService } from '../../services/billingService';
import { Invoice } from '../../types';
import { User as FirebaseUser } from 'firebase/auth';
import { InvoiceDocumentModal } from '../InvoiceDocumentModal';
import { formatINR } from '../../utils/formatUtils';

interface BillingProps {
  user: FirebaseUser | null;
}

export const Billing: React.FC<BillingProps> = ({ user }) => {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    const fetchInvoices = async () => {
      if (user) {
        try {
          const data = await billingService.getInvoices(user.uid);
          setInvoices(data);
        } catch (error) {
          console.error("Error fetching invoices:", error);
        } finally {
          setLoading(false);
        }
      }
    };
    fetchInvoices();
  }, [user]);

  if (loading) {
    return (
      <div className="h-64 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-accent" />
      </div>
    );
  }

  const nextPayment = invoices.length > 0 ? formatINR(invoices[0].total, 2) : '₹0.00';

  return (
    <div className="space-y-8">
      {/* Billing Header */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 p-8 bg-accent rounded-2xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-12 opacity-10 group-hover:scale-110 transition-transform duration-500">
            <CreditCard size={180} />
          </div>
          <div className="relative z-10 space-y-6">
            <div className="text-[11px] font-black uppercase tracking-[0.3em] text-white/70">Default Payment Method</div>
            <div className="flex items-center gap-4">
              <div className="w-12 h-8 bg-white/20 rounded border border-white/30 flex items-center justify-center">
                <span className="text-[8px] font-black text-white italic">UPI</span>
              </div>
              <div className="text-xl font-black text-white tracking-widest uppercase">Saved UPI / QR Method</div>
            </div>
            <div className="flex gap-4">
              <button className="px-6 py-2 bg-white text-accent text-[10px] font-black uppercase tracking-widest rounded transition-all hover:bg-white/90">
                Update Method
              </button>
            </div>
          </div>
        </div>

        <div className="p-8 bg-bg-alt border border-border rounded-2xl flex flex-col justify-between">
          <div className="space-y-1">
            <div className="text-[10px] font-bold uppercase tracking-widest text-foreground-dim">Recent Invoice</div>
            <div className="text-3xl font-black text-foreground">{nextPayment}</div>
            <div className="text-[10px] font-bold uppercase tracking-widest text-emerald-500 flex items-center gap-2">
              <CheckCircle2 size={12} /> Auto-Processed
            </div>
          </div>
          <button className="w-full mt-6 py-3 border border-border rounded-lg text-[10px] font-black uppercase tracking-widest text-foreground hover:bg-bg transition-all">
            Invoices Portal
          </button>
        </div>
      </div>

      {/* Invoice History */}
      <div className="space-y-4">
        <h3 className="text-[11px] font-black uppercase tracking-[0.2em] text-foreground">Invoices</h3>
        <div className="bg-bg-alt border border-border rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left min-w-[600px]">
              <thead>
                <tr className="border-b border-border bg-bg/50">
                  <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-foreground-dim">Invoice ID</th>
                  <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-foreground-dim">Date</th>
                  <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-foreground-dim">Amount</th>
                  <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-foreground-dim">Status</th>
                  <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-foreground-dim text-right">Action</th>
                </tr>
              </thead>
               <tbody className="divide-y divide-border">
                {invoices.length > 0 ? invoices.map((inv) => (
                  <tr 
                    key={inv.id} 
                    className="hover:bg-bg/30 transition-colors cursor-pointer group"
                    onClick={() => {
                      setSelectedInvoice(inv);
                      setIsModalOpen(true);
                    }}
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <FileText size={16} className="text-foreground-dim group-hover:text-accent transition-colors" />
                        <span className="text-[11px] font-bold text-foreground group-hover:text-accent transition-colors">{inv.invoiceNumber}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-[11px] font-bold text-foreground-muted">
                      {new Date(inv.timestamp).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}
                    </td>
                    <td className="px-6 py-4 text-[11px] font-black text-foreground">{formatINR(inv.total, 2)}</td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        {inv.status === 'Paid' ? (
                          <>
                            <CheckCircle2 size={12} className="text-emerald-500" />
                            <span className="text-[9px] font-black uppercase tracking-widest text-emerald-500">{inv.status}</span>
                          </>
                        ) : (
                          <>
                            <Clock size={12} className="text-amber-500" />
                            <span className="text-[9px] font-black uppercase tracking-widest text-amber-500">Pending Verification</span>
                          </>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right" onClick={(e) => e.stopPropagation()}>
                      <button 
                        onClick={() => {
                          setSelectedInvoice(inv);
                          setIsModalOpen(true);
                        }}
                        className="p-2 hover:bg-bg rounded transition-colors text-foreground-dim hover:text-accent"
                        title="View & Download Invoice"
                      >
                        <Download size={16} />
                      </button>
                    </td>
                  </tr>
                )) : (
                  <tr>
                    <td colSpan={5} className="px-6 py-12 text-center text-[10px] font-bold uppercase tracking-widest text-foreground-dim italic">
                      No invoices found. Provision some infrastructure to get started.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* --- INVOICE VIEW & PRINT MODAL --- */}
      <InvoiceDocumentModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        invoice={selectedInvoice}
        clientEmail={user?.email || undefined}
        clientName={user?.displayName || undefined}
      />
    </div>
  );
};
