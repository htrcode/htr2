import React, { useState, useEffect, useRef } from 'react';
import { 
  LifeBuoy, 
  Plus, 
  MessageSquare, 
  Clock, 
  AlertCircle, 
  CheckCircle2, 
  ChevronRight, 
  Send, 
  ArrowLeft, 
  Filter, 
  Search, 
  ShieldCheck, 
  User, 
  Tag, 
  RefreshCw, 
  X,
  Server,
  HelpCircle,
  Lock
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { User as FirebaseUser } from 'firebase/auth';
import { Ticket, TicketMessage, TicketStatus, TicketPriority, TicketDepartment, UserService } from '../../types';
import { ticketService } from '../../services/ticketService';
import { userService } from '../../services/userService';

interface TicketsProps {
  user: FirebaseUser | null;
  services?: UserService[];
}

export const Tickets: React.FC<TicketsProps> = ({ user, services = [] }) => {
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [messages, setMessages] = useState<TicketMessage[]>([]);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [replyText, setReplyText] = useState('');
  const [isSendingReply, setIsSendingReply] = useState(false);
  const [isSubmittingTicket, setIsSubmittingTicket] = useState(false);

  // Filter and Search states
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  // New ticket form
  const [ticketForm, setTicketForm] = useState<{
    subject: string;
    department: TicketDepartment;
    priority: TicketPriority;
    serviceId: string;
    message: string;
  }>({
    subject: '',
    department: 'Technical Support',
    priority: 'medium',
    serviceId: '',
    message: ''
  });

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Real-time listener for user tickets
  useEffect(() => {
    if (!user) return;
    setLoading(true);

    const unsubscribe = ticketService.subscribeToUserTickets(user.uid, (data) => {
      setTickets(data);
      setLoading(false);
      // Update selected ticket if currently open
      if (selectedTicket) {
        const updated = data.find(t => t.id === selectedTicket.id);
        if (updated) {
          setSelectedTicket(updated);
        }
      }
    });

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [user]);

  // Real-time listener for messages when a ticket is opened
  useEffect(() => {
    if (!selectedTicket) {
      setMessages([]);
      return;
    }

    setLoadingMessages(true);
    ticketService.markTicketRead(selectedTicket.id, 'user');

    const unsubscribe = ticketService.subscribeToTicketMessages(selectedTicket.id, (msgs) => {
      setMessages(msgs);
      setLoadingMessages(false);
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    });

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [selectedTicket?.id]);

  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !ticketForm.subject.trim() || !ticketForm.message.trim()) return;

    setIsSubmittingTicket(true);
    try {
      const selectedService = services.find(s => s.id === ticketForm.serviceId);

      const ticketId = await ticketService.createTicket({
        userId: user.uid,
        userEmail: user.email || 'user@hectorhosting.com',
        userName: user.displayName || user.email?.split('@')[0] || 'Client',
        subject: ticketForm.subject.trim(),
        department: ticketForm.department,
        priority: ticketForm.priority,
        initialMessage: ticketForm.message.trim(),
        serviceId: ticketForm.serviceId || undefined,
        serviceName: selectedService?.name || undefined
      });

      // Reset form and close modal
      setTicketForm({
        subject: '',
        department: 'Technical Support',
        priority: 'medium',
        serviceId: '',
        message: ''
      });
      setIsCreateModalOpen(false);

      // Open newly created ticket
      const newTicket = await ticketService.getTicket(ticketId);
      if (newTicket) {
        setSelectedTicket(newTicket);
      }
    } catch (err: any) {
      console.error('Error creating ticket:', err);
      alert(`Failed to create ticket: ${err.message || 'Please try again'}`);
    } finally {
      setIsSubmittingTicket(false);
    }
  };

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !selectedTicket || !replyText.trim() || isSendingReply) return;

    setIsSendingReply(true);
    try {
      await ticketService.addReply(
        selectedTicket.id,
        selectedTicket.userId,
        {
          uid: user.uid,
          email: user.email || 'user@hectorhosting.com',
          name: user.displayName || user.email?.split('@')[0] || 'Client',
          role: 'user'
        },
        replyText.trim()
      );
      setReplyText('');
    } catch (err: any) {
      console.error('Error replying to ticket:', err);
      alert(`Failed to send reply: ${err.message || 'Please try again'}`);
    } finally {
      setIsSendingReply(false);
    }
  };

  const handleStatusChange = async (newStatus: TicketStatus) => {
    if (!selectedTicket) return;
    try {
      await ticketService.updateTicketStatus(selectedTicket.id, newStatus);
      setSelectedTicket(prev => prev ? { ...prev, status: newStatus } : null);
    } catch (err: any) {
      alert(`Failed to update status: ${err.message}`);
    }
  };

  const getPriorityBadge = (priority: TicketPriority) => {
    switch (priority) {
      case 'urgent':
        return <span className="px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-widest bg-red-500/10 text-red-500 border border-red-500/20">Urgent</span>;
      case 'high':
        return <span className="px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-widest bg-orange-500/10 text-orange-400 border border-orange-500/20">High</span>;
      case 'medium':
        return <span className="px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-widest bg-amber-500/10 text-amber-400 border border-amber-500/20">Medium</span>;
      case 'low':
      default:
        return <span className="px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-widest bg-sky-500/10 text-sky-400 border border-sky-500/20">Low</span>;
    }
  };

  const getStatusBadge = (status: TicketStatus) => {
    switch (status) {
      case 'open':
        return <span className="px-2.5 py-1 rounded-full text-[9px] font-black uppercase tracking-widest bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1.5"><span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> Open</span>;
      case 'in_progress':
        return <span className="px-2.5 py-1 rounded-full text-[9px] font-black uppercase tracking-widest bg-purple-500/10 text-purple-400 border border-purple-500/20 flex items-center gap-1.5"><span className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-pulse" /> In Progress</span>;
      case 'waiting_user':
        return <span className="px-2.5 py-1 rounded-full text-[9px] font-black uppercase tracking-widest bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center gap-1.5"><Clock size={10} /> Waiting on You</span>;
      case 'resolved':
        return <span className="px-2.5 py-1 rounded-full text-[9px] font-black uppercase tracking-widest bg-blue-500/10 text-blue-400 border border-blue-500/20 flex items-center gap-1.5"><CheckCircle2 size={10} /> Resolved</span>;
      case 'closed':
        return <span className="px-2.5 py-1 rounded-full text-[9px] font-black uppercase tracking-widest bg-zinc-500/10 text-zinc-400 border border-zinc-500/20 flex items-center gap-1.5"><Lock size={10} /> Closed</span>;
      default:
        return null;
    }
  };

  // Filtered tickets
  const filteredTickets = tickets.filter(t => {
    const matchesStatus = 
      statusFilter === 'ALL' ? true :
      statusFilter === 'active' ? (t.status === 'open' || t.status === 'in_progress' || t.status === 'waiting_user') :
      t.status === statusFilter;

    const matchesSearch = 
      !searchQuery.trim() ? true :
      t.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.ticketNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (t.lastMessage && t.lastMessage.toLowerCase().includes(searchQuery.toLowerCase()));

    return matchesStatus && matchesSearch;
  });

  const openTicketCount = tickets.filter(t => t.status === 'open' || t.status === 'in_progress' || t.status === 'waiting_user').length;
  const resolvedCount = tickets.filter(t => t.status === 'resolved' || t.status === 'closed').length;

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-[14px] font-black uppercase tracking-[0.2em] text-foreground">Support Tickets</h2>
            {openTicketCount > 0 && (
              <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-accent text-white uppercase tracking-widest">
                {openTicketCount} Active
              </span>
            )}
          </div>
          <p className="text-[10px] font-bold uppercase tracking-widest text-foreground-dim mt-0.5">
            24/7 Priority technical assistance and customer helpdesk
          </p>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="flex items-center justify-center gap-2 px-5 py-2.5 bg-accent hover:bg-accent-muted text-white text-[10px] font-black uppercase tracking-widest rounded-xl transition-all shadow-lg shadow-accent/20"
        >
          <Plus size={15} />
          Open New Ticket
        </button>
      </div>

      {/* Main View: Either Thread View or Ticket List */}
      {selectedTicket ? (
        /* Conversation Thread View */
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-bg-alt border border-border rounded-2xl overflow-hidden flex flex-col min-h-[600px]"
        >
          {/* Thread Header */}
          <div className="p-6 border-b border-border bg-bg/50 backdrop-blur-md flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <button 
                onClick={() => setSelectedTicket(null)}
                className="p-2.5 rounded-xl bg-bg border border-border hover:border-accent/40 text-foreground hover:text-accent transition-all"
                title="Back to Tickets list"
              >
                <ArrowLeft size={16} />
              </button>
              <div>
                <div className="flex items-center gap-3 mb-1">
                  <span className="text-[10px] font-mono font-bold text-accent px-2 py-0.5 rounded bg-accent/10 border border-accent/20">
                    #{selectedTicket.ticketNumber}
                  </span>
                  <h3 className="text-[14px] font-black text-foreground tracking-wide">{selectedTicket.subject}</h3>
                </div>
                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[10px] font-bold uppercase tracking-widest text-foreground-dim">
                  <span className="flex items-center gap-1.5 text-foreground"><Tag size={12} className="text-accent" /> {selectedTicket.department}</span>
                  {selectedTicket.serviceName && (
                    <span className="flex items-center gap-1.5"><Server size={12} /> {selectedTicket.serviceName}</span>
                  )}
                  <span>Created {new Date(selectedTicket.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              {getPriorityBadge(selectedTicket.priority)}
              {getStatusBadge(selectedTicket.status)}

              {selectedTicket.status !== 'closed' ? (
                <button
                  onClick={() => handleStatusChange('closed')}
                  className="px-3.5 py-1.5 bg-bg border border-border hover:border-rose-500/40 text-foreground-dim hover:text-rose-400 text-[9px] font-black uppercase tracking-widest rounded-lg transition-all"
                >
                  Close Ticket
                </button>
              ) : (
                <button
                  onClick={() => handleStatusChange('open')}
                  className="px-3.5 py-1.5 bg-bg border border-border hover:border-emerald-500/40 text-foreground-dim hover:text-emerald-400 text-[9px] font-black uppercase tracking-widest rounded-lg transition-all"
                >
                  Reopen Ticket
                </button>
              )}
            </div>
          </div>

          {/* Messages Area */}
          <div className="flex-1 p-6 overflow-y-auto max-h-[500px] space-y-6 custom-scrollbar bg-bg/20">
            {loadingMessages ? (
              <div className="h-48 flex items-center justify-center">
                <div className="w-8 h-8 border-2 border-accent border-t-transparent rounded-full animate-spin" />
              </div>
            ) : messages.length > 0 ? (
              messages.map((msg) => {
                const isAdmin = msg.senderRole === 'admin';
                return (
                  <motion.div
                    key={msg.id}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex gap-4 ${isAdmin ? 'bg-purple-950/20 border-purple-500/20' : 'bg-bg-alt border-border'} p-5 rounded-2xl border transition-all`}
                  >
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                      isAdmin 
                        ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30' 
                        : 'bg-bg border border-border text-foreground'
                    }`}>
                      {isAdmin ? <ShieldCheck size={20} /> : <User size={20} />}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2">
                          <span className="text-[12px] font-black tracking-wide text-foreground">
                            {isAdmin ? 'Hector Support Staff' : msg.senderName}
                          </span>
                          {isAdmin && (
                            <span className="px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-widest bg-purple-500/20 text-purple-300 border border-purple-500/30">
                              Official Staff
                            </span>
                          )}
                        </div>
                        <span className="text-[9px] font-bold text-foreground-dim tracking-wider">
                          {new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} • {new Date(msg.createdAt).toLocaleDateString()}
                        </span>
                      </div>

                      <div className="text-[12px] text-foreground-muted whitespace-pre-wrap leading-relaxed">
                        {msg.message}
                      </div>
                    </div>
                  </motion.div>
                );
              })
            ) : (
              <div className="text-center py-12 text-foreground-dim text-xs font-bold uppercase tracking-widest">
                No messages yet.
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Reply Box */}
          {selectedTicket.status !== 'closed' ? (
            <form onSubmit={handleSendReply} className="p-4 border-t border-border bg-bg/40">
              <div className="flex gap-3">
                <textarea
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
                      handleSendReply(e);
                    }
                  }}
                  placeholder="Type your response to support staff... (Ctrl+Enter to send)"
                  rows={2}
                  className="flex-1 p-3.5 bg-bg border border-border rounded-xl text-xs font-medium text-foreground focus:border-accent outline-none resize-none transition-all placeholder:text-foreground-dim"
                />
                <button
                  type="submit"
                  disabled={!replyText.trim() || isSendingReply}
                  className="px-6 bg-accent hover:bg-accent-muted disabled:opacity-50 text-white font-black text-[10px] uppercase tracking-widest rounded-xl transition-all shadow-lg shadow-accent/20 flex items-center justify-center gap-2"
                >
                  {isSendingReply ? (
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <Send size={14} />
                      Send
                    </>
                  )}
                </button>
              </div>
            </form>
          ) : (
            <div className="p-4 border-t border-border bg-bg/40 text-center">
              <p className="text-[10px] font-bold uppercase tracking-widest text-foreground-dim">
                This ticket is marked as closed. Reopen the ticket to send further messages.
              </p>
            </div>
          )}
        </motion.div>
      ) : (
        /* Ticket List and Summary */
        <>
          {/* Quick Metrics Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-5 bg-bg-alt border border-border rounded-xl flex items-center justify-between">
              <div>
                <div className="text-[9px] font-black uppercase tracking-widest text-foreground-dim mb-1">Total Tickets</div>
                <div className="text-2xl font-black text-foreground">{tickets.length}</div>
              </div>
              <div className="p-3 bg-bg rounded-xl border border-border text-accent">
                <MessageSquare size={20} />
              </div>
            </div>

            <div className="p-5 bg-bg-alt border border-border rounded-xl flex items-center justify-between">
              <div>
                <div className="text-[9px] font-black uppercase tracking-widest text-foreground-dim mb-1">Awaiting Response / Open</div>
                <div className="text-2xl font-black text-emerald-400">{openTicketCount}</div>
              </div>
              <div className="p-3 bg-bg rounded-xl border border-border text-emerald-400">
                <LifeBuoy size={20} />
              </div>
            </div>

            <div className="p-5 bg-bg-alt border border-border rounded-xl flex items-center justify-between">
              <div>
                <div className="text-[9px] font-black uppercase tracking-widest text-foreground-dim mb-1">Resolved Issues</div>
                <div className="text-2xl font-black text-sky-400">{resolvedCount}</div>
              </div>
              <div className="p-3 bg-bg rounded-xl border border-border text-sky-400">
                <CheckCircle2 size={20} />
              </div>
            </div>
          </div>

          {/* Search & Filter Bar */}
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 p-4 bg-bg-alt border border-border rounded-xl">
            <div className="relative w-full md:w-80">
              <Search size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-foreground-dim" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="SEARCH TICKET #, SUBJECT OR MESSAGE..."
                className="w-full pl-10 pr-4 py-2 bg-bg border border-border rounded-lg text-[10px] font-bold text-foreground focus:border-accent outline-none transition-all placeholder:text-foreground-dim"
              />
            </div>

            {/* Status Filter Tabs */}
            <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
              {[
                { id: 'ALL', label: 'All' },
                { id: 'active', label: 'Active' },
                { id: 'open', label: 'Open' },
                { id: 'in_progress', label: 'In Progress' },
                { id: 'resolved', label: 'Resolved' },
                { id: 'closed', label: 'Closed' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setStatusFilter(tab.id)}
                  className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${
                    statusFilter === tab.id
                      ? 'bg-accent text-white shadow-md shadow-accent/20'
                      : 'bg-bg text-foreground-dim hover:text-foreground hover:bg-bg-alt'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Ticket Cards List */}
          {loading ? (
            <div className="h-48 flex items-center justify-center bg-bg-alt border border-border rounded-xl">
              <div className="flex flex-col items-center gap-3">
                <div className="w-8 h-8 border-2 border-accent border-t-transparent rounded-full animate-spin" />
                <span className="text-[10px] font-black uppercase tracking-widest text-foreground-dim">Loading Support Records...</span>
              </div>
            </div>
          ) : filteredTickets.length > 0 ? (
            <div className="space-y-3">
              {filteredTickets.map((ticket, idx) => (
                <motion.div
                  key={ticket.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.04 }}
                  onClick={() => setSelectedTicket(ticket)}
                  className={`p-5 bg-bg-alt border ${
                    ticket.unreadByUser ? 'border-accent shadow-lg shadow-accent/5' : 'border-border'
                  } rounded-xl hover:border-accent/40 cursor-pointer transition-all group`}
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    {/* Left: Info */}
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-xl bg-bg border border-border flex items-center justify-center text-foreground-dim group-hover:text-accent transition-colors shrink-0">
                        <MessageSquare size={22} />
                      </div>

                      <div className="space-y-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-[10px] font-mono font-black text-accent bg-accent/10 px-2 py-0.5 rounded border border-accent/20">
                            #{ticket.ticketNumber}
                          </span>
                          <h3 className="text-[13px] font-black text-foreground tracking-wide group-hover:text-accent transition-colors truncate">
                            {ticket.subject}
                          </h3>
                          {ticket.unreadByUser && (
                            <span className="px-2 py-0.5 rounded-full text-[8px] font-black uppercase tracking-widest bg-accent text-white animate-pulse">
                              New Reply
                            </span>
                          )}
                        </div>

                        {ticket.lastMessage && (
                          <p className="text-[11px] text-foreground-dim line-clamp-1 font-medium">
                            {ticket.lastMessage}
                          </p>
                        )}

                        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[9px] font-bold uppercase tracking-widest text-foreground-dim pt-1">
                          <span className="text-foreground">{ticket.department}</span>
                          {ticket.serviceName && <span>• {ticket.serviceName}</span>}
                          <span>• Updated {new Date(ticket.updatedAt).toLocaleDateString()}</span>
                        </div>
                      </div>
                    </div>

                    {/* Right: Badges & Action */}
                    <div className="flex items-center gap-3 justify-between md:justify-end shrink-0">
                      {getPriorityBadge(ticket.priority)}
                      {getStatusBadge(ticket.status)}
                      <div className="p-2 rounded-lg bg-bg border border-border group-hover:border-accent/30 text-foreground-dim group-hover:text-accent transition-all">
                        <ChevronRight size={16} />
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="p-16 text-center bg-bg-alt border border-dashed border-border rounded-2xl">
              <div className="w-16 h-16 bg-bg border border-border rounded-2xl flex items-center justify-center mx-auto mb-4 text-foreground-dim">
                <LifeBuoy size={32} />
              </div>
              <h3 className="text-[13px] font-black uppercase tracking-widest text-foreground mb-1">
                {searchQuery || statusFilter !== 'ALL' ? 'No Matching Tickets Found' : 'No Support Tickets Yet'}
              </h3>
              <p className="text-[10px] font-bold uppercase tracking-widest text-foreground-dim mb-6 max-w-sm mx-auto">
                {searchQuery || statusFilter !== 'ALL' 
                  ? 'Try changing your search term or active filters.'
                  : 'Have questions or experiencing technical difficulties? Create a ticket and our 24/7 staff will assist you.'}
              </p>
              <button
                onClick={() => setIsCreateModalOpen(true)}
                className="px-6 py-2.5 bg-accent hover:bg-accent-muted text-white text-[10px] font-black uppercase tracking-widest rounded-xl transition-all shadow-lg shadow-accent/20 inline-flex items-center gap-2"
              >
                <Plus size={14} />
                Open First Ticket
              </button>
            </div>
          )}
        </>
      )}

      {/* Create Ticket Modal */}
      <AnimatePresence>
        {isCreateModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#0f0b1a] border border-purple-900/40 rounded-2xl max-w-xl w-full p-6 shadow-2xl overflow-hidden"
            >
              <div className="flex items-center justify-between pb-4 border-b border-purple-900/30 mb-5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-purple-600/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
                    <LifeBuoy size={20} />
                  </div>
                  <div>
                    <h3 className="text-sm font-black uppercase tracking-wider text-white">Create Support Ticket</h3>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Our engineers typically reply within minutes</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsCreateModalOpen(false)}
                  className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors"
                >
                  <X size={18} />
                </button>
              </div>

              <form onSubmit={handleCreateTicket} className="space-y-4">
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-slate-300 mb-1.5">
                    Subject Summary *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Node connectivity lag / Query regarding dedicated server deployment"
                    value={ticketForm.subject}
                    onChange={(e) => setTicketForm({ ...ticketForm, subject: e.target.value })}
                    className="w-full px-4 py-2.5 bg-[#140e25] border border-purple-900/40 rounded-xl text-xs text-white focus:border-purple-500 outline-none transition-all placeholder:text-slate-500"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-black uppercase tracking-widest text-slate-300 mb-1.5">
                      Department *
                    </label>
                    <select
                      value={ticketForm.department}
                      onChange={(e) => setTicketForm({ ...ticketForm, department: e.target.value as TicketDepartment })}
                      className="w-full px-4 py-2.5 bg-[#140e25] border border-purple-900/40 rounded-xl text-xs text-white focus:border-purple-500 outline-none transition-all"
                    >
                      <option value="Technical Support">Technical Support</option>
                      <option value="Billing & Payments">Billing & Payments</option>
                      <option value="Server Inquiry">Server Inquiry</option>
                      <option value="General">General Inquiry</option>
                      <option value="Abuse/Security">Abuse & Security</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] font-black uppercase tracking-widest text-slate-300 mb-1.5">
                      Priority Level *
                    </label>
                    <select
                      value={ticketForm.priority}
                      onChange={(e) => setTicketForm({ ...ticketForm, priority: e.target.value as TicketPriority })}
                      className="w-full px-4 py-2.5 bg-[#140e25] border border-purple-900/40 rounded-xl text-xs text-white focus:border-purple-500 outline-none transition-all"
                    >
                      <option value="low">Low - Routine Question</option>
                      <option value="medium">Medium - Standard Request</option>
                      <option value="high">High - Degraded Performance</option>
                      <option value="urgent">Urgent - Service Critical Outage</option>
                    </select>
                  </div>
                </div>

                {services.length > 0 && (
                  <div>
                    <label className="block text-[10px] font-black uppercase tracking-widest text-slate-300 mb-1.5">
                      Associated Service (Optional)
                    </label>
                    <select
                      value={ticketForm.serviceId}
                      onChange={(e) => setTicketForm({ ...ticketForm, serviceId: e.target.value })}
                      className="w-full px-4 py-2.5 bg-[#140e25] border border-purple-900/40 rounded-xl text-xs text-white focus:border-purple-500 outline-none transition-all"
                    >
                      <option value="">None / General Account Inquiry</option>
                      {services.map(s => (
                        <option key={s.id} value={s.id}>{s.name} ({s.location} - {s.ip || s.nodeName})</option>
                      ))}
                    </select>
                  </div>
                )}

                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-slate-300 mb-1.5">
                    Detailed Message *
                  </label>
                  <textarea
                    required
                    rows={4}
                    placeholder="Describe your issue or inquiry with as much detail as possible..."
                    value={ticketForm.message}
                    onChange={(e) => setTicketForm({ ...ticketForm, message: e.target.value })}
                    className="w-full p-4 bg-[#140e25] border border-purple-900/40 rounded-xl text-xs text-white focus:border-purple-500 outline-none transition-all placeholder:text-slate-500 resize-none"
                  />
                </div>

                <div className="flex gap-3 pt-3">
                  <button
                    type="button"
                    onClick={() => setIsCreateModalOpen(false)}
                    className="flex-1 py-3 bg-white/5 hover:bg-white/10 text-slate-300 font-bold rounded-xl text-xs uppercase tracking-wider transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmittingTicket}
                    className="flex-1 py-3 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white font-bold rounded-xl text-xs uppercase tracking-wider shadow-lg shadow-purple-600/30 transition-all flex items-center justify-center gap-2"
                  >
                    {isSubmittingTicket ? (
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <>
                        <Send size={14} />
                        Submit Ticket
                      </>
                    )}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
