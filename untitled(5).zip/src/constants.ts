import { AppData, ProductSoftwareOption, ProductAddon } from './types';

export const DEFAULT_SOFTWARE_PRESETS: ProductSoftwareOption[] = [
  // Minecraft
  { id: 'mc-paper', category: 'game', gameType: 'minecraft', name: 'Paper (Recommended)', desc: 'High performance Spigot fork with bug fixes', recommended: true },
  { id: 'mc-purpur', category: 'game', gameType: 'minecraft', name: 'Purpur', desc: 'Highly customizable Paper drop-in replacement' },
  { id: 'mc-folia', category: 'game', gameType: 'minecraft', name: 'Folia', desc: 'Multi-threaded regional Minecraft server engine' },
  { id: 'mc-fabric', category: 'game', gameType: 'minecraft', name: 'Fabric', desc: 'Lightweight, modular modding toolchain' },
  { id: 'mc-forge', category: 'game', gameType: 'minecraft', name: 'Forge', desc: 'Standard heavy modpack software' },
  { id: 'mc-bedrock', category: 'game', gameType: 'minecraft', name: 'Bedrock Dedicated', desc: 'C++ engine for Minecraft PE / Windows 10' },

  // Rust
  { id: 'rust-umod', category: 'game', gameType: 'rust', name: 'Oxide / uMod (Recommended)', desc: 'Full modding framework with automatic uMod plugin installer', recommended: true },
  { id: 'rust-vanilla', category: 'game', gameType: 'rust', name: 'Vanilla Rust Dedicated', desc: 'Official Facepunch server binary' },
  { id: 'rust-carbon', category: 'game', gameType: 'rust', name: 'Carbon Framework', desc: 'High concurrency C# modding framework' },

  // FiveM
  { id: 'fivem-txadmin', category: 'game', gameType: 'fivem', name: 'TxAdmin Standalone (Recommended)', desc: 'Official FiveM web panel with 1-click resource deployment', recommended: true },
  { id: 'fivem-esx', category: 'game', gameType: 'fivem', name: 'ESX Legacy Framework', desc: 'Pre-configured roleplay server stack' },
  { id: 'fivem-qbcore', category: 'game', gameType: 'fivem', name: 'QBCore Framework', desc: 'Modern high-performance GTAV RP framework' },

  // Palworld
  { id: 'pal-vanilla', category: 'game', gameType: 'palworld', name: 'PalServer Dedicated (Vanilla)', desc: 'Official Steam Palworld server binary' },
  { id: 'pal-modded', category: 'game', gameType: 'palworld', name: 'Palworld UE5 Modded Engine', desc: 'Unreal Engine 5 modding support & memory leak scrubber', recommended: true },

  // ARK
  { id: 'ark-ascended', category: 'game', gameType: 'ark', name: 'ARK Survival Ascended Dedicated', desc: 'UE5 next-gen ARK dedicated server build', recommended: true },
  { id: 'ark-evolved', category: 'game', gameType: 'ark', name: 'ARK Survival Evolved', desc: 'Classic ARK dedicated server with Steam workshop support' },

  // CS2
  { id: 'cs2-comp', category: 'game', gameType: 'cs2', name: 'CS2 Competitive Source2 Engine', desc: 'High-tick competitive 5v5 / 10v10 server', recommended: true },
  { id: 'cs2-metamod', category: 'game', gameType: 'cs2', name: 'CS2 MetaMod + SourceMod', desc: 'Plugin-enabled CS2 dedicated server' },

  // VPS OS Images
  { id: 'vps-u24', category: 'vps', name: 'Ubuntu 24.04 LTS (Noble Numbat)', desc: 'Latest enterprise Linux release', recommended: true },
  { id: 'vps-u22', category: 'vps', name: 'Ubuntu 22.04 LTS (Jammy Jellyfish)', desc: 'Most popular production Linux' },
  { id: 'vps-deb12', category: 'vps', name: 'Debian 12 Bookworm', desc: 'Rock-solid stability and low memory footprint' },
  { id: 'vps-alma9', category: 'vps', name: 'AlmaLinux 9', desc: 'RHEL-binary compatible enterprise distribution' },
  { id: 'vps-win2022', category: 'vps', name: 'Windows Server 2022', desc: 'GUI edition with Remote Desktop (RDP)' },

  // Discord Bot Runtimes
  { id: 'bot-node20', category: 'bot', name: 'Node.js 20 LTS', desc: 'Modern JS/TS runtime for Discord.js & Eris', recommended: true },
  { id: 'bot-py311', category: 'bot', name: 'Python 3.11 Environment', desc: 'For discord.py, Pycord, Nextcord & AsyncIO' },
  { id: 'bot-java21', category: 'bot', name: 'Java 21 OpenJDK', desc: 'For JDA (Java Discord API) and Lavalink nodes' },
  { id: 'bot-go122', category: 'bot', name: 'Golang 1.22 Runtime', desc: 'High concurrency compiled bot binaries' },

  // Web Stacks
  { id: 'web-lemp', category: 'web', name: 'Nginx + PHP 8.3 + MySQL (LEMP)', desc: 'Optimized LEMP web stack for WordPress & apps', recommended: true },
  { id: 'web-lamp', category: 'web', name: 'Apache + PHP 8.2 + MariaDB (LAMP)', desc: 'Classic LAMP environment with .htaccess support' },
  { id: 'web-cpanel', category: 'web', name: 'cPanel / WHM License Node', desc: 'Graphical web management panel' }
];

export const DEFAULT_ADDON_PRESETS: ProductAddon[] = [
  { id: 'addon-dedicated-ip', name: 'Dedicated Static IPv4 Address', desc: 'Unique port-25565 / port-22 IP for direct domain mapping', priceInr: 150, category: 'all', badge: 'Recommended' },
  { id: 'addon-daily-backups', name: 'Automated Daily Offsite Backups', desc: 'Daily automated snapshot with 7-day retention', priceInr: 99, category: 'all', badge: 'Popular' },
  { id: 'addon-ddos-l7', name: 'Enterprise L7 DDoS Shield Upgrade', desc: 'Dedicated 100Gbps Arbor filter policy for HTTP/UDP', priceInr: 199, category: 'all', badge: 'Protection' },
  { id: 'addon-managed-support', name: 'Priority Managed Installation', desc: 'Engineer setup for custom mods, plugins & domain', priceInr: 299, category: 'all', badge: 'VIP' },
];

export const DEFAULT_DATA: AppData = {
  settings: {
    site_name: 'HECTOR HOSTING',
    tagline: 'High-Frequency AMD Ryzen & EPYC Cloud Infrastructure',
    brand_name: 'Hector Hosting',
    whatsapp_number: '+919876543210',
    whatsapp_message: 'Hi Hector Hosting! I want to order {plan} ({price}).',
    theme: 'dark',
    font: 'space',
    color: 'purple',
    currency: 'INR',
    nav_links: [
      { label: 'VPS', href: '/vps-hosting' },
      { label: 'Game Hosting', href: '/game-servers' },
      { label: 'Web Hosting', href: '/web-hosting' },
      { label: 'Infrastructure', href: '/infrastructure' },
      { label: 'Other Service', href: '/bot-hosting' },
      { label: 'About', href: '/about' },
      { label: 'Contact', href: '/contact' }
    ],
    productConfigs: {
      softwareOptions: DEFAULT_SOFTWARE_PRESETS,
      addons: DEFAULT_ADDON_PRESETS
    }
  },
  categories: ['VPS', 'GAME-HOSTING', 'WEB-HOSTING', 'BOT-HOSTING', 'DED-SERVERS'],
  games: [
    {
      id: 'game-minecraft',
      title: 'MINECRAFT',
      category: 'Sandbox',
      image: '/src/assets/images/minecraft_game_cover_1788180858749.jpg',
      startingPriceInr: 99,
      platforms: ['Java', 'Bedrock', 'PC', 'Mobile', 'Console'],
      badge: 'POPULAR',
      description: 'High clock AMD RYZEN 9 5950X performance hosting for Spigot, Paper, Forge, Fabric & GeyserMC Bedrock crossplay.',
      ramOptions: [
        { ram: '2 GB', slots: '15 Slots', priceInr: 99, cpu: '100% CPU Core' },
        { ram: '4 GB', slots: '30 Slots', priceInr: 199, cpu: '200% CPU Core' },
        { ram: '6 GB', slots: '45 Slots', priceInr: 299, cpu: '250% CPU Core' },
        { ram: '8 GB', slots: '60 Slots', priceInr: 399, cpu: '300% CPU Core' },
        { ram: '12 GB', slots: '100 Slots', priceInr: 599, cpu: '350% CPU Core' },
        { ram: '16 GB', slots: 'Unlimited', priceInr: 799, cpu: '400% CPU Core' },
        { ram: '32 GB', slots: 'Unlimited+', priceInr: 1499, cpu: '600% CPU Core' },
      ],
      metadata: {
        recommendedRam: '8 GB - 16 GB',
        players: '1 to 200+ Players',
        cpuType: 'AMD RYZEN 9 5950X',
        storage: '50GB NVMe Gen4',
        serverSoftware: ['PaperMC', 'Purpur', 'Forge', 'Fabric', 'GeyserMC']
      },
      order: 1,
      is_active: true
    },
    {
      id: 'game-palworld',
      title: 'PALWORLD',
      category: 'Survival',
      image: '/src/assets/images/palworld_game_cover_1788180895611.jpg',
      startingPriceInr: 249,
      platforms: ['PC', 'Xbox', 'GamePass'],
      badge: 'TOP SELLER',
      description: 'Optimized high-RAM Palworld multiplayer dedicated hosting with auto memory leak scrubbing.',
      ramOptions: [
        { ram: '8 GB', slots: '16 Players', priceInr: 249, cpu: '200% CPU Core' },
        { ram: '16 GB', slots: '32 Players', priceInr: 499, cpu: '300% CPU Core' },
        { ram: '24 GB', slots: '64 Players', priceInr: 749, cpu: '400% CPU Core' },
        { ram: '32 GB', slots: '100+ Players', priceInr: 999, cpu: '500% CPU Core' },
      ],
      metadata: {
        recommendedRam: '16 GB - 32 GB',
        players: 'Up to 32 players',
        cpuType: 'AMD RYZEN 9 5950X',
        storage: '60GB NVMe Gen4',
        serverSoftware: ['Steam Dedicated', 'Xbox GamePass', 'Palguard']
      },
      order: 2,
      is_active: true
    },
    {
      id: 'game-rust',
      title: 'RUST',
      category: 'Survival',
      image: '/src/assets/images/rust_game_cover_1788181561811.jpg',
      startingPriceInr: 299,
      platforms: ['PC', 'PlayStation', 'Xbox'],
      badge: 'OXIDE / UMOD',
      description: 'High tick-rate Rust servers with full uMod/Oxide plugin support and DDoS mitigation.',
      ramOptions: [
        { ram: '6 GB', slots: '50 Players', priceInr: 299, cpu: '200% CPU Core' },
        { ram: '10 GB', slots: '80 Players', priceInr: 499, cpu: '300% CPU Core' },
        { ram: '16 GB', slots: '150 Players', priceInr: 799, cpu: '400% CPU Core' },
        { ram: '24 GB', slots: '250 Players', priceInr: 1099, cpu: '500% CPU Core' },
        { ram: '32 GB', slots: '300+ Players', priceInr: 1399, cpu: '600% CPU Core' },
      ],
      metadata: {
        recommendedRam: '16 GB - 32 GB',
        players: '50 to 300+ Players',
        cpuType: 'AMD RYZEN 9 5950X',
        storage: '80GB NVMe Gen4',
        serverSoftware: ['Oxide', 'uMod', 'Carbon']
      },
      order: 3,
      is_active: true
    },
    {
      id: 'game-fivem',
      title: 'FIVEM (GTA V RP)',
      category: 'Simulation',
      image: '/src/assets/images/fivem_game_cover_1788181632786.jpg',
      startingPriceInr: 349,
      platforms: ['PC'],
      badge: 'ESX / QBCore',
      description: 'GTA V FiveM roleplay server hosting with TxAdmin panel, MySQL DB, and OneSync support.',
      ramOptions: [
        { ram: '8 GB', slots: '32 Slots', priceInr: 349, cpu: '250% CPU Core' },
        { ram: '16 GB', slots: '64 Slots', priceInr: 649, cpu: '400% CPU Core' },
        { ram: '24 GB', slots: '100 Slots', priceInr: 899, cpu: '500% CPU Core' },
        { ram: '32 GB', slots: '128 Slots', priceInr: 1199, cpu: '600% CPU Core' },
      ],
      metadata: {
        recommendedRam: '16 GB - 32 GB',
        players: '32 to 128+ Players',
        cpuType: 'AMD RYZEN 9 5950X',
        storage: '80GB NVMe Gen4',
        serverSoftware: ['txAdmin', 'OneSync', 'MySQL']
      },
      order: 4,
      is_active: true
    },
    {
      id: 'game-ark',
      title: 'ARK: SURVIVAL',
      category: 'Survival',
      image: '/src/assets/images/ark_game_cover_1788181616275.jpg',
      startingPriceInr: 349,
      platforms: ['PC', 'PlayStation', 'Xbox'],
      badge: 'CLUSTER READY',
      description: 'ARK: Survival Evolved & Ascended hosting with cross-server cluster transfer capabilities.',
      ramOptions: [
        { ram: '8 GB', slots: '30 Survivors', priceInr: 349, cpu: '200% CPU Core' },
        { ram: '16 GB', slots: '70 Survivors', priceInr: 649, cpu: '350% CPU Core' },
        { ram: '32 GB', slots: '120 Survivors', priceInr: 1199, cpu: '500% CPU Core' },
      ],
      metadata: {
        recommendedRam: '16 GB - 32 GB',
        players: '30 to 120 Players',
        cpuType: 'AMD RYZEN 9 5950X',
        storage: '100GB NVMe Storage',
        serverSoftware: ['ARK Dedicated', 'Steam Workshop']
      },
      order: 5,
      is_active: true
    },
    {
      id: 'game-valheim',
      title: 'VALHEIM',
      category: 'RPG',
      image: '/src/assets/images/valheim_game_cover_1788181581139.jpg',
      startingPriceInr: 199,
      platforms: ['PC', 'Xbox', 'Crossplay'],
      badge: 'CROSSPLAY',
      description: 'Viking co-op survival hosting with automatic cloud world saves & Valheim Plus support.',
      ramOptions: [
        { ram: '4 GB', slots: '10 Vikings', priceInr: 199, cpu: '150% CPU Core' },
        { ram: '8 GB', slots: '20 Vikings', priceInr: 349, cpu: '250% CPU Core' },
        { ram: '12 GB', slots: '40 Vikings', priceInr: 549, cpu: '300% CPU Core' },
        { ram: '16 GB', slots: '50 Vikings', priceInr: 749, cpu: '350% CPU Core' },
      ],
      metadata: {
        recommendedRam: '8 GB - 16 GB',
        players: 'Up to 50 players',
        cpuType: 'AMD RYZEN 9 5950X',
        storage: '40GB NVMe Storage',
        serverSoftware: ['ValheimPlus', 'BepInEx']
      },
      order: 6,
      is_active: true
    },
    {
      id: 'game-samp',
      title: 'SA-MP',
      category: 'Roleplay / Action',
      image: '/src/assets/images/samp_game_cover_1790172922565.jpg',
      startingPriceInr: 49,
      platforms: ['PC', 'Android / Mobile'],
      badge: 'POPULAR',
      description: 'Ultra-low latency San Andreas Multiplayer & open.mp server hosting with Pawn scripting, MySQL & DDoS protection.',
      ramOptions: [
        { ram: '512 MB', slots: '50 Players', priceInr: 49, cpu: '50% CPU Core' },
        { ram: '1 GB', slots: '100 Players', priceInr: 89, cpu: '100% CPU Core' },
        { ram: '2 GB', slots: '250 Players', priceInr: 169, cpu: '150% CPU Core' },
        { ram: '4 GB', slots: '500 Players', priceInr: 299, cpu: '250% CPU Core' },
        { ram: '8 GB', slots: 'Unlimited', priceInr: 549, cpu: '400% CPU Core' },
      ],
      metadata: {
        recommendedRam: '2 GB - 4 GB',
        players: 'Up to 500+ Players',
        cpuType: 'AMD RYZEN 9 5950X',
        storage: '20GB NVMe Storage',
        serverSoftware: ['SA-MP 0.3.7', 'open.mp', 'Pawn']
      },
      order: 7,
      is_active: true
    },
    {
      id: 'game-cs2',
      title: 'COUNTER-STRIKE 2',
      category: 'FPS',
      image: '/src/assets/images/cs2_game_cover.jpg',
      startingPriceInr: 149,
      platforms: ['PC'],
      badge: '128 TICK',
      description: 'Ultra-performance CS2 server hosting with sub-10ms Indian ping and Metamod/SourceMod support.',
      ramOptions: [
        { ram: '4 GB', slots: '10 Slots', priceInr: 149, cpu: '200% CPU Core' },
        { ram: '6 GB', slots: '16 Slots', priceInr: 249, cpu: '300% CPU Core' },
        { ram: '8 GB', slots: '24 Slots', priceInr: 349, cpu: '400% CPU Core' },
        { ram: '12 GB', slots: '32 Slots', priceInr: 549, cpu: '500% CPU Core' },
      ],
      metadata: {
        recommendedRam: '8 GB',
        players: '10 to 32 Players',
        cpuType: 'AMD RYZEN 9 5950X',
        storage: '40GB NVMe Storage',
        serverSoftware: ['Metamod:Source', 'CounterStrikeSharp']
      },
      order: 8,
      is_active: true
    },
    {
      id: 'game-terraria',
      title: 'TERRARIA',
      category: 'Sandbox',
      image: '/src/assets/images/terraria_game_cover.jpg',
      startingPriceInr: 99,
      platforms: ['PC', 'Mobile', 'Console'],
      badge: 'TMODLOADER',
      description: 'Terraria & TShock dedicated server hosting with 1-click mod support and automatic backups.',
      ramOptions: [
        { ram: '2 GB', slots: '8 Players', priceInr: 99, cpu: '100% CPU Core' },
        { ram: '4 GB', slots: '16 Players', priceInr: 189, cpu: '150% CPU Core' },
        { ram: '6 GB', slots: '32 Players', priceInr: 279, cpu: '200% CPU Core' },
        { ram: '8 GB', slots: 'Unlimited', priceInr: 369, cpu: '300% CPU Core' },
      ],
      metadata: {
        recommendedRam: '4 GB - 8 GB',
        players: 'Up to 255 Players',
        cpuType: 'AMD RYZEN 9 5950X',
        storage: '20GB NVMe Storage',
        serverSoftware: ['TShock', 'tModLoader', 'Vanilla']
      },
      order: 9,
      is_active: true
    },
    {
      id: 'game-unturned',
      title: 'UNTURNED',
      category: 'Survival',
      image: '/src/assets/images/unturned_game_cover.jpg',
      startingPriceInr: 129,
      platforms: ['PC'],
      badge: 'ROCKETMOD',
      description: 'Zomibe survival Unturned server hosting with RocketMod and OpenMod support.',
      ramOptions: [
        { ram: '4 GB', slots: '24 Players', priceInr: 129, cpu: '150% CPU Core' },
        { ram: '8 GB', slots: '48 Players', priceInr: 249, cpu: '250% CPU Core' },
        { ram: '16 GB', slots: 'Unlimited', priceInr: 449, cpu: '400% CPU Core' },
      ],
      metadata: {
        recommendedRam: '8 GB',
        players: '24 to 100 Players',
        cpuType: 'AMD RYZEN 9 5950X',
        storage: '30GB NVMe Storage',
        serverSoftware: ['RocketMod', 'OpenMod', 'Workshop']
      },
      order: 10,
      is_active: true
    },
    {
      id: 'game-hytale',
      title: 'HYTALE',
      category: 'Sandbox',
      image: '/src/assets/images/hytale_game_cover_1788180878834.jpg',
      startingPriceInr: 199,
      platforms: ['PC', 'Mac'],
      badge: 'PRE-ORDER READY',
      description: 'Dedicated enterprise infrastructure ready for instant setup upon Hytale server release.',
      ramOptions: [
        { ram: '4 GB', slots: '20 Players', priceInr: 199, cpu: '150% CPU Core' },
        { ram: '8 GB', slots: '45 Players', priceInr: 349, cpu: '250% CPU Core' },
        { ram: '16 GB', slots: '90 Players', priceInr: 649, cpu: '350% CPU Core' },
        { ram: '32 GB', slots: 'Unlimited', priceInr: 1199, cpu: '500% CPU Core' },
      ],
      metadata: {
        recommendedRam: '8 GB - 16 GB',
        players: 'Scalable Slots',
        cpuType: 'AMD RYZEN 9 5950X',
        storage: '50GB NVMe Storage',
        serverSoftware: ['Hytale Engine', 'Official Scripts']
      },
      order: 11,
      is_active: true
    }
  ],
  plans: [
    {
      id: 'vps-starter',
      name: 'VPS Starter (Ryzen 9)',
      price: '599',
      price_inr: '599',
      badge: 'Popular',
      category: 'VPS',
      location: 'India (Mumbai)',
      node: 'AMD Ryzen 9 5950X',
      desc: 'High-frequency 2-core KVM VPS with dedicated DDR4 RAM and NVMe storage in Mumbai.',
      features: ['Full Root SSH Access', 'Dedicated IPv4 Address', 'Automated Anti-DDoS', 'Instant Provisioning']
    },
    {
      id: 'mc-starter',
      name: 'Minecraft Starter (4GB)',
      price: '199',
      price_inr: '199',
      badge: 'Best Value',
      category: 'GAME-HOSTING',
      location: 'India (Mumbai)',
      node: 'AMD Ryzen 9 5950X',
      desc: 'Optimized Paper/Spigot node for small survival SMPs and co-op groups.',
      features: ['4GB DDR4 ECC RAM', '200% CPU Priority', 'NVMe Gen4 Storage', 'Daily Backups', 'Sub-15ms Mumbai Ping']
    },
    {
      id: 'mc-pro',
      name: 'Minecraft Pro (16GB)',
      price: '799',
      price_inr: '799',
      badge: 'Heavyweight',
      category: 'GAME-HOSTING',
      location: 'India (Mumbai)',
      node: 'AMD Ryzen 9 5950X',
      desc: 'Heavyweight node built for large public networks and modded survival.',
      features: ['16GB DDR4 ECC RAM', '400% CPU Priority', 'Dedicated IP Available', 'Hourly Backups', 'BungeeCord Ready']
    },
    {
      id: 'palworld-starter',
      name: 'Palworld Starter (16GB)',
      price: '499',
      price_inr: '499',
      badge: 'Top Seller',
      category: 'GAME-HOSTING',
      location: 'India (Mumbai)',
      node: 'AMD Ryzen 9 5950X',
      desc: 'Dedicated Palworld instance with automated memory leak scrubbing.',
      features: ['16GB High-Speed RAM', '300% CPU Priority', 'Memory Leak Scrubber', 'Steam & Xbox Support', 'Anti-DDoS Shield']
    },
    {
      id: 'fivem-starter',
      name: 'FiveM RP Starter (16GB)',
      price: '649',
      price_inr: '649',
      badge: 'txAdmin Ready',
      category: 'GAME-HOSTING',
      location: 'India (Mumbai)',
      node: 'AMD Ryzen 9 5950X',
      desc: 'GTA V FiveM roleplay node pre-installed with txAdmin and MySQL.',
      features: ['16GB DDR4 RAM', '400% CPU Priority', 'MariaDB Included', 'OneSync Infinity Ready', 'txAdmin Dashboard']
    },
    {
      id: 'rust-starter',
      name: 'Rust Survival (12GB)',
      price: '599',
      price_inr: '599',
      badge: 'Oxide/uMod',
      category: 'GAME-HOSTING',
      location: 'India (Mumbai)',
      node: 'AMD Ryzen 9 5950X',
      desc: '100+ tick rate Rust survival node with fast wipe loading.',
      features: ['12GB DDR4 RAM', '350% CPU Priority', 'uMod/Oxide Support', 'Rust+ Mobile App Support', 'RAID 10 NVMe']
    },
    {
      id: 'cs2-starter',
      name: 'CS2 Competitive (8GB)',
      price: '349',
      price_inr: '349',
      badge: '128 Tick',
      category: 'GAME-HOSTING',
      location: 'India (Mumbai)',
      node: 'AMD Ryzen 9 5950X',
      desc: 'Professional CS2 server with sub-10ms Indian ping.',
      features: ['8GB DDR4 RAM', '400% CPU Priority', '128 Tick Optimized', 'Metamod Ready', 'Sub-10ms Mumbai Ping']
    },
    {
      id: 'samp-starter',
      name: 'SA-MP Roleplay (2GB)',
      price: '169',
      price_inr: '169',
      badge: 'Pawn/MySQL',
      category: 'GAME-HOSTING',
      location: 'India (Mumbai)',
      node: 'AMD Ryzen 9 5950X',
      desc: 'San Andreas Multiplayer node with native Pawn and fast MySQL.',
      features: ['2GB Dedicated RAM', '150% CPU Priority', '250+ Player Capacity', 'Native MySQL Support', 'open.mp Compatible']
    },
    {
      id: 'bot-node-basic',
      name: 'Node/Python Bot Pod',
      price: '149',
      price_inr: '149',
      badge: 'Basic',
      category: 'BOT-HOSTING',
      location: 'India (Mumbai)',
      node: 'AMD Ryzen 9 5950X',
      desc: '24/7 always-online Discord and Telegram bot container with 2GB DDR4 RAM.',
      features: ['24/7 Uptime SLA', 'Git Auto Deploy', 'PM2 Process Manager', 'Web Terminal']
    }
  ],
  testimonials: [
    {
      id: 'rev-1',
      name: 'Rohan Sharma',
      logo: 'zap',
      server: 'Minecraft & CS:GO India Community',
      note: 'Switched our gaming servers to Hector Hosting Mumbai node. Ping dropped from 85ms to 12ms! Support on WhatsApp is lightning fast.'
    }
  ],
  statuses: [
    { id: 'node-mumbai-1', name: 'Mumbai Tier-4 Datacenter (IN-BOM-1)', ip: '103.15.22.1', location: 'Mumbai, India', category: 'Infrastructure & Network', status: 'operational', lastChecked: 'Just now', uptime: '99.99%', latency: '12ms' },
    { id: 'node-mumbai-2', name: 'Ryzen 9 5950X Game Compute Array', ip: '103.15.22.2', location: 'Mumbai, India', category: 'Game Hosting Nodes', status: 'operational', lastChecked: 'Just now', uptime: '99.99%', latency: '14ms' },
    { id: 'node-epyc-1', name: 'AMD EPYC 7763 KVM Host Cluster', ip: '103.15.22.4', location: 'Mumbai, India', category: 'VPS & Dedicated Compute', status: 'operational', lastChecked: 'Just now', uptime: '99.98%', latency: '15ms' },
    { id: 'node-nixi-peering', name: 'NIXI Direct 10Gbps Peering Fabric', ip: '103.15.22.3', location: 'Mumbai, India', category: 'Infrastructure & Network', status: 'operational', lastChecked: 'Just now', uptime: '100.0%', latency: '8ms' },
    { id: 'node-billing-api', name: 'Hector Hosting Client & Billing Portal', ip: '103.15.22.10', location: 'Mumbai, India', category: 'Web & Billing Services', status: 'operational', lastChecked: 'Just now', uptime: '99.99%', latency: '11ms' },
    { id: 'node-pterodactyl-daemon', name: 'Pterodactyl Wings Control Node', ip: '103.15.22.12', location: 'Mumbai, India', category: 'Game Hosting Nodes', status: 'operational', lastChecked: 'Just now', uptime: '99.97%', latency: '13ms' }
  ],
  feedbacks: [],
  privacy: `# Privacy Policy

Deterministic policies regarding the security, collection, processing, and protection of your personal information, computing records, and application telemetry.

## 1. Data Collection & Information Gathering
At Hector Hosting, we prioritize your privacy and strictly adhere to the principle of minimal data collection. We only gather information essential to provisioning high-performance cloud infrastructure, preventing network abuse, and maintaining billing compliance:
*   **Account Registration Data:** Full name, verified email address, phone number, and billing location details required during account setup.
*   **Operational & Telemetry Logs:** Source IP addresses, timestamps, bandwidth utilization, and firewall event logs recorded for DDoS protection and node optimization.
*   **Financial & Payment Records:** Transaction reference IDs, invoice receipts, and billing history. Payment card numbers and banking credentials are handled directly by PCI-DSS compliant payment gateways and are never stored on our servers.

## 2. Data Protection & Infrastructure Security
We employ enterprise-grade security controls to safeguard your personal data and hosted workload environments:
*   **Encryption at Rest & in Transit:** Sensitive database fields are encrypted using AES-256 protocols. Web dashboard communications are enforced over SSL/TLS 1.3 encryption.
*   **Root & Administrative Isolation:** Management access to compute hypervisors is restricted to authorized NOC personnel using hardware security keys and multi-factor authentication VPNs.
*   **Zero Vendor Exploitation:** We do not scan, inspect, or analyze the internal files, databases, or container contents of your hosted applications unless explicitly requested by you for technical support.

## 3. Data Sharing & Third-Party Disclosure
**We do not sell, rent, or trade your personal information to third parties or marketing brokers.** Limited data sharing occurs solely under the following circumstances:
*   **Infrastructure Partners:** Tier 4 Data Center partners in Mumbai, India strictly for network routing, IP transit, and physical cage colocation requirements.
*   **Statutory Compliance:** Disclosure to Indian law enforcement authorities or CERT-In agencies when mandated by valid legal court orders or statutory subpoenas under the Information Technology Act, 2000.

## 4. Data Retention & Erasure Rights
Account data is retained for the duration of your active service subscription plus statutory tax recordkeeping periods. Upon account termination or written deletion request, all virtual server disks, container volumes, and stored backups are permanently purged using zero-fill cryptographic wipe procedures.

## 5. Cookie Policy & Web Analytics
Our web portal uses essential session cookies to keep you authenticated in the client dashboard. We do not employ intrusive cross-site tracking scripts or third-party advertising cookies.
`,
  refund: `# Refund Policy

Uncompromising performance standards. Review our deterministic satisfaction commitment, eligibility criteria, and transparent claim procedures for all infrastructure plans.

## 30-Day Money-Back Guarantee
We stand firmly behind the speed, uptime, and latency of our high-frequency AMD Ryzen™ and EPYC™ server nodes. If you are not completely satisfied with your server performance, control panel experience, or technical support within the first **30 days** of your initial deployment, we will issue a full refund—no hassle, no questions asked.

## Service Refund Eligibility Matrix
Refund eligibility varies by service category based on raw hardware allocation costs and third-party license commitments:

| Service Category | Refund Period | Conditions & Coverage |
| :--- | :--- | :--- |
| **Game Hosting** (Minecraft, Palworld, GTA) | **30 Days** | 100% Full Refund of monthly recurring fees. |
| **Virtual Private Servers** (VPS) | **30 Days** | 100% Full Refund on new instance deployments. |
| **Discord Bot & Web Hosting** | **30 Days** | 100% Full Refund guaranteed. |
| **Dedicated Bare-Metal Nodes** | **7 Days** | Subject to a 15% hardware setup fee deduction; custom bandwidth additions excluded. |
| **Domain Registrations & SSL** | Non-Refundable | Non-refundable due to immediate registry domain fee lock-in. |

## Refund Request & Processing Procedure
1.  **Submit a Request:** Log into the Hector Hosting Support Portal or message our 24/7 WhatsApp support line with your active Order ID and Server Instance details.
2.  **Account Verification:** Our billing team verifies ownership and confirms that no Acceptable Use Policy (AUP) violations or abuse suspensions exist on the account.
3.  **Prompt Disbursement:** Approved refunds are initiated back to your original payment method (UPI) within **3 to 5 business days**.

## Non-Refundable Circumstances
Refunds will not be granted under the following conditions:
*   Account termination or service suspension resulting from DDoS attacks launched from your instance, spamming, crypto mining abuse, or copyright violations.
*   Refund requests submitted after the 30-day guarantee period has elapsed.
*   Multiple consecutive refund claims submitted for the same service type across temporary disposable accounts.
`,
  tos: `# Terms of Service

Operational standards, service commitments, acceptable resource usage policies, and statutory obligations for the deployment of compute resources on Hector Hosting infrastructure.

## 1. Acceptance of Terms & Service Scope
By accessing, registering, or purchasing services through Hector Hosting, you enter into a legally binding agreement to abide by these Terms of Service. Hector Hosting provides virtual private servers (VPS), dedicated bare-metal instances, game server containers, web hosting, and managed bot environments. All services are governed by Indian law and the terms set forth herein.

## 2. Acceptable Use Policy (AUP)
Clients are strictly prohibited from utilizing Hector Hosting compute resources, IP addresses, or network fabrics for any of the following unauthorized activities:
*   **Malicious Traffic & DDoS:** Launching, participating in, or amplifying Denial of Service (DoS/DDoS) attacks, network scanning, or port probing.
*   **Unsolicited Mass Messaging (Spam):** Sending mass marketing emails, operating open mail relays, or engaging in spamming practices.
*   **Crypto Mining on Shared Infrastructure:** Executing cryptocurrency mining (e.g., Bitcoin, Monero, Chia) on non-dedicated shared VPS or game hosting instances.
*   **Illegal Content & Piracy:** Hosting, storing, or transmitting copyrighted material without license, child exploitation content, malware, ransomware, or illegal gambling portals.
*   **System Overuse & Exploitation:** Deliberately attempting to bypass container virtualization limits, exploiting hypervisor vulnerabilities, or abusing CPU resources beyond allocated fair-use quotas.

## 3. Hardware Resource Guarantees & Fair Use Policy
Hector Hosting guarantees dedicated RAM allocation, storage capacity, and designated CPU core allocations as defined by your active service plan. Burstable resources on shared compute nodes are monitored under a strict Fair Use Policy to preserve latency stability and low-jitter execution for all co-located tenants. Excessive continuous single-core 100% saturation for prolonged periods on shared tiers may be subject to automated process throttling.

## 4. Service Level Agreement (SLA) & Uptime Guarantee
We commit to maintaining a minimum of **99.99% monthly network and node power availability**. Scheduled maintenance windows are communicated at least 48 hours in advance and are excluded from downtime calculations. In the event of unscheduled service interruptions exceeding the SLA threshold, account credits are granted upon request as follows:
*   **Monthly Availability 99.0% to 99.89%:** 10% Service Credit applied to next billing cycle.
*   **Monthly Availability 95.0% to 98.99%:** 25% Service Credit applied to next billing cycle.
*   **Monthly Availability Below 95.0%:** 100% Service Credit applied to next billing cycle.

## 5. Account Responsibilities & Data Backups
Clients are sole administrators of their root/SSH credentials and container access tokens. Hector Hosting performs automated system disaster-recovery snapshots, but clients remain strictly responsible for maintaining independent off-site backups of critical databases, application files, and game configuration save states. Hector Hosting bears no liability for data loss resulting from user misconfiguration, compromised credentials, or third-party software bugs.

## 6. Suspension & Service Termination
Hector Hosting reserves the right to immediately suspend or terminate any account or service instance that violates the Acceptable Use Policy, fails to fulfill renewal payments within the grace period (3 calendar days), or receives validated abuse reports from certified Indian CERT-In authorities.
`,
  legal: `# Legal Information & Compliance

Statutory framework, regulatory compliance standards, and corporate governance for Hector Hosting cloud infrastructure.

## Incorporated Entity Information
Hector Hosting operates as a registered cloud infrastructure provider incorporated in Mumbai, Maharashtra, India, complying strictly with the Information Technology Act, 2000, and applicable regional digital commerce regulations.

## Regulatory Compliance Frameworks
We maintain rigorous operational compliance across Indian and global cybersecurity directives:
*   **CERT-In Cyber Security Directions:** Full compliance with the Indian Computer Emergency Response Team directives regarding incident reporting and log retention.
*   **Digital Personal Data Protection (DPDP) Act:** Adherence to statutory data principal rights, consent management, and secure processing standards.
*   **ISO 27001 Certified Facilities:** Infrastructure hosted exclusively in ISO 27001 certified datacenter environments.
*   **Intellectual Property & DMCA Safeguards:** Strict policies for handling DMCA takedown notices and intellectual property infringement reports.

## Legal Jurisdiction & Court Authority
This portal, all hosting contracts, service level agreements, and disputes arising hereunder are governed exclusively by the laws of the Republic of India. Clients agree to submit to the exclusive jurisdiction of the competent courts located in **Mumbai, Maharashtra, India**.
`,
  infrastructure: `# High-Speed Infrastructure in India

Carrier-grade compute clusters, high-frequency AMD silicon, and direct NIXI peering fabrics engineered directly in Mumbai, India for sub-15ms regional latency.

## Tier 4 Datacenter Facility in Mumbai
Our flagship hardware nodes are housed in enterprise Tier 4 datacenter facilities in Mumbai, Maharashtra, India, engineered to meet strict international uptime and physical security standards:
*   **Direct NIXI & Telco Peering:** Direct fiber interconnectivity via the National Internet Exchange of India (NIXI) and Tier-1 Indian telecom providers (Airtel, Reliance Jio, Tata Communications).
*   **N+2 Electrical & Cooling Redundancy:** Dual utility power feeds, emergency diesel generators, and chilled-water climate management ensuring continuous operation.
*   **Physical Security & Cage Isolation:** 24/7 on-site Network Operations Center (NOC) engineers, biometric access controls, and video surveillance.

## Performance Threshold Benchmarks
We maintain strict performance standards with zero hardware overselling across all hypervisor nodes:

| Metric | Guaranteed Minimum | Operational Average |
| :--- | :--- | :--- |
| **Network Uplink** | 10 Gbps | 8.8 Gbps Continuous |
| **SSD NVMe IOPS** | 100,000+ IOPS | 150,000+ Read/Write IOPS |
| **CPU Clock Speed** | 3.7 GHz Base | 4.9 GHz Turbo Boost |
| **Subcontinent Latency** | < 25ms Ping | 12ms Regional Ping |

## Hardware & Network Stack Specifications
We deploy only authentic, enterprise-grade components from top silicon manufacturers:
*   **Processors:** AMD EPYC™ 7763 & Ryzen™ 9 5950X processors delivering single-thread execution leadership for game servers and database workloads.
*   **Storage Arrays:** Enterprise PCIe Gen4 NVMe solid-state drives configured in hardware RAID 10 arrays with battery-backed cache controllers.
*   **DDoS Protection:** Line-rate automated Layer 3, Layer 4, and Layer 7 volumetric anti-DDoS scrubbing appliances with zero throughput degradation.
`,
  about: `# About Hector Hosting

India's Premier Game & High-Frequency Cloud Infrastructure Provider. Built for ultra-low latency, carrier-grade uptime, and uncompromised silicon performance.

## Our Genesis & Mission
Founded in 2018 in Mumbai, India, Hector Hosting was established to address a critical gap in the regional cloud ecosystem: Indian game server administrators, independent developers, and digital enterprises were forced to choose between laggy foreign datacenters with high ping or overpriced local hosts offering oversold, legacy hardware.

Our mission is to democratize high-frequency enterprise cloud infrastructure across India by providing genuine AMD Ryzen™ and EPYC™ bare-metal nodes, sub-15ms regional network routing, and transparent Indian Rupee pricing without hidden renewal surprises.

## Operating Philosophy
We believe infrastructure should be "invisible." You focus on coding your application, hosting your game server, and scaling your community—we handle the silicon thermals, 10Gbps fiber routing, hardware RAID redundancy, and volumetric DDoS mitigation.

### Foundational Pillars
1. **Performance First:** Strictly zero CPU overselling. Dedicated high-frequency cores with guaranteed clock speeds, enterprise NVMe storage, and low-latency RAM.
2. **Indian Support that Cares:** Real systems engineers and network administrators based in India available 24/7/365 via live chat, ticket, and WhatsApp support.
3. **Transparent INR Pricing:** Direct Indian Rupee pricing with zero surprise renewal hikes, foreign transaction exchange fees, or hidden bandwidth charges.

## Institutional Growth in India
*   **2018:** Launched our inaugural low-latency AMD Ryzen™ node in Mumbai, India, serving regional game servers.
*   **2020:** Integrated direct NIXI (National Internet Exchange of India) peering and low-ping routing across major Indian ISP networks.
*   **2022:** Surpassed 10,000+ active virtual machines, Minecraft containers, and enterprise workloads across the subcontinent.
*   **2024:** Deployed enterprise AMD EPYC™ 7763 64-core clusters in Tier-4 datacenters in Mumbai with 10Gbps automated DDoS protection.
`,
  locations: ['India (Mumbai)'],
  nodes: ['AMD EPYC 7763', 'Ryzen 9 5950X', 'Intel Core i9-12900K', 'Xeon Platinum']
};

export const FONTS = [
  { id: 'bebas', name: 'Bebas Neue' },
  { id: 'space', name: 'Space Grotesk' },
];

export const COLORS = [
  { id: 'bw', label: 'Classic', hex: '#eeeee9' },
  { id: 'gold', label: 'Gold', hex: '#d4a853' },
  { id: 'blue', label: 'Blue', hex: '#5b9cf6' },
  { id: 'green', label: 'Green', hex: '#4ade80' },
  { id: 'red', label: 'Red', hex: '#f87171' },
  { id: 'purple', label: 'Purple', hex: '#c084fc' },
];
