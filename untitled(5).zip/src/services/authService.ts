/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { 
  GoogleAuthProvider, 
  signInWithPopup, 
  signOut, 
  onAuthStateChanged, 
  User as FirebaseUser,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  updateProfile,
  updatePassword,
  reauthenticateWithCredential,
  EmailAuthProvider
} from 'firebase/auth';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db } from './firebase';
import { pterodactylService } from './pterodactylService';

const provider = new GoogleAuthProvider();

export const ROOT_ADMIN_EMAILS = [
  'anshalmanoj2011@gmail.com',
  'anshalmanojgaming@gmail.com'
];

export const authService = {
  isLoggingIn: false,
  
  async loginWithGoogle() {
    if (this.isLoggingIn) return;
    this.isLoggingIn = true;
    try {
      const result = await signInWithPopup(auth, provider);
      // Ensure user document exists in users collection
      if (result.user) {
        const userEmail = (result.user.email || '').toLowerCase().trim();
        const isRoot = ROOT_ADMIN_EMAILS.includes(userEmail);
        
        let role = isRoot ? 'admin' : 'user';
        let pterodactylId = null;
        let pterodactylUsername = null;

        try {
          const userDoc = await getDoc(doc(db, 'users', result.user.uid));
          if (userDoc.exists()) {
            const data = userDoc.data();
            if (data?.role) role = isRoot ? 'admin' : data.role;
            if (data?.pterodactylId) pterodactylId = data.pterodactylId;
            if (data?.pterodactylUsername) pterodactylUsername = data.pterodactylUsername;
          }
        } catch (e) {
          // ignore error and proceed
        }

        await setDoc(doc(db, 'users', result.user.uid), {
          uid: result.user.uid,
          email: result.user.email,
          displayName: result.user.displayName,
          photoURL: result.user.photoURL,
          role: role,
          lastLogin: serverTimestamp()
        }, { merge: true });

        if (role === 'admin' || isRoot) {
          await setDoc(doc(db, 'admins', result.user.uid), {
            uid: result.user.uid,
            email: result.user.email,
            role: 'admin',
            updatedAt: new Date().toISOString()
          }, { merge: true });
        }
        
        // We return the user object; the caller (UI) will check for pterodactylId and prompt for password if needed
        return {
          user: result.user,
          pterodactylId,
          pterodactylUsername
        };
      }
      return null;
    } catch (error: any) {
      if (error.code === 'auth/cancelled-popup-request' || error.code === 'auth/popup-closed-by-user') {
        console.warn('Login popup was closed or cancelled.');
        return null;
      }
      console.error('Login error:', error);
      throw error;
    } finally {
      this.isLoggingIn = false;
    }
  },

  async loginWithEmail(email: string, pass: string) {
    const result = await signInWithEmailAndPassword(auth, email, pass);
    if (result.user) {
      const userEmail = (result.user.email || email).toLowerCase().trim();
      const isRoot = ROOT_ADMIN_EMAILS.includes(userEmail);
      
      const updates: any = {
        lastLogin: serverTimestamp()
      };
      if (isRoot) {
        updates.role = 'admin';
        await setDoc(doc(db, 'admins', result.user.uid), {
          uid: result.user.uid,
          email: result.user.email,
          role: 'admin',
          updatedAt: new Date().toISOString()
        }, { merge: true });
      }
      await setDoc(doc(db, 'users', result.user.uid), updates, { merge: true });
    }
    return result.user;
  },

  async registerWithEmail(email: string, pass: string, name: string) {
    const result = await createUserWithEmailAndPassword(auth, email, pass);
    if (result.user) {
      const userEmail = email.toLowerCase().trim();
      const isRoot = ROOT_ADMIN_EMAILS.includes(userEmail);
      const role = isRoot ? 'admin' : 'user';

      await updateProfile(result.user, { displayName: name });
      await setDoc(doc(db, 'users', result.user.uid), {
        uid: result.user.uid,
        email: result.user.email,
        displayName: name,
        role: role,
        createdAt: serverTimestamp(),
        lastLogin: serverTimestamp()
      });

      if (isRoot) {
        await setDoc(doc(db, 'admins', result.user.uid), {
          uid: result.user.uid,
          email: result.user.email,
          role: 'admin',
          updatedAt: new Date().toISOString()
        }, { merge: true });
      }

      // Automatically create Pterodactyl Game Panel account on https://gp.hector.host
      try {
        const pteroRes = await pterodactylService.createOrLinkUser({
          email: userEmail,
          name: name,
          password: pass,
          firebaseUid: result.user.uid
        });

        if (pteroRes.success && pteroRes.user) {
          await setDoc(doc(db, 'users', result.user.uid), {
            pterodactylId: pteroRes.user.id,
            pterodactylUsername: pteroRes.user.username,
            pterodactylCreatedAt: pteroRes.user.created_at
          }, { merge: true });
        }
      } catch (pteroErr) {
        console.warn('[Pterodactyl] User registration sync error:', pteroErr);
      }
    }
    return result.user;
  },

  async resetPassword(email: string) {
    await sendPasswordResetEmail(auth, email);
  },

  async sendPasswordResetForCurrentUser(): Promise<void> {
    const user = auth.currentUser;
    if (!user || !user.email) {
      throw new Error("No user email available to send password reset.");
    }
    await sendPasswordResetEmail(auth, user.email);
  },

  async changePassword(currentPassword?: string, newPassword?: string): Promise<{ success: boolean; message: string }> {
    const user = auth.currentUser;
    if (!user) {
      throw new Error("No active user session found. Please log in again.");
    }
    if (!newPassword || newPassword.length < 6) {
      throw new Error("New password must be at least 6 characters long.");
    }

    const isPasswordProvider = user.providerData.some(p => p.providerId === 'password');

    // If email/password account and current password provided, reauthenticate
    if (isPasswordProvider && currentPassword && user.email) {
      try {
        const cred = EmailAuthProvider.credential(user.email, currentPassword);
        await reauthenticateWithCredential(user, cred);
      } catch (err: any) {
        if (err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
          throw new Error("The current password you entered is incorrect.");
        }
        throw err;
      }
    }

    try {
      await updatePassword(user, newPassword);
    } catch (err: any) {
      if (err.code === 'auth/requires-recent-login') {
        throw new Error("Security timeout: Please enter your current password to verify your identity.");
      }
      throw err;
    }

    // Also sync password with Pterodactyl Game Panel if user has game servers
    try {
      await pterodactylService.createOrLinkUser({
        email: user.email || '',
        name: user.displayName || user.email?.split('@')[0] || 'User',
        password: newPassword,
        firebaseUid: user.uid
      });
    } catch (pteroErr) {
      console.warn("Pterodactyl panel password sync note:", pteroErr);
    }

    return { success: true, message: "Password updated successfully across Hector Hosting security systems." };
  },

  async updateDisplayName(name: string): Promise<void> {
    const user = auth.currentUser;
    if (!user) throw new Error("No user currently signed in.");
    await updateProfile(user, { displayName: name });
    await setDoc(doc(db, 'users', user.uid), {
      displayName: name,
      updatedAt: serverTimestamp()
    }, { merge: true });
  },

  async logout() {
    await signOut(auth);
  },

  onAuthStateChanged(callback: (user: FirebaseUser | null) => void) {
    return onAuthStateChanged(auth, callback);
  },

  async isAdmin(uid: string | undefined, email: string | null = null) {
    if (!uid) return false;
    
    if (email && ROOT_ADMIN_EMAILS.includes(email.toLowerCase().trim())) return true;
    
    try {
      const adminDoc = await getDoc(doc(db, 'admins', uid));
      if (adminDoc.exists()) return true;

      // Also check if user doc has role admin
      const userDoc = await getDoc(doc(db, 'users', uid));
      if (userDoc.exists()) {
        const data = userDoc.data();
        if (data?.role === 'admin' || (data?.email && ROOT_ADMIN_EMAILS.includes(data.email.toLowerCase().trim()))) {
          return true;
        }
      }

      return false;
    } catch (error) {
      console.error('Admin check error:', error);
      return false;
    }
  }
};
