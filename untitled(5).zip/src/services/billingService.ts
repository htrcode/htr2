import { collection, query, where, getDocs, addDoc, orderBy } from 'firebase/firestore';
import { db } from './firebase';
import { Invoice, CartItem, UserService } from '../types';
import { userService } from './userService';
import { cartService } from './cartService';

export interface CheckoutOptions {
  utrNumber?: string;
  couponCode?: string;
  discountAmount?: number;
  notes?: string;
  customerInfo?: {
    name?: string;
    email?: string;
    phone?: string;
    discord?: string;
  };
}

export const billingService = {
  async getInvoices(userId: string): Promise<Invoice[]> {
    try {
      const q = query(
        collection(db, 'invoices'), 
        where('userId', '==', userId),
        orderBy('timestamp', 'desc')
      );
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as Invoice));
    } catch (err) {
      console.warn('Error fetching invoices from Firestore:', err);
      return [];
    }
  },

  async checkout(
    userId: string, 
    cart: CartItem[], 
    method: string,
    options?: CheckoutOptions
  ): Promise<{ invoiceId: string; invoiceNumber: string; totalPaid: number }> {
    if (cart.length === 0) throw new Error("Cart is empty");

    const grossTotal = cart.reduce((sum, item) => {
      const price = parseFloat(item.price.replace(/[^0-9.]/g, ''));
      return sum + (price * item.quantity);
    }, 0);

    const discount = options?.discountAmount || 0;
    const finalTotal = Math.max(0, grossTotal - discount);
    const invoiceNumber = `INV-${Date.now().toString().slice(-6)}`;
    
    // 1. Create Invoice
    const invoiceData: Omit<Invoice, 'id'> = {
      userId,
      invoiceNumber,
      items: cart.map(item => ({
        name: item.name,
        price: item.price,
        quantity: item.quantity,
        category: item.category || '',
        planId: item.planId
      })),
      total: `₹${finalTotal.toFixed(2)}`,
      status: 'Unpaid', // Set to Unpaid initially for verification
      method: method || 'UPI',
      paymentMethod: method || 'UPI',
      timestamp: new Date().toISOString()
    };

    const invoiceRef = await addDoc(collection(db, 'invoices'), {
      ...invoiceData,
      grossTotal: `₹${grossTotal.toFixed(2)}`,
      discount: discount > 0 ? `₹${discount.toFixed(2)}` : null,
      couponCode: options?.couponCode || null,
      utrNumber: options?.utrNumber || null,
      customerInfo: options?.customerInfo || null,
      notes: options?.notes || null
    });

    // 2. Provision Services in user_services
    for (const item of cart) {
      for (let i = 0; i < item.quantity; i++) {
        const isGame = (item.category || '').toLowerCase().includes('game') || (item.name || '').toLowerCase().includes('minecraft');
        const isVPS = (item.category || '').toLowerCase().includes('vps') || (item.category || '').toLowerCase().includes('dedicated');
        const randomIp = `103.195.${Math.floor(100 + Math.random() * 50)}.${Math.floor(10 + Math.random() * 240)}`;
        const assignedPort = isGame ? 25565 + Math.floor(Math.random() * 400) : (isVPS ? 22 : 80);

        const serviceData: Omit<UserService, 'id'> = {
          userId,
          planId: item.planId,
          name: item.name,
          category: item.category || 'Hosting Service',
          price: item.price,
          invoiceId: invoiceRef.id,
          status: 'pending',
          location: item.location || 'Mumbai, India (NIXI 10Gbps)',
          nodeName: `${isGame ? 'Game Instance' : 'Cloud Instance'} #${Math.floor(100 + Math.random() * 900)}`,
          ip: randomIp,
          port: assignedPort,
          panelLink: 'https://gp.hector.host',
          serverType: isVPS ? 'vps_dedicated' : 'panel',
          expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
          createdAt: new Date().toISOString(),
          autoRenew: true
        };
        await addDoc(collection(db, 'user_services'), serviceData);
      }
    }

    // 3. Clear Cart for this user
    await cartService.clearCart(userId);

    // 4. Log User Activity
    await userService.logActivity(
      userId, 
      'purchase', 
      `Ordered ${cart.length} service(s) [${invoiceNumber}]. Payment method: ${method}.`
    );

    return {
      invoiceId: invoiceRef.id,
      invoiceNumber,
      totalPaid: finalTotal
    };
  }
};
