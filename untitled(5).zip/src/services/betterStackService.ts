import axios from 'axios';

export interface BetterStackMonitor {
  id: string;
  name: string;
  url: string;
  status: 'up' | 'down' | 'paused' | 'pending' | 'maintenance';
  monitor_type: string;
  last_checked_at: string | null;
  check_frequency: number;
  regions: string[];
  paused: boolean;
}

export interface BetterStackResource {
  id: string;
  public_name: string;
  resource_id: number | null;
  section_id: number | null;
  section_name?: string;
  status: 'operational' | 'downtime' | 'degraded' | 'maintenance' | 'not_monitored';
  availability: number;
  history: Array<{
    day: string;
    status: string;
    downtime_duration: number;
    maintenance_duration: number;
  }>;
  url?: string;
}

export interface BetterStackIncident {
  id: string;
  name: string;
  url: string;
  cause: string;
  status: 'Ongoing' | 'Acknowledged' | 'Resolved' | string;
  started_at: string;
  resolved_at: string | null;
  regions: string[];
  severity: 'critical' | 'major' | 'minor' | 'info';
  description?: string;
}

export interface BetterStackStatusResponse {
  provider: 'betterstack';
  status_page: {
    id: string;
    company_name: string;
    subdomain: string;
    custom_domain: string;
    aggregate_state: 'operational' | 'degraded' | 'downtime' | string;
    published: boolean;
    timezone: string;
  };
  summary: {
    overall_status: 'operational' | 'degraded' | 'outage' | 'maintenance';
    uptime_percentage: string;
    monitored_nodes_count: number;
    active_incidents_count: number;
    last_updated: string;
  };
  sections: Array<{
    id: number;
    name: string;
    position: number;
    resources: BetterStackResource[];
  }>;
  monitors: BetterStackMonitor[];
  incidents: BetterStackIncident[];
}

export const betterStackService = {
  async getStatus(forceRefresh = false): Promise<BetterStackStatusResponse> {
    const url = forceRefresh ? '/api/status?refresh=true' : '/api/status';
    const response = await axios.get<BetterStackStatusResponse>(url);
    const data = response.data;

    // Safety normalizer: If sections array is empty or missing from API,
    // automatically generate sections from monitors so the UI ALWAYS displays all monitors!
    if ((!data.sections || data.sections.length === 0) && data.monitors && data.monitors.length > 0) {
      const resources: BetterStackResource[] = data.monitors.map(m => ({
        id: String(m.id),
        public_name: m.name,
        resource_id: parseInt(m.id) || null,
        section_id: m.monitor_type === 'ping' ? 2 : 1,
        section_name: m.monitor_type === 'ping' ? 'Compute & Dedicated Nodes' : 'Core Services & Panels',
        status: (m.status === 'up' ? 'operational' : m.status === 'down' ? 'downtime' : m.status === 'maintenance' ? 'maintenance' : 'operational') as BetterStackResource['status'],
        availability: 1,
        history: [],
        url: m.url
      }));

      const coreResources = resources.filter(r => r.section_id === 1);
      const nodeResources = resources.filter(r => r.section_id === 2);

      data.sections = [
        {
          id: 1,
          name: 'Core Services & Panels',
          position: 1,
          resources: coreResources.length > 0 ? coreResources : resources
        },
        ...(nodeResources.length > 0 ? [{
          id: 2,
          name: 'Compute & Dedicated Nodes',
          position: 2,
          resources: nodeResources
        }] : [])
      ];
    }

    return data;
  },

  async refreshStatus(): Promise<BetterStackStatusResponse> {
    const response = await axios.post<{ success: boolean; data: BetterStackStatusResponse }>('/api/status/refresh');
    return response.data.data;
  },

  async toggleMonitor(monitorId: string, paused: boolean): Promise<any> {
    const response = await axios.post(`/api/status/monitors/${monitorId}/toggle`, { paused });
    return response.data;
  }
};
