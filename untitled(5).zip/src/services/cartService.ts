import { collection, query, where, getDocs, deleteDoc, doc, updateDoc, setDoc } from 'firebase/firestore';
import { db } from './firebase';
import { CartItem } from '../types';

const GUEST_CART_KEY = 'hector_hosting_guest_cart';

const getGuestCart = (): CartItem[] => {
  try {
    const raw = localStorage.getItem(GUEST_CART_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (err) {
    console.error('Error reading guest cart from localStorage:', err);
    return [];
  }
};

const saveGuestCart = (cart: CartItem[]): void => {
  try {
    localStorage.setItem(GUEST_CART_KEY, JSON.stringify(cart));
  } catch (err) {
    console.error('Error saving guest cart to localStorage:', err);
  }
};

export const cartService = {
  async getCart(userId?: string | null): Promise<CartItem[]> {
    if (!userId) {
      return getGuestCart();
    }

    try {
      // 1. Check if there are guest items to migrate
      const guestItems = getGuestCart();
      if (guestItems.length > 0) {
        for (const gItem of guestItems) {
          const docId = `${userId}_${gItem.planId}_${gItem.billingCycle || 'monthly'}`.replace(/[^a-zA-Z0-9_-]/g, '_');
          await setDoc(doc(db, 'carts', docId), {
            ...gItem,
            userId,
            id: docId
          }, { merge: true });
        }
        localStorage.removeItem(GUEST_CART_KEY);
      }

      // 2. Fetch all user items
      const q = query(collection(db, 'carts'), where('userId', '==', userId));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(d => ({ ...d.data(), id: d.id } as CartItem));
    } catch (err) {
      console.warn('Firestore getCart failed, falling back to local guest cart:', err);
      return getGuestCart();
    }
  },

  async addToCart(userId: string | null | undefined, item: Omit<CartItem, 'id' | 'userId'>): Promise<void> {
    if (!userId) {
      const guestCart = getGuestCart();
      const existingIdx = guestCart.findIndex(i => i.planId === item.planId && i.billingCycle === item.billingCycle);
      if (existingIdx >= 0) {
        guestCart[existingIdx].quantity += (item.quantity || 1);
      } else {
        guestCart.push({
          ...item,
          id: `guest_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          userId: 'guest',
          quantity: item.quantity || 1
        });
      }
      saveGuestCart(guestCart);
      return;
    }

    const docId = `${userId}_${item.planId}_${item.billingCycle || 'monthly'}`.replace(/[^a-zA-Z0-9_-]/g, '_');
    const cartItemRef = doc(db, 'carts', docId);
    
    try {
      const currentCart = await this.getCart(userId);
      const existing = currentCart.find(i => i.id === docId || (i.planId === item.planId && i.billingCycle === item.billingCycle));

      if (existing) {
        await updateDoc(cartItemRef, {
          quantity: existing.quantity + (item.quantity || 1)
        });
      } else {
        await setDoc(cartItemRef, {
          ...item,
          userId,
          quantity: item.quantity || 1,
          createdAt: new Date().toISOString()
        });
      }
    } catch (err) {
      console.error('Firestore addToCart error, storing in local fallback:', err);
      const guestCart = getGuestCart();
      guestCart.push({
        ...item,
        id: docId,
        userId,
        quantity: item.quantity || 1
      });
      saveGuestCart(guestCart);
    }
  },

  async updateQuantity(itemId: string, quantity: number, userId?: string | null): Promise<void> {
    if (quantity <= 0) {
      await this.removeFromCart(itemId, userId);
      return;
    }

    if (!userId || itemId.startsWith('guest_')) {
      const guestCart = getGuestCart();
      const target = guestCart.find(i => i.id === itemId);
      if (target) {
        target.quantity = quantity;
        saveGuestCart(guestCart);
      }
      return;
    }

    try {
      await updateDoc(doc(db, 'carts', itemId), { quantity });
    } catch (err) {
      console.error('Firestore updateQuantity failed:', err);
    }
  },

  async removeFromCart(itemId: string, userId?: string | null): Promise<void> {
    if (!userId || itemId.startsWith('guest_')) {
      const guestCart = getGuestCart().filter(i => i.id !== itemId);
      saveGuestCart(guestCart);
      return;
    }

    try {
      await deleteDoc(doc(db, 'carts', itemId));
    } catch (err) {
      console.error('Firestore removeFromCart failed:', err);
      const guestCart = getGuestCart().filter(i => i.id !== itemId);
      saveGuestCart(guestCart);
    }
  },

  async clearCart(userId?: string | null): Promise<void> {
    localStorage.removeItem(GUEST_CART_KEY);
    if (!userId) return;

    try {
      const cart = await this.getCart(userId);
      const promises = cart.map(item => item.id && deleteDoc(doc(db, 'carts', item.id)));
      await Promise.all(promises);
    } catch (err) {
      console.error('Firestore clearCart failed:', err);
    }
  }
};
