/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { 
  collection, doc, getDoc, getDocs, setDoc, addDoc, updateDoc, deleteDoc, 
  query, orderBy, onSnapshot, where 
} from 'firebase/firestore';
import { db, OperationType, handleFirestoreError } from './firebase';
import { Settings, Plan, Testimonial, Feedback, AppData, ServiceStatus, StatusIncident, Game } from '../types';
import { ROOT_ADMIN_EMAILS } from './authService';

export const dataService = {
  // Site Config
  async getSettings(): Promise<Partial<AppData> | null> {
    const path = 'config/site';
    try {
      const snap = await getDoc(doc(db, path));
      return snap.exists() ? snap.data() as Partial<AppData> : null;
    } catch (e) {
      handleFirestoreError(e, OperationType.GET, path);
      return null;
    }
  },

  async updateSettings(settings: Partial<AppData>) {
    const path = 'config/site';
    try {
      await setDoc(doc(db, path), settings, { merge: true });
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, path);
    }
  },

  // Plans
  async getPlans(): Promise<Plan[]> {
    const path = 'plans';
    try {
      const snap = await getDocs(query(collection(db, path)));
      return snap.docs.map(d => ({ ...d.data(), id: d.id } as Plan));
    } catch (e) {
      handleFirestoreError(e, OperationType.LIST, path);
      return [];
    }
  },

  async addPlan(plan: Omit<Plan, 'id'>) {
    const path = 'plans';
    try {
      const docRef = await addDoc(collection(db, path), plan);
      return docRef.id;
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, path);
    }
  },

  async updatePlan(id: string, plan: Partial<Plan>) {
    const path = `plans/${id}`;
    try {
      await updateDoc(doc(db, 'plans', id), plan);
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, path);
    }
  },

  async deletePlan(id: string) {
    const path = `plans/${id}`;
    try {
      await deleteDoc(doc(db, 'plans', id));
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, path);
    }
  },

  // Statuses
  async getStatuses(): Promise<ServiceStatus[]> {
    const path = 'statuses';
    try {
      const snap = await getDocs(collection(db, path));
      return snap.docs.map(d => ({ ...d.data(), id: d.id } as ServiceStatus));
    } catch (e) {
      handleFirestoreError(e, OperationType.LIST, path);
      return [];
    }
  },

  subscribeStatuses(callback: (statuses: ServiceStatus[]) => void) {
    const path = 'statuses';
    return onSnapshot(
      collection(db, path),
      (snap) => {
        const statuses = snap.docs.map(d => ({ ...d.data(), id: d.id } as ServiceStatus));
        const unique = Array.from(new Map(statuses.map(item => [item.id, item])).values());
        callback(unique);
      },
      (e) => {
        console.error(`Snapshot listener error on ${path}:`, e);
      }
    );
  },

  async addStatus(status: Omit<ServiceStatus, 'id'>) {
    const path = 'statuses';
    try {
      const docRef = await addDoc(collection(db, path), status);
      return docRef.id;
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, path);
    }
  },

  async updateStatus(id: string, status: Partial<ServiceStatus>) {
    const path = `statuses/${id}`;
    try {
      await updateDoc(doc(db, 'statuses', id), status);
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, path);
    }
  },

  async deleteStatus(id: string) {
    const path = `statuses/${id}`;
    try {
      await deleteDoc(doc(db, 'statuses', id));
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, path);
    }
  },

  // Incidents
  async getIncidents(): Promise<StatusIncident[]> {
    const path = 'incidents';
    try {
      const snap = await getDocs(query(collection(db, path), orderBy('createdAt', 'desc')));
      return snap.docs.map(d => ({ ...d.data(), id: d.id } as StatusIncident));
    } catch (e) {
      handleFirestoreError(e, OperationType.LIST, path);
      return [];
    }
  },

  subscribeIncidents(callback: (incidents: StatusIncident[]) => void) {
    const path = 'incidents';
    return onSnapshot(
      query(collection(db, path), orderBy('createdAt', 'desc')),
      (snap) => {
        const incidents = snap.docs.map(d => ({ ...d.data(), id: d.id } as StatusIncident));
        callback(incidents);
      },
      (e) => {
        console.error(`Snapshot listener error on ${path}:`, e);
      }
    );
  },

  async addIncident(incident: Omit<StatusIncident, 'id'>) {
    const path = 'incidents';
    try {
      const docRef = await addDoc(collection(db, path), incident);
      return docRef.id;
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, path);
    }
  },

  async updateIncident(id: string, incident: Partial<StatusIncident>) {
    const path = `incidents/${id}`;
    try {
      await updateDoc(doc(db, 'incidents', id), incident);
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, path);
    }
  },

  async deleteIncident(id: string) {
    const path = `incidents/${id}`;
    try {
      await deleteDoc(doc(db, 'incidents', id));
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, path);
    }
  },

  // Testimonials
  async getTestimonials(): Promise<Testimonial[]> {
    const path = 'testimonials';
    try {
      const snap = await getDocs(collection(db, path));
      return snap.docs.map(d => ({ ...d.data(), id: d.id } as Testimonial));
    } catch (e) {
      handleFirestoreError(e, OperationType.LIST, path);
      return [];
    }
  },

  async addTestimonial(t: Omit<Testimonial, 'id'>) {
    const path = 'testimonials';
    try {
      const docRef = await addDoc(collection(db, path), t);
      return docRef.id;
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, path);
    }
  },

  async updateTestimonial(id: string, t: Partial<Testimonial>) {
    const path = `testimonials/${id}`;
    try {
      await updateDoc(doc(db, 'testimonials', id), t);
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, path);
    }
  },

  async deleteTestimonial(id: string) {
    const path = `testimonials/${id}`;
    try {
      await deleteDoc(doc(db, 'testimonials', id));
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, path);
    }
  },

  // Feedbacks
  async addFeedback(feedback: Omit<Feedback, 'id'>) {
    const path = 'feedbacks';
    try {
      const docRef = await addDoc(collection(db, path), feedback);
      return docRef.id;
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, path);
    }
  },

  async updateFeedback(id: string, feedback: Partial<Feedback>) {
    const path = `feedbacks/${id}`;
    try {
      await updateDoc(doc(db, 'feedbacks', id), feedback);
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, path);
    }
  },

  async deleteFeedback(id: string) {
    const path = `feedbacks/${id}`;
    try {
      await deleteDoc(doc(db, 'feedbacks', id));
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, path);
    }
  },

  // Games
  async getGames(): Promise<Game[]> {
    const path = 'games';
    try {
      const snap = await getDocs(query(collection(db, path), orderBy('order', 'asc')));
      return snap.docs.map(d => ({ ...d.data(), id: d.id } as Game));
    } catch (e) {
      handleFirestoreError(e, OperationType.LIST, path);
      return [];
    }
  },

  async addGame(game: Omit<Game, 'id'>) {
    const path = 'games';
    try {
      const docRef = await addDoc(collection(db, path), game);
      return docRef.id;
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, path);
    }
  },

  async updateGame(id: string, game: Partial<Game>) {
    const path = `games/${id}`;
    try {
      await updateDoc(doc(db, 'games', id), game);
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, path);
    }
  },

  async deleteGame(id: string) {
    const path = `games/${id}`;
    console.log(`[DataService] Attempting to delete game document: ${path}`);
    try {
      await deleteDoc(doc(db, 'games', id));
      console.log(`[DataService] Successfully deleted game document: ${path}`);
    } catch (e) {
      console.error(`[DataService] Failed to delete game document: ${path}`, e);
      handleFirestoreError(e, OperationType.DELETE, path);
    }
  },

  subscribeFeedbacks(callback: (feedbacks: Feedback[]) => void) {
    const path = 'feedbacks';
    return onSnapshot(
      query(collection(db, path), orderBy('time', 'desc')), 
      (snap) => {
        const feedbacks = snap.docs.map(d => ({ ...d.data(), id: d.id } as Feedback));
        // Defensive: Deduplicate feedbacks by document ID
        const uniqueFeedbacks = Array.from(new Map(feedbacks.map(item => [item.id, item])).values());
        callback(uniqueFeedbacks);
      },
      (e) => {
        console.error(`Snapshot listener error on ${path}:`, e);
      }
    );
  },

  // Admins
  async getAdmins(): Promise<{ uid: string, email: string }[]> {
    const path = 'admins';
    try {
      const snap = await getDocs(collection(db, path));
      const list = snap.docs.map(d => ({ uid: d.id, ...d.data() } as { uid: string, email: string }));
      
      for (const email of ROOT_ADMIN_EMAILS) {
        if (!list.some(a => (a.email && a.email.toLowerCase().trim() === email.toLowerCase().trim()) || a.uid === email)) {
          list.push({ uid: email, email });
        }
      }
      return list;
    } catch (e) {
      handleFirestoreError(e, OperationType.LIST, path);
      return ROOT_ADMIN_EMAILS.map(email => ({ uid: email, email }));
    }
  },

  async addAdmin(uid: string, email: string) {
    const path = `admins/${uid}`;
    try {
      await setDoc(doc(db, 'admins', uid), { email });
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, path);
    }
  },

  async deleteAdmin(uid: string) {
    const path = `admins/${uid}`;
    try {
      await deleteDoc(doc(db, 'admins', uid));
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, path);
    }
  },

  // Seed Default Data
  async seedAllDefaultData(defaultData: AppData) {
    try {
      // 1. Config Site - Flatten the settings to match blueprint
      await setDoc(doc(db, 'config', 'site'), {
        ...defaultData.settings,
        privacy: defaultData.privacy,
        refund: defaultData.refund,
        tos: defaultData.tos,
        legal: defaultData.legal,
        infrastructure: defaultData.infrastructure,
        about: defaultData.about,
        categories: defaultData.categories,
        locations: defaultData.locations,
        nodes: defaultData.nodes
      }, { merge: true });

      // 2. Plans
      for (const plan of defaultData.plans) {
        const { id, ...planData } = plan;
        if (id) {
          await setDoc(doc(db, 'plans', id), planData, { merge: true });
        } else {
          await addDoc(collection(db, 'plans'), planData);
        }
      }

      // 3. Statuses
      if (defaultData.statuses) {
        for (const status of defaultData.statuses) {
          const { id, ...statusData } = status;
          if (id) {
            await setDoc(doc(db, 'statuses', id), statusData, { merge: true });
          } else {
            await addDoc(collection(db, 'statuses'), statusData);
          }
        }
      }

      // 4. Games
      if (defaultData.games) {
        for (const game of defaultData.games) {
          const { id, ...gameData } = game;
          if (id) {
            await setDoc(doc(db, 'games', id), gameData, { merge: true });
          } else {
            await addDoc(collection(db, 'games'), gameData);
          }
        }
      }

      // 5. Testimonials
      for (const t of defaultData.testimonials) {
        const { id, ...tData } = t;
        if (id) {
          await setDoc(doc(db, 'testimonials', id), tData, { merge: true });
        } else {
          await addDoc(collection(db, 'testimonials'), tData);
        }
      }
      return true;
    } catch (e) {
      console.error('Failed to seed default data:', e);
      return false;
    }
  }
};
