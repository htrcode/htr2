import { 
  collection, 
  query, 
  where, 
  getDocs, 
  getDoc,
  doc, 
  setDoc, 
  addDoc, 
  updateDoc,
  deleteDoc, 
  orderBy, 
  onSnapshot,
  serverTimestamp 
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { Ticket, TicketMessage, TicketStatus, TicketPriority, TicketDepartment } from '../types';
import { userService } from './userService';

export const ticketService = {
  // Generate random readable ticket number TICK-XXXX
  generateTicketNumber(): string {
    const randomNum = Math.floor(1000 + Math.random() * 9000);
    return `TICK-${randomNum}`;
  },

  // Create a new support ticket with initial message
  async createTicket(payload: {
    userId: string;
    userEmail: string;
    userName?: string;
    subject: string;
    department: TicketDepartment;
    priority: TicketPriority;
    initialMessage: string;
    serviceId?: string;
    serviceName?: string;
  }): Promise<string> {
    const path = 'tickets';
    try {
      const now = new Date().toISOString();
      const ticketRef = doc(collection(db, path));
      const ticketId = ticketRef.id;
      const ticketNumber = this.generateTicketNumber();

      const ticketData: Ticket = {
        id: ticketId,
        ticketNumber,
        userId: payload.userId,
        userEmail: payload.userEmail,
        userName: payload.userName || payload.userEmail.split('@')[0],
        subject: payload.subject.trim(),
        department: payload.department,
        priority: payload.priority,
        status: 'open',
        serviceId: payload.serviceId || '',
        serviceName: payload.serviceName || '',
        createdAt: now,
        updatedAt: now,
        lastMessage: payload.initialMessage.trim().substring(0, 150),
        lastReplyBy: 'user',
        unreadByAdmin: true,
        unreadByUser: false
      };

      await setDoc(ticketRef, ticketData);

      // Add the first conversation message
      const msgRef = doc(collection(db, 'ticket_messages'));
      const initialMsg: TicketMessage = {
        id: msgRef.id,
        ticketId: ticketId,
        ticketUserId: payload.userId,
        senderId: payload.userId,
        senderEmail: payload.userEmail,
        senderName: payload.userName || payload.userEmail.split('@')[0],
        senderRole: 'user',
        message: payload.initialMessage.trim(),
        createdAt: now
      };

      await setDoc(msgRef, initialMsg);

      // Log user activity if authenticated user (skip for guest users)
      if (!payload.userId.startsWith('guest_')) {
        try {
          await userService.logActivity(
            payload.userId, 
            'support', 
            `Created support ticket #${ticketNumber}: "${payload.subject.trim()}"`
          );
        } catch (err) {
          console.warn('Could not log user activity for ticket:', err);
        }
      }

      return ticketId;
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
      throw error;
    }
  },

  // Lookup ticket by Ticket Number & Email
  async findTicketByNumberAndEmail(ticketNumber: string, email: string): Promise<Ticket | null> {
    const path = 'tickets';
    try {
      const q = query(
        collection(db, path),
        where('ticketNumber', '==', ticketNumber.trim().toUpperCase())
      );
      const snapshot = await getDocs(q);
      if (snapshot.empty) return null;
      const t = { id: snapshot.docs[0].id, ...snapshot.docs[0].data() } as Ticket;
      if ((t.userEmail || '').toLowerCase().trim() === email.toLowerCase().trim()) {
        return t;
      }
      return null;
    } catch (error) {
      console.error('Error finding ticket by number:', error);
      return null;
    }
  },

  // Get tickets for a specific user
  async getUserTickets(userId: string): Promise<Ticket[]> {
    const path = 'tickets';
    try {
      let snapshot;
      try {
        const q = query(
          collection(db, path),
          where('userId', '==', userId),
          orderBy('updatedAt', 'desc')
        );
        snapshot = await getDocs(q);
      } catch (err) {
        // Fallback without ordering if composite index is pending
        const qFallback = query(
          collection(db, path),
          where('userId', '==', userId)
        );
        snapshot = await getDocs(qFallback);
      }

      const tickets = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Ticket));
      // In-memory sort fallback
      tickets.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
      return tickets;
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
      return [];
    }
  },

  // Admin: Get all tickets across all users
  async getAllTickets(): Promise<Ticket[]> {
    const path = 'tickets';
    try {
      let snapshot;
      try {
        const q = query(collection(db, path), orderBy('updatedAt', 'desc'));
        snapshot = await getDocs(q);
      } catch (err) {
        snapshot = await getDocs(collection(db, path));
      }

      const tickets = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Ticket));
      tickets.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
      return tickets;
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
      return [];
    }
  },

  // Get a single ticket by ID
  async getTicket(ticketId: string): Promise<Ticket | null> {
    const path = `tickets/${ticketId}`;
    try {
      const snap = await getDoc(doc(db, 'tickets', ticketId));
      if (!snap.exists()) return null;
      return { id: snap.id, ...snap.data() } as Ticket;
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, path);
      return null;
    }
  },

  // Get messages for a ticket
  async getTicketMessages(ticketId: string): Promise<TicketMessage[]> {
    const path = 'ticket_messages';
    try {
      let snapshot;
      try {
        const q = query(
          collection(db, path),
          where('ticketId', '==', ticketId),
          orderBy('createdAt', 'asc')
        );
        snapshot = await getDocs(q);
      } catch (err) {
        const qFallback = query(
          collection(db, path),
          where('ticketId', '==', ticketId)
        );
        snapshot = await getDocs(qFallback);
      }

      const msgs = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as TicketMessage));
      msgs.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
      return msgs;
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
      return [];
    }
  },

  // Send a reply message in a ticket thread
  async addReply(
    ticketId: string,
    ticketUserId: string,
    sender: {
      uid: string;
      email: string;
      name: string;
      role: 'admin' | 'user';
    },
    message: string
  ): Promise<TicketMessage> {
    const path = 'ticket_messages';
    try {
      const now = new Date().toISOString();
      const msgRef = doc(collection(db, path));
      
      const newMsg: TicketMessage = {
        id: msgRef.id,
        ticketId,
        ticketUserId,
        senderId: sender.uid,
        senderEmail: sender.email,
        senderName: sender.name,
        senderRole: sender.role,
        message: message.trim(),
        createdAt: now
      };

      await setDoc(msgRef, newMsg);

      // Update ticket metadata
      const ticketUpdates: Partial<Ticket> = {
        updatedAt: now,
        lastMessage: message.trim().substring(0, 150),
        lastReplyBy: sender.role
      };

      if (sender.role === 'admin') {
        ticketUpdates.status = 'in_progress';
        ticketUpdates.unreadByUser = true;
        ticketUpdates.unreadByAdmin = false;
      } else {
        ticketUpdates.status = 'open';
        ticketUpdates.unreadByAdmin = true;
        ticketUpdates.unreadByUser = false;
      }

      await setDoc(doc(db, 'tickets', ticketId), ticketUpdates, { merge: true });

      return newMsg;
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
      throw error;
    }
  },

  // Update ticket status
  async updateTicketStatus(ticketId: string, status: TicketStatus): Promise<void> {
    const path = `tickets/${ticketId}`;
    try {
      const now = new Date().toISOString();
      await setDoc(doc(db, 'tickets', ticketId), {
        status,
        updatedAt: now
      }, { merge: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
      throw error;
    }
  },

  // Update ticket priority
  async updateTicketPriority(ticketId: string, priority: TicketPriority): Promise<void> {
    const path = `tickets/${ticketId}`;
    try {
      const now = new Date().toISOString();
      await setDoc(doc(db, 'tickets', ticketId), {
        priority,
        updatedAt: now
      }, { merge: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
      throw error;
    }
  },

  // Mark ticket as read by user or admin
  async markTicketRead(ticketId: string, viewerRole: 'admin' | 'user'): Promise<void> {
    const path = `tickets/${ticketId}`;
    try {
      const updates = viewerRole === 'admin' 
        ? { unreadByAdmin: false } 
        : { unreadByUser: false };
      await setDoc(doc(db, 'tickets', ticketId), updates, { merge: true });
    } catch (error) {
      // Non-critical, ignore silent error
    }
  },

  // Delete a ticket and its messages
  async deleteTicket(ticketId: string): Promise<void> {
    const path = `tickets/${ticketId}`;
    try {
      await deleteDoc(doc(db, 'tickets', ticketId));
      
      // Clean up messages
      const msgsQuery = query(collection(db, 'ticket_messages'), where('ticketId', '==', ticketId));
      const msgsSnap = await getDocs(msgsQuery);
      for (const msgDoc of msgsSnap.docs) {
        await deleteDoc(doc(db, 'ticket_messages', msgDoc.id));
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
      throw error;
    }
  },

  // Real-time listener for user tickets
  subscribeToUserTickets(userId: string, callback: (tickets: Ticket[]) => void) {
    const q = query(
      collection(db, 'tickets'),
      where('userId', '==', userId)
    );
    return onSnapshot(q, (snap) => {
      const tickets = snap.docs.map(d => ({ id: d.id, ...d.data() } as Ticket));
      tickets.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
      callback(tickets);
    }, (error) => {
      console.error('Error subscribing to user tickets:', error);
    });
  },

  // Real-time listener for all tickets (Admin)
  subscribeToAllTickets(callback: (tickets: Ticket[]) => void) {
    const q = query(collection(db, 'tickets'));
    return onSnapshot(q, (snap) => {
      const tickets = snap.docs.map(d => ({ id: d.id, ...d.data() } as Ticket));
      tickets.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
      callback(tickets);
    }, (error) => {
      console.error('Error subscribing to all tickets:', error);
    });
  },

  // Real-time listener for messages of a ticket
  subscribeToTicketMessages(ticketId: string, callback: (msgs: TicketMessage[]) => void) {
    const q = query(
      collection(db, 'ticket_messages'),
      where('ticketId', '==', ticketId)
    );
    return onSnapshot(q, (snap) => {
      const msgs = snap.docs.map(d => ({ id: d.id, ...d.data() } as TicketMessage));
      msgs.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
      callback(msgs);
    }, (error) => {
      console.error('Error subscribing to ticket messages:', error);
    });
  }
};
