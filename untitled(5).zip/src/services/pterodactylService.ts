import axios from 'axios';
import { PterodactylUser, PterodactylServer, PterodactylNode } from '../types';

export interface PterodactylStatusResponse {
  connected: boolean;
  panelUrl: string;
  latency?: string;
  stats: {
    totalUsers: number;
    totalServers: number;
    totalNodes: number;
  };
  nodes: PterodactylNode[];
  error?: string;
}

export interface PterodactylCreateUserResponse {
  success: boolean;
  user: PterodactylUser;
  panelUrl: string;
  alreadyExisted: boolean;
  message?: string;
  error?: string;
}

export const pterodactylService = {
  // Check panel status and telemetry
  async getStatus(): Promise<PterodactylStatusResponse> {
    try {
      const res = await axios.get('/api/pterodactyl/status');
      return res.data;
    } catch (err: any) {
      return {
        connected: false,
        panelUrl: 'https://gp.hector.host',
        stats: { totalUsers: 0, totalServers: 0, totalNodes: 0 },
        nodes: [],
        error: err.response?.data?.error || err.message
      };
    }
  },

  // Create or link a Pterodactyl account for a user (called during registration or login)
  async createOrLinkUser(params: {
    email: string;
    username?: string;
    name?: string;
    password?: string;
    firebaseUid?: string;
  }): Promise<PterodactylCreateUserResponse> {
    try {
      const res = await axios.post('/api/pterodactyl/create-user', params);
      return res.data;
    } catch (err: any) {
      console.error('Failed to create/link Pterodactyl user:', err.response?.data || err.message);
      return {
        success: false,
        user: {} as PterodactylUser,
        panelUrl: 'https://gp.hector.host',
        alreadyExisted: false,
        error: err.response?.data?.error || err.message
      };
    }
  },

  // Update password directly on Pterodactyl panel account
  async updatePassword(params: {
    email: string;
    password: string;
    firebaseUid?: string;
  }): Promise<{ success: boolean; message?: string; error?: string; user?: any }> {
    try {
      const res = await axios.post('/api/pterodactyl/update-password', params);
      return res.data;
    } catch (err: any) {
      const errorMsg = err.response?.data?.error || err.message;
      return {
        success: false,
        error: errorMsg
      };
    }
  },

  // List all users from panel (admin)
  async getUsers(page: number = 1, perPage: number = 50): Promise<{ users: PterodactylUser[]; meta?: any }> {
    try {
      const res = await axios.get(`/api/pterodactyl/users?page=${page}&per_page=${perPage}`);
      const data = res.data;
      if (data?.users) return data;
      if (Array.isArray(data?.data)) {
        const users = data.data.map((item: any) => item.attributes || item);
        return { users, meta: data.meta };
      }
      return { users: [] };
    } catch (err: any) {
      return { users: [] };
    }
  },

  // List all servers from panel
  async getServers(page: number = 1, perPage: number = 50): Promise<{ servers: PterodactylServer[]; meta?: any }> {
    try {
      const res = await axios.get(`/api/pterodactyl/servers?page=${page}&per_page=${perPage}`);
      const data = res.data;
      if (data?.servers) return data;
      if (Array.isArray(data?.data)) {
        const servers = data.data.map((item: any) => item.attributes || item);
        return { servers, meta: data.meta };
      }
      return { servers: [] };
    } catch (err: any) {
      return { servers: [] };
    }
  },

  // List nodes
  async getNodes(): Promise<PterodactylNode[]> {
    try {
      const res = await axios.get('/api/pterodactyl/nodes');
      return res.data.nodes || [];
    } catch (err: any) {
      return [];
    }
  }
};
