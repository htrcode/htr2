import { collection, query, getDocs, doc, orderBy, getDoc, deleteDoc, setDoc, addDoc } from 'firebase/firestore';
import { db } from './firebase';
import { Invoice, UserService, Settings, UserProfile } from '../types';
import { ROOT_ADMIN_EMAILS } from './authService';

export const adminService = {
  // Invoices Management
  async getAllInvoices(): Promise<Invoice[]> {
    try {
      let snapshot;
      try {
        const q = query(collection(db, 'invoices'), orderBy('timestamp', 'desc'));
        snapshot = await getDocs(q);
      } catch (err) {
        snapshot = await getDocs(collection(db, 'invoices'));
      }
      return snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as Invoice));
    } catch (e) {
      console.error("Error fetching invoices:", e);
      return [];
    }
  },

  async updateInvoiceStatus(invoiceId: string, status: Invoice['status']): Promise<void> {
    await setDoc(doc(db, 'invoices', invoiceId), { status }, { merge: true });
  },

  async createInvoice(invoice: Invoice): Promise<string> {
    const invoiceDocId = invoice.id || `INV-${Date.now().toString().slice(-6)}`;
    const invoiceData = {
      ...invoice,
      id: invoiceDocId
    };
    await setDoc(doc(db, 'invoices', invoiceDocId), invoiceData, { merge: true });
    return invoiceDocId;
  },

  async deleteInvoice(invoiceId: string): Promise<void> {
    await deleteDoc(doc(db, 'invoices', invoiceId));
  },

  // Orders (Services) Management
  async getAllServices(): Promise<UserService[]> {
    try {
      let snapshot;
      try {
        const q = query(collection(db, 'user_services'), orderBy('createdAt', 'desc'));
        snapshot = await getDocs(q);
      } catch (err) {
        snapshot = await getDocs(collection(db, 'user_services'));
      }
      return snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as UserService));
    } catch (e) {
      console.error("Error fetching services:", e);
      return [];
    }
  },

  async addService(service: Omit<UserService, 'id'>): Promise<string> {
    const docRef = await addDoc(collection(db, 'user_services'), service);
    return docRef.id;
  },

  async updateService(serviceId: string, data: Partial<UserService>): Promise<void> {
    await setDoc(doc(db, 'user_services', serviceId), data, { merge: true });
  },

  async deleteService(serviceId: string): Promise<void> {
    await deleteDoc(doc(db, 'user_services', serviceId));
  },

  // User Management
  async getAllUsers(): Promise<UserProfile[]> {
    try {
      let snapshot;
      try {
        const q = query(collection(db, 'users'), orderBy('lastLogin', 'desc'));
        snapshot = await getDocs(q);
      } catch (err) {
        snapshot = await getDocs(collection(db, 'users'));
      }
      return snapshot.docs.map(doc => {
        const data = doc.data();
        const userEmail = (data.email || '').toLowerCase().trim();
        const isRootAdmin = ROOT_ADMIN_EMAILS.includes(userEmail);
        return { 
          id: doc.id,
          email: data.email || '',
          displayName: data.displayName || '',
          photoURL: data.photoURL || '',
          role: (isRootAdmin ? 'admin' : (data.role || 'user')),
          createdAt: data.createdAt?.toDate?.() ? data.createdAt.toDate().toISOString() : (typeof data.createdAt === 'string' ? data.createdAt : new Date().toISOString()),
          lastLogin: data.lastLogin?.toDate?.() ? data.lastLogin.toDate().toISOString() : (typeof data.lastLogin === 'string' ? data.lastLogin : undefined)
        } as UserProfile;
      });
    } catch (e) {
      console.error("Error fetching users:", e);
      return [];
    }
  },

  async updateUserRole(userId: string, role: 'admin' | 'user'): Promise<void> {
    await setDoc(doc(db, 'users', userId), { role }, { merge: true });
    if (role === 'admin') {
      await setDoc(doc(db, 'admins', userId), { 
        uid: userId,
        role: 'admin',
        updatedAt: new Date().toISOString() 
      }, { merge: true });
    } else {
      try {
        await deleteDoc(doc(db, 'admins', userId));
      } catch (e) {
        // ignore if not exists
      }
    }
  },

  async deleteUser(userId: string): Promise<void> {
    await deleteDoc(doc(db, 'users', userId));
    try {
      await deleteDoc(doc(db, 'admins', userId));
    } catch (e) {
      // ignore if not exists
    }
  },

  // Configuration Management
  async getConfig(): Promise<Settings | null> {
    try {
      const docRef = doc(db, 'config', 'site');
      const docSnap = await getDoc(docRef);
      return docSnap.exists() ? docSnap.data() as Settings : null;
    } catch (e) {
      console.error("Error fetching config:", e);
      return null;
    }
  },

  async updateConfig(data: Partial<Settings>): Promise<void> {
    await setDoc(doc(db, 'config', 'site'), data, { merge: true });
  }
};
