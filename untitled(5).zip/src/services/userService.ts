import { collection, query, where, getDocs, addDoc, serverTimestamp, orderBy, limit } from 'firebase/firestore';
import { db } from './firebase';
import { UserService, UserActivity } from '../types';

export const userService = {
  async getUserServices(userId: string): Promise<UserService[]> {
    const q = query(
      collection(db, 'user_services'),
      where('userId', '==', userId)
    );
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as UserService));
  },

  async getUserActivities(userId: string, limitCount: number = 10): Promise<UserActivity[]> {
    const q = query(
      collection(db, 'user_activities'),
      where('userId', '==', userId),
      orderBy('timestamp', 'desc'),
      limit(limitCount)
    );
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as UserActivity));
  },

  async logActivity(userId: string, type: UserActivity['type'], description: string) {
    try {
      await addDoc(collection(db, 'user_activities'), {
        userId,
        type,
        description,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error logging activity:', error);
    }
  }
};
