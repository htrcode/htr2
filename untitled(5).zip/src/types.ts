/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface User {
  uid: string;
  email: string;
  role: 'admin' | 'user';
  createdAt: string;
}

export interface NavLink {
  label: string;
  href: string;
}

export interface Plan {
  id: string; 
  product_id?: string; // Unique immutable ID for billing/identification
  name: string;
  price: string;
  price_inr?: string;
  price_eur?: string;
  badge: string;
  category: string;
  location: string;
  node: string;
  desc: string;
  features: string[];
  specs?: Record<string, string>; // Add specific specs (e.g. CPU: "2 Cores", RAM: "4GB")
  ram?: string;
  cpu?: string;
  processor?: string;
  storage?: string;
  ddosProtection?: string;
  networkSpeed?: string;
  slots?: string;
  order?: number;
  is_active?: boolean;
  archived?: boolean;
  subcategory?: 'budget' | 'standard' | 'performance' | string;
}

export interface Testimonial {
  id: string;
  name: string;
  logo: string;
  server: string;
  note: string;
}

export interface Feedback {
  id: string;
  name: string;
  msg: string;
  rating: number;
  time: string;
}

export interface ProductSoftwareOption {
  id: string;
  category: 'game' | 'vps' | 'bot' | 'web' | string;
  gameType?: string; // e.g., 'minecraft', 'rust', 'fivem', 'palworld', 'ark', 'cs2'
  name: string;
  desc: string;
  recommended?: boolean;
}

export interface ProductAddon {
  id: string;
  name: string;
  desc: string;
  priceInr: number;
  category?: string; // 'all', 'game', 'vps', 'bot', 'web'
  badge?: string;
}

export interface ProductConfigSettings {
  softwareOptions?: ProductSoftwareOption[];
  addons?: ProductAddon[];
}

export interface Settings {
  site_name: string;
  tagline: string;
  brand_name?: string;
  announcement_text?: string;
  show_announcement?: boolean;
  support_email?: string;
  discord_url?: string;
  billing_url?: string;
  upi_id?: string;
  payment_instructions?: string;
  maintenance_mode?: boolean;
  maintenance_message?: string;
  theme: 'dark' | 'light';
  font: string;
  color: string;
  currency: string;
  whatsapp_number: string;
  whatsapp_message: string;
  nav_links: NavLink[];
  productConfigs?: ProductConfigSettings;
}

export interface StatusHistoryItem {
  date: string;
  status: 'operational' | 'degraded' | 'outage' | 'maintenance' | 'unmonitored';
  uptimePercent: number;
  latencyMs?: number;
}

export interface ServiceStatus {
  id: string;
  name: string;
  ip: string;
  location: string;
  category?: string;
  status: 'operational' | 'degraded' | 'outage' | 'maintenance';
  lastChecked: string;
  uptime: string;
  latency: string;
  history?: StatusHistoryItem[];
}

export interface IncidentUpdate {
  id: string;
  message: string;
  status: 'investigating' | 'identified' | 'monitoring' | 'resolved';
  timestamp: string;
}

export interface StatusIncident {
  id: string;
  title: string;
  serviceId?: string;
  serviceName?: string;
  status: 'investigating' | 'identified' | 'monitoring' | 'resolved';
  severity: 'minor' | 'major' | 'critical' | 'maintenance';
  impact?: 'operational' | 'degraded' | 'outage' | 'maintenance';
  description: string;
  updates: IncidentUpdate[];
  createdAt: string;
  updatedAt: string;
  resolvedAt?: string;
}

export interface UserService {
  id: string;
  userId: string;
  planId: string;
  name: string;
  status: 'active' | 'suspended' | 'pending' | 'terminated';
  ip?: string;
  location: string;
  nodeName: string;
  expiresAt: string;
  createdAt: string;
  autoRenew: boolean;
  price?: string | number;
  panelLink?: string;
  panelEmail?: string;
  panelPassword?: string;
  category?: string;
  invoiceId?: string;
  serverId?: string;         // For Game, Discord Bot, Web Hosting
  sshPort?: string | number; // For VPS or Dedicated
  sshUsername?: string;      // For VPS or Dedicated
  port?: string | number;    // Primary/Service port for VPS or Dedicated
  rootPassword?: string;     // Root/access password for VPS or Dedicated
  serverType?: 'panel' | 'vps_dedicated';
}

export interface UserActivity {
  id: string;
  userId: string;
  type: 'login' | 'purchase' | 'support' | 'security';
  description: string;
  timestamp: string;
  metadata?: any;
}

export interface CartItem {
  id?: string;
  userId: string;
  planId: string;
  product_id?: string;
  name: string;
  price: string;
  quantity: number;
  category: string;
  location?: string;
  billingCycle?: 'monthly' | 'quarterly' | 'semi-annual' | 'annual' | string;
  hostname?: string;
  osTemplate?: string;
  javaVersion?: string;
  startupFile?: string;
  addOns?: string[];
  specs?: string;
  features?: string[];
}

export interface InvoiceItem {
  name: string;
  price: string | number;
  quantity: number;
  category?: string;
  planId?: string;
}

export interface Invoice {
  id: string;
  userId: string;
  invoiceNumber: string;
  items: InvoiceItem[];
  total: string | number;
  status: 'Paid' | 'Unpaid' | 'Cancelled' | 'pending' | 'UPI_PENDING_VERIFICATION' | string;
  method?: string;
  paymentMethod?: string;
  timestamp: string;
  utrNumber?: string;
  notes?: string;
  couponCode?: string;
  discount?: string;
}

export interface UserProfile {
  id: string;
  email: string;
  displayName?: string;
  photoURL?: string;
  role: 'admin' | 'user';
  createdAt: string;
  lastLogin?: string;
  pterodactylId?: number;
  pterodactylUsername?: string;
  pterodactylCreatedAt?: string;
}

export interface PterodactylUser {
  id: number;
  external_id?: string;
  uuid: string;
  username: string;
  email: string;
  first_name: string;
  last_name: string;
  language: string;
  root_admin: boolean;
  '2fa'?: boolean;
  created_at: string;
  updated_at: string;
}

export interface PterodactylServer {
  id: number;
  external_id?: string;
  uuid: string;
  identifier: string;
  name: string;
  description: string;
  status: string | null;
  suspended: boolean;
  limits: {
    memory: number;
    swap: number;
    disk: number;
    io: number;
    cpu: number;
  };
  feature_limits: {
    databases: number;
    allocations: number;
    backups: number;
  };
  user: number;
  node: number;
  allocation: number;
  nest: number;
  egg: number;
  created_at: string;
  updated_at: string;
}

export interface PterodactylNode {
  id: number;
  name: string;
  description?: string;
  location_id: number;
  fqdn: string;
  scheme: string;
  behind_proxy: boolean;
  maintenance_mode: boolean;
  memory: number;
  disk: number;
  daemon_listen: number;
  daemon_sftp: number;
}

export type TicketDepartment = 'Technical Support' | 'Billing & Payments' | 'Server Inquiry' | 'General' | 'Abuse/Security';
export type TicketPriority = 'low' | 'medium' | 'high' | 'urgent';
export type TicketStatus = 'open' | 'in_progress' | 'waiting_user' | 'resolved' | 'closed';

export interface TicketMessage {
  id: string;
  ticketId: string;
  ticketUserId?: string;
  senderId: string;
  senderEmail: string;
  senderName: string;
  senderRole: 'admin' | 'user';
  message: string;
  createdAt: string;
  attachments?: string[];
}

export interface Ticket {
  id: string;
  ticketNumber: string;
  userId: string;
  userEmail: string;
  userName?: string;
  subject: string;
  department: TicketDepartment;
  priority: TicketPriority;
  status: TicketStatus;
  serviceId?: string;
  serviceName?: string;
  createdAt: string;
  updatedAt: string;
  lastMessage?: string;
  lastReplyBy?: 'admin' | 'user';
  unreadByAdmin?: boolean;
  unreadByUser?: boolean;
}

export interface GameRamOption {
  product_id?: string; // Unique immutable ID for billing/identification
  id?: string;
  name?: string;
  ram: string;
  slots: string;
  priceInr: number;
  cpu: string;
  processor?: string;
  storage?: string;
  ddosProtection?: string;
  networkSpeed?: string;
  features?: string[];
  specs?: Record<string, string>;
  is_popular?: boolean;
  subcategory?: 'budget' | 'standard' | 'performance' | string;
}

export interface Game {
  id: string;
  title: string;
  category: string;
  image: string;
  startingPriceInr: number;
  platforms: string[];
  badge?: string;
  description: string;
  ramOptions: GameRamOption[];
  metadata?: {
    recommendedRam?: string;
    players?: string;
    cpuType?: string;
    storage?: string;
    serverSoftware?: string[];
  };
  is_active?: boolean;
  order?: number;
  use_catalog_plans?: boolean;
}

export interface AppData {
  settings: Settings;
  productConfigs?: ProductConfigSettings;
  plans: Plan[];
  games: Game[];
  testimonials: Testimonial[];
  feedbacks: Feedback[];
  statuses: ServiceStatus[];
  incidents?: StatusIncident[];
  privacy: string;
  refund: string;
  tos: string;
  legal: string;
  infrastructure: string;
  about: string;
  categories: string[];
  locations: string[];
  nodes: string[];
}
