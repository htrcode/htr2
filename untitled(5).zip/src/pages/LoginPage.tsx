import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Mail, Lock, ArrowRight, ArrowLeft, Chrome, Eye, EyeOff, 
  ShieldCheck, ShieldAlert, Zap, Server, 
  AlertCircle, KeyRound, RefreshCw, X, CheckCircle2 
} from 'lucide-react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { doc, setDoc } from 'firebase/firestore';
import { db } from '../services/firebase';
import { authService } from '../services/authService';
import { pterodactylService } from '../services/pterodactylService';
import { Logo } from '../components/Logo';

export const LoginPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isPopupBlocked, setIsPopupBlocked] = useState(false);
  
  // Rate-limiting and Brute Force Protection
  const [failedAttempts, setFailedAttempts] = useState<number>(() => {
    return Number(sessionStorage.getItem('hh_login_failed_attempts') || 0);
  });
  const [cooldownRemaining, setCooldownRemaining] = useState<number>(0);

  // Password reset modal state
  const [showResetModal, setShowResetModal] = useState(false);
  const [resetEmail, setResetEmail] = useState('');
  const [resetLoading, setResetLoading] = useState(false);
  const [resetSuccess, setResetSuccess] = useState<string | null>(null);
  const [resetError, setResetError] = useState<string | null>(null);

  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const redirectTarget = searchParams.get('redirect') ? `/${searchParams.get('redirect')}` : '/dashboard';

  // Cooldown timer
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (cooldownRemaining > 0) {
      timer = setInterval(() => {
        setCooldownRemaining((prev) => Math.max(0, prev - 1));
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [cooldownRemaining]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cooldownRemaining > 0) return;

    setError(null);
    setIsPopupBlocked(false);

    // Validation
    const cleanEmail = email.trim();
    if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      setError('Please provide a valid email address.');
      return;
    }
    if (!password) {
      setError('Please enter your password.');
      return;
    }

    setLoading(true);
    try {
      await authService.loginWithEmail(cleanEmail, password);
      sessionStorage.removeItem('hh_login_failed_attempts');
      navigate(redirectTarget);
    } catch (err: any) {
      const newAttempts = failedAttempts + 1;
      setFailedAttempts(newAttempts);
      sessionStorage.setItem('hh_login_failed_attempts', String(newAttempts));

      if (newAttempts >= 5) {
        setCooldownRemaining(30);
        setError('Security threshold triggered: 5 failed attempts. Please wait 30s before trying again.');
      } else {
        const code = err?.code || '';
        if (code === 'auth/wrong-password' || code === 'auth/user-not-found' || code === 'auth/invalid-credential') {
          setError(`Invalid credentials. Attempt ${newAttempts} of 5 before temporary lock.`);
        } else if (code === 'auth/too-many-requests') {
          setError('Too many requests. Account temporarily throttled by Firebase security.');
        } else {
          setError(err.message || 'Login failed. Please verify your credentials.');
        }
      }
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleClick = async () => {
    setError(null);
    setIsPopupBlocked(false);
    try {
      const result = await authService.loginWithGoogle();
      if (result && result.user) {
        setLoading(true);
        if (result.pterodactylId) {
          navigate(redirectTarget);
        } else {
          // Go to registration page with Google pre-filled details
          navigate('/auth/register', { 
            state: { 
              googleUser: { 
                uid: result.user.uid, 
                email: result.user.email, 
                displayName: result.user.displayName 
              } 
            } 
          });
        }
      }
    } catch (err: any) {
      if (err.code === 'auth/popup-blocked' || err.message?.includes('popup-blocked')) {
        setIsPopupBlocked(true);
        setError('Login pop-up was blocked by your browser settings or preview frame.');
      } else {
        setError(err.message || 'Google Login failed.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSendResetEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setResetError(null);
    setResetSuccess(null);

    const clean = resetEmail.trim();
    if (!clean || !clean.includes('@')) {
      setResetError('Please enter a valid email address.');
      return;
    }

    setResetLoading(true);
    try {
      await authService.resetPassword(clean);
      setResetSuccess(`Password recovery email dispatched to ${clean}. Please check your inbox.`);
      setTimeout(() => {
        setShowResetModal(false);
        setResetSuccess(null);
      }, 4000);
    } catch (err: any) {
      setResetError(err.message || 'Failed to send password reset email.');
    } finally {
      setResetLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-bg text-foreground pt-32 pb-24 px-4 sm:px-6 relative overflow-hidden font-sans flex flex-col justify-center">
      
      {/* Precision Background - Radial Gradient overlay */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[600px] bg-[radial-gradient(circle_at_center,rgba(139,92,246,0.03)_0%,transparent_70%)] pointer-events-none" />

      {/* Top Header Bar */}
      <div className="absolute top-6 left-6 right-6 max-w-7xl mx-auto flex items-center justify-between z-30">
        <Link to="/" className="flex items-center gap-3 group">
          <Logo size={36} className="group-hover:scale-105 transition-transform" />
          <span className="font-display font-black text-xl tracking-tight uppercase text-foreground">
            Hector<span className="text-accent">Hosting</span>
          </span>
        </Link>

        <Link
          to="/"
          className="inline-flex items-center gap-2 px-4 py-2 bg-bg-alt border border-border hover:bg-border text-foreground text-xs font-bold uppercase tracking-widest rounded transition-all"
        >
          <ArrowLeft size={14} className="text-accent" />
          <span>Home</span>
        </Link>
      </div>

      <div className="max-w-6xl mx-auto relative z-10 w-full mt-12 sm:mt-0">
        <div className="grid lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Technical Infrastructure & Security Highlights */}
          <div className="lg:col-span-5 space-y-8 order-2 lg:order-1">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-bg-alt border border-border text-[10px] font-black uppercase tracking-[0.2em] text-accent">
                <ShieldCheck size={13} />
                <span>Enterprise Identity Governance</span>
              </div>

              <h1 className="text-3xl sm:text-5xl font-extrabold uppercase tracking-tight text-foreground leading-[1.05] font-display">
                Client Portal <br />
                <span className="text-foreground-muted">Access.</span>
              </h1>

              <p className="text-foreground-muted text-sm leading-relaxed font-normal">
                Authenticate to dispatch server commands, manage bare-metal compute instances, review telemetry logs, and access Pterodactyl orchestrators.
              </p>
            </div>

            {/* Technical Metrics List (1px Bordered Box) */}
            <div className="grid grid-cols-1 gap-px bg-border border border-border rounded-lg overflow-hidden">
              <div className="p-5 bg-bg flex items-start gap-4">
                <div className="w-10 h-10 rounded bg-bg-alt border border-border flex items-center justify-center text-accent shrink-0 mt-0.5">
                  <ShieldCheck size={18} />
                </div>
                <div>
                  <h4 className="text-xs font-black uppercase tracking-wider text-foreground">10 Tbps DDoS Filtration</h4>
                  <p className="text-[11px] text-foreground-muted mt-0.5 leading-relaxed">Inline Anycast scrubbing fabric protects your game nodes with zero latency overhead.</p>
                </div>
              </div>

              <div className="p-5 bg-bg flex items-start gap-4">
                <div className="w-10 h-10 rounded bg-bg-alt border border-border flex items-center justify-center text-emerald-400 shrink-0 mt-0.5">
                  <Server size={18} />
                </div>
                <div>
                  <h4 className="text-xs font-black uppercase tracking-wider text-foreground">Pterodactyl Panel Orchestration</h4>
                  <p className="text-[11px] text-foreground-muted mt-0.5 leading-relaxed">Direct credentials sync for live console, SFTP file management, and automated backups.</p>
                </div>
              </div>

              <div className="p-5 bg-bg flex items-start gap-4">
                <div className="w-10 h-10 rounded bg-bg-alt border border-border flex items-center justify-center text-purple-400 shrink-0 mt-0.5">
                  <Zap size={18} />
                </div>
                <div>
                  <h4 className="text-xs font-black uppercase tracking-wider text-foreground">30s Instant Provisioning</h4>
                  <p className="text-[11px] text-foreground-muted mt-0.5 leading-relaxed">Automated lifecycle pipeline initializes node binaries immediately upon order confirmation.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Clean Professional Auth Card */}
          <div className="lg:col-span-7 order-1 lg:order-2">
            <div className="bg-bg-alt border border-border p-8 sm:p-10 rounded-lg shadow-xl relative">
              
              <div className="mb-8">
                <span className="text-[10px] font-black uppercase tracking-[0.2em] text-accent block mb-1">
                  Authentication Desk
                </span>
                <h2 className="text-2xl sm:text-3xl font-black text-foreground uppercase tracking-tight font-display">
                  Sign In to Account
                </h2>
                <p className="text-xs text-foreground-muted mt-1">
                  Provide your registered credentials to access server control nodes
                </p>
              </div>

              {/* Error Alert */}
              {error && (
                <div className="mb-6 p-4 bg-rose-500/10 border border-rose-500/30 rounded text-rose-400 text-xs font-bold flex items-start gap-3">
                  <AlertCircle size={16} className="shrink-0 mt-0.5" />
                  <span className="leading-relaxed">{error}</span>
                </div>
              )}

              {/* Cooldown Lock Alert */}
              {cooldownRemaining > 0 && (
                <div className="mb-6 p-4 bg-amber-500/10 border border-amber-500/30 rounded text-amber-300 text-xs font-bold flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ShieldAlert size={16} />
                    <span>Security Throttling Active</span>
                  </div>
                  <span className="font-mono bg-bg px-2 py-1 rounded border border-border text-xs">
                    {cooldownRemaining}s
                  </span>
                </div>
              )}

              <form className="space-y-5" onSubmit={handleLogin}>
                <div>
                  <label className="block text-[10px] font-black text-foreground-dim uppercase tracking-widest mb-2">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-foreground-dim" size={16} />
                    <input
                      type="email"
                      required
                      value={email}
                      disabled={cooldownRemaining > 0 || loading}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-bg border border-border focus:border-accent rounded py-3.5 pl-11 pr-4 text-xs text-foreground outline-none transition-all placeholder:text-foreground-dim disabled:opacity-50"
                      placeholder="client@hectorhosting.com"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="block text-[10px] font-black text-foreground-dim uppercase tracking-widest">
                      Password
                    </label>
                    <button 
                      type="button"
                      onClick={() => {
                        setResetEmail(email);
                        setShowResetModal(true);
                      }}
                      className="text-[10px] font-bold text-accent hover:underline uppercase tracking-wider"
                    >
                      Forgot Password?
                    </button>
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-foreground-dim" size={16} />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={password}
                      disabled={cooldownRemaining > 0 || loading}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-bg border border-border focus:border-accent rounded py-3.5 pl-11 pr-11 text-xs text-foreground outline-none transition-all placeholder:text-foreground-dim disabled:opacity-50"
                      placeholder="••••••••••••"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-foreground-dim hover:text-foreground transition-colors"
                    >
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading || cooldownRemaining > 0}
                  className="w-full py-4 bg-accent hover:bg-accent-muted text-white font-bold text-xs uppercase tracking-[0.2em] rounded transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {loading ? (
                    <>
                      <RefreshCw className="animate-spin" size={14} />
                      <span>Authenticating...</span>
                    </>
                  ) : (
                    <>
                      <span>Sign In to Control Panel</span>
                      <ArrowRight size={14} />
                    </>
                  )}
                </button>
              </form>

              {/* Divider */}
              <div className="my-6 relative flex items-center justify-center">
                <div className="border-t border-border w-full" />
                <span className="bg-bg-alt px-4 text-[9px] font-black uppercase tracking-widest text-foreground-dim absolute">
                  Alternative Sign In
                </span>
              </div>

              {/* Google OAuth Button */}
              <button
                type="button"
                onClick={handleGoogleClick}
                disabled={loading}
                className="w-full py-3.5 px-4 bg-bg border border-border hover:bg-border text-foreground text-xs font-bold uppercase tracking-wider rounded transition-all flex items-center justify-center gap-3 cursor-pointer disabled:opacity-50"
              >
                <Chrome size={16} className="text-accent" />
                <span>Continue with Google</span>
              </button>

              <div className="mt-8 pt-6 border-t border-border text-center">
                <p className="text-xs text-foreground-muted">
                  Don't have a server account?{' '}
                  <Link 
                    to="/auth/register" 
                    className="font-black text-accent hover:underline uppercase tracking-wider ml-1"
                  >
                    Register Account →
                  </Link>
                </p>
              </div>

            </div>
          </div>

        </div>
      </div>

      {/* Password Reset Modal */}
      <AnimatePresence>
        {showResetModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <div className="bg-bg-alt border border-border rounded-lg p-8 max-w-md w-full relative shadow-2xl">
              <button
                onClick={() => setShowResetModal(false)}
                className="absolute top-4 right-4 text-foreground-dim hover:text-foreground"
              >
                <X size={18} />
              </button>

              <div className="text-center mb-6">
                <div className="w-10 h-10 rounded bg-bg border border-border flex items-center justify-center mx-auto mb-3 text-accent">
                  <KeyRound size={20} />
                </div>
                <h3 className="text-lg font-black text-foreground uppercase tracking-tight">Reset Password</h3>
                <p className="text-xs text-foreground-muted mt-1">
                  We'll dispatch a recovery link to your registered email address.
                </p>
              </div>

              {resetSuccess && (
                <div className="mb-4 p-3 bg-emerald-500/10 border border-emerald-500/30 rounded text-emerald-400 text-xs font-bold flex items-start gap-2">
                  <CheckCircle2 size={16} className="shrink-0 mt-0.5" />
                  <span>{resetSuccess}</span>
                </div>
              )}

              {resetError && (
                <div className="mb-4 p-3 bg-rose-500/10 border border-rose-500/30 rounded text-rose-400 text-xs font-bold flex items-start gap-2">
                  <AlertCircle size={16} className="shrink-0 mt-0.5" />
                  <span>{resetError}</span>
                </div>
              )}

              <form onSubmit={handleSendResetEmail} className="space-y-4">
                <div>
                  <label className="block text-[10px] font-black text-foreground-dim uppercase tracking-widest mb-1.5">
                    Account Email
                  </label>
                  <input
                    type="email"
                    required
                    value={resetEmail}
                    onChange={(e) => setResetEmail(e.target.value)}
                    placeholder="client@hectorhosting.com"
                    className="w-full px-4 py-3 bg-bg border border-border focus:border-accent rounded text-xs text-foreground outline-none transition-all placeholder:text-foreground-dim"
                  />
                </div>

                <div className="flex items-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowResetModal(false)}
                    className="flex-1 py-3 px-4 bg-bg border border-border hover:bg-border text-foreground text-xs font-bold uppercase tracking-wider rounded"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={resetLoading}
                    className="flex-1 py-3 px-4 bg-accent hover:bg-accent-muted text-white text-xs font-bold uppercase tracking-wider rounded transition-all disabled:opacity-50"
                  >
                    {resetLoading ? 'Sending...' : 'Send Link'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
