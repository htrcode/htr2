import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  Box, 
  CreditCard, 
  LifeBuoy,
  Settings as SettingsIcon, 
  LogOut,
  Bell,
  Search,
  Menu,
  X,
  Home,
  ExternalLink,
  Shield,
  Check,
  CheckCheck,
  Trash2,
  ChevronDown,
  User,
  Server,
  Activity,
  Globe,
  Lock,
  ArrowRight
} from 'lucide-react';
import { User as FirebaseUser } from 'firebase/auth';
import { UserService, UserActivity } from '../types';
import { userService } from '../services/userService';
import { billingService } from '../services/billingService';
import { authService } from '../services/authService';
import { useNavigate, Link } from 'react-router-dom';
import { Logo } from '../components/Logo';
import { Overview } from '../components/dashboard/Overview';
import { Services } from '../components/dashboard/Services';
import { Billing } from '../components/dashboard/Billing';
import { Settings } from '../components/dashboard/Settings';
import { Tickets } from '../components/dashboard/Tickets';

interface DashboardProps {
  user: FirebaseUser | null;
  isAdmin?: boolean;
  onOpenAdmin?: () => void;
}

interface NotificationItem {
  id: string;
  title: string;
  message: string;
  time: string;
  type: 'service' | 'security' | 'billing' | 'ticket' | 'network';
  actionTab?: string;
  unread: boolean;
}

export const DashboardPage: React.FC<DashboardProps> = ({ 
  user, 
  isAdmin = false, 
  onOpenAdmin 
}) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [services, setServices] = useState<UserService[]>([]);
  const [activities, setActivities] = useState<UserActivity[]>([]);
  const [loading, setLoading] = useState(true);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  // Header Dropdowns State
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isAccountMenuOpen, setIsAccountMenuOpen] = useState(false);
  const [notificationFilter, setNotificationFilter] = useState<'all' | 'unread'>('all');
  const [readNotificationIds, setReadNotificationIds] = useState<string[]>(() => {
    if (!user) return [];
    try {
      const saved = localStorage.getItem(`hector_notifications_read_${user.uid}`);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [clearedNotificationIds, setClearedNotificationIds] = useState<string[]>(() => {
    if (!user) return [];
    try {
      const saved = localStorage.getItem(`hector_notifications_cleared_${user.uid}`);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const notifRef = useRef<HTMLDivElement>(null);
  const accountRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  // Close dropdowns on click outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(event.target as Node)) {
        setIsNotificationsOpen(false);
      }
      if (accountRef.current && !accountRef.current.contains(event.target as Node)) {
        setIsAccountMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (!user) {
      navigate('/auth/login');
      return;
    }

    const fetchData = async () => {
      try {
        const [userServices, userActivities, userInvoices] = await Promise.all([
          userService.getUserServices(user.uid),
          userService.getUserActivities(user.uid),
          billingService.getInvoices(user.uid)
        ]);

        // Merge unpaid/pending invoice items into services list as pending products if not already created
        const extraPendingServices: UserService[] = [];
        userInvoices.forEach(inv => {
          if (inv.status === 'Unpaid' || inv.status === 'pending' || inv.status === 'UPI_PENDING_VERIFICATION') {
            (inv.items || []).forEach((item, itemIdx) => {
              const exists = userServices.some(s => 
                (s.invoiceId && s.invoiceId === inv.id) ||
                (s.name && item.name && s.name.trim().toLowerCase() === item.name.trim().toLowerCase() && s.status !== 'active')
              );
              if (!exists) {
                extraPendingServices.push({
                  id: `inv_service_${inv.id}_${itemIdx}`,
                  userId: user.uid,
                  planId: item.planId || 'pending-plan',
                  name: item.name || 'Pending Service Order',
                  category: item.category || 'Hosting Node',
                  price: item.price || inv.total || 'Pending',
                  invoiceId: inv.id,
                  status: 'pending',
                  location: 'India (Mumbai)',
                  nodeName: 'Pending Provisioning Node',
                  ip: 'Verification Pending',
                  port: 25565,
                  createdAt: inv.timestamp || new Date().toISOString(),
                  expiresAt: new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString(),
                  autoRenew: true
                });
              }
            });
          }
        });

        setServices([...userServices, ...extraPendingServices]);
        setActivities(userActivities);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user, navigate]);

  // Persist read/cleared notifications in localStorage
  const markAsRead = (id: string) => {
    if (!readNotificationIds.includes(id)) {
      const updated = [...readNotificationIds, id];
      setReadNotificationIds(updated);
      if (user) {
        localStorage.setItem(`hector_notifications_read_${user.uid}`, JSON.stringify(updated));
      }
    }
  };

  const markAllAsRead = () => {
    const allIds = generatedNotifications.map(n => n.id);
    setReadNotificationIds(allIds);
    if (user) {
      localStorage.setItem(`hector_notifications_read_${user.uid}`, JSON.stringify(allIds));
    }
  };

  const clearAllNotifications = () => {
    const allIds = generatedNotifications.map(n => n.id);
    setClearedNotificationIds(allIds);
    if (user) {
      localStorage.setItem(`hector_notifications_cleared_${user.uid}`, JSON.stringify(allIds));
    }
  };

  const handleLogout = async () => {
    await authService.logout();
    navigate('/auth/login');
  };

  // Construct dynamic notifications list
  const baseNotifications: NotificationItem[] = [
    {
      id: 'notif-network-mumbai',
      title: 'Mumbai Datacenter Operational',
      message: 'Direct NIXI peering active with sub-15ms latency across Indian networks.',
      time: 'Real-time Status',
      type: 'network',
      unread: !readNotificationIds.includes('notif-network-mumbai')
    },
    {
      id: 'notif-security-protection',
      title: 'Hardware DDoS Mitigation Active',
      message: 'L3/L4 and Layer 7 protection filtering packets automatically.',
      time: '2 hours ago',
      type: 'security',
      actionTab: 'settings',
      unread: !readNotificationIds.includes('notif-security-protection')
    },
    {
      id: 'notif-support-desk',
      title: '24/7/365 Indian Support Desk',
      message: 'Need technical assistance or custom node configuration? Our engineers are online.',
      time: 'Support Notice',
      type: 'ticket',
      actionTab: 'tickets',
      unread: !readNotificationIds.includes('notif-support-desk')
    }
  ];

  if (services.length > 0) {
    baseNotifications.unshift({
      id: 'notif-active-services',
      title: `${services.length} Active Cloud Service(s)`,
      message: `All your compute instances and game servers are provisioned and healthy.`,
      time: 'Live',
      type: 'service',
      actionTab: 'services',
      unread: !readNotificationIds.includes('notif-active-services')
    });
  } else {
    baseNotifications.unshift({
      id: 'notif-deploy-service',
      title: 'Deploy High-Frequency Server',
      message: 'Launch your first AMD RYZEN 9 5950X or AMD EPYC server with instant setup.',
      time: 'Get Started',
      type: 'service',
      actionTab: 'overview',
      unread: !readNotificationIds.includes('notif-deploy-service')
    });
  }

  // Add recent activity if present
  if (activities.length > 0) {
    const latestAct = activities[0];
    const actId = `notif-act-${latestAct.id || 'recent'}`;
    baseNotifications.splice(1, 0, {
      id: actId,
      title: `${latestAct.type || 'Account Activity'}`,
      message: latestAct.description || 'Recent action registered on your account.',
      time: 'Recent',
      type: 'security',
      actionTab: 'settings',
      unread: !readNotificationIds.includes(actId)
    });
  }

  // Filter out cleared notifications
  const generatedNotifications = baseNotifications.filter(
    n => !clearedNotificationIds.includes(n.id)
  );

  const unreadCount = generatedNotifications.filter(n => n.unread).length;
  const filteredNotifications = notificationFilter === 'unread' 
    ? generatedNotifications.filter(n => n.unread)
    : generatedNotifications;

  const tabs = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'services', label: 'My Services', icon: Box },
    { id: 'tickets', label: 'Support Tickets', icon: LifeBuoy },
    { id: 'invoices', label: 'Invoices', icon: CreditCard },
    { id: 'settings', label: 'Settings', icon: SettingsIcon },
  ];

  const showSidebarLabels = isSidebarOpen || isMobileMenuOpen;

  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isMobileMenuOpen]);

  if (loading) {
    return (
      <div className="min-h-screen bg-bg flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-accent border-t-transparent rounded-full animate-spin" />
          <div className="text-[10px] font-black uppercase tracking-[0.3em] text-foreground-dim">Syncing Client Portal...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-bg flex">
      {/* Mobile Backdrop */}
      {isMobileMenuOpen && (
        <div 
          onClick={() => setIsMobileMenuOpen(false)}
          className="fixed inset-0 bg-black/75 backdrop-blur-sm z-40 lg:hidden"
        />
      )}

      {/* Sidebar */}
      <aside 
        className={`fixed left-0 top-0 bottom-0 bg-bg-alt border-r border-border z-50 transition-all duration-300 lg:translate-x-0 ${
          isMobileMenuOpen ? 'translate-x-0 w-[280px] max-w-[85vw]' : '-translate-x-full lg:translate-x-0'
        } ${isSidebarOpen ? 'lg:w-[280px]' : 'lg:w-[80px]'} flex flex-col`}
      >
        {/* Brand Header */}
        <div className="p-6 border-b border-border flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3 group">
            <Logo size={36} />
            {showSidebarLabels && (
              <span className="text-[13px] font-black uppercase tracking-[0.2em] text-foreground">
                Hector<span className="text-accent">Panel</span>
              </span>
            )}
          </Link>
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-2 hover:bg-bg rounded-lg border border-transparent hover:border-border transition-all text-foreground-dim hover:text-foreground hidden lg:block"
            title={isSidebarOpen ? "Collapse sidebar" : "Expand sidebar"}
          >
            {isSidebarOpen ? <X size={16} /> : <Menu size={16} />}
          </button>
          <button 
            onClick={() => setIsMobileMenuOpen(false)}
            className="w-9 h-9 flex items-center justify-center hover:bg-bg rounded-lg text-foreground-dim hover:text-foreground lg:hidden"
          >
            <X size={18} />
          </button>
        </div>

        {/* Tab Navigation */}
        <nav className="flex-1 px-4 py-6 space-y-2 overflow-y-auto custom-scrollbar">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id);
                setIsMobileMenuOpen(false);
              }}
              className={`w-full flex items-center gap-4 p-4 rounded-xl font-sans transition-all text-left group ${
                activeTab === tab.id 
                  ? 'bg-accent text-white font-black shadow-lg shadow-accent/20' 
                  : 'text-foreground-muted hover:bg-bg hover:text-foreground font-bold'
              }`}
            >
              <tab.icon size={20} className={activeTab === tab.id ? 'text-white' : 'text-foreground-dim group-hover:text-accent'} />
              {showSidebarLabels && (
                <span className="text-[11px] uppercase tracking-widest">{tab.label}</span>
              )}
            </button>
          ))}
        </nav>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-border space-y-1">
          {/* Main Website Link */}
          <Link
            to="/"
            onClick={() => setIsMobileMenuOpen(false)}
            className="w-full flex items-center gap-4 p-4 rounded-xl text-foreground-muted hover:bg-bg hover:text-accent transition-all group"
            title="Return to Hector Hosting Website"
          >
            <Home size={20} className="group-hover:text-accent shrink-0" />
            {showSidebarLabels && (
              <span className="text-[11px] font-black uppercase tracking-widest">Main Website</span>
            )}
          </Link>

          {/* Game Server Console external link */}
          <a
            href="https://gp.hector.host"
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => setIsMobileMenuOpen(false)}
            className="w-full flex items-center gap-4 p-4 rounded-xl text-foreground-muted hover:bg-bg hover:text-emerald-400 transition-all group"
            title="Pterodactyl Game Server Panel"
          >
            <Server size={20} className="group-hover:text-emerald-400 shrink-0" />
            {showSidebarLabels && (
              <div className="flex items-center justify-between flex-1">
                <span className="text-[11px] font-black uppercase tracking-widest">Game Panel</span>
                <ExternalLink size={12} className="text-foreground-dim group-hover:text-emerald-400" />
              </div>
            )}
          </a>

          {/* Logout */}
          <button 
            onClick={handleLogout}
            className="w-full flex items-center gap-4 p-4 rounded-xl text-foreground-muted hover:bg-rose-500/10 hover:text-rose-500 transition-all group"
          >
            <LogOut size={20} className="shrink-0" />
            {showSidebarLabels && (
              <span className="text-[11px] font-black uppercase tracking-widest">Logout</span>
            )}
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className={`flex-1 transition-all duration-300 ${isSidebarOpen ? 'lg:ml-[280px]' : 'lg:ml-[80px]'}`}>
        {/* Top Header */}
        <header className="h-20 bg-bg/80 backdrop-blur-xl border-b border-border sticky top-0 z-40 px-4 sm:px-8 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsMobileMenuOpen(true)}
              className="lg:hidden p-2 hover:bg-bg-alt rounded-lg text-foreground-muted hover:text-foreground"
            >
              <Menu size={20} />
            </button>
            <h1 className="text-[14px] font-black uppercase tracking-[0.2em] text-foreground">
              {tabs.find(t => t.id === activeTab)?.label}
            </h1>
          </div>

          <div className="flex items-center gap-3 sm:gap-6">
            {/* Search Box */}
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-foreground-dim" size={14} />
              <input 
                type="text" 
                placeholder="Search instances, IP, tickets, invoices..."
                onClick={() => setActiveTab('services')}
                className="pl-10 pr-4 py-2 bg-bg-alt border border-border rounded-xl text-xs font-medium text-foreground focus:border-accent outline-none w-64 transition-all"
              />
            </div>

            {/* Notification Button & Interactive Center */}
            <div className="relative" ref={notifRef}>
              <button 
                onClick={() => {
                  setIsNotificationsOpen(!isNotificationsOpen);
                  setIsAccountMenuOpen(false);
                }}
                className={`relative p-2.5 rounded-lg border transition-all ${
                  isNotificationsOpen 
                    ? 'bg-bg-alt border-accent/40 text-accent' 
                    : 'bg-bg hover:bg-bg-alt border-border text-foreground-muted hover:text-foreground'
                }`}
                title="Client Notifications"
                aria-label="View notifications"
              >
                <Bell size={18} />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 bg-accent text-white text-[9px] font-black rounded-full flex items-center justify-center border-2 border-bg shadow-lg animate-pulse">
                    {unreadCount}
                  </span>
                )}
              </button>

              {/* Notification Popover Dropdown */}
              <AnimatePresence>
                {isNotificationsOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 10, scale: 0.98 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 8, scale: 0.98 }}
                    transition={{ duration: 0.15 }}
                    className="absolute top-full right-0 mt-3 w-[calc(100vw-2rem)] sm:w-96 max-w-sm bg-bg-alt border border-border rounded-2xl shadow-2xl z-50 overflow-hidden"
                  >
                    {/* Header */}
                    <div className="p-4 border-b border-border flex items-center justify-between bg-bg/50">
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] font-black uppercase tracking-widest text-foreground">
                          Notifications
                        </span>
                        {unreadCount > 0 ? (
                          <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase bg-accent/10 text-accent border border-accent/20">
                            {unreadCount} Unread
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                            All Caught Up
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-1">
                        {unreadCount > 0 && (
                          <button
                            onClick={markAllAsRead}
                            className="p-1.5 hover:bg-bg rounded text-foreground-dim hover:text-accent transition-colors"
                            title="Mark all as read"
                          >
                            <CheckCheck size={16} />
                          </button>
                        )}
                        {generatedNotifications.length > 0 && (
                          <button
                            onClick={clearAllNotifications}
                            className="p-1.5 hover:bg-bg rounded text-foreground-dim hover:text-rose-400 transition-colors"
                            title="Clear notifications"
                          >
                            <Trash2 size={15} />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Filter Tabs */}
                    <div className="px-4 py-2 bg-bg/30 border-b border-border flex gap-2">
                      <button
                        onClick={() => setNotificationFilter('all')}
                        className={`px-3 py-1 rounded text-[9px] font-black uppercase tracking-widest transition-all ${
                          notificationFilter === 'all' 
                            ? 'bg-bg text-foreground border border-border' 
                            : 'text-foreground-dim hover:text-foreground'
                        }`}
                      >
                        All ({generatedNotifications.length})
                      </button>
                      <button
                        onClick={() => setNotificationFilter('unread')}
                        className={`px-3 py-1 rounded text-[9px] font-black uppercase tracking-widest transition-all ${
                          notificationFilter === 'unread' 
                            ? 'bg-bg text-foreground border border-border' 
                            : 'text-foreground-dim hover:text-foreground'
                        }`}
                      >
                        Unread ({unreadCount})
                      </button>
                    </div>

                    {/* Notifications List */}
                    <div className="max-h-[380px] overflow-y-auto divide-y divide-border/50 custom-scrollbar">
                      {filteredNotifications.length === 0 ? (
                        <div className="p-8 text-center flex flex-col items-center justify-center">
                          <div className="w-12 h-12 rounded-full bg-bg border border-border flex items-center justify-center text-foreground-dim mb-3">
                            <Check size={20} className="text-emerald-400" />
                          </div>
                          <div className="text-[11px] font-black uppercase tracking-widest text-foreground mb-1">
                            No Notifications
                          </div>
                          <p className="text-[10px] font-medium text-foreground-dim max-w-xs">
                            {notificationFilter === 'unread' 
                              ? "You have read all pending announcements and notices." 
                              : "No alerts or recent updates to display at this time."}
                          </p>
                        </div>
                      ) : (
                        filteredNotifications.map((notif) => {
                          const getIcon = () => {
                            switch (notif.type) {
                              case 'service': return <Box size={14} className="text-blue-400" />;
                              case 'security': return <Shield size={14} className="text-emerald-400" />;
                              case 'billing': return <CreditCard size={14} className="text-amber-400" />;
                              case 'ticket': return <LifeBuoy size={14} className="text-accent" />;
                              case 'network': return <Globe size={14} className="text-purple-400" />;
                              default: return <Bell size={14} className="text-foreground-dim" />;
                            }
                          };

                          return (
                            <div 
                              key={notif.id}
                              onClick={() => {
                                markAsRead(notif.id);
                                if (notif.actionTab) {
                                  setActiveTab(notif.actionTab);
                                  setIsNotificationsOpen(false);
                                }
                              }}
                              className={`p-4 transition-all cursor-pointer flex gap-3.5 hover:bg-bg ${
                                notif.unread ? 'bg-accent/5' : 'opacity-80 hover:opacity-100'
                              }`}
                            >
                              <div className="mt-0.5 p-2 rounded-lg bg-bg border border-border shrink-0 self-start">
                                {getIcon()}
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center justify-between gap-2 mb-1">
                                  <h4 className="text-[11px] font-black uppercase tracking-widest text-foreground truncate">
                                    {notif.title}
                                  </h4>
                                  <span className="text-[8px] font-bold uppercase tracking-widest text-foreground-dim shrink-0">
                                    {notif.time}
                                  </span>
                                </div>
                                <p className="text-[10px] text-foreground-muted font-medium leading-relaxed">
                                  {notif.message}
                                </p>
                              </div>
                              {notif.unread && (
                                <span className="w-2 h-2 rounded-full bg-accent shrink-0 mt-1.5" />
                              )}
                            </div>
                          );
                        })
                      )}
                    </div>

                    {/* Bottom Status bar */}
                    <div className="p-3 bg-bg/80 border-t border-border flex items-center justify-between text-[9px] font-bold text-foreground-dim uppercase tracking-widest">
                      <span className="flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />
                        Infrastructure Live
                      </span>
                      <button 
                        onClick={() => {
                          setActiveTab('settings');
                          setIsNotificationsOpen(false);
                        }}
                        className="text-accent hover:underline"
                      >
                        Settings
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Interactive Account Button & Dropdown */}
            <div className="relative pl-3 sm:pl-6 border-l border-border" ref={accountRef}>
              <button 
                onClick={() => {
                  setIsAccountMenuOpen(!isAccountMenuOpen);
                  setIsNotificationsOpen(false);
                }}
                className="flex items-center gap-3 p-1.5 rounded-xl hover:bg-bg-alt transition-all group"
                aria-label="User Account Menu"
              >
                <div className="text-right hidden sm:block">
                  <div className="text-[10px] font-black uppercase tracking-widest text-foreground truncate max-w-[120px]">
                    {user?.displayName || user?.email?.split('@')[0] || 'Client'}
                  </div>
                  <div className="text-[9px] font-bold uppercase tracking-widest text-foreground-dim flex items-center justify-end gap-1">
                    {isAdmin ? (
                      <span className="text-accent font-black">Administrator</span>
                    ) : (
                      <span>Verified Client</span>
                    )}
                  </div>
                </div>

                <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-accent/10 border border-accent/20 flex items-center justify-center text-accent overflow-hidden group-hover:border-accent/40 transition-all shrink-0">
                  {user?.photoURL ? (
                    <img src={user.photoURL} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <User size={18} />
                  )}
                </div>

                <ChevronDown 
                  size={14} 
                  className={`text-foreground-dim transition-transform duration-200 hidden sm:block ${
                    isAccountMenuOpen ? 'rotate-180 text-accent' : 'group-hover:text-foreground'
                  }`} 
                />
              </button>

              {/* Account Dropdown Popover */}
              <AnimatePresence>
                {isAccountMenuOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 10, scale: 0.98 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 8, scale: 0.98 }}
                    transition={{ duration: 0.15 }}
                    className="absolute top-full right-0 mt-3 w-[calc(100vw-2rem)] sm:w-72 max-w-xs bg-bg-alt border border-border rounded-2xl shadow-2xl z-50 p-2 space-y-1 overflow-hidden"
                  >
                    {/* User Summary Header */}
                    <div className="p-3 bg-bg border border-border rounded-xl mb-2">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-10 h-10 rounded-lg bg-accent/10 border border-accent/20 flex items-center justify-center text-accent shrink-0 overflow-hidden">
                          {user?.photoURL ? (
                            <img src={user.photoURL} alt="" className="w-full h-full object-cover" />
                          ) : (
                            <User size={18} />
                          )}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="text-[11px] font-black uppercase tracking-widest text-foreground truncate">
                            {user?.displayName || 'Client Account'}
                          </div>
                          <div className="text-[9px] text-foreground-dim truncate">
                            {user?.email}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center justify-between pt-1 border-t border-border/50 text-[8px] font-black uppercase tracking-widest text-foreground-dim">
                        <span>Role Status</span>
                        <span className={`px-2 py-0.5 rounded ${
                          isAdmin 
                            ? 'bg-accent/10 text-accent border border-accent/20' 
                            : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        }`}>
                          {isAdmin ? 'System Admin' : 'Client'}
                        </span>
                      </div>
                    </div>

                    {/* DASHBOARD NAVIGATION SECTION (matching image.png) */}
                    <div className="px-3 py-2 text-[9px] font-black uppercase tracking-[0.2em] text-foreground-dim">
                      Dashboard Navigation
                    </div>

                    <div className="space-y-1">
                      <button
                        onClick={() => {
                          setActiveTab('services');
                          setIsAccountMenuOpen(false);
                        }}
                        className="w-full flex items-center gap-3.5 px-3 py-2.5 rounded-xl hover:bg-bg text-[10px] text-foreground-muted hover:text-white font-black uppercase tracking-widest transition-all group"
                      >
                        <div className="p-1.5 rounded-lg bg-bg border border-border group-hover:border-accent/40 text-foreground-dim group-hover:text-accent transition-colors">
                          <Box size={15} />
                        </div>
                        <span>My Services ({services.length})</span>
                      </button>

                      <button
                        onClick={() => {
                          setActiveTab('tickets');
                          setIsAccountMenuOpen(false);
                        }}
                        className="w-full flex items-center gap-3.5 px-3 py-2.5 rounded-xl hover:bg-bg text-[10px] text-foreground-muted hover:text-white font-black uppercase tracking-widest transition-all group"
                      >
                        <div className="p-1.5 rounded-lg bg-bg border border-border group-hover:border-accent/40 text-foreground-dim group-hover:text-accent transition-colors">
                          <LifeBuoy size={15} />
                        </div>
                        <span>Support Desk</span>
                      </button>

                      <button
                        onClick={() => {
                          setActiveTab('invoices');
                          setIsAccountMenuOpen(false);
                        }}
                        className="w-full flex items-center gap-3.5 px-3 py-2.5 rounded-xl hover:bg-bg text-[10px] text-foreground-muted hover:text-white font-black uppercase tracking-widest transition-all group"
                      >
                        <div className="p-1.5 rounded-lg bg-bg border border-border group-hover:border-accent/40 text-foreground-dim group-hover:text-accent transition-colors">
                          <CreditCard size={15} />
                        </div>
                        <span>Invoices</span>
                      </button>

                      <button
                        onClick={() => {
                          setActiveTab('settings');
                          setIsAccountMenuOpen(false);
                        }}
                        className="w-full flex items-center gap-3.5 px-3 py-2.5 rounded-xl hover:bg-bg text-[10px] text-foreground-muted hover:text-white font-black uppercase tracking-widest transition-all group"
                      >
                        <div className="p-1.5 rounded-lg bg-bg border border-border group-hover:border-accent/40 text-foreground-dim group-hover:text-accent transition-colors">
                          <Lock size={15} />
                        </div>
                        <span>Password & Security</span>
                      </button>
                    </div>

                    <div className="my-2 border-t border-border" />

                    {/* Sign Out Button */}
                    <button
                      onClick={() => {
                        setIsAccountMenuOpen(false);
                        handleLogout();
                      }}
                      className="w-full flex items-center gap-3.5 p-2.5 rounded-xl hover:bg-rose-500/10 text-[10px] text-foreground-muted hover:text-rose-400 font-black uppercase tracking-widest transition-all group"
                    >
                      <div className="w-8 h-8 rounded-lg bg-bg border border-border flex items-center justify-center text-foreground-dim group-hover:text-rose-400 group-hover:border-rose-500/30 transition-colors">
                        <LogOut size={15} />
                      </div>
                      <span>Sign Out</span>
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <div className="p-4 sm:p-8 max-w-[1600px] mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {activeTab === 'overview' && <Overview services={services} activities={activities} onTabChange={setActiveTab} />}
              {activeTab === 'services' && <Services services={services} user={user} />}
              {activeTab === 'tickets' && <Tickets user={user} services={services} />}
              {(activeTab === 'invoices' || activeTab === 'billing') && <Billing user={user} />}
              {activeTab === 'settings' && <Settings user={user} />}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
};
