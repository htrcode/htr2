import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import QRCode from 'qrcode';
import { 
  ShieldCheck, 
  ArrowLeft, 
  Check, 
  Server, 
  Clock, 
  Cpu, 
  ExternalLink,
  CheckCircle2,
  AlertCircle,
  Zap,
  Globe,
  Settings,
  Sparkles,
  Tag,
  X,
  Copy,
  QrCode,
  RefreshCw,
  Hourglass,
  ArrowRight
} from 'lucide-react';
import { authService } from '../services/authService';
import { billingService } from '../services/billingService';
import { CartItem, AppData } from '../types';
import { getDynamicLocations } from '../utils/locationUtils';

interface CheckoutPageProps {
  data?: AppData;
  activeCurrency?: 'INR' | 'USD';
}

const UPI_VPA = 'viswavisu2005@oksbi';

const BILLING_CYCLES = [
  { id: 'monthly', label: '1 Month', discountMultiplier: 1.0, badge: 'Standard' },
  { id: 'quarterly', label: '3 Months', discountMultiplier: 0.95, badge: '5% Off' },
  { id: 'semi-annual', label: '6 Months', discountMultiplier: 0.90, badge: '10% Off' },
  { id: 'annual', label: '12 Months', discountMultiplier: 0.85, badge: '15% Off' },
];

const GAME_SOFTWARE_PRESETS: Record<string, { id: string; name: string; desc: string }[]> = {
  minecraft: [
    { id: 'paper', name: 'Paper (Recommended)', desc: 'High performance Spigot fork with bug fixes' },
    { id: 'purpur', name: 'Purpur', desc: 'Highly customizable Paper drop-in replacement' },
    { id: 'folia', name: 'Folia', desc: 'Multi-threaded regional Minecraft server engine' },
    { id: 'vanilla', name: 'Vanilla', desc: 'Official unmodified Mojang server binary' },
    { id: 'fabric', name: 'Fabric', desc: 'Lightweight, modular modding toolchain' },
    { id: 'forge', name: 'Forge', desc: 'Standard heavy modpack software' },
    { id: 'spigot', name: 'Spigot', desc: 'Classic plugin-supported Minecraft engine' },
    { id: 'bedrock', name: 'Bedrock Dedicated', desc: 'C++ engine for Minecraft PE / Windows 10' },
    { id: 'mohist', name: 'Mohist', desc: 'Hybrid engine supporting both Mods & Plugins' },
    { id: 'bungeecord', name: 'Bungeecord / Velocity', desc: 'Proxy software for multi-server networks' }
  ],
  rust: [
    { id: 'rust-umod', name: 'Oxide / uMod (Recommended)', desc: 'Full modding framework with automatic uMod plugin installer' },
    { id: 'rust-vanilla', name: 'Vanilla Rust Dedicated', desc: 'Official Facepunch server binary' },
    { id: 'rust-carbon', name: 'Carbon Framework', desc: 'High concurrency C# modding framework' }
  ],
  fivem: [
    { id: 'fivem-txadmin', name: 'TxAdmin Standalone (Recommended)', desc: 'Official FiveM web panel with 1-click resource deployment' },
    { id: 'fivem-esx', name: 'ESX Legacy Framework', desc: 'Pre-configured roleplay server stack' },
    { id: 'fivem-qbcore', name: 'QBCore Framework', desc: 'Modern high-performance GTAV RP framework' }
  ],
  palworld: [
    { id: 'pal-modded', name: 'Palworld UE5 Modded Engine (Recommended)', desc: 'Unreal Engine 5 modding support & memory leak scrubber' },
    { id: 'pal-vanilla', name: 'PalServer Dedicated (Vanilla)', desc: 'Official Steam Palworld server binary' }
  ],
  ark: [
    { id: 'ark-ascended', name: 'ARK Survival Ascended Dedicated (Recommended)', desc: 'UE5 next-gen ARK dedicated server build' },
    { id: 'ark-evolved', name: 'ARK Survival Evolved', desc: 'Classic ARK dedicated server with Steam workshop support' }
  ],
  cs2: [
    { id: 'cs2-comp', name: 'CS2 Competitive Source2 Engine (Recommended)', desc: 'High-tick competitive 5v5 / 10v10 server' },
    { id: 'cs2-metamod', name: 'CS2 MetaMod + SourceMod', desc: 'Plugin-enabled CS2 dedicated server' }
  ],
  general: [
    { id: 'game-steamcmd', name: 'SteamCMD Dedicated Server', desc: 'Pre-configured SteamCMD game binary wrapper' },
    { id: 'game-custom', name: 'Custom Control Script', desc: 'Custom start command & startup arguments' }
  ]
};

const JAVA_VERSION_OPTIONS = [
  { id: 'java21', name: 'Java 21 LTS (Recommended)', desc: 'For modern Minecraft builds' },
  { id: 'java17', name: 'Java 17 LTS', desc: 'For standard Minecraft builds' },
  { id: 'java11', name: 'Java 11 LTS', desc: 'For legacy Minecraft builds' },
  { id: 'java8', name: 'Java 8', desc: 'For classic Minecraft builds' }
];

const VPS_OS_OPTIONS = [
  { id: 'ubuntu-24', name: 'Ubuntu 24.04 LTS (Noble Numbat)', desc: 'Latest enterprise Linux release' },
  { id: 'ubuntu-22', name: 'Ubuntu 22.04 LTS (Jammy Jellyfish)', desc: 'Most popular production Linux' },
  { id: 'debian-12', name: 'Debian 12 Bookworm', desc: 'Rock-solid stability and low memory usage' },
  { id: 'almalinux-9', name: 'AlmaLinux 9', desc: 'RHEL-binary compatible enterprise distribution' },
  { id: 'rocky-9', name: 'Rocky Linux 9', desc: 'Community RHEL downstream distribution' },
  { id: 'win-2022', name: 'Windows Server 2022', desc: 'GUI edition with RDP access' }
];

const BOT_RUNTIME_OPTIONS = [
  { id: 'node-20', name: 'Node.js 20 LTS', desc: 'Modern JavaScript/TypeScript runtime for Discord.js & Eris' },
  { id: 'python-311', name: 'Python 3.11 Environment', desc: 'For discord.py, Pycord, Nextcord & AsyncIO' },
  { id: 'java-21', name: 'Java 21 OpenJDK', desc: 'For JDA (Java Discord API) and Lavalink nodes' },
  { id: 'golang-122', name: 'Golang 1.22', desc: 'High concurrency compiled bot binaries' },
  { id: 'rust-175', name: 'Rust 1.75 Environment', desc: 'Blazing fast low-footprint bot services' }
];

const WEB_STACK_OPTIONS = [
  { id: 'nginx-php83', name: 'Nginx + PHP 8.3 + MySQL', desc: 'Optimized LEMP web stack for WordPress & custom apps' },
  { id: 'apache-php82', name: 'Apache + PHP 8.2 + MariaDB', desc: 'Classic LAMP environment with .htaccess support' },
  { id: 'cpanel', name: 'cPanel / WHM License Node', desc: 'Graphical web management panel with 1-click installer' }
];

import { DEFAULT_ADDON_PRESETS } from '../constants';

export const CheckoutPage: React.FC<CheckoutPageProps> = ({ data, activeCurrency = 'INR' }) => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  // Authentication state
  const [user, setUser] = useState<any>(null);
  const [authLoading, setAuthLoading] = useState(true);

  // Workflow step: 'config' -> 'payment' -> 'verification'
  const [checkoutStep, setCheckoutStep] = useState<'config' | 'payment' | 'verification'>('config');

  // Selected Plan Data
  const planQuery = searchParams.get('plan');
  const directPlan = useMemo(() => {
    // 1. Try retrieving saved custom/game plan from sessionStorage if available
    try {
      const stored = sessionStorage.getItem('checkout_selected_plan');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed && parsed.id && (!planQuery || parsed.id.toLowerCase() === planQuery.toLowerCase() || parsed.id.includes(planQuery) || planQuery.includes(parsed.id))) {
          return parsed as CartItem & any;
        }
      }
    } catch (e) {
      console.error("Failed parsing stored checkout plan:", e);
    }

    if (!data?.plans || data.plans.length === 0) return null;

    if (planQuery) {
      // 2. Exact match in data.plans
      const matchInPlans = data.plans.find(p => p.id === planQuery || p.id.toLowerCase() === planQuery.toLowerCase());
      if (matchInPlans) return matchInPlans;

      // 3. Search inside games ramOptions for generated tier ids (e.g. game-minecraft-tier-0)
      for (const g of (data?.games || [])) {
        if (g.ramOptions) {
          for (let idx = 0; idx < g.ramOptions.length; idx++) {
            const opt = g.ramOptions[idx];
            const tierId = `${g.id}-tier-${idx}`;
            if (tierId === planQuery || tierId.toLowerCase() === planQuery.toLowerCase()) {
              return {
                id: tierId,
                name: `${g.title} ${opt.ram} (${opt.slots})`,
                price: String(Math.round(opt.priceInr / 83)),
                price_inr: String(opt.priceInr),
                badge: idx === 1 ? 'Best Value' : '',
                category: 'GAME-HOSTING',
                location: 'India (Mumbai)',
                node: opt.cpu || g.metadata?.cpuType || 'AMD RYZEN 9 5950X',
                desc: `High-performance ${g.title} node with ${opt.ram} RAM and ${opt.slots} capacity.`,
                features: opt.features && opt.features.length > 0 ? opt.features : [
                  `${opt.ram} Dedicated DDR4 RAM`,
                  `${opt.slots} Player Slots`,
                  `${opt.cpu || 'High-Clock CPU'}`,
                  g.metadata?.storage || '50GB NVMe Storage',
                  'Pterodactyl Panel Access',
                  'Instant 60s Deployment'
                ],
                is_active: true
              };
            }
          }
        }
      }

      // 4. Fuzzy match in data.plans
      const fuzzyPlan = data.plans.find(p => 
        p.id.toLowerCase().includes(planQuery.toLowerCase()) || 
        planQuery.toLowerCase().includes(p.id.toLowerCase())
      );
      if (fuzzyPlan) return fuzzyPlan;

      // 5. Category-aware fallback if query hints at game hosting
      if (planQuery.includes('game') || planQuery.includes('mc') || planQuery.includes('tier') || planQuery.includes('minecraft')) {
        const gamePlan = data.plans.find(p => (p.category || '').toUpperCase().includes('GAME'));
        if (gamePlan) return gamePlan;
      }
    }

    // 6. Default fallback to first plan
    return data.plans[0];
  }, [planQuery, data]);

  // Load available dynamic locations
  const dynamicLocations = useMemo(() => {
    return getDynamicLocations(data?.locations || []);
  }, [data?.locations]);

  // Product Customization State
  const [selectedLocation, setSelectedLocation] = useState('');
  
  useEffect(() => {
    if (dynamicLocations.length > 0 && !selectedLocation) {
      setSelectedLocation(dynamicLocations[0].name);
    }
  }, [dynamicLocations, selectedLocation]);

  const [selectedCycle, setSelectedCycle] = useState('monthly');
  
  // Dynamic Option States
  const [selectedSoftware, setSelectedSoftware] = useState('');
  const [selectedJavaVersion, setSelectedJavaVersion] = useState('Java 21 LTS (Recommended)');
  const [selectedStartupFile, setSelectedStartupFile] = useState('index.js / bot.py');
  const [selectedAddonIds, setSelectedAddonIds] = useState<string[]>([]);

  // Promo Code State
  const [promoInput, setPromoInput] = useState('');
  const [appliedPromo, setAppliedPromo] = useState<any>(() => {
    try {
      const raw = sessionStorage.getItem('hh_applied_promo');
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  });
  const [promoError, setPromoError] = useState<string | null>(null);
  const [promoSuccess, setPromoSuccess] = useState<string | null>(null);

  // Payment & QR Code States
  const [qrCodeUrl, setQrCodeUrl] = useState<string>('');
  const [copiedVpa, setCopiedVpa] = useState(false);
  const [utrNumber, setUtrNumber] = useState('');
  
  // 5-Minute Timer (300 seconds)
  const [timeLeft, setTimeLeft] = useState(300);
  const [timerExpired, setTimerExpired] = useState(false);

  // Submission State
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionError, setSubmissionError] = useState<string | null>(null);
  const [orderResult, setOrderResult] = useState<{
    invoiceId: string;
    invoiceNumber: string;
    totalPaid: number;
  } | null>(null);

  // Check Auth
  useEffect(() => {
    const unsub = authService.onAuthStateChanged((u) => {
      setUser(u);
      setAuthLoading(false);
    });
    return unsub;
  }, []);

  // Category determination
  const productCategory = useMemo(() => {
    if (!directPlan) return 'game';
    const cat = (directPlan.category || '').toLowerCase();
    const name = (directPlan.name || '').toLowerCase();
    
    if (cat.includes('vps') || cat.includes('dedicated') || name.includes('vps') || name.includes('ryzen') || name.includes('epyc')) return 'vps';
    if (cat.includes('bot') || cat.includes('discord') || name.includes('bot')) return 'bot';
    if (cat.includes('web') || name.includes('web')) return 'web';
    return 'game';
  }, [directPlan]);

  const detectedGameType = useMemo(() => {
    if (!directPlan) return 'minecraft';
    const text = `${directPlan.id || ''} ${directPlan.name || ''} ${directPlan.category || ''}`.toLowerCase();
    if (text.includes('rust')) return 'rust';
    if (text.includes('fivem') || text.includes('gta')) return 'fivem';
    if (text.includes('palworld') || text.includes('pal')) return 'palworld';
    if (text.includes('ark')) return 'ark';
    if (text.includes('cs2') || text.includes('counter')) return 'cs2';
    if (text.includes('minecraft') || text.includes('mc') || text.includes('spigot') || text.includes('paper')) return 'minecraft';
    return 'general';
  }, [directPlan]);

  // Compute active software options (checking admin custom options or fallback presets)
  const activeSoftwareOptions = useMemo(() => {
    const customOpts = data?.settings?.productConfigs?.softwareOptions;
    if (customOpts && customOpts.length > 0) {
      if (productCategory === 'game') {
        const match = customOpts.filter(o => o.category === 'game' && (o.gameType || 'minecraft').toLowerCase() === detectedGameType);
        if (match.length > 0) return match.map(m => ({ id: m.id, name: m.name, desc: m.desc }));
      } else {
        const match = customOpts.filter(o => o.category === productCategory);
        if (match.length > 0) return match.map(m => ({ id: m.id, name: m.name, desc: m.desc }));
      }
    }

    if (productCategory === 'game') {
      return GAME_SOFTWARE_PRESETS[detectedGameType] || GAME_SOFTWARE_PRESETS['general'];
    } else if (productCategory === 'vps') {
      return VPS_OS_OPTIONS;
    } else if (productCategory === 'bot') {
      return BOT_RUNTIME_OPTIONS;
    } else if (productCategory === 'web') {
      return WEB_STACK_OPTIONS;
    }
    return GAME_SOFTWARE_PRESETS['minecraft'];
  }, [productCategory, detectedGameType, data?.settings?.productConfigs?.softwareOptions]);

  // Compute available addons
  const availableAddons = useMemo(() => {
    const customAddons = data?.settings?.productConfigs?.addons ?? (data as any)?.productConfigs?.addons;
    if (customAddons !== undefined && Array.isArray(customAddons)) {
      return customAddons;
    }
    return DEFAULT_ADDON_PRESETS;
  }, [data?.settings?.productConfigs?.addons, (data as any)?.productConfigs?.addons]);

  // Clean up any deleted addons from selected state immediately
  useEffect(() => {
    setSelectedAddonIds(prev => prev.filter(id => availableAddons.some(a => a.id === id)));
  }, [availableAddons]);

  // Set default software option
  useEffect(() => {
    if (activeSoftwareOptions.length > 0) {
      if (!selectedSoftware || !activeSoftwareOptions.some(o => o.name === selectedSoftware)) {
        setSelectedSoftware(activeSoftwareOptions[0].name);
      }
    }
  }, [activeSoftwareOptions, selectedSoftware]);

  // Cycle multiplier calculation
  const cycleObj = BILLING_CYCLES.find(c => c.id === selectedCycle) || BILLING_CYCLES[0];
  const cycleMultiplier = cycleObj.discountMultiplier;

  const basePriceNum = parseFloat(String(directPlan?.price_inr || directPlan?.price || '499').replace(/[^0-9.]/g, '')) || 0;
  const cycleAdjustedBase = Math.round(basePriceNum * cycleMultiplier);

  const addonsPriceTotal = useMemo(() => {
    return selectedAddonIds.reduce((sum, id) => {
      const ad = availableAddons.find(a => a.id === id);
      return sum + (ad?.priceInr || 0);
    }, 0);
  }, [selectedAddonIds, availableAddons]);

  let promoDiscount = 0;
  if (appliedPromo) {
    const subtotal = cycleAdjustedBase + addonsPriceTotal;
    if (appliedPromo.type === 'percent') {
      promoDiscount = Math.round((subtotal * appliedPromo.value) / 100);
    } else if (appliedPromo.type === 'flat') {
      promoDiscount = Math.min(subtotal, appliedPromo.value);
    }
  }

  const finalPayable = Math.max(0, cycleAdjustedBase + addonsPriceTotal - promoDiscount);

  // 5-Minute Timer Effect when in 'payment' step
  useEffect(() => {
    if (checkoutStep !== 'payment') return;

    setTimerExpired(false);
    const interval = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          setTimerExpired(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [checkoutStep]);

  // Generate UPI QR Code URL when entering payment step or timer reset
  useEffect(() => {
    if (checkoutStep === 'payment' && finalPayable > 0) {
      const invoiceRefNum = Date.now().toString().slice(-6);
      const upiUrl = `upi://pay?pa=${UPI_VPA}&pn=HectorHosting&am=${finalPayable.toFixed(2)}&cu=INR&tn=Invoice_${invoiceRefNum}`;
      
      QRCode.toDataURL(upiUrl, {
        margin: 2,
        width: 300,
        color: {
          dark: '#0c0818',
          light: '#ffffff'
        }
      })
      .then(url => setQrCodeUrl(url))
      .catch(err => console.error('QR Code error:', err));
    }
  }, [checkoutStep, finalPayable]);

  const resetTimer = () => {
    setTimeLeft(300);
    setTimerExpired(false);
  };

  const handleCopyVpa = () => {
    navigator.clipboard.writeText(UPI_VPA);
    setCopiedVpa(true);
    setTimeout(() => setCopiedVpa(false), 2000);
  };

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    setPromoError(null);
    setPromoSuccess(null);

    const clean = promoInput.trim().toUpperCase();
    if (!clean) {
      setPromoError('Please enter a coupon code.');
      return;
    }

    if (clean === 'HECTOR10') {
      const p = { code: 'HECTOR10', type: 'percent', value: 10, description: '10% discount on total order' };
      setAppliedPromo(p);
      sessionStorage.setItem('hh_applied_promo', JSON.stringify(p));
      setPromoSuccess('10% discount coupon applied!');
    } else if (clean === 'WELCOME20') {
      const p = { code: 'WELCOME20', type: 'percent', value: 20, description: '20% off on your order' };
      setAppliedPromo(p);
      sessionStorage.setItem('hh_applied_promo', JSON.stringify(p));
      setPromoSuccess('20% discount coupon applied!');
    } else {
      setPromoError('Invalid coupon code. Try HECTOR10 or WELCOME20.');
    }
    setPromoInput('');
  };

  const handleRemovePromo = () => {
    setAppliedPromo(null);
    sessionStorage.removeItem('hh_applied_promo');
    setPromoSuccess(null);
    setPromoError(null);
  };

  // Step 1 -> Step 2
  const handleProceedToPayment = () => {
    setSubmissionError(null);

    if (!user) {
      navigate('/auth/login?redirect=checkout');
      return;
    }

    if (!directPlan) {
      setSubmissionError('No product selected.');
      return;
    }

    resetTimer();
    setCheckoutStep('payment');
  };

  // Step 2 -> Step 3 (Payment Completed clicked)
  const handleConfirmPaymentCompleted = async () => {
    setSubmissionError(null);

    if (!user) {
      navigate('/auth/login?redirect=checkout');
      return;
    }

    if (!directPlan) {
      setSubmissionError('Product plan not found.');
      return;
    }

    setIsSubmitting(true);

    try {
      const checkoutItem: CartItem = {
        id: `order_${directPlan.id}`,
        planId: directPlan.id,
        userId: user.uid,
        name: directPlan.name,
        price: String(basePriceNum),
        quantity: 1,
        category: directPlan.category || 'Hosting Plan',
        location: selectedLocation,
        billingCycle: selectedCycle,
        osTemplate: selectedSoftware,
        javaVersion: productCategory === 'game' ? selectedJavaVersion : undefined,
        startupFile: productCategory === 'bot' ? selectedStartupFile : undefined,
        specs: directPlan.features?.slice(0, 3).join(', '),
        product_id: (directPlan as any).product_id
      };

      const selectedAddonNames = selectedAddonIds
        .map(id => availableAddons.find(a => a.id === id)?.name)
        .filter(Boolean);

      const notesDetails = [
        `Datacenter: ${selectedLocation}`,
        `Software/OS: ${selectedSoftware}`,
        (productCategory === 'game' && detectedGameType === 'minecraft') ? `Java Runtime: ${selectedJavaVersion}` : null,
        selectedAddonNames.length > 0 ? `Addons: ${selectedAddonNames.join(', ')}` : null,
        utrNumber.trim() ? `UTR: ${utrNumber.trim()}` : 'Payment Completed via QR'
      ].filter(Boolean).join(' | ');

      const res = await billingService.checkout(
        user.uid,
        [checkoutItem],
        'UPI_PENDING_VERIFICATION',
        {
          utrNumber: utrNumber.trim() || undefined,
          couponCode: appliedPromo?.code,
          discountAmount: promoDiscount,
          notes: notesDetails
        }
      );

      sessionStorage.removeItem('hh_applied_promo');

      setOrderResult({
        invoiceId: res.invoiceId,
        invoiceNumber: res.invoiceNumber,
        totalPaid: res.totalPaid
      });

      setCheckoutStep('verification');
    } catch (err: any) {
      console.error('Order creation error:', err);
      setSubmissionError(err.message || 'Payment submission failed. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Timer Helper Display (05:00)
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-[#08060c] pt-32 pb-20 px-4 sm:px-6 flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-10 h-10 border-2 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs font-semibold text-slate-400 tracking-wider uppercase">Loading Checkout...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#08060c] text-slate-100 pt-28 pb-24 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-7xl mx-auto">
        
        {/* Navigation & Step Progress Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-3">
            <Link to="/" className="hover:text-purple-400 transition-colors">Home</Link>
            <span>/</span>
            <span className="text-slate-200 font-semibold">Checkout</span>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#231938] pb-5">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-2.5">
                {checkoutStep === 'config' && 'Configure Server Options'}
                {checkoutStep === 'payment' && 'Complete UPI Payment'}
                {checkoutStep === 'verification' && 'Payment Under Verification'}
              </h1>
              <p className="text-xs text-slate-400 mt-1">
                {checkoutStep === 'config' && 'Select your datacenter, contract billing term, and server engine software.'}
                {checkoutStep === 'payment' && 'Scan the dynamic UPI QR code within 5 minutes to submit payment.'}
                {checkoutStep === 'verification' && 'Your payment is being verified by our automated dispatch team.'}
              </p>
            </div>

            {/* Visual Step Indicator */}
            <div className="flex items-center gap-2 text-xs">
              <div className={`px-3 py-1.5 rounded-lg border font-bold flex items-center gap-1.5 ${
                checkoutStep === 'config' 
                  ? 'bg-purple-600/20 border-purple-500 text-purple-300' 
                  : 'bg-[#130e22] border-[#231938] text-slate-400'
              }`}>
                <span>1. Options</span>
              </div>
              <span className="text-slate-600">→</span>
              <div className={`px-3 py-1.5 rounded-lg border font-bold flex items-center gap-1.5 ${
                checkoutStep === 'payment' 
                  ? 'bg-purple-600/20 border-purple-500 text-purple-300' 
                  : 'bg-[#130e22] border-[#231938] text-slate-400'
              }`}>
                <span>2. Payment QR</span>
              </div>
              <span className="text-slate-600">→</span>
              <div className={`px-3 py-1.5 rounded-lg border font-bold flex items-center gap-1.5 ${
                checkoutStep === 'verification' 
                  ? 'bg-amber-500/20 border-amber-500 text-amber-300' 
                  : 'bg-[#130e22] border-[#231938] text-slate-400'
              }`}>
                <span>3. Verification</span>
              </div>
            </div>
          </div>
        </div>

        {/* ========================================================
            STEP 3: PAYMENT VERIFICATION PENDING (2-4 HOURS NOTICE)
           ======================================================== */}
        {checkoutStep === 'verification' && orderResult && (
          <div className="max-w-2xl mx-auto my-6">
            <div className="bg-[#130e22] border border-[#231938] rounded-xl p-8 sm:p-10 text-center space-y-6 shadow-2xl">
              
              {/* Amber Verification Hourglass Badge */}
              <div className="w-16 h-16 bg-amber-500/10 border border-amber-500/30 rounded-full flex items-center justify-center text-amber-400 mx-auto animate-pulse">
                <Hourglass size={34} />
              </div>

              <div className="space-y-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400 bg-amber-500/10 border border-amber-500/20 px-3 py-1 rounded-full">
                  Pending Verification
                </span>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight pt-2">
                  Payment Under Verification
                </h2>
              </div>

              {/* High Visibility 2-4 Hours Verification Notice Box */}
              <div className="bg-amber-950/30 border border-amber-500/30 rounded-xl p-5 text-left text-xs sm:text-sm text-amber-200 leading-relaxed space-y-2">
                <div className="font-bold text-amber-300 text-sm flex items-center gap-2">
                  <Clock size={16} className="shrink-0" />
                  <span>Payment Verification Notice</span>
                </div>
                <p>
                  Your order has been submitted and is currently undergoing payment verification by our billing team. 
                </p>
                <p className="font-semibold text-white">
                  Payment verification takes <span className="text-amber-400 font-extrabold underline">2 - 4 hours</span>. After payment verification is complete, your server node will be automatically deployed and login credentials will be dispatched to your Client Dashboard.
                </p>
              </div>

              {/* Order Reference Card */}
              <div className="bg-[#0c0818] border border-[#231938] rounded-lg p-5 text-left space-y-3 text-xs">
                <div className="flex items-center justify-between border-b border-[#231938] pb-3">
                  <span className="text-slate-400">Order Reference</span>
                  <span className="font-mono font-bold text-white">{orderResult.invoiceNumber}</span>
                </div>
                <div className="flex items-center justify-between border-b border-[#231938] pb-3">
                  <span className="text-slate-400">Plan Name</span>
                  <span className="font-bold text-white">{directPlan?.name}</span>
                </div>
                <div className="flex items-center justify-between border-b border-[#231938] pb-3">
                  <span className="text-slate-400">Datacenter Region</span>
                  <span className="text-purple-300 font-semibold">{selectedLocation}</span>
                </div>
                <div className="flex items-center justify-between border-b border-[#231938] pb-3">
                  <span className="text-slate-400">Software Engine</span>
                  <span className="text-slate-200">{selectedSoftware}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Total Payable</span>
                  <span className="font-bold text-emerald-400 tabular-nums">₹{orderResult.totalPaid.toFixed(2)}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <Link
                  to="/dashboard"
                  className="flex-1 py-3.5 px-4 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-colors text-center flex items-center justify-center gap-2"
                >
                  <span>Go to Client Dashboard</span>
                  <Zap size={14} />
                </Link>
                <a
                  href="https://gp.hector.host"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="py-3.5 px-5 border border-[#231938] bg-[#0c0818] hover:bg-[#1a1330] text-slate-300 hover:text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-colors flex items-center justify-center gap-2"
                >
                  <span>Open Game Panel</span>
                  <ExternalLink size={13} />
                </a>
              </div>

            </div>
          </div>
        )}

        {/* ========================================================
            STEP 2: PAYMENT PAGE (5-MINUTE DYNAMIC QR CODE TIMER)
           ======================================================== */}
        {checkoutStep === 'payment' && (
          <div className="max-w-2xl mx-auto my-4 space-y-6">
            
            <div className="bg-[#130e22] border border-[#231938] rounded-xl p-6 sm:p-8 space-y-6 shadow-2xl">
              
              <div className="flex items-center justify-between border-b border-[#231938] pb-4">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-widest text-purple-400 block mb-0.5">
                    UPI Payment Gateway
                  </span>
                  <h2 className="text-xl font-bold text-white">
                    Scan QR Code to Pay
                  </h2>
                </div>

                <button
                  onClick={() => setCheckoutStep('config')}
                  className="text-xs text-slate-400 hover:text-white flex items-center gap-1 transition-colors"
                >
                  <ArrowLeft size={13} />
                  <span>Modify Options</span>
                </button>
              </div>

              {/* 5-MIN COUNTDOWN TIMER BAR */}
              <div className={`p-4 rounded-xl border flex items-center justify-between transition-colors ${
                timerExpired 
                  ? 'bg-rose-500/10 border-rose-500/30 text-rose-300' 
                  : (timeLeft < 60 ? 'bg-amber-500/10 border-amber-500/30 text-amber-300' : 'bg-purple-600/10 border-purple-500/30 text-purple-300')
              }`}>
                <div className="flex items-center gap-2.5">
                  <Clock size={18} className="shrink-0" />
                  <div>
                    <div className="text-xs font-bold">
                      {timerExpired ? 'Payment QR Code Expired' : 'QR Code Valid Duration'}
                    </div>
                    <div className="text-[11px] opacity-80">
                      {timerExpired ? 'Please regenerate link to proceed.' : 'Complete transfer before timer runs out.'}
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="font-mono text-2xl font-black tabular-nums">
                    {formatTime(timeLeft)}
                  </div>
                </div>
              </div>

              {/* QR CODE & UPI VPA DETAILS */}
              {!timerExpired ? (
                <div className="bg-[#0c0818] border border-[#231938] rounded-xl p-6 flex flex-col sm:flex-row items-center gap-6">
                  
                  {/* High Contrast Dynamic QR Image */}
                  <div className="p-3 bg-white rounded-2xl shadow-lg shrink-0 border border-slate-200">
                    {qrCodeUrl ? (
                      <img 
                        src={qrCodeUrl} 
                        alt="Hector Hosting UPI Payment QR Code"
                        className="w-48 h-48 mx-auto object-contain"
                      />
                    ) : (
                      <div className="w-48 h-48 flex items-center justify-center text-slate-500 text-xs">
                        Generating QR Code...
                      </div>
                    )}
                  </div>

                  {/* Payment Instructions & Copy VPA */}
                  <div className="space-y-4 text-xs flex-1 w-full">
                    <div>
                      <div className="text-[11px] text-slate-400">Total Payable Amount</div>
                      <div className="text-2xl font-extrabold text-emerald-400 tabular-nums">
                        ₹{finalPayable.toFixed(2)}
                      </div>
                    </div>

                    <div>
                      <div className="text-[11px] text-slate-400 mb-1">Merchant UPI ID / VPA</div>
                      <div className="flex items-center gap-2">
                        <code className="px-3 py-1.5 rounded-lg bg-[#130e22] border border-[#231938] font-mono text-xs text-purple-300 font-bold select-all flex-1">
                          {UPI_VPA}
                        </code>
                        <button
                          type="button"
                          onClick={handleCopyVpa}
                          className="px-3 py-1.5 rounded-lg border border-[#231938] bg-[#1a1330] hover:bg-[#231938] text-slate-200 text-xs font-semibold transition-colors flex items-center gap-1 shrink-0"
                        >
                          {copiedVpa ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
                          <span>{copiedVpa ? 'Copied' : 'Copy'}</span>
                        </button>
                      </div>
                    </div>

                    <div className="text-[11px] text-slate-400 space-y-1 leading-relaxed bg-[#130e22] p-3 rounded-lg border border-[#231938]">
                      <p>1. Open Google Pay, PhonePe, Paytm, CRED or BHIM.</p>
                      <p>2. Scan QR or pay exactly <span className="text-white font-bold">₹{finalPayable.toFixed(2)}</span> to <span className="text-purple-300 font-mono">{UPI_VPA}</span>.</p>
                    </div>
                  </div>

                </div>
              ) : (
                /* Timer Expired Banner */
                <div className="bg-[#0c0818] border border-rose-500/30 rounded-xl p-8 text-center space-y-4">
                  <div className="w-12 h-12 bg-rose-500/10 rounded-full flex items-center justify-center text-rose-400 mx-auto">
                    <AlertCircle size={24} />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">QR Session Expired</h3>
                    <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                      The 5-minute payment window has elapsed. Click below to refresh the payment link and reset timer.
                    </p>
                  </div>
                  <button
                    onClick={resetTimer}
                    className="inline-flex items-center gap-2 px-5 py-2.5 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-colors"
                  >
                    <RefreshCw size={14} />
                    <span>Regenerate Payment QR</span>
                  </button>
                </div>
              )}

              {/* Optional UTR Input */}
              {!timerExpired && (
                <div className="space-y-2 pt-2 border-t border-[#231938]">
                  <label htmlFor="utrInput" className="text-xs font-semibold text-slate-300 block">
                    Transaction Ref / UTR Number (Optional)
                  </label>
                  <input
                    id="utrInput"
                    type="text"
                    value={utrNumber}
                    onChange={(e) => setUtrNumber(e.target.value.replace(/[^0-9a-zA-Z]/g, ''))}
                    placeholder="e.g. 426819284719"
                    maxLength={20}
                    className="w-full bg-[#0c0818] border border-[#231938] rounded-lg px-3.5 py-2.5 text-xs text-white placeholder-slate-500 font-mono focus:outline-none focus:border-purple-500"
                  />
                </div>
              )}

              {/* Submission Error Banner */}
              {submissionError && (
                <div className="p-3.5 rounded-lg border border-rose-500/40 bg-rose-500/10 text-rose-300 text-xs flex items-start gap-2">
                  <AlertCircle size={15} className="shrink-0 mt-0.5" />
                  <span>{submissionError}</span>
                </div>
              )}

              {/* Payment Completed CTA */}
              <button
                type="button"
                onClick={handleConfirmPaymentCompleted}
                disabled={isSubmitting || timerExpired}
                className="w-full py-4 px-4 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/30"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Submitting Order...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 size={16} />
                    <span>Payment Completed</span>
                  </>
                )}
              </button>

            </div>

          </div>
        )}

        {/* ========================================================
            STEP 1: PRODUCT CUSTOMIZATION / SPECIFICATIONS CONFIG
           ======================================================== */}
        {checkoutStep === 'config' && directPlan && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Left Column: Customization Form (7 cols) */}
            <div className="lg:col-span-7 space-y-6">
              
              {/* Product Info Header */}
              <div className="bg-[#130e22] border border-[#231938] rounded-xl p-6 space-y-4">
                <div className="flex items-start justify-between gap-4 border-b border-[#231938] pb-4">
                  <div className="flex items-start gap-3">
                    <div className="w-11 h-11 rounded-lg bg-[#1a1330] border border-[#231938] flex items-center justify-center text-purple-400 shrink-0">
                      <Server size={20} />
                    </div>
                    <div>
                      <h2 className="text-base sm:text-lg font-bold text-white">
                        {directPlan.name}
                      </h2>
                      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 mt-1">
                        <span>Category: <strong className="text-slate-200">{directPlan.category}</strong></span>
                        {(directPlan as any).product_id && (
                          <>
                            <span>·</span>
                            <span className="font-mono bg-[#0c0818] border border-[#231938] px-1.5 py-0.5 rounded text-[10px] text-purple-300">
                              SKU: {(directPlan as any).product_id}
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-xs text-slate-400">Base Unit Rate</div>
                    <div className="text-base font-bold text-white tabular-nums">
                      ₹{basePriceNum} <span className="text-[10px] text-slate-400 font-normal">/ mo</span>
                    </div>
                  </div>
                </div>

                {/* Specs Highlights */}
                {directPlan.features && directPlan.features.length > 0 && (
                  <div className="bg-[#0c0818] border border-[#231938] rounded-lg p-3 text-xs text-slate-300 flex items-center gap-2">
                    <Cpu size={15} className="text-purple-400 shrink-0" />
                    <span>Included Hardware: <strong className="text-white">{directPlan.features.slice(0, 3).join(', ')}</strong></span>
                  </div>
                )}
              </div>

              {/* 1. Datacenter Location Selection */}
              <div className="bg-[#130e22] border border-[#231938] rounded-xl p-6 space-y-4">
                <div className="flex items-center justify-between border-b border-[#231938] pb-3">
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <Globe size={16} className="text-purple-400" />
                      Available Datacenter Regions
                    </h3>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Select target low-latency region.
                    </p>
                  </div>
                  <span className="text-[10px] uppercase tracking-wider font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded">
                    {dynamicLocations.length} Online
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {dynamicLocations.map(loc => {
                    const isSelected = selectedLocation === loc.name;
                    return (
                      <button
                        key={loc.id}
                        type="button"
                        onClick={() => setSelectedLocation(loc.name)}
                        className={`p-3.5 rounded-lg border text-left transition-all relative ${
                          isSelected
                            ? 'border-purple-500 bg-[#1a1330] text-white shadow-sm ring-1 ring-purple-500/50'
                            : 'border-[#231938] bg-[#0c0818] text-slate-300 hover:border-purple-500/40 hover:bg-[#130e22]'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs font-bold text-white">{loc.name}</span>
                          <span className="text-[10px] text-emerald-400 font-mono font-bold bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
                            {loc.ping}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400 flex items-center justify-between mt-1">
                          <span>{loc.load || 'Available'}</span>
                          {isSelected && <Check size={14} className="text-purple-400" />}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 2. Billing Cycle Selection */}
              <div className="bg-[#130e22] border border-[#231938] rounded-xl p-6 space-y-4">
                <div className="flex items-center justify-between border-b border-[#231938] pb-3">
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <Clock size={16} className="text-purple-400" />
                      Billing Cycle & Commitment Term
                    </h3>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Save up to 15% on long-term commitments
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {BILLING_CYCLES.map(cycle => {
                    const isSelected = selectedCycle === cycle.id;
                    return (
                      <button
                        key={cycle.id}
                        type="button"
                        onClick={() => setSelectedCycle(cycle.id)}
                        className={`p-3 rounded-lg border text-center transition-all ${
                          isSelected
                            ? 'border-purple-500 bg-[#1a1330] text-white ring-1 ring-purple-500/50'
                            : 'border-[#231938] bg-[#0c0818] text-slate-300 hover:border-purple-500/40'
                        }`}
                      >
                        <div className="text-xs font-bold text-white">{cycle.label}</div>
                        <div className={`text-[10px] mt-1 font-semibold ${isSelected ? 'text-purple-300' : 'text-slate-400'}`}>
                          {cycle.badge}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 3. Product Specific Software Options */}
              <div className="bg-[#130e22] border border-[#231938] rounded-xl p-6 space-y-5">
                <div className="border-b border-[#231938] pb-3">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Settings size={16} className="text-purple-400" />
                    {productCategory === 'game' && `${detectedGameType.toUpperCase()} Engine & Server Software`}
                    {productCategory === 'vps' && 'Operating System & Linux Image'}
                    {productCategory === 'bot' && 'Application Runtime & Environment'}
                    {productCategory === 'web' && 'Web Hosting Stack & Management'}
                  </h3>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Select your preferred pre-configured stack.
                  </p>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-2">
                    {productCategory === 'game' ? `${detectedGameType.toUpperCase()} Engine / Software Build` : (productCategory === 'vps' ? 'OS Distribution' : 'Runtime Environment')}
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {activeSoftwareOptions.map((opt) => {
                      const isSelected = selectedSoftware === opt.name;
                      return (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => setSelectedSoftware(opt.name)}
                          className={`p-3 rounded-lg border text-left transition-all ${
                            isSelected
                              ? 'border-purple-500 bg-[#1a1330] text-white ring-1 ring-purple-500/50'
                              : 'border-[#231938] bg-[#0c0818] text-slate-300 hover:border-purple-500/40'
                          }`}
                        >
                          <div className="text-xs font-bold text-white flex items-center justify-between">
                            <span>{opt.name}</span>
                            {isSelected && <Check size={13} className="text-purple-400 shrink-0" />}
                          </div>
                          <div className="text-[10px] text-slate-400 mt-0.5 leading-snug">{opt.desc}</div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Java Version selector ONLY for Minecraft */}
                {productCategory === 'game' && detectedGameType === 'minecraft' && (
                  <div className="pt-3 border-t border-[#231938]">
                    <label className="text-xs font-semibold text-slate-300 block mb-2">
                      Java Runtime Version
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {JAVA_VERSION_OPTIONS.map((javaOpt) => {
                        const isSelected = selectedJavaVersion === javaOpt.name;
                        return (
                          <button
                            key={javaOpt.id}
                            type="button"
                            onClick={() => setSelectedJavaVersion(javaOpt.name)}
                            className={`p-2.5 rounded-lg border text-left transition-all ${
                              isSelected
                                ? 'border-purple-500 bg-[#1a1330] text-white'
                                : 'border-[#231938] bg-[#0c0818] text-slate-300 hover:border-purple-500/40'
                            }`}
                          >
                            <div className="text-xs font-bold text-white">{javaOpt.name}</div>
                            <div className="text-[10px] text-slate-400">{javaOpt.desc}</div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {productCategory === 'bot' && (
                  <div className="pt-2 border-t border-[#231938]">
                    <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                      Main Entry File / Startup File
                    </label>
                    <input
                      type="text"
                      value={selectedStartupFile}
                      onChange={(e) => setSelectedStartupFile(e.target.value)}
                      placeholder="index.js, bot.py, app.js or main.go"
                      className="w-full bg-[#0c0818] border border-[#231938] rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-purple-500"
                    />
                  </div>
                )}
              </div>

              {/* 4. Optional Addons & Configuration Upgrades */}
              {availableAddons.length > 0 && (
                <div className="bg-[#130e22] border border-[#231938] rounded-xl p-6 space-y-4">
                  <div className="border-b border-[#231938] pb-3">
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <Sparkles size={16} className="text-purple-400" />
                      Optional Addons & Upgrades
                    </h3>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Select additional infrastructure features or managed services.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {availableAddons.map(ad => {
                      const isChecked = selectedAddonIds.includes(ad.id);
                      return (
                        <button
                          key={ad.id}
                          type="button"
                          onClick={() => {
                            if (isChecked) {
                              setSelectedAddonIds(prev => prev.filter(id => id !== ad.id));
                            } else {
                              setSelectedAddonIds(prev => [...prev, ad.id]);
                            }
                          }}
                          className={`p-3.5 rounded-lg border text-left transition-all ${
                            isChecked
                              ? 'border-purple-500 bg-[#1a1330] text-white ring-1 ring-purple-500/40'
                              : 'border-[#231938] bg-[#0c0818] text-slate-300 hover:border-purple-500/40'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xs font-bold text-white">{ad.name}</span>
                            <div className={`w-4 h-4 rounded flex items-center justify-center border transition-all ${
                              isChecked ? 'bg-purple-600 border-purple-400 text-white' : 'border-[#231938] bg-[#130e22]'
                            }`}>
                              {isChecked && <Check size={12} />}
                            </div>
                          </div>
                          <p className="text-[10px] text-slate-400 leading-tight mb-2">{ad.desc}</p>
                          <div className="flex items-center justify-between text-[11px] font-mono">
                            <span className="text-emerald-400 font-bold">+₹{ad.priceInr} / mo</span>
                            {ad.badge && (
                              <span className="px-1.5 py-0.5 bg-purple-500/10 border border-purple-500/20 text-purple-300 rounded text-[9px] font-sans">
                                {ad.badge}
                              </span>
                            )}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

            </div>

            {/* Right Column: Order Summary & Action (5 cols) */}
            <div className="lg:col-span-5 space-y-6">
              
              <div className="bg-[#130e22] border border-[#231938] rounded-xl p-6 sticky top-28 space-y-6">
                
                <h2 className="text-base font-bold text-white border-b border-[#231938] pb-4">
                  Product Config Summary
                </h2>

                <div className="bg-[#0c0818] border border-[#231938] rounded-lg p-4 space-y-2 text-xs">
                  <div className="flex justify-between text-slate-400">
                    <span>Selected Plan:</span>
                    <strong className="text-white">{directPlan.name}</strong>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Datacenter:</span>
                    <strong className="text-purple-300">{selectedLocation}</strong>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Software Engine:</span>
                    <strong className="text-slate-200">{selectedSoftware}</strong>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Contract Period:</span>
                    <strong className="text-slate-200">{cycleObj.label}</strong>
                  </div>
                </div>

                {/* Pricing Calculation */}
                <div className="space-y-3 text-xs">
                  <div className="flex items-start justify-between text-slate-300">
                    <div>
                      <div className="font-semibold text-white">{directPlan.name}</div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        Base Rate: ₹{basePriceNum} / mo
                      </div>
                    </div>
                    <span className="font-semibold text-white tabular-nums">
                      ₹{cycleAdjustedBase.toFixed(2)}
                    </span>
                  </div>

                  {addonsPriceTotal > 0 && (
                    <div className="flex items-center justify-between text-purple-300 pt-2 border-t border-[#231938]">
                      <span>Selected Addons & Upgrades</span>
                      <span className="font-semibold tabular-nums">+₹{addonsPriceTotal.toFixed(2)}</span>
                    </div>
                  )}

                  {appliedPromo && promoDiscount > 0 && (
                    <div className="flex items-center justify-between text-emerald-400 pt-2 border-t border-[#231938]">
                      <div className="flex items-center gap-1">
                        <Tag size={12} />
                        <span>Promo ({appliedPromo.code})</span>
                        <button onClick={handleRemovePromo} className="text-slate-500 hover:text-rose-400 ml-1">
                          <X size={12} />
                        </button>
                      </div>
                      <span className="font-semibold tabular-nums">-₹{promoDiscount.toFixed(2)}</span>
                    </div>
                  )}

                  <div className="flex items-center justify-between text-slate-400 pt-2 border-t border-[#231938]">
                    <span>Hardware Provisioning</span>
                    <span className="font-semibold text-emerald-400">Instant (₹0)</span>
                  </div>

                  <div className="pt-4 border-t border-[#231938] flex items-baseline justify-between">
                    <div>
                      <span className="text-sm font-bold text-white block">Total Payable Rate</span>
                      <span className="text-[11px] text-slate-400">Billed for {cycleObj.label}</span>
                    </div>
                    <span className="text-2xl font-bold text-purple-400 tabular-nums">
                      ₹{finalPayable.toFixed(2)}
                    </span>
                  </div>
                </div>

                {/* Promo Coupon */}
                <form onSubmit={handleApplyPromo} className="space-y-2 pt-2 border-t border-[#231938]">
                  <label htmlFor="promoInput" className="text-xs font-semibold text-slate-400 block">
                    Have a promo coupon?
                  </label>
                  <div className="flex gap-2">
                    <input
                      id="promoInput"
                      type="text"
                      value={promoInput}
                      onChange={(e) => setPromoInput(e.target.value)}
                      placeholder="e.g. HECTOR10"
                      className="flex-1 bg-[#0c0818] border border-[#231938] rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 font-mono"
                    />
                    <button
                      type="submit"
                      className="px-3.5 py-2 bg-[#1a1330] hover:bg-[#231938] text-purple-300 hover:text-white border border-[#231938] hover:border-purple-500/50 rounded-lg text-xs font-semibold transition-colors"
                    >
                      Apply
                    </button>
                  </div>
                  {promoError && <p className="text-[11px] text-rose-400 mt-1">{promoError}</p>}
                  {promoSuccess && (
                    <p className="text-[11px] text-emerald-400 mt-1 flex items-center gap-1">
                      <Check size={12} /> {promoSuccess}
                    </p>
                  )}
                </form>

                {/* Submission Error Banner */}
                {submissionError && (
                  <div className="p-3.5 rounded-lg border border-rose-500/40 bg-rose-500/10 text-rose-300 text-xs flex items-start gap-2">
                    <AlertCircle size={15} className="shrink-0 mt-0.5" />
                    <span>{submissionError}</span>
                  </div>
                )}

                {/* Primary Proceed CTA Button */}
                <button
                  type="button"
                  onClick={handleProceedToPayment}
                  className="w-full py-4 px-4 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-lg shadow-purple-900/20"
                >
                  <span>{user ? 'Proceed to Payment' : 'Login / Sign Up to Pay'}</span>
                  <ArrowRight size={15} />
                </button>

                {/* Guarantees */}
                <div className="space-y-2.5 pt-3 border-t border-[#231938] text-[11px] text-slate-400">
                  <div className="flex items-center gap-2 text-slate-300">
                    <ShieldCheck size={14} className="text-purple-400 shrink-0" />
                    <span>256-Bit Encrypted Transaction</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-300">
                    <Clock size={14} className="text-purple-400 shrink-0" />
                    <span>5-Minute Dynamic UPI Payment Window</span>
                  </div>
                </div>

              </div>

            </div>

          </div>
        )}

      </div>
    </div>
  );
};
