import React from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, ArrowLeft, FileText, Scale, Building, CheckCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { AppData } from '../types';
import { parseLegalMarkdown } from '../lib/policyParser';
import { FormattedMarkdown } from '../components/FormattedMarkdown';

interface LegalPageProps {
  data: AppData;
}

export const LegalPage: React.FC<LegalPageProps> = ({ data }) => {
  const parsed = parseLegalMarkdown(data.legal);

  return (
    <div className="min-h-screen bg-bg text-foreground pt-32 pb-24 px-4 sm:px-6 relative overflow-hidden font-sans">
      
      {/* Subtle Ambient Glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[600px] bg-[radial-gradient(circle_at_center,rgba(139,92,246,0.02)_0%,transparent_70%)] pointer-events-none" />

      <div className="max-w-6xl mx-auto relative z-10">
        
        {/* Navigation Breadcrumb */}
        <div className="mb-12">
          <Link to="/" className="inline-flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.2em] text-foreground-dim hover:text-accent transition-all group">
            <ArrowLeft size={14} className="group-hover:-translate-x-1 transition-transform" />
            Back to Home
          </Link>
        </div>

        {/* Header Hero Banner */}
        <div className="bg-bg border border-border rounded-xl p-8 sm:p-12 mb-16 shadow-sm">
          <div className="flex items-center gap-3 text-accent mb-6">
            <Scale size={22} />
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-foreground-dim">Statutory Framework & Governance</span>
          </div>
          <h1 className="text-3xl sm:text-6xl font-extrabold text-foreground uppercase tracking-tight mb-4">
            {parsed.title}
          </h1>
          <p className="text-sm sm:text-base text-foreground-muted font-normal leading-relaxed text-balance max-w-3xl">
            {parsed.subtitle}
          </p>
        </div>

        {/* Entity & Jurisdiction Split */}
        <div className="grid md:grid-cols-2 gap-8 mb-16">
          <div className="bg-bg-alt border border-border p-8 rounded-xl space-y-4">
            <div className="w-10 h-10 bg-bg border border-border rounded-lg flex items-center justify-center text-accent">
              <Building size={20} />
            </div>
            <h3 className="text-lg font-black text-foreground uppercase tracking-tight">Incorporated Entity</h3>
            <p className="text-sm font-bold text-foreground mb-1">{parsed.entityName}</p>
            <p className="text-xs text-foreground-muted leading-relaxed">
              Operating under the laws of the Republic of India and compliant with the Information Technology Act, 2000. Headquartered in Mumbai, Maharashtra.
            </p>
          </div>

          <div className="bg-bg-alt border border-border p-8 rounded-xl space-y-4">
            <div className="w-10 h-10 bg-bg border border-border rounded-lg flex items-center justify-center text-accent">
              <Scale size={20} />
            </div>
            <h3 className="text-lg font-black text-foreground uppercase tracking-tight">Legal Jurisdiction</h3>
            <p className="text-sm font-bold text-foreground mb-1">Mumbai Court Jurisdiction</p>
            <p className="text-xs text-foreground-muted leading-relaxed">
              All legal claims, disputes, and operational interpretations are subject exclusively to the competent courts located in <span className="text-foreground font-bold">Mumbai, Maharashtra, India</span>.
            </p>
          </div>
        </div>

        {/* Regulatory Compliance Badges */}
        <div className="mb-20">
          <div className="flex items-center gap-3 mb-8">
            <ShieldCheck size={18} className="text-accent" />
            <h2 className="text-2xl font-black text-foreground uppercase tracking-tight">Statutory Compliance Directives</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {parsed.complianceList.map((item, idx) => (
              <div key={idx} className="bg-bg border border-border p-6 rounded-xl flex items-start gap-3 shadow-sm">
                <CheckCircle size={18} className="text-emerald-500 shrink-0 mt-0.5" />
                <span className="text-xs font-bold text-foreground uppercase tracking-wider leading-snug">{item}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Dynamic Legal Sections */}
        {parsed.sections.length > 0 && (
          <div className="space-y-px bg-border border border-border rounded-xl overflow-hidden shadow-sm">
            {parsed.sections.map((sec, idx) => (
              <div key={idx} id={sec.id} className="bg-bg p-8 sm:p-12 space-y-4">
                <h3 className="text-xl font-black text-foreground uppercase tracking-tight">{sec.title}</h3>
                <FormattedMarkdown content={sec.content} />
              </div>
            ))}
          </div>
        )}

      </div>
    </div>
  );
};
