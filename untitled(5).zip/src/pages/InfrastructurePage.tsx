import React from 'react';
import { motion } from 'motion/react';
import { Server, ArrowLeft, ShieldCheck, Cpu, Network, Zap, CheckCircle, MapPin, Activity } from 'lucide-react';
import { Link } from 'react-router-dom';
import { AppData } from '../types';
import { parseInfrastructureMarkdown } from '../lib/policyParser';
import { FormattedMarkdown } from '../components/FormattedMarkdown';

interface InfrastructurePageProps {
  data: AppData;
}

export const InfrastructurePage: React.FC<InfrastructurePageProps> = ({ data }) => {
  const parsed = parseInfrastructureMarkdown(data.infrastructure);

  return (
    <div className="min-h-screen bg-bg text-foreground pt-32 pb-24 px-4 sm:px-6 relative overflow-hidden font-sans">
      
      {/* Subtle Ambient Glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[600px] bg-[radial-gradient(circle_at_center,rgba(139,92,246,0.02)_0%,transparent_70%)] pointer-events-none" />

      <div className="max-w-6xl mx-auto relative z-10">
        
        {/* Navigation Breadcrumb */}
        <div className="mb-12">
          <Link to="/" className="inline-flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.2em] text-foreground-dim hover:text-accent transition-all group">
            <ArrowLeft size={14} className="group-hover:-translate-x-1 transition-transform" />
            Back to Home
          </Link>
        </div>

        {/* Header Hero Banner */}
        <div className="bg-bg border border-border rounded-xl p-8 sm:p-12 mb-16 shadow-sm">
          <div className="flex items-center gap-3 text-accent mb-6">
            <Server size={22} />
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-foreground-dim">Global Compute Architecture</span>
          </div>
          <h1 className="text-3xl sm:text-6xl font-extrabold text-foreground uppercase tracking-tight mb-4">
            {parsed.title}
          </h1>
          <p className="text-sm sm:text-base text-foreground-muted font-normal leading-relaxed text-balance max-w-3xl">
            {parsed.subtitle}
          </p>
        </div>

        {/* Datacenter & Backbone Highlights Grid */}
        <div className="grid md:grid-cols-3 gap-6 mb-16">
          <div className="bg-bg-alt/70 border border-border/80 p-8 rounded-2xl space-y-4 backdrop-blur-xl hover:border-accent/40 transition-all shadow-lg">
            <div className="w-12 h-12 bg-bg border border-border rounded-xl flex items-center justify-center text-accent">
              <MapPin size={22} />
            </div>
            <h3 className="text-xl font-black text-foreground uppercase tracking-tight font-display">Primary Datacenter</h3>
            <p className="text-xs text-foreground-muted leading-relaxed font-normal">
              Enterprise Tier-4 facility in <span className="text-foreground font-bold">Mumbai, Maharashtra, India</span> featuring N+2 power redundancy and dual grid connectivity.
            </p>
          </div>

          <div className="bg-bg-alt/70 border border-border/80 p-8 rounded-2xl space-y-4 backdrop-blur-xl hover:border-accent/40 transition-all shadow-lg">
            <div className="w-12 h-12 bg-bg border border-border rounded-xl flex items-center justify-center text-accent">
              <Network size={22} />
            </div>
            <h3 className="text-xl font-black text-foreground uppercase tracking-tight font-display">Direct Peering Fabric</h3>
            <p className="text-xs text-foreground-muted leading-relaxed font-normal">
              Direct interconnectivity via <span className="text-foreground font-bold">NIXI (National Internet Exchange of India)</span> and Tier-1 Indian telco backbones (Airtel, Jio, Tata).
            </p>
          </div>

          <div className="bg-bg-alt/70 border border-border/80 p-8 rounded-2xl space-y-4 backdrop-blur-xl hover:border-accent/40 transition-all shadow-lg">
            <div className="w-12 h-12 bg-bg border border-border rounded-xl flex items-center justify-center text-accent">
              <Zap size={22} />
            </div>
            <h3 className="text-xl font-black text-foreground uppercase tracking-tight font-display">Low Ping Latency</h3>
            <p className="text-xs text-foreground-muted leading-relaxed font-normal">
              Guaranteed <span className="text-emerald-400 font-bold font-mono">sub-15ms round-trip latency</span> across major metro zones throughout the Indian subcontinent.
            </p>
          </div>
        </div>

        {/* Hardware Benchmark Specs */}
        <div className="mb-20">
          <div className="flex items-center gap-3 mb-8">
            <Activity size={20} className="text-accent" />
            <h2 className="text-2xl font-black text-foreground uppercase tracking-tight font-display">Performance Threshold Benchmarks</h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {parsed.specs.map((spec, idx) => (
              <div key={idx} className="bg-bg-alt/70 border border-border/80 rounded-2xl p-8 text-center space-y-2 backdrop-blur-xl hover:border-accent/40 transition-all shadow-md">
                <div className="text-[10px] font-black text-foreground-dim uppercase tracking-widest">{spec.metric}</div>
                <div className="text-2xl sm:text-3xl font-black text-foreground tracking-tighter font-display">{spec.guaranteed}</div>
                <div className="text-[10px] font-mono text-emerald-400 font-bold">Avg: {spec.average}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Hardware Stack Cards */}
        <div className="mb-20">
          <div className="flex items-center gap-3 mb-8">
            <Cpu size={20} className="text-accent" />
            <h2 className="text-2xl font-black text-foreground uppercase tracking-tight font-display">Silicon & Network Stack</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {parsed.hardwareStack.map((item, idx) => (
              <div key={idx} className="bg-bg-alt/70 border border-border/80 p-8 rounded-2xl space-y-3 backdrop-blur-xl hover:border-accent/40 transition-all shadow-md">
                <div className="w-10 h-10 rounded-xl bg-bg border border-border flex items-center justify-center text-accent">
                  <CheckCircle size={18} />
                </div>
                <h4 className="text-base font-extrabold text-foreground uppercase tracking-tight font-display">{item.title}</h4>
                <p className="text-xs text-foreground-muted leading-relaxed font-normal">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Dynamic Infrastructure Sections */}
        {parsed.sections.length > 0 && (
          <div className="space-y-6">
            {parsed.sections.map((sec, idx) => (
              <div key={idx} id={sec.id} className="bg-bg-alt/70 border border-border/80 p-8 sm:p-12 rounded-2xl space-y-4 backdrop-blur-xl shadow-lg">
                <h3 className="text-xl font-black text-foreground uppercase tracking-tight font-display">{sec.title}</h3>
                <FormattedMarkdown content={sec.content} />
              </div>
            ))}
          </div>
        )}

      </div>
    </div>
  );
};
