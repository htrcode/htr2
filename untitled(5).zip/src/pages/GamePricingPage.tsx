import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { 
  ArrowLeft, 
  CheckCircle2, 
  Cpu, 
  HardDrive, 
  Shield, 
  Zap, 
  Server, 
  Globe, 
  Sparkles, 
  ArrowRight,
  ChevronRight,
  ChevronDown,
  Layers,
  Clock,
  Sliders,
  MessageSquare,
  Lock,
  Star,
  DollarSign
} from 'lucide-react';
import { AppData, Plan, Game } from '../types';
import { parseAmount } from '../utils/formatUtils';
import { getDynamicLocations } from '../utils/locationUtils';

interface GamePricingPageProps {
  data: AppData;
  activeCurrency?: 'USD' | 'INR' | 'EUR';
  handleOrder: (plan: Plan) => void;
}

export const GamePricingPage: React.FC<GamePricingPageProps> = ({
  data,
  activeCurrency = 'INR',
  handleOrder,
}) => {
  const { gameId } = useParams<{ gameId: string }>();
  const navigate = useNavigate();

  // Find game by multiple potential URL match patterns
  const game = (data.games || []).find(g => {
    if (!gameId) return false;
    const cleanParam = gameId.toLowerCase();
    const cleanId = g.id.toLowerCase();
    return (
      cleanId === cleanParam ||
      cleanId.replace('game-', '') === cleanParam ||
      cleanId.replace('game-mc-', 'minecraft-') === cleanParam ||
      g.title.toLowerCase().replace(/[^a-z0-9]+/g, '-') === cleanParam
    );
  });

  // Redirect to game-servers if game not found
  useEffect(() => {
    if (!game) {
      navigate('/game-servers');
    }
  }, [game, navigate]);

  if (!game) return null;

  const locations = getDynamicLocations(data?.locations);

  // Selected config states
  const [selectedLocation, setSelectedLocation] = useState(
    locations[0]?.name || 'India (Mumbai)'
  );
  const [selectedCycle, setSelectedCycle] = useState<'monthly' | 'quarterly' | 'annual'>('monthly');
  const [selectedPlanId, setSelectedPlanId] = useState<string | null>(null);
  const [activeFaq, setActiveFaq] = useState<number | null>(0);
  const [selectedCategoryTab, setSelectedCategoryTab] = useState<'budget' | 'standard' | 'performance'>('standard');

  useEffect(() => {
    if (locations.length > 0 && !locations.some(l => l.name === selectedLocation)) {
      setSelectedLocation(locations[0].name);
    }
  }, [locations, selectedLocation]);

  // Reset selected plan and subcategory tab when switching games
  useEffect(() => {
    setSelectedPlanId(null);
    setSelectedCategoryTab('standard');
  }, [game.id]);

  // Format currency helper
  const formatPrice = (priceInr: number) => {
    if (activeCurrency === 'USD') {
      return `$${Math.round(priceInr / 83)}`;
    }
    if (activeCurrency === 'EUR') {
      return `€${Math.round(priceInr / 90)}`;
    }
    return `₹${priceInr}`;
  };

  // Query all active GAME-HOSTING plans from admin database
  const allGameHostingPlans = (data.plans?.filter(p => {
    if (p.is_active === false || p.archived) return false;
    const cat = (p.category || '').toLowerCase().replace(/[-_ ]/g, '');
    const gameTitlesAndIds = (data.games || []).map(g => g.title.toLowerCase().replace(/[-_ ]/g, ''));
    const gameIdsClean = (data.games || []).map(g => g.id.toLowerCase().replace('game-', '').replace(/[-_ ]/g, ''));
    
    return (
      cat.includes('game') ||
      cat === 'gamehosting' ||
      gameTitlesAndIds.some(title => cat.includes(title) || title.includes(cat)) ||
      gameIdsClean.some(id => cat.includes(id) || id.includes(cat))
    );
  }) || []).sort((a, b) => (a.order || 0) - (b.order || 0));

  // Find plans specifically tailored or named for this game
  const specificGamePlans = allGameHostingPlans.filter(p => {
    const name = (p.name || '').toLowerCase();
    const id = (p.id || '').toLowerCase();
    const desc = (p.desc || '').toLowerCase();
    const cat = (p.category || '').toLowerCase();
    const gameTitle = (game.title || '').toLowerCase();
    const gameIdClean = game.id.toLowerCase().replace('game-', '');

    const aliases: Record<string, string[]> = {
      minecraft: ['minecraft', 'mc', 'paper', 'purpur', 'spigot', 'fabric', 'forge'],
      palworld: ['palworld', 'pal'],
      rust: ['rust', 'oxide', 'umod'],
      fivem: ['fivem', 'gta', 'txadmin'],
      ark: ['ark', 'survival evolved', 'survival ascended'],
      valheim: ['valheim'],
      samp: ['samp', 'sa-mp', 'san andreas', 'openmp', 'open.mp', 'pawn'],
      hytale: ['hytale']
    };

    const keywords = [gameTitle, gameIdClean, ...(aliases[gameIdClean] || [])];
    return keywords.some(keyword => name.includes(keyword) || id.includes(keyword) || desc.includes(keyword) || cat.includes(keyword));
  });

  // Connect all games to admin database:
  // Prioritize ramOptions defined specifically for this game in the 'games' collection
  // If not available, fallback to searching for general plans in the 'plans' collection
  const gameSpecificTiers: Plan[] = (game.ramOptions || []).map((opt, idx) => ({
    id: `${game.id}-tier-${idx}`,
    product_id: opt.product_id,
    name: opt.name || `${game.title} ${opt.ram} (${opt.slots})`,
    price: String(Math.round(opt.priceInr / 83)),
    price_inr: String(opt.priceInr),
    price_eur: String(Math.round(opt.priceInr / 90)),
    badge: opt.is_popular ? 'Best Value' : (idx === 1 ? 'Best Value' : ''),
    category: 'GAME-HOSTING',
    location: selectedLocation,
    node: opt.processor || opt.cpu || game.metadata?.cpuType || 'AMD RYZEN 9 7950X',
    ram: opt.ram,
    cpu: opt.cpu,
    processor: opt.processor,
    storage: opt.storage,
    ddosProtection: opt.ddosProtection,
    networkSpeed: opt.networkSpeed,
    slots: opt.slots,
    specs: opt.specs,
    desc: `High-performance ${game.title} node with ${opt.ram} RAM, ${opt.cpu || '4 vCPU'}, and ${opt.slots} capacity.`,
    features: opt.features && opt.features.length > 0 ? opt.features : [
      `${opt.ram} Dedicated RAM`,
      `${opt.slots} Player Slots`,
      `${opt.cpu || 'High-Clock CPU'}`,
      opt.storage || game.metadata?.storage || '50GB NVMe Storage',
      opt.ddosProtection || 'Path.net 12 Tbps+ Anti-DDoS',
      opt.networkSpeed || '1 Gbps Unmetered Port',
      'Pterodactyl Panel Access',
      'Instant 60s Deployment'
    ],
    is_active: true,
    subcategory: opt.subcategory
  }));

  const dbGamePlans = game.use_catalog_plans
    ? (specificGamePlans.length > 0 ? specificGamePlans : allGameHostingPlans)
    : (specificGamePlans.length > 0 ? specificGamePlans : (gameSpecificTiers.length > 0 ? gameSpecificTiers : allGameHostingPlans));

  // Helper to categorize each plan cleanly into Budget, Standard, or Performance
  const getPlanCategory = (plan: Plan, index: number, total: number): 'budget' | 'standard' | 'performance' => {
    const subcat = (plan.subcategory || '').toLowerCase().trim();
    if (subcat) {
      if (subcat.startsWith('bud')) return 'budget';
      if (subcat.startsWith('stan') || subcat === 'standerd') return 'standard';
      if (subcat.startsWith('perf') || subcat.includes('perf')) return 'performance';
    }
    
    const nameLower = plan.name.toLowerCase();
    
    if (nameLower.includes('budget') || nameLower.includes('starter') || nameLower.includes('entry') || nameLower.includes('low')) {
      return 'budget';
    }
    if (nameLower.includes('extreme') || nameLower.includes('ultra') || nameLower.includes('performance') || nameLower.includes('perfomance') || nameLower.includes('pro') || nameLower.includes('enterprise') || nameLower.includes('max') || nameLower.includes('perf')) {
      return 'performance';
    }
    if (nameLower.includes('standard') || nameLower.includes('standerd') || nameLower.includes('medium')) {
      return 'standard';
    }

    const ramStr = (plan.ram || '').toUpperCase();
    const ramValueMatch = ramStr.match(/(\d+)\s*GB/);
    if (ramValueMatch) {
      const ramGb = parseInt(ramValueMatch[1]);
      const gameIdClean = game.id.toLowerCase().replace('game-', '');
      
      if (gameIdClean === 'minecraft') {
        if (ramGb <= 3) return 'budget';
        if (ramGb <= 6) return 'standard';
        return 'performance';
      }
      
      if (gameIdClean === 'samp' || gameIdClean === 'sa-mp') {
        if (ramGb <= 1.5) return 'budget';
        if (ramGb <= 2.5) return 'standard';
        return 'performance';
      }

      if (ramGb <= 6) return 'budget';
      if (ramGb <= 16) return 'standard';
      return 'performance';
    }

    if (total <= 1) {
      return 'standard';
    }
    if (total === 2) {
      return index === 0 ? 'budget' : 'performance';
    }
    if (total === 3) {
      if (index === 0) return 'budget';
      if (index === 1) return 'standard';
      return 'performance';
    }
    if (index === 0) return 'budget';
    if (index === 1) return 'standard';
    return 'performance';
  };

  const budgetPlans = dbGamePlans.filter((plan, idx) => getPlanCategory(plan, idx, dbGamePlans.length) === 'budget');
  const standardPlans = dbGamePlans.filter((plan, idx) => getPlanCategory(plan, idx, dbGamePlans.length) === 'standard');
  const performancePlans = dbGamePlans.filter((plan, idx) => getPlanCategory(plan, idx, dbGamePlans.length) === 'performance');

  // Sync chosen tab if the current one has no plans on first load
  useEffect(() => {
    if (dbGamePlans.length > 0) {
      const hasBudget = budgetPlans.length > 0;
      const hasStandard = standardPlans.length > 0;
      const hasPerformance = performancePlans.length > 0;

      if (selectedCategoryTab === 'standard' && !hasStandard) {
        if (hasBudget) {
          setSelectedCategoryTab('budget');
        } else if (hasPerformance) {
          setSelectedCategoryTab('performance');
        }
      } else if (selectedCategoryTab === 'budget' && !hasBudget) {
        if (hasStandard) {
          setSelectedCategoryTab('standard');
        } else if (hasPerformance) {
          setSelectedCategoryTab('performance');
        }
      } else if (selectedCategoryTab === 'performance' && !hasPerformance) {
        if (hasStandard) {
          setSelectedCategoryTab('standard');
        } else if (hasBudget) {
          setSelectedCategoryTab('budget');
        }
      }
    }
  }, [dbGamePlans, game.id]);

  // Sync selected plan to match the active tab's first plan
  useEffect(() => {
    const displayed = selectedCategoryTab === 'budget' ? budgetPlans : (selectedCategoryTab === 'standard' ? standardPlans : performancePlans);
    if (displayed.length > 0 && !displayed.some(p => p.id === selectedPlanId)) {
      setSelectedPlanId(displayed[0].id);
    }
  }, [selectedCategoryTab, dbGamePlans]);

  const getOtherGameStartingPrice = (otherG: Game) => {
    const gameTitle = (otherG.title || '').toLowerCase();
    const gameIdClean = otherG.id.toLowerCase().replace('game-', '');
    const plansForGame = allGameHostingPlans.filter(p => {
      const name = (p.name || '').toLowerCase();
      const id = (p.id || '').toLowerCase();
      const desc = (p.desc || '').toLowerCase();
      return name.includes(gameTitle) || name.includes(gameIdClean) || id.includes(gameIdClean) || desc.includes(gameTitle);
    });
    const pool = plansForGame.length > 0 ? plansForGame : allGameHostingPlans;
    if (pool.length > 0) {
      const prices = pool.map(p => parseAmount(p.price_inr || p.price)).filter(n => !isNaN(n) && n > 0);
      if (prices.length > 0) return Math.min(...prices);
    }
    return otherG.startingPriceInr;
  };

  const getPriceForOption = (basePrice: number) => {
    let price = basePrice;
    if (selectedCycle === 'quarterly') price = price * 0.9; // 10% discount
    if (selectedCycle === 'annual') price = price * 0.8; // 20% discount
    return Math.round(price);
  };

  const handleDeployPlan = (plan: Plan) => {
    const basePrice = parseAmount(plan.price_inr || plan.price);
    const finalPrice = getPriceForOption(basePrice);
    
    // Format plan name cleanly for the selected game if it's a general game node
    const planDisplayName = plan.name.toLowerCase().includes(game.title.toLowerCase())
      ? plan.name
      : `${game.title} Server - ${plan.name}`;

    handleOrder({
      ...plan,
      name: planDisplayName,
      price_inr: String(finalPrice),
      price: String(Math.round(finalPrice / 83)),
      price_eur: String(Math.round(finalPrice / 90)),
      location: selectedLocation,
      features: [
        `Target Game: ${game.title}`,
        ...(plan.features || []),
        `Datacenter: ${selectedLocation}`,
        `Billing Term: ${selectedCycle.toUpperCase()}`
      ]
    });
  };

  // If literally no game hosting plans exist in database
  if (dbGamePlans.length === 0) {
    return (
      <div className="min-h-screen bg-bg text-foreground pt-32 pb-24 px-4 sm:px-6 relative overflow-hidden font-sans">
        <div className="max-w-4xl mx-auto text-center pt-16 pb-20">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-bg-alt border border-border text-[10px] font-bold uppercase tracking-wider text-foreground-dim mb-8">
            <Link to="/game-servers" className="hover:text-foreground">Game Hosting</Link>
            <ChevronRight size={10} />
            <span className="text-foreground">{game.title}</span>
          </div>

          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-foreground uppercase mb-6">
            Nodes In High Demand
          </h1>
          <p className="text-foreground-muted text-base sm:text-lg max-w-xl mx-auto mb-10 font-normal leading-relaxed">
            All server nodes for {game.title} are currently at peak allocation. Fresh high-clock hardware is being deployed to the network. Please check back shortly or explore our other available titles.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link
              to="/game-servers"
              className="px-6 py-3.5 rounded-md text-[10px] font-black uppercase tracking-[0.2em] bg-accent text-white hover:bg-accent/90 transition-all inline-flex items-center gap-2"
            >
              <ArrowLeft size={14} />
              <span>Browse All Games</span>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // FAQs specific to game server hosting
  const gameFaqs = [
    {
      q: `How long does it take for my ${game.title} server to start?`,
      a: "Our system is entirely automated. Within 60 seconds of completing payment, your server will be fully provisioned, initialized, and accessible via the customized game panel. You will receive an instant confirmation details sheet."
    },
    {
      q: "Can I upgrade my RAM or player slots later?",
      a: "Absolutely. You can scale your hardware resources at any time directly through support. Your server files, modpacks, and worlds are automatically preserved during the upgrade without data loss."
    },
    {
      q: "Do you support custom mods, plugins, and modpacks?",
      a: "Yes! Our control panel provides full root file system access (via SFTP and file manager). You can install any mod, custom jar, script engine, or modpack you wish. There are no arbitrary limitations on files."
    },
    {
      q: "What DDoS Protection is active on game nodes?",
      a: "Every single node is fortified behind a 10Tbps Anycast network with game-specific inline scrubbing filters. We protect against UDP query flood exploits, port exhaustion, and server crashing attacks with zero added latency."
    }
  ];

  return (
    <div className="min-h-screen bg-bg text-foreground pt-32 pb-24 px-4 sm:px-6 relative overflow-hidden font-sans">
      
      {/* Subtle Depth */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[600px] bg-[radial-gradient(circle_at_center,rgba(139,92,246,0.02)_0%,transparent_70%)] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Navigation & Header */}
        <div className="mb-12 flex flex-wrap items-center justify-between gap-6">
          <Link 
            to="/game-servers" 
            className="inline-flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.2em] text-foreground-dim hover:text-accent transition-all group"
          >
            <ArrowLeft size={14} className="group-hover:-translate-x-1 transition-transform" />
            Back to Infrastructure
          </Link>

          <span className="text-[10px] uppercase font-black text-accent tracking-[0.2em]">
            {game.category} Node Selector
          </span>
        </div>

        {/* Game Showcase Header Section */}
        <div className="bg-bg border border-border rounded-lg overflow-hidden shadow-sm mb-8 sm:mb-10">
          <div className="relative min-h-[180px] h-48 sm:h-[300px] overflow-hidden">
            <img 
              src={game.image} 
              alt={game.title} 
              className="w-full h-full object-cover object-center grayscale-[20%]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/60 to-transparent" />
            
            <div className="absolute bottom-4 left-4 right-4 sm:bottom-8 sm:left-8 sm:right-8">
              <h1 className="text-xl sm:text-4xl md:text-5xl font-extrabold text-white uppercase tracking-tight leading-[1.1] mb-2">
                {game.title} <span className="text-white/60">Server.</span>
              </h1>
              <p className="text-white/80 text-[10px] sm:text-sm max-w-2xl font-normal leading-relaxed text-balance line-clamp-2 sm:line-clamp-none">
                {game.description} Provisioned on deterministic AMD Ryzen™ compute nodes with specialized Layer 7 DDoS mitigation.
              </p>
            </div>
          </div>
        </div>

        {/* Global Configuration Controls - COMPACT VERSION */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-10">
          
          {/* Compact Region Selection */}
          <div className="bg-[#0f0a1a] border border-white/10 rounded-2xl p-5 shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-accent/10 flex items-center justify-center text-accent">
                  <Globe size={16} />
                </div>
                <div>
                  <h3 className="text-[11px] font-black text-white uppercase tracking-widest">Network Topology</h3>
                </div>
              </div>
              <div className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-emerald-500/10 border border-emerald-500/20">
                <div className="w-1 h-1 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-[8px] font-black text-emerald-500 uppercase tracking-widest">Online</span>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {locations.map((loc) => {
                const isSelected = selectedLocation === loc.name;
                return (
                  <button
                    key={loc.name}
                    onClick={() => setSelectedLocation(loc.name)}
                    className={`relative p-3 rounded-xl text-left transition-all duration-300 border ${
                      isSelected
                        ? 'bg-accent/10 border-accent shadow-[0_0_15px_-5px_rgba(139,92,246,0.3)]'
                        : 'bg-white/[0.02] border-white/5 hover:border-white/20'
                    }`}
                  >
                    <div className="flex items-center gap-2 relative z-10">
                      <span className={`text-lg transition-transform ${isSelected ? 'scale-110' : 'grayscale group-hover:grayscale-0'}`}>
                        {loc.flag}
                      </span>
                      <div className="min-w-0">
                        <span className={`text-[9px] block font-black uppercase tracking-wider truncate transition-colors ${isSelected ? 'text-white' : 'text-slate-400'}`}>
                          {loc.name.split(' (')[0]}
                        </span>
                      </div>
                    </div>
                    {isSelected && (
                      <div className="absolute top-1.5 right-1.5">
                        <CheckCircle2 size={10} className="text-accent" />
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Compact Billing Cycle Selection */}
          <div className="bg-[#0f0a1a] border border-white/10 rounded-2xl p-5 shadow-xl">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-accent/10 flex items-center justify-center text-accent">
                <Clock size={16} />
              </div>
              <div>
                <h3 className="text-[11px] font-black text-white uppercase tracking-widest">Cycle Strategy</h3>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'monthly', label: 'Monthly', percent: '0%' },
                { id: 'quarterly', label: 'Quarterly', percent: '10%' },
                { id: 'annual', label: 'Annual', percent: '20%' },
              ].map((cycle) => {
                const isSelected = selectedCycle === cycle.id;
                return (
                  <button
                    key={cycle.id}
                    onClick={() => setSelectedCycle(cycle.id as any)}
                    className={`relative p-3 rounded-xl text-center transition-all duration-300 border ${
                      isSelected
                        ? 'bg-accent/10 border-accent shadow-[0_0_15px_-5px_rgba(139,92,246,0.3)]'
                        : 'bg-white/[0.02] border-white/5 hover:border-white/20'
                    }`}
                  >
                    <span className={`text-[9px] block font-black uppercase tracking-wider mb-1 transition-colors ${isSelected ? 'text-white' : 'text-slate-400'}`}>
                      {cycle.label}
                    </span>
                    <span className={`text-[8px] font-bold uppercase tracking-widest block ${isSelected ? 'text-emerald-400' : 'text-slate-600'}`}>
                      {cycle.percent} OFF
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Structured Real Admin Plans Grid */}
        <div className="mb-12">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
            <h2 className="text-xl font-black text-white uppercase tracking-tighter flex items-center gap-2">
              <Layers size={20} className="text-accent" />
              Available Compute Tiers
            </h2>
            <div className="text-[10px] font-black text-foreground-dim uppercase tracking-[0.2em]">
              {dbGamePlans.length} Nodes Configured
            </div>
          </div>

          {/* High-Fidelity Category Switcher tabs */}
          <div className="flex justify-center mb-10">
            <div className="inline-flex p-1 bg-[#0f0a1a] border border-white/10 rounded-2xl shadow-xl max-w-full overflow-x-auto no-scrollbar gap-1">
              {[
                { id: 'budget', label: 'Budget Tiers', plansCount: budgetPlans.length, desc: 'Cost-Effective Hosting' },
                { id: 'standard', label: 'Standard Tiers', plansCount: standardPlans.length, desc: 'Balanced Performance' },
                { id: 'performance', label: 'Performance Tiers', plansCount: performancePlans.length, desc: 'Ultra-High Clock Power' }
              ].map((tab) => {
                const isSelected = selectedCategoryTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setSelectedCategoryTab(tab.id as any)}
                    className={`px-5 py-3 rounded-xl transition-all duration-300 text-left shrink-0 ${
                      isSelected
                        ? 'bg-accent/15 border border-accent/50 shadow-[0_0_15px_-5px_rgba(139,92,246,0.3)] text-white'
                        : 'border border-transparent hover:border-white/5 text-slate-400 hover:text-white'
                    }`}
                  >
                    <div className="font-black uppercase tracking-widest text-[11px] flex items-center gap-2">
                      <span className={`w-1.5 h-1.5 rounded-full ${isSelected ? 'bg-accent animate-pulse' : 'bg-slate-600'}`} />
                      {tab.label}
                    </div>
                    <div className="text-[9px] text-slate-500 font-bold uppercase tracking-wider mt-0.5 whitespace-nowrap">
                      {tab.plansCount} {tab.plansCount === 1 ? 'Node' : 'Nodes'} · {tab.desc}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Render active category plans */}
          {(() => {
            const displayedPlans = selectedCategoryTab === 'budget' 
              ? budgetPlans 
              : (selectedCategoryTab === 'standard' ? standardPlans : performancePlans);

            if (displayedPlans.length === 0) {
              return (
                <div className="py-16 text-center bg-[#0f0a1a] border border-white/5 rounded-2xl p-8 w-full">
                  <Cpu size={40} className="mx-auto text-slate-600 mb-4 opacity-30 animate-pulse" />
                  <h3 className="text-base font-black text-white uppercase tracking-tight mb-1">Tiers In Peak Demand</h3>
                  <p className="text-xs text-slate-400 max-w-md mx-auto">
                    All {selectedCategoryTab} nodes for {game.title} are currently at peak allocation. Fresh AMD Ryzen™ hardware is being provisioned. Please check other tiers or contact support.
                  </p>
                </div>
              );
            }

            return (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {displayedPlans.map((plan, idx) => {
                  const basePrice = parseAmount(plan.price_inr || plan.price);
                  const optionPrice = getPriceForOption(basePrice);
                  const isSelected = selectedPlanId === plan.id;

                  return (
                    <motion.div
                      key={plan.id || idx}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: idx * 0.05 }}
                      onClick={() => setSelectedPlanId(plan.id)}
                      className={`relative p-6 rounded-2xl border transition-all duration-500 cursor-pointer flex flex-col justify-between group overflow-hidden ${
                        isSelected 
                          ? 'bg-[#1a122e] border-accent shadow-[0_0_50px_-12px_rgba(139,92,246,0.25)] ring-1 ring-accent/50' 
                          : 'bg-[#0f0a1a] border-white/5 hover:border-white/10'
                      }`}
                    >
                      {/* Decorative Background Element */}
                      {isSelected && (
                        <div className="absolute -top-24 -right-24 w-48 h-48 bg-accent/10 rounded-full blur-3xl pointer-events-none" />
                      )}

                      {/* Selection Indicator */}
                      <div className={`absolute top-4 right-4 w-5 h-5 rounded-full border flex items-center justify-center transition-all duration-500 ${
                        isSelected ? 'bg-accent border-accent text-white scale-110' : 'border-white/10 text-transparent'
                      }`}>
                        <CheckCircle2 size={12} strokeWidth={3} />
                      </div>

                      <div>
                        <div className="mb-5 flex items-center gap-2">
                          <span className={`text-[9px] font-black tracking-[0.2em] uppercase py-1 px-2.5 rounded-md transition-colors ${
                            isSelected ? 'bg-accent text-white' : 'bg-white/5 text-slate-500'
                          }`}>
                            {plan.badge || `PRO TIER 0${idx + 1}`}
                          </span>
                          {isSelected && (
                            <motion.span 
                              initial={{ opacity: 0, x: -5 }}
                              animate={{ opacity: 1, x: 0 }}
                              className="text-[9px] font-black text-emerald-400 uppercase tracking-widest"
                            >
                              Selected
                            </motion.span>
                          )}
                        </div>

                        <h3 className={`text-2xl font-black uppercase tracking-tighter mb-1 transition-colors ${isSelected ? 'text-white' : 'text-slate-200'}`}>
                          {plan.name.split(' (')[0].replace(game.title, '').trim() || plan.name}
                        </h3>
                        <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-1.5">
                          <Zap size={12} className="text-accent" />
                          {plan.processor || plan.node || 'AMD Ryzen™ 9 7950X'}
                        </div>

                        {/* Hardware Specs Highlights Grid */}
                        <div className="grid grid-cols-2 gap-2 mb-6 text-[10px] font-mono">
                          {plan.ram && (
                            <div className="p-2 rounded-lg bg-white/5 border border-white/5 flex items-center gap-1.5 text-slate-300">
                              <Cpu size={12} className="text-purple-400 shrink-0" />
                              <span className="truncate">{plan.ram}</span>
                            </div>
                          )}
                          {plan.storage && (
                            <div className="p-2 rounded-lg bg-white/5 border border-white/5 flex items-center gap-1.5 text-slate-300">
                              <HardDrive size={12} className="text-indigo-400 shrink-0" />
                              <span className="truncate">{plan.storage}</span>
                            </div>
                          )}
                          {plan.ddosProtection && (
                            <div className="p-2 rounded-lg bg-white/5 border border-white/5 flex items-center gap-1.5 text-slate-300">
                              <Shield size={12} className="text-emerald-400 shrink-0" />
                              <span className="truncate" title={plan.ddosProtection}>{plan.ddosProtection}</span>
                            </div>
                          )}
                          {plan.networkSpeed && (
                            <div className="p-2 rounded-lg bg-white/5 border border-white/5 flex items-center gap-1.5 text-slate-300">
                              <Globe size={12} className="text-cyan-400 shrink-0" />
                              <span className="truncate">{plan.networkSpeed}</span>
                            </div>
                          )}
                        </div>

                        {/* Price Block */}
                        <div className="mb-6 p-4 rounded-xl bg-black/20 border border-white/5 relative overflow-hidden group-hover:border-white/10 transition-colors">
                          <div className="flex items-baseline gap-1 relative z-10">
                            <span className="text-4xl font-black text-white font-mono tracking-tighter">
                              {formatPrice(optionPrice)}
                            </span>
                            <span className="text-xs text-slate-500 font-bold uppercase tracking-widest">/month</span>
                          </div>
                          <p className="text-[9px] text-slate-500 font-bold uppercase mt-1 relative z-10">
                            {selectedCycle === 'monthly' ? 'Base Allocation' : `${selectedCycle} commitment`}
                          </p>
                          <div className={`absolute bottom-0 right-0 p-2 opacity-10 transition-transform duration-700 group-hover:scale-110 ${isSelected ? 'text-accent' : 'text-white'}`}>
                            <DollarSign size={40} strokeWidth={1} />
                          </div>
                        </div>

                        {/* Custom Game Key-Value Specs Pills */}
                        {plan.specs && Object.keys(plan.specs).length > 0 && (
                          <div className="mb-6 space-y-1.5">
                            <span className="text-[9px] font-black text-accent uppercase tracking-wider block">Game Specifications</span>
                            <div className="flex flex-wrap gap-1.5">
                              {Object.entries(plan.specs).map(([sKey, sVal]) => (
                                <span key={sKey} className="inline-flex items-center px-2 py-1 rounded bg-purple-950/80 border border-accent/30 text-[10px] font-mono text-purple-200">
                                  <strong className="text-accent mr-1 font-bold">{sKey}:</strong> {sVal}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Feature List */}
                        <div className="space-y-3 mb-8">
                          {plan.features?.map((feature: string, fIdx: number) => (
                            <div key={fIdx} className="flex items-start gap-2.5 group/feat">
                              <div className={`mt-0.5 transition-colors ${isSelected ? 'text-accent' : 'text-slate-600 group-hover/feat:text-slate-400'}`}>
                                <Zap size={13} fill={isSelected ? 'currentColor' : 'none'} className="opacity-80" />
                              </div>
                              <span className={`text-xs font-medium leading-tight transition-colors ${isSelected ? 'text-slate-200' : 'text-slate-400'}`}>
                                {feature}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeployPlan(plan);
                        }}
                        className={`w-full py-4 rounded-xl text-[11px] font-black uppercase tracking-[0.2em] transition-all duration-500 flex items-center justify-center gap-3 active:scale-95 ${
                          isSelected 
                            ? 'bg-accent text-white shadow-[0_10px_20px_-10px_rgba(139,92,246,0.5)] hover:shadow-[0_15px_30px_-10px_rgba(139,92,246,0.6)] hover:-translate-y-0.5' 
                            : 'bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white'
                        }`}
                      >
                        <span>Configure Node</span>
                        <ArrowRight size={16} className={`transition-transform duration-500 ${isSelected ? 'translate-x-1' : 'group-hover:translate-x-1'}`} />
                      </button>
                    </motion.div>
                  );
                })}
              </div>
            );
          })()}

          {/* Bottom Action for Selected Plan (Optional if each has button) */}
          <div className="mt-12 p-8 bg-accent/5 border border-dashed border-accent/20 rounded-3xl flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-accent/10 flex items-center justify-center text-accent">
                <Sparkles size={24} />
              </div>
              <div>
                <h4 className="text-lg font-black text-white uppercase tracking-tight">Enterprise Infrastructure Guarantee</h4>
                <p className="text-sm text-slate-400">All selected tiers include deterministic AMD Ryzen™ hardware and Layer 7 protection.</p>
              </div>
            </div>
            {selectedPlanId && (
              <button 
                onClick={() => {
                  const selected = dbGamePlans.find(p => p.id === selectedPlanId);
                  if (selected) handleDeployPlan(selected);
                }}
                className="px-10 py-4 bg-accent hover:bg-accent-muted text-white font-black text-xs uppercase tracking-[0.2em] rounded-xl transition-all shadow-xl shadow-accent/20 active:scale-95"
              >
                Proceed to Checkout
              </button>
            )}
          </div>
        </div>

        {/* Feature Grid */}
        <div className="bg-bg-alt border border-border rounded-lg p-12 mb-32">
          <div className="text-center mb-16">
            <span className="text-[10px] uppercase font-black text-accent tracking-[0.2em] block mb-4 flex items-center justify-center gap-2">
              <Star size={14} /> Performance Governance
            </span>
            <h2 className="text-3xl sm:text-5xl font-extrabold text-foreground uppercase tracking-tight">
              Hardware <span className="text-foreground-muted">Logistics.</span>
            </h2>
          </div>

          <div className="grid sm:grid-cols-3 gap-px bg-border border border-border rounded overflow-hidden">
            {[
              { title: 'Deterministic Setup', desc: 'Automated lifecycle routines. Node initializes instantly with selected application binaries on checkout.' },
              { icon: Sliders, title: 'Unconstrained Access', desc: 'Secure SFTP and web-based orchestrators for world state management and plugin governance.' },
              { icon: Shield, title: 'Layer 7 Mitigation', desc: 'Specialized application-aware scrubbing filters for deterministic protection against game-specific exploits.' }
            ].map((feat, idx) => (
              <div key={idx} className="p-10 bg-bg space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-8 h-8 rounded bg-bg-alt border border-border flex items-center justify-center text-accent">
                    <CheckCircle2 size={16} />
                  </div>
                  <h4 className="text-base font-black text-foreground uppercase tracking-tight">{feat.title}</h4>
                </div>
                <p className="text-sm text-foreground-muted leading-relaxed font-normal">{feat.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* FAQ Section */}
        <div className="max-w-4xl mx-auto mb-32">
          <div className="text-center mb-16">
            <span className="text-[10px] uppercase font-black text-accent tracking-[0.2em] block mb-4">
              Infrastructure Support
            </span>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-foreground uppercase tracking-tight">
              Platform <span className="text-foreground-muted">Documentation.</span>
            </h2>
          </div>

          <div className="grid gap-px bg-border border border-border rounded-lg overflow-hidden">
            {gameFaqs.map((faq, idx) => {
              const isOpen = activeFaq === idx;
              return (
                <div 
                  key={idx} 
                  className="bg-bg transition-all"
                >
                  <button
                    onClick={() => setActiveFaq(isOpen ? null : idx)}
                    className="w-full py-6 px-8 text-left flex items-center justify-between text-[15px] font-black text-foreground uppercase tracking-tight hover:bg-bg-alt transition-colors"
                  >
                    <span>{faq.q}</span>
                    <ChevronDown size={18} className={`text-foreground-dim transition-transform ${isOpen ? 'rotate-180 text-accent' : ''}`} />
                  </button>
                  
                  {isOpen && (
                    <div className="px-8 pb-6 text-sm text-foreground-muted leading-relaxed border-t border-border pt-4 font-normal">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Other game categories bottom carousel slider */}
        <div>
          <div className="flex items-center justify-between mb-12">
            <div>
              <h3 className="text-2xl font-extrabold text-foreground uppercase tracking-tight">
                Alternative <span className="text-foreground-muted">Nodes.</span>
              </h3>
              <p className="text-[11px] text-foreground-dim font-black uppercase tracking-widest mt-2">Explore alternative multiplayer infrastructure.</p>
            </div>
            <Link to="/game-servers" className="text-[10px] font-black uppercase tracking-[0.2em] text-accent hover:text-foreground transition-all flex items-center gap-2">
              View Catalog <ArrowRight size={14} />
            </Link>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-px bg-border border border-border rounded-lg overflow-hidden">
            {(data.games || []).filter(g => g.id !== game.id).slice(0, 4).map((otherGame) => (
              <Link
                key={otherGame.id}
                to={`/game/${otherGame.id.replace('game-', '')}`}
                className="group bg-bg overflow-hidden transition-all duration-300 flex flex-col"
              >
                <div className="relative aspect-[4/3] overflow-hidden bg-bg-alt">
                  <img 
                    src={otherGame.image} 
                    alt={otherGame.title} 
                    className="w-full h-full object-cover object-center grayscale-[20%] group-hover:grayscale-0 group-hover:scale-105 transition-all duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-bg via-transparent to-transparent opacity-80" />
                </div>
                <div className="p-6 bg-bg flex-1 flex flex-col justify-between">
                  <h4 className="text-[11px] font-black text-foreground uppercase tracking-widest group-hover:text-accent transition-colors truncate">
                    {otherGame.title}
                  </h4>
                  <div className="text-[10px] text-emerald-500 font-black uppercase tracking-widest mt-3">
                    FROM {formatPrice(getOtherGameStartingPrice(otherGame))}/MO
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
