import React, { useCallback, useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import {
  Activity,
  Mail,
  MessageSquare,
  Play,
  RotateCcw,
  Shield,
  Trophy,
  Volume2,
  VolumeX,
} from "lucide-react";
import { AppData } from "../types";

interface MaintenancePageProps {
  data: AppData;
}

const CANVAS_WIDTH = 340;
const CANVAS_HEIGHT = 260;
const PADDLE_WIDTH = 80;
const PADDLE_HEIGHT = 8;
const PADDLE_Y = CANVAS_HEIGHT - 20;
const BALL_RADIUS = 6;
const HIGH_SCORE_KEY = "hector_maint_highscore";

type SoundType = "bounce" | "score" | "gameover";

export const MaintenancePage: React.FC<MaintenancePageProps> = ({ data }) => {
  const settings = data.settings;

  const siteTitle =
    settings.site_name && settings.site_name !== "Untitled"
      ? settings.site_name
      : "HectorHosting";

  // --------------------------------------------------
  // UI state
  // --------------------------------------------------

  const [isMuted, setIsMuted] = useState(true);
  const [gameStarted, setGameStarted] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(() =>
    Number(localStorage.getItem(HIGH_SCORE_KEY) || 0)
  );

  // Demo telemetry
  const [cpuLoad, setCpuLoad] = useState(14);
  const [networkIn, setNetworkIn] = useState(142);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);

  const ballRef = useRef({
    x: CANVAS_WIDTH / 2,
    y: 50,
    vx: 2.5,
    vy: 3,
  });

  const paddleRef = useRef({
    x: (CANVAS_WIDTH - PADDLE_WIDTH) / 2,
  });

  const keysRef = useRef({
    left: false,
    right: false,
  });

  // --------------------------------------------------
  // Audio
  // --------------------------------------------------

  const playSound = useCallback(
    (type: SoundType) => {
      if (isMuted) return;

      try {
        const AudioContextClass =
          window.AudioContext ||
          (window as typeof window & {
            webkitAudioContext?: typeof AudioContext;
          }).webkitAudioContext;

        if (!AudioContextClass) return;

        if (!audioContextRef.current) {
          audioContextRef.current = new AudioContextClass();
        }

        const ctx = audioContextRef.current;

        if (ctx.state === "suspended") {
          ctx.resume();
        }

        const oscillator = ctx.createOscillator();
        const gain = ctx.createGain();

        oscillator.connect(gain);
        gain.connect(ctx.destination);

        const now = ctx.currentTime;

        switch (type) {
          case "bounce":
            oscillator.type = "triangle";
            oscillator.frequency.setValueAtTime(150, now);
            oscillator.frequency.exponentialRampToValueAtTime(
              300,
              now + 0.1
            );
            gain.gain.setValueAtTime(0.12, now);
            gain.gain.exponentialRampToValueAtTime(0.01, now + 0.1);
            oscillator.start(now);
            oscillator.stop(now + 0.1);
            break;

          case "score":
            oscillator.type = "sine";
            oscillator.frequency.setValueAtTime(523, now);
            oscillator.frequency.setValueAtTime(659, now + 0.08);
            gain.gain.setValueAtTime(0.15, now);
            gain.gain.exponentialRampToValueAtTime(0.01, now + 0.25);
            oscillator.start(now);
            oscillator.stop(now + 0.25);
            break;

          case "gameover":
            oscillator.type = "sawtooth";
            oscillator.frequency.setValueAtTime(220, now);
            oscillator.frequency.linearRampToValueAtTime(80, now + 0.4);
            gain.gain.setValueAtTime(0.2, now);
            gain.gain.exponentialRampToValueAtTime(0.01, now + 0.45);
            oscillator.start(now);
            oscillator.stop(now + 0.45);
            break;
        }
      } catch {
        // Audio is optional. Ignore unsupported browsers.
      }
    },
    [isMuted]
  );

  // --------------------------------------------------
  // Demo telemetry
  // --------------------------------------------------

  useEffect(() => {
    const interval = window.setInterval(() => {
      setCpuLoad(Math.round(12 + Math.random() * 8));
      setNetworkIn(Math.round(135 + Math.random() * 20));
    }, 2500);

    return () => window.clearInterval(interval);
  }, []);

  // --------------------------------------------------
  // Keyboard controls
  // --------------------------------------------------

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "ArrowLeft") {
        event.preventDefault();
        keysRef.current.left = true;
      }

      if (event.key === "ArrowRight") {
        event.preventDefault();
        keysRef.current.right = true;
      }
    };

    const handleKeyUp = (event: KeyboardEvent) => {
      if (event.key === "ArrowLeft") {
        keysRef.current.left = false;
      }

      if (event.key === "ArrowRight") {
        keysRef.current.right = false;
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
    };
  }, []);

  // --------------------------------------------------
  // Game helpers
  // --------------------------------------------------

  const updateHighScore = useCallback(
    (newScore: number) => {
      if (newScore <= highScore) return;

      setHighScore(newScore);
      localStorage.setItem(HIGH_SCORE_KEY, String(newScore));
    },
    [highScore]
  );

  const startGame = () => {
    setScore(0);
    setGameOver(false);
    setGameStarted(true);

    paddleRef.current.x = (CANVAS_WIDTH - PADDLE_WIDTH) / 2;

    const speed = 1;

    ballRef.current = {
      x: CANVAS_WIDTH / 2,
      y: 50,
      vx: (Math.random() > 0.5 ? 2.5 : -2.5) * speed,
      vy: 3 * speed,
    };
  };

  const movePaddle = (x: number) => {
    paddleRef.current.x = Math.max(
      0,
      Math.min(CANVAS_WIDTH - PADDLE_WIDTH, x - PADDLE_WIDTH / 2)
    );
  };

  const handlePointerMove = (
    event: React.PointerEvent<HTMLCanvasElement>
  ) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();

    const scaleX = CANVAS_WIDTH / rect.width;
    const pointerX = (event.clientX - rect.left) * scaleX;

    movePaddle(pointerX);
  };

  // --------------------------------------------------
  // Game loop
  // --------------------------------------------------

  useEffect(() => {
    if (!gameStarted || gameOver) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const drawGrid = () => {
      ctx.strokeStyle = "rgba(255,255,255,0.035)";
      ctx.lineWidth = 1;

      for (let x = 0; x <= CANVAS_WIDTH; x += 20) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, CANVAS_HEIGHT);
        ctx.stroke();
      }

      for (let y = 0; y <= CANVAS_HEIGHT; y += 20) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(CANVAS_WIDTH, y);
        ctx.stroke();
      }
    };

    const drawPaddle = () => {
      const { x } = paddleRef.current;

      ctx.fillStyle = "#6366f1";
      ctx.beginPath();
      ctx.roundRect(
        x,
        PADDLE_Y,
        PADDLE_WIDTH,
        PADDLE_HEIGHT,
        4
      );
      ctx.fill();
    };

    const drawBall = () => {
      const ball = ballRef.current;

      ctx.fillStyle = "#10b981";
      ctx.beginPath();
      ctx.arc(
        ball.x,
        ball.y,
        BALL_RADIUS,
        0,
        Math.PI * 2
      );
      ctx.fill();

      // Glow
      ctx.fillStyle = "rgba(16,185,129,0.12)";
      ctx.beginPath();
      ctx.arc(ball.x, PADDLE_Y + 5, 4, 0, Math.PI * 2);
      ctx.fill();
    };

    const endGame = () => {
      playSound("gameover");
      setGameOver(true);
    };

    const update = () => {
      const ball = ballRef.current;
      const paddle = paddleRef.current;

      // Paddle
      const paddleSpeed = 6;

      if (keysRef.current.left) {
        paddle.x = Math.max(0, paddle.x - paddleSpeed);
      }

      if (keysRef.current.right) {
        paddle.x = Math.min(
          CANVAS_WIDTH - PADDLE_WIDTH,
          paddle.x + paddleSpeed
        );
      }

      // Ball
      ball.x += ball.vx;
      ball.y += ball.vy;

      // Left / right walls
      if (ball.x - BALL_RADIUS <= 0) {
        ball.x = BALL_RADIUS;
        ball.vx = Math.abs(ball.vx);
        playSound("bounce");
      }

      if (ball.x + BALL_RADIUS >= CANVAS_WIDTH) {
        ball.x = CANVAS_WIDTH - BALL_RADIUS;
        ball.vx = -Math.abs(ball.vx);
        playSound("bounce");
      }

      // Top wall
      if (ball.y - BALL_RADIUS <= 0) {
        ball.y = BALL_RADIUS;
        ball.vy = Math.abs(ball.vy);
        playSound("bounce");
      }

      // Paddle collision
      const hitsPaddle =
        ball.y + BALL_RADIUS >= PADDLE_Y &&
        ball.y + BALL_RADIUS <= PADDLE_Y + PADDLE_HEIGHT + 4 &&
        ball.x >= paddle.x &&
        ball.x <= paddle.x + PADDLE_WIDTH &&
        ball.vy > 0;

      if (hitsPaddle) {
        ball.y = PADDLE_Y - BALL_RADIUS;
        ball.vy = -Math.abs(ball.vy);

        const hitPosition =
          (ball.x - (paddle.x + PADDLE_WIDTH / 2)) /
          (PADDLE_WIDTH / 2);

        ball.vx = hitPosition * 4.5;

        setScore((current) => {
          const next = current + 1;
          updateHighScore(next);
          return next;
        });

        playSound("score");
      }

      // Missed paddle
      if (ball.y - BALL_RADIUS > CANVAS_HEIGHT) {
        endGame();
        return;
      }

      // Render
      ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

      drawGrid();
      drawPaddle();
      drawBall();

      animationRef.current = requestAnimationFrame(update);
    };

    animationRef.current = requestAnimationFrame(update);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [
    gameStarted,
    gameOver,
    playSound,
    updateHighScore,
  ]);

  // --------------------------------------------------
  // Render
  // --------------------------------------------------

  const maintenanceMessage =
    settings.maintenance_message ||
    "We are performing database updates, platform improvements, and game panel maintenance. Your running services remain operational.";

  return (
    <div className="min-h-screen bg-[#070913] text-slate-50 flex flex-col px-6 py-6 md:px-12 relative overflow-hidden font-sans">

      {/* Background */}
      <div className="absolute inset-0 pointer-events-none opacity-50 bg-[linear-gradient(to_right,#1e293b12_1px,transparent_1px),linear-gradient(to_bottom,#1e293b12_1px,transparent_1px)] bg-[size:4rem_4rem]" />

      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-6xl h-[500px] pointer-events-none bg-[radial-gradient(circle_at_center,rgba(99,102,241,0.06),transparent_70%)]" />

      {/* Header */}
      <header className="relative z-10 max-w-7xl w-full mx-auto py-4 border-b border-slate-800/60 flex items-center justify-between">

        <div className="flex items-center gap-2">
          <Shield className="text-indigo-500" size={18} />

          <span className="text-xs font-black tracking-[0.25em] uppercase">
            {siteTitle}
          </span>
        </div>

        <div className="flex items-center gap-4">

          <button
            type="button"
            onClick={() => setIsMuted((value) => !value)}
            aria-label={isMuted ? "Enable sound" : "Disable sound"}
            className="text-slate-500 hover:text-white transition-colors"
          >
            {isMuted ? (
              <VolumeX size={16} />
            ) : (
              <Volume2 size={16} />
            )}
          </button>

          <Link
            to="/status"
            className="flex items-center gap-2 rounded-lg border border-indigo-500/20 bg-indigo-500/5 px-3 py-1.5 text-[10px] font-bold uppercase tracking-widest text-indigo-400 hover:text-indigo-300 transition"
          >
            <Activity size={10} />
            Status
          </Link>
        </div>
      </header>

      {/* Main */}
      <main className="relative z-10 flex-1 max-w-6xl w-full mx-auto grid lg:grid-cols-2 gap-12 lg:gap-20 items-center py-12 lg:py-20">

        {/* Information */}
        <section className="max-w-xl">

          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-md bg-amber-500/10 border border-amber-500/20 text-[10px] font-bold font-mono uppercase tracking-widest text-amber-400">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
            Maintenance in progress
          </div>

          <div className="mt-7 space-y-4">

            <h1 className="text-5xl sm:text-7xl font-black tracking-tight leading-[0.9] uppercase">
              System
              <br />
              Upgrade.
            </h1>

            <p className="text-sm sm:text-base text-slate-400 leading-relaxed max-w-lg">
              {maintenanceMessage}
            </p>
          </div>

          {/* Telemetry */}
          <div className="grid grid-cols-3 gap-3 mt-8 p-4 rounded-2xl border border-slate-800 bg-slate-950/50">

            <Metric
              label="CPU Load"
              value={`${cpuLoad}%`}
            />

            <Metric
              label="Network"
              value={`${networkIn} Mbps`}
            />

            <Metric
              label="Integrity"
              value="100%"
              valueClass="text-emerald-400"
            />
          </div>

          {/* Support */}
          <div className="flex flex-wrap gap-3 mt-6">

            {settings.discord_url && (
              <a
                href={settings.discord_url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-[10px] font-black uppercase tracking-widest transition shadow-lg shadow-indigo-600/10"
              >
                <MessageSquare size={14} />
                Discord Support
              </a>
            )}

            {settings.support_email && (
              <a
                href={`mailto:${settings.support_email}`}
                className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-white text-[10px] font-black uppercase tracking-widest transition"
              >
                <Mail size={14} />
                Contact Support
              </a>
            )}
          </div>
        </section>

        {/* Game */}
        <section className="flex justify-center">

          <div className="w-full max-w-[380px] overflow-hidden rounded-2xl border border-slate-800 bg-[#0b0f19] shadow-2xl">

            {/* Game header */}
            <div className="flex items-center justify-between px-4 py-3 bg-[#101626] border-b border-slate-800">

              <div className="flex gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500/80" />
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
              </div>

              <div className="flex items-center gap-1.5 text-[9px] font-bold font-mono uppercase tracking-widest text-slate-500">
                <Trophy size={11} className="text-amber-500" />
                Best: {highScore}
              </div>
            </div>

            {/* Canvas */}
            <div className="relative p-4 bg-[#070a13]">

              <canvas
                ref={canvasRef}
                width={CANVAS_WIDTH}
                height={CANVAS_HEIGHT}
                onPointerMove={handlePointerMove}
                className="w-full h-auto rounded-xl border border-slate-800/70 bg-[#05070f] block touch-none"
              />

              {/* Start screen */}
              {!gameStarted && (
                <GameOverlay>
                  <div className="w-12 h-12 rounded-full bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
                    <Shield size={24} />
                  </div>

                  <div>
                    <h2 className="text-sm font-black font-mono uppercase tracking-wider">
                      Core Packet Defender
                    </h2>

                    <p className="mt-2 text-[10px] leading-relaxed text-slate-500 max-w-[240px]">
                      Deflect incoming packets before they breach the firewall.
                      Use your mouse, touch, or arrow keys.
                    </p>
                  </div>

                  <GameButton onClick={startGame}>
                    <Play size={12} />
                    Initialize Shield
                  </GameButton>
                </GameOverlay>
              )}

              {/* Game over */}
              {gameOver && (
                <GameOverlay>

                  <div className="text-xs font-black font-mono uppercase tracking-[0.2em] text-rose-500">
                    Firewall Compromised
                  </div>

                  <div>
                    <div className="text-3xl font-black font-mono">
                      {score}
                    </div>

                    <div className="mt-1 text-[9px] text-slate-500 uppercase tracking-wider">
                      Packets Deflected
                    </div>
                  </div>

                  <GameButton onClick={startGame}>
                    <RotateCcw size={12} />
                    Reboot & Retry
                  </GameButton>

                </GameOverlay>
              )}
            </div>

            {/* Game footer */}
            <div className="flex items-center justify-between px-4 py-3 bg-[#101626] border-t border-slate-800 text-[9px] font-mono uppercase tracking-wider">

              <span className="text-slate-500">
                Score:
                <strong className="ml-1 text-indigo-400">
                  {score}
                </strong>
              </span>

              <span className="text-indigo-500 font-bold">
                Shield v2.5
              </span>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="relative z-10 max-w-7xl w-full mx-auto py-4 border-t border-slate-800/30 text-center text-[9px] font-mono uppercase tracking-[0.2em] text-slate-600">
        © {new Date().getFullYear()} {siteTitle} • System Integrity Online
      </footer>
    </div>
  );
};

// --------------------------------------------------
// Small reusable components
// --------------------------------------------------

interface MetricProps {
  label: string;
  value: string;
  valueClass?: string;
}

const Metric: React.FC<MetricProps> = ({
  label,
  value,
  valueClass = "text-slate-100",
}) => (
  <div className="space-y-1">
    <span className="block text-[9px] font-semibold font-mono uppercase tracking-wider text-slate-600">
      {label}
    </span>

    <span className={`text-lg font-bold font-mono ${valueClass}`}>
      {value}
    </span>
  </div>
);

const GameOverlay: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => (
  <div className="absolute inset-4 z-20 rounded-xl bg-[#05070f]/95 flex flex-col items-center justify-center gap-4 text-center p-6">
    {children}
  </div>
);

const GameButton: React.FC<{
  children: React.ReactNode;
  onClick: () => void;
}> = ({ children, onClick }) => (
  <button
    type="button"
    onClick={onClick}
    className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[10px] font-black uppercase tracking-widest transition shadow-md shadow-indigo-600/20"
  >
    {children}
  </button>
);
