import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  Gamepad2, 
  Star, 
  Sparkles, 
  ShieldCheck, 
  Server, 
  HelpCircle, 
  SlidersHorizontal, 
  Monitor, 
  Tv, 
  Smartphone, 
  Layers, 
  Info, 
  ArrowRight,
  Download,
  Terminal,
  Clock,
  ChevronDown
} from 'lucide-react';
import { AppData, Plan, Game } from '../types';
import { GameInfoModal } from '../components/GameInfoModal';


interface GameServersPageProps {
  data: AppData;
  activeCurrency?: 'USD' | 'INR' | 'EUR';
  setActiveCurrency?: (c: 'USD' | 'INR' | 'EUR') => void;
  handleOrder: (plan: Plan) => void;
}

export const GameServersPage: React.FC<GameServersPageProps> = ({
  data,
  activeCurrency = 'INR',
  handleOrder,
}) => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedPlatform, setSelectedPlatform] = useState('All');
  const [sortBy, setSortBy] = useState<'popular' | 'price-low' | 'price-high' | 'name'>('popular');
  const [infoGameModal, setInfoGameModal] = useState<Game | null>(null);

  const handleDeployGame = (game: Game) => {
    const slug = game.id.replace('game-', '').toLowerCase();
    navigate(`/game/${slug}`);
  };

  const categories = ['All', 'Popular', 'Survival', 'Sandbox', 'RPG', 'Simulation'];
  const platforms = [
    { id: 'All', label: 'All Platforms', icon: Monitor },
    { id: 'PC', label: 'PC / Steam', icon: Monitor },
    { id: 'PlayStation', label: 'PlayStation', icon: Tv },
    { id: 'Xbox', label: 'Xbox', icon: Tv },
    { id: 'Crossplay', label: 'Crossplay', icon: Layers },
    { id: 'Mobile', label: 'Mobile', icon: Smartphone },
  ];

  // Filtering & Sorting
  const filteredGames = (data.games || []).filter((game) => {
    const matchesSearch = game.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          game.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === 'All' || 
                            (selectedCategory === 'Popular' && game.badge === 'POPULAR') ||
                            game.category === selectedCategory;

    const matchesPlatform = selectedPlatform === 'All' || 
                            game.platforms.includes(selectedPlatform);

    return matchesSearch && matchesCategory && matchesPlatform;
  }).sort((a, b) => {
    if (sortBy === 'price-low') return a.startingPriceInr - b.startingPriceInr;
    if (sortBy === 'price-high') return b.startingPriceInr - a.startingPriceInr;
    if (sortBy === 'name') return a.title.localeCompare(b.title);
    return 0; // default popular
  });

  const formatPrice = (priceInr: number) => {
    if (activeCurrency === 'USD') {
      return `$${Math.round(priceInr / 83)}`;
    }
    if (activeCurrency === 'EUR') {
      return `€${Math.round(priceInr / 90)}`;
    }
    return `₹${priceInr}`;
  };

  const getGameStartingPrice = (game: Game) => {
    // 1. Check if there are specific ramOptions defined for this game and we are NOT in catalog mode
    if (!game.use_catalog_plans && game.ramOptions && game.ramOptions.length > 0) {
      const prices = game.ramOptions.map(opt => Number(opt.priceInr)).filter(n => !isNaN(n) && n > 0);
      if (prices.length > 0) return Math.min(...prices);
    }

    // 2. Fallback: Search in general plans collection
    const gameTitle = (game.title || '').toLowerCase();
    const gameIdClean = game.id.toLowerCase().replace('game-', '');

    const allGameHostingPlans = (data.plans?.filter(p => {
      if (p.is_active === false || p.archived) return false;
      const cat = (p.category || '').toUpperCase().replace(/[-_ ]/g, '');
      return cat === 'GAMEHOSTING' || cat.includes('GAME') || (p.category || '').toUpperCase() === 'GAME-HOSTING';
    }) || []);

    const plansForGame = allGameHostingPlans.filter(p => {
      const name = (p.name || '').toLowerCase();
      const id = (p.id || '').toLowerCase();
      const desc = (p.desc || '').toLowerCase();
      return name.includes(gameTitle) || name.includes(gameIdClean) || id.includes(gameIdClean) || desc.includes(gameTitle);
    });

    if (plansForGame.length > 0) {
      const prices = plansForGame.map(p => Number(p.price_inr || p.price)).filter(n => !isNaN(n) && n > 0);
      if (prices.length > 0) return Math.min(...prices);
    }
    
    return game.startingPriceInr;
  };

  return (
    <div className="min-h-screen bg-bg text-foreground pt-32 pb-24 px-4 sm:px-6 relative overflow-hidden font-sans">
      
      {/* Subtle Depth */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[600px] bg-[radial-gradient(circle_at_center,rgba(139,92,246,0.02)_0%,transparent_70%)] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">

        {/* Hero Header */}
        <div className="text-center max-w-4xl mx-auto mb-16 sm:mb-24">
          <span className="text-[10px] uppercase font-black text-accent tracking-[0.2em] block mb-3">
            Infrastructure / Multiplayer Nodes
          </span>

          <motion.h1 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-3xl sm:text-5xl md:text-7xl font-extrabold uppercase tracking-tight text-foreground leading-[1.1] mb-5"
          >
            Game <span className="text-foreground-muted">Compute.</span>
          </motion.h1>

          <p className="text-foreground-muted text-sm sm:text-lg font-normal max-w-2xl mx-auto leading-relaxed mb-8 text-balance">
            Deterministic performance for competitive gaming. Provisioned on high-clock AMD Ryzen™ architectures with specialized Layer 7 DDoS mitigation and NVMe storage.
          </p>

          {/* Trustpilot Rating Bar */}
          <div className="inline-flex items-center gap-2.5 sm:gap-3 px-4 sm:px-5 py-2.5 sm:py-3 bg-bg-alt border border-border rounded-md text-[9px] sm:text-[10px] font-black uppercase tracking-widest text-foreground-dim shadow-sm max-w-full overflow-hidden">
            <div className="flex items-center gap-1 text-emerald-400 shrink-0">
              {[...Array(5)].map((_, i) => (
                <Star key={i} size={12} className="fill-current" />
              ))}
            </div>
            <span className="truncate">Based on <strong className="text-foreground">25,000+ reviews</strong></span>
            <span className="text-emerald-400 font-bold flex items-center gap-1 border-l border-border pl-2.5 sm:pl-3 shrink-0">
              Trustpilot
            </span>
          </div>
        </div>

        {/* Control Toolbar */}
        <div className="bg-bg border border-border rounded-lg p-4 sm:p-6 mb-12 sm:mb-16 shadow-sm space-y-5">
          
          <div className="flex flex-col lg:flex-row gap-4 sm:gap-6 items-stretch lg:items-center justify-between">
            
            {/* Search Input */}
            <div className="relative w-full lg:w-80">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-foreground-dim" size={14} />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Query game nodes..."
                className="w-full bg-bg-alt border border-border rounded-md py-3 pl-11 pr-4 text-[13px] text-foreground focus:border-accent outline-none transition-all placeholder:text-foreground-dim"
              />
            </div>

            {/* Category Pills (Touch friendly scroll on mobile) */}
            <div className="flex items-center overflow-x-auto no-scrollbar py-1 gap-1 sm:gap-0 sm:bg-border sm:p-px sm:rounded w-full lg:w-auto">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-4 sm:px-5 py-2 sm:py-2.5 text-[10px] font-black uppercase tracking-widest shrink-0 transition-all rounded sm:rounded-none ${
                    selectedCategory === cat
                      ? 'bg-accent sm:bg-bg text-white sm:text-accent shadow-sm'
                      : 'bg-bg-alt text-foreground-dim hover:text-foreground border sm:border-0 border-border sm:border-r sm:border-border sm:last:border-r-0'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Sort Dropdown */}
            <div className="flex items-center justify-between sm:justify-end gap-3 w-full lg:w-auto">
              <span className="text-[10px] text-foreground-dim font-black uppercase tracking-widest">Sort:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-bg-alt border border-border rounded px-3 py-2 text-[11px] text-foreground outline-none focus:border-accent font-bold uppercase tracking-widest flex-1 sm:flex-initial"
              >
                <option value="popular">POPULARITY</option>
                <option value="price-low">PRICE: ASC</option>
                <option value="price-high">PRICE: DESC</option>
                <option value="name">TITLE: A-Z</option>
              </select>
            </div>

          </div>

          {/* Platform Filter */}
          <div className="pt-4 sm:pt-6 border-t border-border flex flex-wrap items-center gap-2">
            <span className="text-[10px] font-black uppercase tracking-widest text-foreground-dim mr-2 sm:mr-4 flex items-center gap-2 w-full sm:w-auto mb-1 sm:mb-0">
              <SlidersHorizontal size={14} className="text-accent" /> Platform:
            </span>

            {platforms.map((p) => {
              const IconComponent = p.icon;
              const isSelected = selectedPlatform === p.id;
              return (
                <button
                  key={p.id}
                  onClick={() => setSelectedPlatform(p.id)}
                  className={`inline-flex items-center gap-2 px-4 py-2 rounded text-[10px] font-black uppercase tracking-widest transition-all border ${
                    isSelected
                      ? 'bg-bg-alt border-accent text-accent'
                      : 'bg-bg border-border text-foreground-dim hover:text-foreground hover:border-foreground-dim'
                  }`}
                >
                  <IconComponent size={12} />
                  <span>{p.label}</span>
                </button>
              );
            })}
          </div>

        </div>

        {/* Game Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-px bg-border border border-border rounded-lg overflow-hidden mb-32">
          <AnimatePresence mode="popLayout">
            {filteredGames.length > 0 ? (
              filteredGames.map((game, idx) => (
                <motion.div
                  key={game.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.25, delay: idx * 0.03 }}
                  className="group bg-bg overflow-hidden transition-all duration-300 flex flex-col relative"
                >
                  {/* Poster Image Container */}
                  <div className="relative aspect-[3/4] overflow-hidden bg-bg-alt">
                    <img
                      src={game.image}
                      alt={game.title}
                      className="w-full h-full object-cover object-center grayscale-[20%] group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700"
                    />
                    
                    {/* Minimal Overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-bg via-transparent to-transparent opacity-80" />

                    {/* Top Badge */}
                    {game.badge && (
                      <div className="absolute top-4 left-4 px-3 py-1 rounded bg-accent text-white font-black text-[10px] tracking-[0.2em] uppercase border border-white/20 shadow-lg">
                        {game.badge}
                      </div>
                    )}

                    {/* Game Information Trigger */}
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        setInfoGameModal(game);
                      }}
                      title={`View ${game.title} Information & Hardware Specs`}
                      className="absolute top-4 right-4 p-2 rounded bg-bg/80 border border-border text-foreground-dim hover:text-accent hover:border-accent transition-all cursor-pointer z-10"
                    >
                      <Info size={14} />
                    </button>

                    {/* Content Layer */}
                    <div className="absolute bottom-6 left-6 right-6">
                      <h3 className="text-xl font-black text-white uppercase tracking-tight mb-2">
                        {game.title}
                      </h3>

                      {/* Starting Price Tag */}
                      <div className="text-[11px] text-foreground-dim font-black uppercase tracking-widest mb-4">
                        FROM <span className="text-accent text-sm ml-1">{formatPrice(getGameStartingPrice(game))}</span>/MO
                      </div>

                      {/* Supported Platform Badges */}
                      <div className="flex items-center gap-2">
                        {game.platforms.map((plat) => (
                          <span key={plat} className="px-2 py-0.5 rounded bg-bg/40 border border-white/10 text-[9px] font-black uppercase tracking-widest text-white/80">
                            {plat}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Card Action Footer */}
                  <div className="p-4 bg-bg border-t border-border mt-auto">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeployGame(game);
                      }}
                      className="w-full py-4 rounded text-[10px] font-black uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-2 border border-border hover:border-accent hover:bg-accent hover:text-white cursor-pointer"
                    >
                      <span>Deploy Server</span>
                      <ArrowRight size={14} />
                    </button>
                  </div>
                </motion.div>
              ))
            ) : (
              <div className="col-span-full py-24 text-center bg-bg">
                <Gamepad2 size={48} className="mx-auto text-foreground-dim mb-4 opacity-20" />
                <h3 className="text-lg font-black text-foreground uppercase tracking-tight mb-2">Null Result</h3>
                <p className="text-sm text-foreground-muted">Query returned no active game nodes matching current filters.</p>
              </div>
            )}
          </AnimatePresence>
        </div>

        {/* Feature Grid */}
        <div className="mb-32">
          <div className="text-center mb-16">
            <span className="text-[10px] uppercase font-black text-accent tracking-[0.2em] block mb-4">
              Infrastructure Governance
            </span>
            <h2 className="text-3xl sm:text-5xl font-extrabold text-foreground uppercase tracking-tight">
              Hardware <span className="text-foreground-muted">Logistics.</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-px bg-border border border-border rounded-lg overflow-hidden">
            {[
              { icon: Download, title: 'Runtime Deployment', desc: 'Automated lifecycle management for modpacks and application binaries. Support for CurseForge™, Modrinth™, and legacy protocols.' },
              { icon: Terminal, title: 'Panel Orchestration', desc: 'Secure web-based control interfaces for real-time telemetry, SFTP integration, and automated redundancy routines.' },
              { icon: ShieldCheck, title: 'Volumetric Filtering', desc: 'Inline mitigation strategies for Layer 7 exploits. Sub-2ms scrubbing of volumetric UDP and SYN reflection incidents.' }
            ].map((feat, i) => (
              <div key={i} className="p-12 bg-bg space-y-8">
                <div className="w-12 h-12 rounded bg-bg-alt border border-border flex items-center justify-center text-accent">
                  <feat.icon size={24} />
                </div>
                <div className="space-y-3">
                  <h3 className="text-lg font-black text-foreground uppercase tracking-tight">{feat.title}</h3>
                  <p className="text-sm text-foreground-muted leading-relaxed">
                    {feat.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Game Information Modal */}
      <GameInfoModal
        game={infoGameModal as any}
        onClose={() => setInfoGameModal(null)}
        onDeploy={(game) => {
          setInfoGameModal(null);
          handleDeployGame(game as any);
        }}
      />
    </div>
  );
};
