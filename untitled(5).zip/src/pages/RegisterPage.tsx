import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Mail, Lock, User, ArrowRight, ArrowLeft, Chrome, 
  ShieldCheck, Server, Zap, CheckCircle2, AlertCircle, 
  Eye, EyeOff, RefreshCw, Sparkles 
} from 'lucide-react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../services/firebase';
import { authService } from '../services/authService';
import { pterodactylService } from '../services/pterodactylService';
import { Logo } from '../components/Logo';

export const RegisterPage: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [discord, setDiscord] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [loading, setLoading] = useState(false);
  const [isGoogleRegister, setIsGoogleRegister] = useState(false);
  const [googleUid, setGoogleUid] = useState('');
  const [successInfo, setSuccessInfo] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();
  const location = useLocation();

  React.useEffect(() => {
    if (location.state && location.state.googleUser) {
      const { uid, email, displayName } = location.state.googleUser;
      setName(displayName || '');
      setEmail(email || '');
      setIsGoogleRegister(true);
      setGoogleUid(uid);
    }
  }, [location.state]);

  // Password Security Strength Calculations
  const hasMinLength = password.length >= 8;
  const hasUppercase = /[A-Z]/.test(password);
  const hasLowercase = /[a-z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  const hasSpecial = /[^A-Za-z0-9]/.test(password);

  const strengthScore = [hasMinLength, hasUppercase, hasLowercase, hasNumber, hasSpecial].filter(Boolean).length;
  
  const getStrengthLabel = () => {
    if (password.length === 0) return { label: '', color: 'bg-border', text: 'text-foreground-dim' };
    if (strengthScore <= 2) return { label: 'Weak', color: 'bg-rose-500', text: 'text-rose-400' };
    if (strengthScore <= 3) return { label: 'Fair', color: 'bg-amber-500', text: 'text-amber-400' };
    if (strengthScore <= 4) return { label: 'Strong', color: 'bg-emerald-500', text: 'text-emerald-400' };
    return { label: 'Ultra-Secure', color: 'bg-accent', text: 'text-accent' };
  };

  const strength = getStrengthLabel();

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessInfo(null);

    const cleanEmail = email.trim();
    const cleanName = name.trim();

    if (!cleanName) {
      setError('Please provide your name or organization title.');
      return;
    }

    if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      setError('Please provide a valid email address.');
      return;
    }

    if (!hasMinLength) {
      setError('Password must be at least 8 characters in length.');
      return;
    }

    if (password !== confirmPassword) {
      setError('Passwords do not match. Please verify both fields.');
      return;
    }

    if (!agreeTerms) {
      setError('Please accept the Terms of Service and Privacy Policy to continue.');
      return;
    }

    setLoading(true);
    try {
      if (isGoogleRegister) {
        const pteroRes = await pterodactylService.createOrLinkUser({
          email: cleanEmail,
          name: cleanName,
          password: password,
          firebaseUid: googleUid
        });

        if (pteroRes.success && pteroRes.user) {
          await setDoc(doc(db, 'users', googleUid), {
            uid: googleUid,
            email: cleanEmail,
            displayName: cleanName,
            phone: phone.trim(),
            discord: discord.trim(),
            pterodactylId: pteroRes.user.id,
            pterodactylUsername: pteroRes.user.username,
            pterodactylCreatedAt: pteroRes.user.created_at,
            createdAt: serverTimestamp()
          }, { merge: true });

          setSuccessInfo('Google authenticated & Pterodactyl Game Panel synchronized!');
          setTimeout(() => navigate('/dashboard'), 1500);
        } else {
          throw new Error(pteroRes.error || 'Failed to link Pterodactyl account.');
        }
      } else {
        const user = await authService.registerWithEmail(cleanEmail, password, cleanName);
        if (user) {
          await setDoc(doc(db, 'users', user.uid), {
            phone: phone.trim(),
            discord: discord.trim()
          }, { merge: true });
        }
        setSuccessInfo('Account created successfully! Synchronizing Pterodactyl Game Panel...');
        setTimeout(() => navigate('/dashboard'), 1500);
      }
    } catch (err: any) {
      const code = err?.code || '';
      if (code === 'auth/email-already-in-use') {
        setError('This email address is already registered. Please sign in instead.');
      } else if (code === 'auth/weak-password') {
        setError('Password is too weak. Please include letters, numbers, and symbols.');
      } else {
        setError(err.message || 'Registration failed. Please check your details and try again.');
      }
      setLoading(false);
    }
  };

  const handleGoogleClick = async () => {
    setError(null);
    try {
      const result = await authService.loginWithGoogle();
      if (result && result.user) {
        setLoading(true);
        if (result.pterodactylId) {
          navigate('/dashboard');
        } else {
          setName(result.user.displayName || '');
          setEmail(result.user.email || '');
          setIsGoogleRegister(true);
          setGoogleUid(result.user.uid);
        }
      }
    } catch (err: any) {
      if (err.code === 'auth/popup-blocked') {
        setError('The sign-up popup was blocked by your browser. Please allow popups for this site and try again.');
      } else {
        setError(err.message || 'Google Registration failed.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-bg text-foreground pt-32 pb-24 px-4 sm:px-6 relative overflow-hidden font-sans flex flex-col justify-center">
      
      {/* Precision Background */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[600px] bg-[radial-gradient(circle_at_center,rgba(139,92,246,0.03)_0%,transparent_70%)] pointer-events-none" />

      {/* Top Header Bar */}
      <div className="absolute top-6 left-6 right-6 max-w-7xl mx-auto flex items-center justify-between z-30">
        <Link to="/" className="flex items-center gap-3 group">
          <Logo size={36} className="group-hover:scale-105 transition-transform" />
          <span className="font-display font-black text-xl tracking-tight uppercase text-foreground">
            Hector<span className="text-accent">Hosting</span>
          </span>
        </Link>

        <Link
          to="/"
          className="inline-flex items-center gap-2 px-4 py-2 bg-bg-alt border border-border hover:bg-border text-foreground text-xs font-bold uppercase tracking-widest rounded transition-all"
        >
          <ArrowLeft size={14} className="text-accent" />
          <span>Home</span>
        </Link>
      </div>

      <div className="max-w-6xl mx-auto relative z-10 w-full mt-12 sm:mt-0">
        <div className="grid lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Technical Highlights */}
          <div className="lg:col-span-5 space-y-8 order-2 lg:order-1">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-bg-alt border border-border text-[10px] font-black uppercase tracking-[0.2em] text-accent">
                <Sparkles size={13} />
                <span>Instant Cloud Registration</span>
              </div>
              
              <h1 className="text-3xl sm:text-5xl font-extrabold uppercase tracking-tight text-foreground leading-[1.05] font-display">
                Create Account. <br />
                <span className="text-foreground-muted">Deploy Instant Nodes.</span>
              </h1>
              <p className="text-foreground-muted text-sm leading-relaxed font-normal">
                Join community owners, server developers, and enterprise projects provisioned on Hector Hosting's low-latency Indian & global network.
              </p>
            </div>

            {/* Technical Highlights (1px Bordered Box) */}
            <div className="grid grid-cols-1 gap-px bg-border border border-border rounded-lg overflow-hidden">
              <div className="p-5 bg-bg flex items-start gap-4">
                <div className="w-10 h-10 rounded bg-bg-alt border border-border flex items-center justify-center text-accent shrink-0 mt-0.5">
                  <Server size={18} />
                </div>
                <div>
                  <h4 className="text-xs font-black uppercase tracking-wider text-foreground">AMD RYZEN™ 9 5950X Compute</h4>
                  <p className="text-[11px] text-foreground-muted mt-0.5 leading-relaxed">Dedicated high-clock cores operating at sustained 4.9GHz boost speeds.</p>
                </div>
              </div>

              <div className="p-5 bg-bg flex items-start gap-4">
                <div className="w-10 h-10 rounded bg-bg-alt border border-border flex items-center justify-center text-emerald-400 shrink-0 mt-0.5">
                  <ShieldCheck size={18} />
                </div>
                <div>
                  <h4 className="text-xs font-black uppercase tracking-wider text-foreground">Multi-Layer DDoS Immunity</h4>
                  <p className="text-[11px] text-foreground-muted mt-0.5 leading-relaxed">Filtered through inline scrubbing centers to stop UDP floods without ping spikes.</p>
                </div>
              </div>

              <div className="p-5 bg-bg flex items-start gap-4">
                <div className="w-10 h-10 rounded bg-bg-alt border border-border flex items-center justify-center text-amber-400 shrink-0 mt-0.5">
                  <Zap size={18} />
                </div>
                <div>
                  <h4 className="text-xs font-black uppercase tracking-wider text-foreground">Automated Daily Backups</h4>
                  <p className="text-[11px] text-foreground-muted mt-0.5 leading-relaxed">Off-site snapshot protection for 1-click recovery during world corruption or file errors.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Registration Card */}
          <div className="lg:col-span-7 order-1 lg:order-2">
            <div className="bg-bg-alt border border-border p-8 sm:p-10 rounded-lg shadow-xl relative">
              
              <div className="mb-8">
                <span className="text-[10px] font-black uppercase tracking-[0.2em] text-accent block mb-1">
                  Registration Desk
                </span>
                <h2 className="text-2xl sm:text-3xl font-black text-foreground uppercase tracking-tight font-display">
                  Create Client Account
                </h2>
                <p className="text-xs text-foreground-muted mt-1">
                  Get started with Hector Hosting Cloud & Game Infrastructure
                </p>
              </div>

              {/* Success Message */}
              {successInfo && (
                <div className="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/30 rounded text-emerald-400 text-xs font-bold flex items-center gap-3">
                  <CheckCircle2 size={16} className="shrink-0" />
                  <span>{successInfo}</span>
                </div>
              )}

              {/* Error Alert */}
              {error && (
                <div className="mb-6 p-4 bg-rose-500/10 border border-rose-500/30 rounded text-rose-400 text-xs font-bold flex items-start gap-3">
                  <AlertCircle size={16} className="shrink-0 mt-0.5" />
                  <span className="leading-relaxed">{error}</span>
                </div>
              )}

              <form className="space-y-4" onSubmit={handleRegister}>
                <div>
                  <label className="block text-[10px] font-black text-foreground-dim uppercase tracking-widest mb-1.5">
                    Full Name / Organization
                  </label>
                  <div className="relative">
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 text-foreground-dim" size={16} />
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      disabled={isGoogleRegister}
                      className="w-full bg-bg border border-border focus:border-accent rounded py-3 pl-11 pr-4 text-xs text-foreground outline-none transition-all placeholder:text-foreground-dim disabled:opacity-75 disabled:cursor-not-allowed"
                      placeholder="Alex Morgan"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-black text-foreground-dim uppercase tracking-widest mb-1.5">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-foreground-dim" size={16} />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      disabled={isGoogleRegister}
                      className="w-full bg-bg border border-border focus:border-accent rounded py-3 pl-11 pr-4 text-xs text-foreground outline-none transition-all placeholder:text-foreground-dim disabled:opacity-75 disabled:cursor-not-allowed"
                      placeholder="client@hectorhosting.com"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-black text-foreground-dim uppercase tracking-widest mb-1.5">
                      Phone / WhatsApp (Dispatch)
                    </label>
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full bg-bg border border-border focus:border-accent rounded py-3 px-4 text-xs text-foreground outline-none transition-all placeholder:text-foreground-dim"
                      placeholder="+91 98765 43210"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-foreground-dim uppercase tracking-widest mb-1.5">
                      Discord Tag / Username
                    </label>
                    <input
                      type="text"
                      value={discord}
                      onChange={(e) => setDiscord(e.target.value)}
                      className="w-full bg-bg border border-border focus:border-accent rounded py-3 px-4 text-xs text-foreground outline-none transition-all placeholder:text-foreground-dim"
                      placeholder="username or user#0000"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-black text-foreground-dim uppercase tracking-widest mb-1.5">
                    Secure Password
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-foreground-dim" size={16} />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-bg border border-border focus:border-accent rounded py-3 pl-11 pr-11 text-xs text-foreground outline-none transition-all placeholder:text-foreground-dim"
                      placeholder="••••••••••••"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-foreground-dim hover:text-foreground transition-colors"
                    >
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>

                  {password.length > 0 && (
                    <div className="mt-2 space-y-1">
                      <div className="flex items-center justify-between text-[10px]">
                        <span className="text-foreground-dim">Password Strength:</span>
                        <span className={`font-bold uppercase tracking-wider ${strength.text}`}>
                          {strength.label}
                        </span>
                      </div>
                      <div className="w-full bg-bg h-1 rounded overflow-hidden border border-border">
                        <div 
                          className={`h-full transition-all duration-300 ${strength.color}`} 
                          style={{ width: `${(strengthScore / 5) * 100}%` }}
                        />
                      </div>
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-[10px] font-black text-foreground-dim uppercase tracking-widest mb-1.5">
                    Confirm Password
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-foreground-dim" size={16} />
                    <input
                      type={showConfirmPassword ? 'text' : 'password'}
                      required
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full bg-bg border border-border focus:border-accent rounded py-3 pl-11 pr-11 text-xs text-foreground outline-none transition-all placeholder:text-foreground-dim"
                      placeholder="••••••••••••"
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-foreground-dim hover:text-foreground transition-colors"
                    >
                      {showConfirmPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                  {confirmPassword && password !== confirmPassword && (
                    <p className="text-[10px] text-rose-400 mt-1 font-bold">Passwords do not match.</p>
                  )}
                </div>

                <div className="pt-2">
                  <label className="flex items-start gap-3 cursor-pointer group">
                    <input
                      type="checkbox"
                      checked={agreeTerms}
                      onChange={(e) => setAgreeTerms(e.target.checked)}
                      className="mt-0.5 w-4 h-4 rounded bg-bg border-border text-accent focus:ring-accent accent-accent"
                    />
                    <span className="text-xs text-foreground-muted leading-normal">
                      I accept the{' '}
                      <Link to="/tos" target="_blank" className="text-accent hover:underline font-bold">
                        Terms of Service
                      </Link>{' '}
                      and{' '}
                      <Link to="/privacy" target="_blank" className="text-accent hover:underline font-bold">
                        Privacy Policy
                      </Link>.
                    </span>
                  </label>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-4 bg-accent hover:bg-accent-muted text-white font-bold text-xs uppercase tracking-[0.2em] rounded transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 mt-4"
                >
                  {loading ? (
                    <>
                      <RefreshCw className="animate-spin" size={14} />
                      <span>Provisioning Account...</span>
                    </>
                  ) : (
                    <>
                      <span>Complete Registration</span>
                      <ArrowRight size={14} />
                    </>
                  )}
                </button>
              </form>

              {/* Divider */}
              <div className="my-6 relative flex items-center justify-center">
                <div className="border-t border-border w-full" />
                <span className="bg-bg-alt px-4 text-[9px] font-black uppercase tracking-widest text-foreground-dim absolute">
                  Alternative Sign Up
                </span>
              </div>

              {/* Google OAuth Button */}
              <button
                type="button"
                onClick={handleGoogleClick}
                disabled={loading}
                className="w-full py-3.5 px-4 bg-bg border border-border hover:bg-border text-foreground text-xs font-bold uppercase tracking-wider rounded transition-all flex items-center justify-center gap-3 cursor-pointer disabled:opacity-50"
              >
                <Chrome size={16} className="text-accent" />
                <span>Continue with Google</span>
              </button>

              <div className="mt-8 pt-6 border-t border-border text-center">
                <p className="text-xs text-foreground-muted">
                  Already have a client account?{' '}
                  <Link 
                    to="/auth/login" 
                    className="font-black text-accent hover:underline uppercase tracking-wider ml-1"
                  >
                    Sign In Here →
                  </Link>
                </p>
              </div>

            </div>
          </div>

        </div>
      </div>

    </div>
  );
};
