import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Cpu, 
  ShieldCheck, 
  Zap, 
  Globe, 
  Terminal, 
  HardDrive, 
  Server, 
  Star, 
  ArrowRight, 
  CheckCircle2, 
  ChevronRight,
  Settings2, 
  Layers,
  Lock,
  RefreshCw
} from 'lucide-react';
import { AppData, Plan } from '../types';
import { getDynamicLocations } from '../utils/locationUtils';
import { parseAmount } from '../utils/formatUtils';

interface VpsHostingPageProps {
  data: AppData;
  activeCurrency?: 'USD' | 'INR' | 'EUR';
  setActiveCurrency?: (c: 'USD' | 'INR' | 'EUR') => void;
  handleOrder: (plan: Plan) => void;
}

interface VpsPlanSpec {
  id: string;
  name: string;
  badge: string;
  vcpu: string;
  ram: string;
  storage: string;
  bandwidth: string;
  priceInr: number;
  popular?: boolean;
  desc: string;
}

const VPS_PLANS: VpsPlanSpec[] = [];

const SUPPORTED_OS = [
  { name: 'Ubuntu 22.04 LTS', icon: '🐧', type: 'Linux' },
  { name: 'Debian 12 Bookworm', icon: '🌀', type: 'Linux' },
  { name: 'AlmaLinux 9', icon: '🌐', type: 'Linux' },
  { name: 'CentOS Stream 9', icon: '⚙️', type: 'Linux' },
  { name: 'Windows Server 2022', icon: '🪟', type: 'Windows' },
  { name: 'Docker Engine 1-Click', icon: '🐳', type: 'App' },
  { name: 'cPanel / WHM', icon: '🚀', type: 'Panel' },
  { name: 'CyberPanel / LiteSpeed', icon: '⚡', type: 'Panel' },
];

export const VpsHostingPage: React.FC<VpsHostingPageProps> = ({
  data,
  activeCurrency,
  setActiveCurrency,
  handleOrder,
}) => {
  const availableLocations = getDynamicLocations(data?.locations);
  const [selectedOS, setSelectedOS] = useState('Ubuntu 22.04 LTS');
  const [selectedLocation, setSelectedLocation] = useState(
    availableLocations[0]?.name || 'India (Mumbai)'
  );

  // Sync selected location if data updates
  useEffect(() => {
    if (availableLocations.length > 0 && !availableLocations.some(l => l.name === selectedLocation)) {
      setSelectedLocation(availableLocations[0].name);
    }
  }, [availableLocations, selectedLocation]);

  // Render database VPS plans dynamically if configured, else fall back to static
  const dbVpsPlans = (data?.plans?.filter(p => {
    if (p.is_active === false || p.archived) return false;
    const cat = (p.category || '').toLowerCase();
    return cat === 'ryzen-vps-pricing' || cat === 'intel-vps-pricing' || cat.includes('vps');
  }) || []).sort((a, b) => (a.order || 0) - (b.order || 0));

  if (dbVpsPlans.length === 0) {
    return (
      <div className="bg-[#050409] min-h-screen text-slate-100 pt-32 pb-20 text-center">
        <h2 className="text-2xl font-bold opacity-50 uppercase font-sans">No VPS plans available currently.</h2>
        <p className="text-slate-400 mt-2 font-light">Nodes are currently being provisioned. Please check back shortly.</p>
      </div>
    );
  }

  const displayPlans = dbVpsPlans.map(plan => ({
    id: plan.id,
    name: plan.name,
    badge: plan.badge || 'KVM CLOUD',
    vcpu: plan.features[0] || '1 vCPU Core',
    ram: plan.features[1] || '2 GB DDR4 RAM',
    storage: plan.features[2] || '30 GB NVMe Storage',
    bandwidth: plan.features[3] || 'Unmetered Bandwidth',
    priceInr: parseAmount(plan.price_inr || plan.price),
    popular: plan.badge?.toLowerCase().includes('popular') || plan.badge?.toLowerCase().includes('best') || false,
    desc: plan.desc,
    features: plan.features,
    location: plan.location,
    node: plan.node
  }));

  const formatPrice = (priceInr: number) => {
    return `₹${priceInr}`;
  };

  const handlePlanOrder = (vps: any) => {
    const dbPlan = data?.plans?.find(p => p.id === vps.id);
    if (dbPlan) {
      handleOrder({
        ...dbPlan,
        location: selectedLocation, // respect chosen location
      });
    } else {
      const plan: Plan = {
        id: vps.id,
        name: vps.name,
        category: 'VPS-Hosting',
        badge: vps.badge,
        location: selectedLocation,
        node: 'Ryzen-KVM-Node-01',
        desc: vps.desc,
        price: String(Math.round(vps.priceInr / 83)),
        price_inr: String(vps.priceInr),
        price_eur: String(Math.round(vps.priceInr / 90)),
        features: [
          vps.vcpu,
          vps.ram,
          vps.storage,
          vps.bandwidth,
          `Selected OS: ${selectedOS}`,
          `Full Root Access / HTML5 VNC Console`,
          `Location: ${selectedLocation}`,
          `10Tbps DDoS Mitigation included`
        ]
      };
      handleOrder(plan);
    }
  };

  return (
    <div className="min-h-screen bg-bg text-foreground pt-32 pb-24 px-4 sm:px-6 relative overflow-hidden">
      
      {/* Subtle Depth */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[600px] bg-[radial-gradient(circle_at_center,rgba(139,92,246,0.02)_0%,transparent_70%)] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">

        {/* Header & Hero */}
        <div className="text-center max-w-4xl mx-auto mb-20">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-bg-alt border border-border text-[10px] font-bold uppercase tracking-wider text-foreground-dim mb-8">
            <span>Home</span>
            <ChevronRight size={10} />
            <span className="text-foreground">KVM Virtual Private Servers</span>
          </div>

          <motion.h1 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl sm:text-7xl font-extrabold tracking-tight text-foreground leading-[1.05] mb-6 text-balance"
          >
            Deterministic <span className="text-foreground-muted">KVM Hosting.</span>
          </motion.h1>

          <p className="text-foreground-muted text-base sm:text-lg font-normal max-w-2xl mx-auto leading-relaxed mb-10 text-balance">
            High-frequency AMD RYZEN™ 9 5950X infrastructure with unmetered 10Gbps connectivity and enterprise-grade NVMe storage arrays.
          </p>

          {/* Top Control Bar: Datacenter Location Pills */}
          <div className="inline-flex flex-wrap items-center justify-center gap-2 bg-bg-alt border border-border p-2 rounded-lg shadow-sm">
            {/* Location selector pills */}
            <div className="flex flex-wrap items-center gap-1.5">
              {availableLocations.map(loc => (
                <button
                  key={loc.id}
                  onClick={() => setSelectedLocation(loc.name)}
                  className={`px-3 py-1.5 rounded text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 transition-all ${
                    selectedLocation === loc.name 
                      ? 'bg-accent text-white' 
                      : 'bg-bg border border-border text-foreground-dim hover:text-foreground'
                  }`}
                >
                  <span>{loc.flag}</span>
                  <span>{loc.name}</span>
                  <span className="text-[9px] opacity-70 font-mono">({loc.ping})</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* VPS Plans Grid - High Precision Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-32">
          {displayPlans.map((vps, idx) => (
            <motion.div
              key={vps.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: idx * 0.05 }}
              className={`bg-bg-alt/70 border rounded-2xl p-8 flex flex-col justify-between group relative backdrop-blur-xl transition-all duration-300 hover:shadow-xl ${
                vps.popular 
                  ? 'border-accent/60 shadow-lg shadow-accent/10' 
                  : 'border-border/80 hover:border-accent/40'
              }`}
            >
              {vps.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-accent text-white text-[9px] font-black uppercase tracking-widest shadow-md">
                  Most Popular
                </div>
              )}

              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[10px] font-black tracking-[0.2em] text-accent uppercase">
                    {vps.badge}
                  </span>
                </div>
                <h3 className="text-2xl font-black text-foreground tracking-tight uppercase font-display mb-2">
                  {vps.name}
                </h3>
                <p className="text-xs text-foreground-muted mb-6 leading-relaxed line-clamp-2 min-h-[36px]">
                  {vps.desc}
                </p>

                {/* Price Display */}
                <div className="bg-bg/80 border border-border/60 rounded-xl p-5 mb-8 text-center">
                  <div className="text-[9px] uppercase font-bold text-foreground-dim tracking-wider mb-1">Monthly Operations</div>
                  <div className="flex items-baseline justify-center gap-1">
                    <span className="text-3xl font-black text-foreground tracking-tighter font-display">{formatPrice(vps.priceInr)}</span>
                    <span className="text-xs font-normal text-foreground-dim">/mo</span>
                  </div>
                </div>

                {/* Spec List */}
                <div className="space-y-3.5 mb-10 border-t border-border/60 pt-6">
                  {vps.features && vps.features.length > 0 ? (
                    vps.features.slice(0, 5).map((feature: string, fIdx: number) => (
                      <div key={fIdx} className="flex items-center gap-3 text-xs text-foreground-muted">
                        <CheckCircle2 size={16} className="text-accent shrink-0" />
                        <span className="truncate font-normal">{feature}</span>
                      </div>
                    ))
                  ) : (
                    <>
                      <div className="flex items-center gap-3 text-xs text-foreground-muted">
                        <Cpu size={16} className="text-accent shrink-0" />
                        <span className="font-normal">{vps.vcpu}</span>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-foreground-muted">
                        <Zap size={16} className="text-accent shrink-0" />
                        <span className="font-normal">{vps.ram}</span>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-foreground-muted">
                        <HardDrive size={16} className="text-accent shrink-0" />
                        <span className="font-normal">{vps.storage}</span>
                      </div>
                    </>
                  )}
                </div>
              </div>

              <button
                onClick={() => handlePlanOrder(vps)}
                className={`w-full py-4 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-2 shadow-md cursor-pointer ${
                  vps.popular
                    ? 'bg-accent hover:bg-accent-muted text-white shadow-accent/20'
                    : 'bg-bg hover:bg-accent text-foreground hover:text-white border border-border hover:border-accent'
                }`}
              >
                <span>Deploy VPS Node</span>
                <ArrowRight size={14} />
              </button>
            </motion.div>
          ))}
        </div>

        {/* Feature Grid: Enterprise KVM Architecture */}
        <div>
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-5xl font-extrabold text-foreground tracking-tight uppercase">
              Technical <span className="text-foreground-muted">Benchmarks.</span>
            </h2>
            <p className="text-foreground-muted mt-4 max-w-xl mx-auto text-base">
              Engineered for deterministic performance and zero resource contention.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-px bg-border border border-border rounded-lg overflow-hidden">
            {[
              { icon: Lock, title: 'KVM Isolation', desc: 'Kernel-based Virtual Machine ensures strictly dedicated compute and memory IOPS.' },
              { icon: Terminal, title: 'SolusVM Stack', desc: 'Full root access with automated OS delivery and HTML5-based remote VNC.' },
              { icon: ShieldCheck, title: 'DDoS Scrubbing', desc: 'Hardware-level in-line filtration blocks volumetric and application-layer attacks.' }
            ].map((item, i) => (
              <div key={i} className="p-10 bg-bg space-y-6">
                <div className="w-10 h-10 rounded-md bg-bg-alt border border-border flex items-center justify-center text-accent">
                  <item.icon size={20} />
                </div>
                <div className="space-y-2">
                  <h3 className="text-lg font-bold text-foreground uppercase tracking-tight">{item.title}</h3>
                  <p className="text-[13px] text-foreground-muted leading-relaxed">
                    {item.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
