import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Activity, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  ShieldCheck, 
  RefreshCw,
  Server,
  Wifi,
  ChevronRight,
  Search,
  AlertTriangle,
  X,
  ExternalLink,
  Radio,
  Layers
} from 'lucide-react';
import { AppData, ServiceStatus, StatusIncident } from '../types';
import { Link } from 'react-router-dom';
import { UptimeBar } from '../components/status/UptimeBar';
import { IncidentCard } from '../components/status/IncidentCard';
import { betterStackService, BetterStackStatusResponse, BetterStackResource } from '../services/betterStackService';

interface StatusPageProps {
  data: AppData;
}

export const StatusPage: React.FC<StatusPageProps> = ({ data }) => {
  const [betterStackData, setBetterStackData] = useState<BetterStackStatusResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [lastRefreshedAt, setLastRefreshedAt] = useState<string>('Just now');
  const [showIncidentHistory, setShowIncidentHistory] = useState(true);
  const [expandedSections, setExpandedSections] = useState<Record<number, boolean>>({});

  const isInitialSectionsSet = useRef(false);

  // Initialize expanded sections only on first load, preserving user toggles during 3-second auto-refreshes
  useEffect(() => {
    if (!betterStackData?.sections) return;

    setExpandedSections(prev => {
      const next = { ...prev };
      let updated = false;

      // Initial load: expand all sections by default so users see all monitors immediately
      if (!isInitialSectionsSet.current) {
        betterStackData.sections.forEach((sec) => {
          next[sec.id] = true;
        });
        isInitialSectionsSet.current = true;
        return next;
      }

      // Subsequent 3s auto-refreshes: maintain user's explicit open/closed state
      betterStackData.sections.forEach(sec => {
        if (next[sec.id] === undefined) {
          next[sec.id] = false;
          updated = true;
        }
      });

      return updated ? next : prev;
    });
  }, [betterStackData]);

  // Expand matching sections when user actively searches or switches category tabs
  useEffect(() => {
    if ((searchQuery.trim() !== '' || selectedCategory !== 'All') && betterStackData?.sections) {
      const expanded: Record<number, boolean> = {};
      betterStackData.sections.forEach(sec => {
        expanded[sec.id] = true;
      });
      setExpandedSections(expanded);
    }
  }, [searchQuery, selectedCategory]);

  const toggleSection = (sectionId: number) => {
    setExpandedSections(prev => ({
      ...prev,
      [sectionId]: !prev[sectionId]
    }));
  };

  // Fetch status directly from Better Stack API
  const fetchStatus = useCallback(async (force = false, silent = false) => {
    try {
      if (force && !silent) setIsRefreshing(true);
      setError(null);
      const res = await betterStackService.getStatus(force);
      setBetterStackData(res);
      setLastRefreshedAt(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    } catch (err: any) {
      console.error('Failed to load Better Stack status:', err);
      setError('Unable to fetch live telemetry from Better Stack API. Retrying...');
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, []);

  useEffect(() => {
    fetchStatus(false);

    // Auto-poll Better Stack every 3 seconds bypassing cached backend queries
    const interval = setInterval(() => {
      fetchStatus(true, true);
    }, 3000);

    return () => clearInterval(interval);
  }, [fetchStatus]);

  // Convert Better Stack resources to ServiceStatus items for UptimeBar
  const mapResourceToServiceStatus = (r: BetterStackResource): ServiceStatus => {
    const isMaint = r.status === 'maintenance' || (data.settings.maintenance_mode && (r.public_name.toLowerCase().includes('website') || r.public_name.toLowerCase().includes('landing')));
    
    let normalizedStatus: ServiceStatus['status'] = 'operational';
    if (isMaint) normalizedStatus = 'maintenance';
    else if (r.status === 'downtime') normalizedStatus = 'outage';
    else if (r.status === 'degraded') normalizedStatus = 'degraded';
    else normalizedStatus = 'operational';

    const historyItems = (r.history || []).map(h => ({
      date: h.day,
      status: h.status === 'operational' ? 'operational' as const :
              h.status === 'downtime' ? 'outage' as const :
              h.status === 'maintenance' ? 'maintenance' as const :
              h.status === 'degraded' ? 'degraded' as const : 'unmonitored' as const,
      uptimePercent: h.status === 'operational' ? 100 : h.status === 'maintenance' ? 99 : 0
    }));

    return {
      id: String(r.id),
      name: r.public_name,
      ip: r.url || 'status.hector.host',
      location: 'Asia / India & Singapore',
      category: r.section_name || 'Core Services',
      status: normalizedStatus,
      lastChecked: betterStackData?.summary.last_updated || new Date().toISOString(),
      uptime: `${((r.availability || 1) * 100).toFixed(2)}%`,
      latency: '12ms',
      history: historyItems
    };
  };

  // Convert Better Stack incidents to StatusIncident items for IncidentCard
  const mappedIncidents: StatusIncident[] = (betterStackData?.incidents || []).map(inc => {
    let status: StatusIncident['status'] = 'resolved';
    if (inc.status === 'Ongoing') status = 'investigating';
    else if (inc.status === 'Acknowledged') status = 'identified';
    else status = 'resolved';

    return {
      id: inc.id,
      title: `${inc.name}: ${inc.cause || 'Service Alert'}`,
      description: inc.description || `Incident recorded for endpoint ${inc.url}. Better Stack observability engine tracked telemetry deviations in Asia regions.`,
      severity: inc.severity === 'info' ? 'minor' : inc.severity,
      status,
      serviceName: inc.name,
      createdAt: inc.started_at,
      updatedAt: inc.resolved_at || inc.started_at,
      resolvedAt: inc.resolved_at || undefined,
      updates: [
        {
          id: `up-${inc.id}-1`,
          timestamp: inc.started_at,
          status: 'investigating',
          message: `Better Stack automated probe detected anomaly: ${inc.cause || 'Unresponsive target'}`
        },
        ...(inc.resolved_at ? [{
          id: `up-${inc.id}-2`,
          timestamp: inc.resolved_at,
          status: 'resolved' as const,
          message: 'Target response restored to 200 OK. All Asia edge latency benchmarks verified operational.'
        }] : [])
      ]
    };
  });

  // Extract all resources from Better Stack sections, with fallback to direct monitors
  const allResources: BetterStackResource[] = (betterStackData?.sections && betterStackData.sections.length > 0)
    ? betterStackData.sections.flatMap(s => s.resources)
    : (betterStackData?.monitors || []).map(m => ({
        id: String(m.id),
        public_name: m.name,
        resource_id: parseInt(m.id) || null,
        section_id: m.monitor_type === 'ping' ? 2 : 1,
        section_name: m.monitor_type === 'ping' ? 'Compute & Dedicated Nodes' : 'Core Services & Panels',
        status: (m.status === 'up' ? 'operational' : m.status === 'down' ? 'downtime' : m.status === 'maintenance' ? 'maintenance' : 'operational') as BetterStackResource['status'],
        availability: 1,
        history: [],
        url: m.url
      }));

  // Build effective sections list (using sections if available, else generated from monitors)
  const effectiveSections = (betterStackData?.sections && betterStackData.sections.length > 0)
    ? betterStackData.sections
    : (betterStackData?.monitors && betterStackData.monitors.length > 0)
      ? [
          {
            id: 1,
            name: 'Core Services & Panels',
            position: 1,
            resources: allResources.filter(r => r.section_id === 1)
          },
          {
            id: 2,
            name: 'Compute & Dedicated Nodes',
            position: 2,
            resources: allResources.filter(r => r.section_id === 2)
          }
        ].filter(s => s.resources.length > 0)
      : [];

  // Distinct category list from effective sections
  const sectionsList = ['All', ...effectiveSections.map(s => s.name)];

  // Filtered resources
  const filteredResources = allResources.filter(r => {
    const matchesCategory = selectedCategory === 'All' || r.section_name === selectedCategory;
    const matchesQuery = searchQuery.trim() === '' || 
      r.public_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (r.section_name && r.section_name.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesQuery;
  });

  const overallStatus = betterStackData?.summary.overall_status || 'operational';
  const uptimePercentage = betterStackData?.summary.uptime_percentage || '99.98%';
  const activeIncidents = mappedIncidents.filter(i => i.status !== 'resolved');
  const pastIncidents = mappedIncidents.filter(i => i.status === 'resolved');

  return (
    <div className="min-h-screen bg-bg text-foreground pt-32 pb-24 px-4 sm:px-6 relative overflow-hidden font-sans">
      {/* Dynamic Background Glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[600px] bg-[radial-gradient(circle_at_center,rgba(139,92,246,0.04)_0%,transparent_70%)] pointer-events-none" />

      <div className="max-w-6xl mx-auto relative z-10 space-y-12">
        
        {/* Navigation Breadcrumb & Header */}
        <div className="text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-bg-alt border border-border text-[10px] font-bold uppercase tracking-wider text-foreground-dim mb-6">
            <Link to="/" className="hover:text-accent transition-colors">Home</Link>
            <ChevronRight size={10} />
            <span className="text-foreground flex items-center gap-1.5">
              <Radio size={12} className="text-emerald-400 animate-pulse" />
              Better Stack Observability
            </span>
          </div>

          <motion.h1 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl sm:text-6xl font-black tracking-tight text-foreground leading-tight mb-4 uppercase"
          >
            System <span className="text-accent">Status.</span>
          </motion.h1>

          <p className="text-foreground-muted text-sm sm:text-base max-w-2xl mx-auto mb-8 font-light">
            Real-time multi-region telemetry powered directly by the <strong className="text-foreground font-semibold">Better Stack Uptime API</strong>. Continuous probes measure HTTP availability, ping round-trips, and cluster health across Asia-Pacific datacenters.
          </p>

          {/* System Health Status Banner */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            className={`p-6 sm:p-8 rounded-3xl border flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl transition-all ${
              overallStatus === 'operational' ? 'bg-emerald-500/5 border-emerald-500/20' :
              overallStatus === 'degraded' ? 'bg-amber-500/5 border-amber-500/20' :
              overallStatus === 'outage' ? 'bg-rose-500/5 border-rose-500/20' : 'bg-blue-500/5 border-blue-500/20'
            }`}
          >
            <div className="flex items-center gap-5 text-left w-full md:w-auto">
              <div className={`w-16 h-16 rounded-2xl flex items-center justify-center shrink-0 border ${
                overallStatus === 'operational' ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' :
                overallStatus === 'degraded' ? 'bg-amber-500/10 border-amber-500/30 text-amber-400' :
                overallStatus === 'outage' ? 'bg-rose-500/10 border-rose-500/30 text-rose-400' : 'bg-blue-500/10 border-blue-500/30 text-blue-400'
              }`}>
                {overallStatus === 'operational' ? <CheckCircle2 size={32} /> : <AlertTriangle size={32} />}
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h2 className="text-2xl font-black text-foreground uppercase tracking-tight">
                    {overallStatus === 'operational' ? 'All Systems Operational' :
                     overallStatus === 'degraded' ? 'Partial System Degradation' :
                     overallStatus === 'outage' ? 'Major Service Outage Detected' : 'Scheduled Maintenance Active'}
                  </h2>
                  <span className="hidden sm:inline-flex px-2 py-0.5 rounded text-[9px] font-mono font-bold uppercase bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                    Better Stack Verified
                  </span>
                </div>
                <p className="text-xs text-foreground-dim font-mono">
                  Continuous live checks across all infrastructure nodes • Last sync: {lastRefreshedAt}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 w-full md:w-auto justify-end">
              <a
                href="https://status.hector.host"
                target="_blank"
                rel="noreferrer"
                className="px-4 py-2.5 rounded-xl bg-bg-alt hover:bg-bg border border-border text-foreground text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all"
              >
                <span>status.hector.host</span>
                <ExternalLink size={12} className="text-foreground-dim" />
              </a>
              <button
                onClick={() => fetchStatus(true)}
                disabled={isRefreshing || isLoading}
                className="px-4 py-2.5 rounded-xl bg-accent text-white text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all hover:brightness-110 active:scale-95 disabled:opacity-50 shadow-lg shadow-accent/20"
              >
                <RefreshCw size={14} className={isRefreshing ? 'animate-spin' : ''} />
                <span>{isRefreshing ? 'Syncing...' : 'Live Refresh'}</span>
              </button>
            </div>
          </motion.div>
        </div>

        {/* Global Statistics Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: '90-Day SLA Uptime', val: uptimePercentage, icon: Clock, desc: 'Better Stack Measured' },
            { label: 'Monitored Resources', val: `${allResources.length || 8} Endpoints`, icon: Server, desc: 'Control Panels & Nodes' },
            { label: 'Probe Frequency', val: '60-180s', icon: Wifi, desc: 'Automated Multi-Region' },
            { label: 'Active Incidents', val: `${activeIncidents.length}`, icon: ShieldCheck, desc: activeIncidents.length === 0 ? 'Zero active issues' : 'Attention required' }
          ].map((stat, idx) => (
            <div key={idx} className="bg-bg-alt border border-border p-5 rounded-2xl flex flex-col justify-between space-y-3 shadow-sm hover:border-border/80 transition-colors">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase tracking-widest text-foreground-dim">{stat.label}</span>
                <stat.icon size={16} className="text-foreground-dim opacity-40" />
              </div>
              <div>
                <div className="text-2xl font-black text-foreground tracking-tight font-mono">{stat.val}</div>
                <div className="text-[10px] font-mono text-emerald-400 mt-1">{stat.desc}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Active Incidents Banner (if any) */}
        {activeIncidents.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-lg font-extrabold text-foreground uppercase tracking-tight flex items-center gap-2">
              <AlertTriangle className="text-amber-400" size={18} />
              Active System Incidents ({activeIncidents.length})
            </h2>
            <div className="space-y-4">
              {activeIncidents.map(incident => (
                <IncidentCard key={incident.id} incident={incident} />
              ))}
            </div>
          </div>
        )}

        {/* Category Filter & Search Bar */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 border-b border-border/80 pb-6">
          {/* Category / Section Pills */}
          <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto pb-2 md:pb-0 scrollbar-none">
            {sectionsList.map(secName => (
              <button
                key={secName}
                onClick={() => setSelectedCategory(secName)}
                className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider whitespace-nowrap transition-all ${
                  selectedCategory === secName 
                    ? 'bg-foreground text-bg shadow-md' 
                    : 'bg-bg-alt text-foreground-dim hover:text-foreground border border-border'
                }`}
              >
                {secName}
              </button>
            ))}
          </div>

          {/* Search Bar */}
          <div className="relative w-full md:w-72">
            <Search size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-foreground-dim" />
            <input
              type="text"
              placeholder="Search services or endpoints..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-bg-alt border border-border rounded-xl pl-9 pr-4 py-2 text-xs font-mono text-foreground placeholder:text-foreground-dim/50 focus:outline-none focus:border-accent transition-all"
            />
            {searchQuery && (
              <button onClick={() => setSearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-foreground-dim hover:text-foreground">
                <X size={12} />
              </button>
            )}
          </div>
        </div>

        {/* Monitored Services List by Section */}
        <div className="space-y-8">
          <div className="flex items-center justify-between">
            <h2 className="text-lg sm:text-xl font-extrabold text-foreground uppercase tracking-tight flex items-center gap-2">
              <Layers size={20} className="text-accent" />
              Better Stack Monitored Infrastructure
            </h2>
            <span className="text-xs font-mono text-foreground-dim">
              {effectiveSections.reduce((acc, sec) => {
                const matchesCategory = selectedCategory === 'All' || sec.name === selectedCategory;
                if (!matchesCategory) return acc;
                const matching = sec.resources.filter(r => {
                  return searchQuery.trim() === '' || 
                    r.public_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                    (r.section_name && r.section_name.toLowerCase().includes(searchQuery.toLowerCase()));
                });
                return acc + matching.length;
              }, 0)} Services Monitored
            </span>
          </div>

          {isLoading && !betterStackData ? (
            <div className="p-16 bg-bg-alt border border-border rounded-3xl text-center space-y-4">
              <RefreshCw size={32} className="mx-auto text-accent animate-spin" />
              <p className="text-xs font-mono text-foreground-dim uppercase tracking-wider">
                Connecting to Better Stack Uptime API...
              </p>
            </div>
          ) : effectiveSections.filter(sec => {
            const matchesCategory = selectedCategory === 'All' || sec.name === selectedCategory;
            if (!matchesCategory) return false;
            const matchingResources = sec.resources.filter(r => {
              return searchQuery.trim() === '' || 
                r.public_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                (r.section_name && r.section_name.toLowerCase().includes(searchQuery.toLowerCase()));
            });
            return matchingResources.length > 0 || searchQuery.trim() === '';
          }).length === 0 ? (
            <div className="p-16 bg-bg-alt border border-border rounded-3xl text-center space-y-4">
              <Server size={44} className="mx-auto text-foreground-dim opacity-20" />
              <p className="text-foreground-muted font-medium">No services match your search filter.</p>
              <button 
                onClick={() => { setSelectedCategory('All'); setSearchQuery(''); }}
                className="text-xs text-accent font-bold uppercase tracking-wider hover:underline"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              {effectiveSections
                .filter(sec => {
                  const matchesCategory = selectedCategory === 'All' || sec.name === selectedCategory;
                  if (!matchesCategory) return false;
                  const matchingResources = sec.resources.filter(r => {
                    return searchQuery.trim() === '' || 
                      r.public_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                      (r.section_name && r.section_name.toLowerCase().includes(searchQuery.toLowerCase()));
                  });
                  return matchingResources.length > 0 || searchQuery.trim() === '';
                })
                .map((section) => {
                  const matchingResources = section.resources.filter(r => {
                    return searchQuery.trim() === '' || 
                      r.public_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                      (r.section_name && r.section_name.toLowerCase().includes(searchQuery.toLowerCase()));
                  });

                  if (matchingResources.length === 0 && searchQuery.trim() !== '') return null;

                  const getSectionStatus = (resourcesList: BetterStackResource[]) => {
                    if (resourcesList.some(r => r.status === 'downtime')) return 'outage';
                    if (resourcesList.some(r => r.status === 'degraded')) return 'degraded';
                    if (resourcesList.some(r => r.status === 'maintenance')) return 'maintenance';
                    return 'operational';
                  };

                  const secStatus = getSectionStatus(matchingResources);
                  const isExpanded = !!expandedSections[section.id];

                  return (
                    <div 
                      key={section.id} 
                      className="bg-bg-alt/50 border border-border rounded-3xl overflow-hidden shadow-sm hover:border-border/80 transition-all"
                    >
                      {/* Section Accordion Header */}
                      <div 
                        onClick={() => toggleSection(section.id)}
                        className="p-6 sm:p-7 flex items-center justify-between gap-4 cursor-pointer select-none hover:bg-bg-alt/80 transition-colors"
                      >
                        <h3 className="text-base sm:text-lg font-extrabold text-foreground tracking-tight uppercase">
                          {section.name}
                        </h3>

                        <div className="flex items-center gap-4 shrink-0">
                          {/* Section Status Badge */}
                          <div className={`px-3 py-1.5 rounded-xl border text-[10px] sm:text-xs font-black uppercase tracking-widest flex items-center gap-1.5 ${
                            secStatus === 'operational' ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' :
                            secStatus === 'degraded' ? 'bg-amber-500/10 border-amber-500/20 text-amber-400' :
                            secStatus === 'outage' ? 'bg-rose-500/10 border-rose-500/20 text-rose-400' :
                            'bg-blue-500/10 border-blue-500/20 text-blue-400'
                          }`}>
                            <span className={`w-1.5 h-1.5 rounded-full ${
                              secStatus === 'operational' ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.5)]' :
                              secStatus === 'degraded' ? 'bg-amber-400' :
                              secStatus === 'outage' ? 'bg-rose-400 animate-pulse' : 'bg-blue-400'
                            }`} />
                            <span>{secStatus === 'operational' ? 'Operational' : secStatus === 'outage' ? 'Outage' : secStatus}</span>
                          </div>

                          <ChevronRight 
                            size={18} 
                            className={`text-foreground-dim transition-transform duration-300 ${
                              isExpanded ? 'rotate-90 text-foreground' : ''
                            }`} 
                          />
                        </div>
                      </div>

                      {/* Accordion Content Block */}
                      <AnimatePresence initial={false}>
                        {isExpanded && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.25, ease: 'easeInOut' }}
                          >
                            <div className="px-6 pb-7 sm:px-7 sm:pb-8 border-t border-border/30 pt-6 space-y-6 divide-y divide-border/20">
                              {matchingResources.map((res, index) => {
                                const serviceStatus = mapResourceToServiceStatus(res);
                                return (
                                  <div key={res.id} className={index > 0 ? "pt-6" : ""}>
                                    <UptimeBar 
                                      service={serviceStatus} 
                                      days={90}
                                      sessionUptime={serviceStatus.uptime}
                                      variant="minimal"
                                    />
                                  </div>
                                );
                              })}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  );
                })}
            </div>
          )}
        </div>

        {/* Incident History Section from Better Stack */}
        {pastIncidents.length > 0 && (
          <div className="pt-8 border-t border-border/60 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-black text-foreground uppercase tracking-tight flex items-center gap-2">
                  <Clock className="text-accent" size={18} />
                  Better Stack Incident History ({pastIncidents.length})
                </h3>
                <p className="text-xs text-foreground-dim mt-0.5">
                  Full historical archive of resolved incidents, timeout records, and recovery metrics.
                </p>
              </div>
              <button
                onClick={() => setShowIncidentHistory(!showIncidentHistory)}
                className="text-xs font-mono text-accent hover:underline uppercase font-bold"
              >
                {showIncidentHistory ? 'Hide History' : 'Show History'}
              </button>
            </div>

            <AnimatePresence>
              {showIncidentHistory && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="space-y-4"
                >
                  {pastIncidents.slice(0, 5).map(incident => (
                    <IncidentCard key={incident.id} incident={incident} />
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}

        {/* Verified Better Stack Notice & SLA Guarantee */}
        <div className="bg-bg-alt/50 border border-border/80 rounded-3xl p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center sm:text-left">
            <h4 className="text-sm font-bold text-foreground uppercase tracking-wide flex items-center justify-center sm:justify-start gap-2">
              <ShieldCheck size={18} className="text-emerald-400" />
              99.99% Network Availability Guarantee
            </h4>
            <p className="text-xs text-foreground-dim max-w-xl font-light">
              Independent uptime tracking provided by Better Stack. Real-time probes are dispatched globally to ensure zero unrecorded anomalies on Hector Cloud hardware.
            </p>
          </div>
          <a 
            href="https://status.hector.host" 
            target="_blank" 
            rel="noreferrer"
            className="shrink-0 px-5 py-3 rounded-2xl bg-bg border border-border text-foreground hover:text-accent text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-colors"
          >
            <span>Official Status Portal</span>
            <ExternalLink size={14} />
          </a>
        </div>

      </div>
    </div>
  );
};
