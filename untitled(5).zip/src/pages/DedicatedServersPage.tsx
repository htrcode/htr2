import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Server, 
  Cpu, 
  ShieldCheck, 
  Zap, 
  Globe, 
  HardDrive, 
  Terminal, 
  ArrowRight, 
  Star, 
  Lock, 
  Activity,
  Layers,
  Settings,
  CheckCircle2
} from 'lucide-react';
import { AppData, Plan } from '../types';
import { getDynamicLocations } from '../utils/locationUtils';

interface DedicatedServersPageProps {
  data?: AppData;
  activeCurrency?: 'USD' | 'INR' | 'EUR';
  setActiveCurrency?: (c: 'USD' | 'INR' | 'EUR') => void;
  handleOrder: (plan: Plan) => void;
}

interface DedicatedPlanSpec {
  id: string;
  name: string;
  badge: string;
  cpu: string;
  cores: string;
  ram: string;
  storage: string;
  bandwidth: string;
  ip: string;
  priceInr: number;
  popular?: boolean;
  desc: string;
}

export const DedicatedServersPage: React.FC<DedicatedServersPageProps> = ({
  data,
  handleOrder,
}) => {
  const availableLocations = getDynamicLocations(data?.locations);
  const [selectedLocation, setSelectedLocation] = useState(
    availableLocations[0]?.name || 'India (Mumbai)'
  );

  useEffect(() => {
    if (availableLocations.length > 0 && !availableLocations.some(l => l.name === selectedLocation)) {
      setSelectedLocation(availableLocations[0].name);
    }
  }, [availableLocations, selectedLocation]);

  // Filter real database-synced plans for Dedicated / Bare Metal
  const dedicatedPlans = (data?.plans || []).filter(p => {
    if (p.is_active === false || p.archived) return false;
    const pCat = (p.category || '').toLowerCase();
    const pName = (p.name || '').toLowerCase();
    return (
      pCat.includes('dedicated') || 
      pCat.includes('bare metal') || 
      pCat.includes('bare-metal') ||
      pCat.includes('ded-servers') ||
      pCat.includes('dedi') ||
      pName.includes('dedicated') ||
      pName.includes('bare metal')
    );
  }).sort((a, b) => (a.order || 0) - (b.order || 0));

  const formatPrice = (plan: Plan) => {
    if (plan.price_inr) return `₹${plan.price_inr}`;
    if (plan.price) return `$${plan.price}`;
    return 'Contact Us';
  };

  const handlePlanOrder = (plan: Plan) => {
    handleOrder({
      ...plan,
      location: selectedLocation
    });
  };

  return (
    <div className="min-h-screen bg-bg text-foreground pt-32 pb-24 px-4 sm:px-6 relative overflow-hidden font-sans">
      
      {/* Subtle Depth */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[600px] bg-[radial-gradient(circle_at_center,rgba(139,92,246,0.02)_0%,transparent_70%)] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">

        {/* Hero Header */}
        <div className="text-center max-w-4xl mx-auto mb-24">
          <span className="text-[10px] uppercase font-black text-accent tracking-[0.2em] block mb-4">
            Infrastructure / Bare Metal
          </span>

          <motion.h1 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl sm:text-7xl font-extrabold uppercase tracking-tight text-foreground leading-[1.1] mb-6"
          >
            Dedicated <span className="text-foreground-muted">Compute.</span>
          </motion.h1>

          <p className="text-foreground-muted text-base sm:text-lg font-normal max-w-2xl mx-auto leading-relaxed mb-10 text-balance">
            Zero-virtualization enterprise hardware. Provisioned with deterministic AMD RYZEN™ 9 5950X and EPYC™ architectures for mission-critical workloads.
          </p>

          {/* Location Controls */}
          <div className="inline-flex flex-wrap items-center justify-center bg-border border border-border p-px rounded-lg overflow-hidden shadow-sm">
            {/* Location Selector */}
            <div className="flex flex-wrap items-center bg-bg">
              {availableLocations.map(loc => (
                <button
                  key={loc.id}
                  onClick={() => setSelectedLocation(loc.name)}
                  className={`px-5 py-3 text-[10px] font-black uppercase tracking-widest flex items-center gap-2 transition-all border-r last:border-r-0 border-border ${
                    selectedLocation === loc.name 
                      ? 'bg-bg-alt text-accent' 
                      : 'text-foreground-dim hover:text-foreground'
                  }`}
                >
                  <span>{loc.flag}</span>
                  <span>{loc.name}</span>
                  <span className="text-[9px] opacity-70 font-mono">({loc.latency})</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Dedicated Servers Cards Grid */}
        {dedicatedPlans.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-32">
            {dedicatedPlans.map((plan, idx) => (
              <motion.div
                key={plan.id}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: idx * 0.05 }}
                className="bg-bg-alt/70 border border-border/80 hover:border-accent/40 rounded-2xl p-8 flex flex-col justify-between transition-all duration-300 relative group backdrop-blur-xl hover:shadow-xl"
              >
                <div>
                  <span className="text-[10px] font-black tracking-[0.2em] text-accent uppercase block mb-3">
                    {plan.badge || 'BARE METAL'}
                  </span>
                  <h3 className="text-2xl font-black text-foreground uppercase tracking-tight font-display mb-2">
                    {plan.name}
                  </h3>
                  <p className="text-xs text-foreground-muted mb-6 leading-relaxed line-clamp-2 min-h-[36px]">
                    {plan.desc || 'High-performance bare metal server hardware synced directly from database.'}
                  </p>

                  {/* Price Display */}
                  <div className="bg-bg/80 border border-border/60 rounded-xl p-5 mb-8 text-center">
                    <div className="text-[9px] uppercase font-bold text-foreground-dim tracking-wider mb-1">Monthly Billing</div>
                    <div className="text-3xl font-black text-foreground tracking-tighter font-display">
                      {formatPrice(plan)}
                      <span className="text-xs font-normal text-foreground-dim ml-1">/mo</span>
                    </div>
                  </div>

                  {/* Features List */}
                  <div className="space-y-3 mb-10 border-t border-border/60 pt-6">
                    {plan.features?.map((feat, i) => (
                      <div key={i} className="flex items-start gap-3 text-xs text-foreground-muted">
                        <CheckCircle2 size={16} className="text-accent shrink-0 mt-0.5" />
                        <span className="leading-tight font-normal">{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => handlePlanOrder(plan)}
                  className="w-full py-4 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-2 bg-accent hover:bg-accent-muted text-white shadow-md active:scale-95 cursor-pointer"
                >
                  <span>Deploy Bare Metal Node</span>
                  <ArrowRight size={14} />
                </button>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="p-12 text-center bg-bg-alt/60 border border-border rounded-2xl mb-32 max-w-2xl mx-auto space-y-6 backdrop-blur-xl">
            <div className="w-16 h-16 rounded-2xl bg-accent/10 border border-accent/20 flex items-center justify-center text-accent mx-auto">
              <Server size={32} />
            </div>
            <div>
              <h3 className="text-2xl font-black text-foreground uppercase tracking-tight mb-2 font-display">
                No Dedicated Server Plans Active
              </h3>
              <p className="text-foreground-muted text-xs leading-relaxed">
                All dedicated bare-metal nodes are currently assigned or synced directly from the live database. Create dedicated server plans in the Admin Control Panel or request a custom node quote via Web Ticket support.
              </p>
            </div>
          </div>
        )}

        {/* Feature Grid */}
        <div className="mb-32">
          <div className="text-center mb-16">
            <span className="text-[10px] uppercase font-black text-accent tracking-[0.2em] block mb-4">
              Enterprise Integration
            </span>
            <h2 className="text-3xl sm:text-5xl font-extrabold text-foreground uppercase tracking-tight">
              Hardware <span className="text-foreground-muted">Governance.</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-px bg-border border border-border rounded-lg overflow-hidden">
            {[
              { icon: Server, title: 'Out-of-Band Access', desc: 'Full IPMI / iDRAC management consoles for deterministic control at the kernel level, independent of OS state.' },
              { icon: Globe, title: 'Network Topology', desc: 'Each node provisioned with dedicated IPv4 addressing and /64 IPv6 subnets with full BGP routing and reverse DNS.' },
              { icon: ShieldCheck, title: 'Inline Mitigation', desc: 'Hardware-level DDoS scrubbing with automated Layer 7 inspection for sub-2ms filtration of volumetric attacks.' }
            ].map((feat, i) => (
              <div key={i} className="p-10 bg-bg space-y-6">
                <div className="w-12 h-12 rounded bg-bg-alt border border-border flex items-center justify-center text-accent">
                  <feat.icon size={24} />
                </div>
                <div className="space-y-2">
                  <h3 className="text-lg font-black text-foreground uppercase tracking-tight">{feat.title}</h3>
                  <p className="text-sm text-foreground-muted leading-relaxed">
                    {feat.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
