import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  PhoneCall, 
  Mail, 
  MessageSquare, 
  Clock, 
  Send, 
  CheckCircle2, 
  ArrowRight,
  ShieldAlert,
  Ticket as TicketIcon,
  Search,
  Copy,
  Check,
  ExternalLink,
  ShieldCheck,
  AlertCircle,
  User as UserIcon,
  Server,
  LifeBuoy
} from 'lucide-react';
import { AppData, Ticket, TicketDepartment, TicketPriority, UserService } from '../types';
import { ticketService } from '../services/ticketService';
import { userService } from '../services/userService';
import { User as FirebaseUser } from 'firebase/auth';
import { Link, useNavigate } from 'react-router-dom';

interface ContactPageProps {
  data: AppData;
  user?: FirebaseUser | null;
}

interface LocalGuestTicket {
  ticketNumber: string;
  email: string;
  subject: string;
  department: string;
  createdAt: string;
}

export const ContactPage: React.FC<ContactPageProps> = ({ data, user }) => {
  const navigate = useNavigate();

  // Active Tab: 'create' | 'track' | 'mytickets'
  const [activeTab, setActiveTab] = useState<'create' | 'track' | 'mytickets'>('create');

  // Form State
  const [form, setForm] = useState({
    name: user?.displayName || '',
    email: user?.email || '',
    department: 'Technical Support' as TicketDepartment,
    priority: 'medium' as TicketPriority,
    subject: '',
    message: '',
    serviceId: '',
    serviceName: ''
  });

  // User Services State (for logged-in users attaching a service)
  const [userServices, setUserServices] = useState<UserService[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedTicket, setSubmittedTicket] = useState<{ id: string; ticketNumber: string } | null>(null);
  const [copied, setCopied] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Track Ticket State
  const [trackNumber, setTrackNumber] = useState('');
  const [trackEmail, setTrackEmail] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [foundTicket, setFoundTicket] = useState<Ticket | null>(null);
  const [searchAttempted, setSearchAttempted] = useState(false);

  // User tickets list (if logged in)
  const [myTickets, setMyTickets] = useState<Ticket[]>([]);
  const [loadingMyTickets, setLoadingMyTickets] = useState(false);

  // Local Storage guest tickets
  const [guestHistory, setGuestHistory] = useState<LocalGuestTicket[]>([]);

  // Update name/email if user changes
  useEffect(() => {
    if (user) {
      setForm(prev => ({
        ...prev,
        name: prev.name || user.displayName || user.email?.split('@')[0] || '',
        email: user.email || prev.email
      }));

      // Fetch user services for attachment
      userService.getUserServices(user.uid).then(svcs => {
        setUserServices(svcs.filter(s => s.status === 'active' || s.status === 'pending'));
      }).catch(err => console.error('Error fetching services for ticket:', err));

      // Fetch user tickets
      setLoadingMyTickets(true);
      ticketService.getUserTickets(user.uid).then(tkts => {
        setMyTickets(tkts);
        setLoadingMyTickets(false);
      }).catch(err => {
        console.error('Error loading tickets:', err);
        setLoadingMyTickets(false);
      });
    }
  }, [user]);

  // Load guest history from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('hector_guest_tickets');
      if (saved) {
        setGuestHistory(JSON.parse(saved));
      }
    } catch (e) {
      // Ignore storage error
    }
  }, []);

  const supportChannels = [
    {
      title: 'WhatsApp Helpline',
      info: data.settings.whatsapp_number ? `+${data.settings.whatsapp_number}` : '+91 98765 43210',
      desc: 'Instant pre-sales, order queries, and server set up.',
      actionLabel: 'Message on WhatsApp',
      actionUrl: `https://wa.me/${data.settings.whatsapp_number?.replace(/\D/g, '')}`,
      color: 'text-emerald-400',
      icon: PhoneCall
    },
    {
      title: 'Live Web Ticket Desk',
      info: '24/7 SLA NOC Dispatch',
      desc: 'Official web ticket creation with real-time engineer dispatch.',
      actionLabel: 'Submit Web Ticket',
      actionUrl: '#web-ticket-desk',
      isAnchor: true,
      color: 'text-accent',
      icon: TicketIcon
    },
    {
      title: 'Email Ticket Desk',
      info: data.settings.support_email || 'support@hectorhosting.com',
      desc: 'Technical issues, business proposals, and custom quotes.',
      actionLabel: 'Email Support Team',
      actionUrl: `mailto:${data.settings.support_email || 'support@hectorhosting.com'}`,
      color: 'text-purple-400',
      icon: Mail
    },
    {
      title: 'Discord Community',
      info: '@hectorhosting',
      desc: 'Real-time peer discussions, guides, and status pings.',
      actionLabel: 'Join Discord Server',
      actionUrl: data.settings.discord_url || 'https://discord.gg',
      color: 'text-blue-400',
      icon: MessageSquare
    }
  ];

  // Submit Web Ticket Handler
  const handleSubmitTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.subject || !form.message) {
      setErrorMsg('Please fill in all required fields.');
      return;
    }

    setIsSubmitting(true);
    setErrorMsg('');

    try {
      const ticketUserId = user ? user.uid : `guest_${Date.now()}`;
      
      const ticketId = await ticketService.createTicket({
        userId: ticketUserId,
        userEmail: form.email.trim(),
        userName: form.name.trim(),
        subject: form.subject.trim(),
        department: form.department,
        priority: form.priority,
        initialMessage: form.message.trim(),
        serviceId: form.serviceId || undefined,
        serviceName: form.serviceName || undefined
      });

      // Fetch the created ticket to get ticketNumber
      const createdTkt = await ticketService.getTicket(ticketId);
      const ticketNumber = createdTkt?.ticketNumber || `TICK-${Math.floor(1000 + Math.random() * 9000)}`;

      setSubmittedTicket({ id: ticketId, ticketNumber });

      // Save to guest history if not logged in
      if (!user) {
        const newGuestEntry: LocalGuestTicket = {
          ticketNumber,
          email: form.email.trim(),
          subject: form.subject.trim(),
          department: form.department,
          createdAt: new Date().toISOString()
        };
        const updatedHistory = [newGuestEntry, ...guestHistory.slice(0, 4)];
        setGuestHistory(updatedHistory);
        localStorage.setItem('hector_guest_tickets', JSON.stringify(updatedHistory));
      } else {
        // Refresh my tickets
        const updated = await ticketService.getUserTickets(user.uid);
        setMyTickets(updated);
      }

      // Reset form
      setForm(prev => ({
        ...prev,
        subject: '',
        message: '',
        serviceId: '',
        serviceName: ''
      }));

    } catch (err: any) {
      console.error('Error creating support ticket:', err);
      setErrorMsg(err.message || 'Failed to dispatch ticket. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Lookup Ticket Handler
  const handleTrackTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!trackNumber || !trackEmail) return;

    setIsSearching(true);
    setSearchAttempted(true);
    setFoundTicket(null);

    try {
      const result = await ticketService.findTicketByNumberAndEmail(trackNumber, trackEmail);
      setFoundTicket(result);
    } catch (err) {
      console.error('Error tracking ticket:', err);
    } finally {
      setIsSearching(false);
    }
  };

  const copyTicketNumber = (num: string) => {
    navigator.clipboard.writeText(num);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'open':
        return <span className="px-2.5 py-1 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 text-[9px] font-black uppercase tracking-widest">Open</span>;
      case 'in_progress':
        return <span className="px-2.5 py-1 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20 text-[9px] font-black uppercase tracking-widest">In Progress</span>;
      case 'waiting_user':
        return <span className="px-2.5 py-1 rounded bg-purple-500/10 text-purple-400 border border-purple-500/20 text-[9px] font-black uppercase tracking-widest">Awaiting User</span>;
      case 'resolved':
      case 'closed':
        return <span className="px-2.5 py-1 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[9px] font-black uppercase tracking-widest">Closed</span>;
      default:
        return <span className="px-2.5 py-1 rounded bg-slate-500/10 text-slate-400 border border-slate-500/20 text-[9px] font-black uppercase tracking-widest">{status}</span>;
    }
  };

  return (
    <div className="min-h-screen bg-bg text-foreground pt-32 pb-24 px-4 sm:px-6 relative overflow-hidden font-sans">
      
      {/* Subtle Depth Background */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[600px] bg-[radial-gradient(circle_at_center,rgba(139,92,246,0.02)_0%,transparent_70%)] pointer-events-none" />

      <div className="max-w-6xl mx-auto relative z-10">
        
        {/* Header Title Section */}
        <div className="text-center mb-20">
          <span className="text-[10px] uppercase font-black text-accent tracking-[0.2em] block mb-4">
            Technical Assistance Center
          </span>
          <h1 className="text-4xl sm:text-7xl font-extrabold text-foreground uppercase tracking-tight leading-none mb-6">
            Contact <span className="text-foreground-muted">Operations.</span>
          </h1>
          <p className="text-foreground-muted text-base sm:text-lg max-w-2xl mx-auto font-normal leading-relaxed text-balance">
            Technical consultations, server setups, and 24/7 web ticket support dispatched directly to on-duty NOC engineers.
          </p>
        </div>

        {/* Support Channels Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-px bg-border border border-border rounded-lg overflow-hidden mb-24">
          {supportChannels.map((channel, idx) => {
            const Icon = channel.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: idx * 0.05 }}
                className="bg-bg p-8 flex flex-col justify-between group"
              >
                <div className="mb-8">
                  <div className="w-12 h-12 bg-bg-alt border border-border rounded-md flex items-center justify-center text-accent mb-6">
                    <Icon size={24} />
                  </div>
                  <h3 className="text-lg font-black text-foreground uppercase tracking-tight mb-2">
                    {channel.title}
                  </h3>
                  <div className="text-[10px] font-black text-accent uppercase tracking-widest mb-3">{channel.info}</div>
                  <p className="text-xs text-foreground-muted leading-relaxed font-normal">
                    {channel.desc}
                  </p>
                </div>

                {channel.isAnchor ? (
                  <a
                    href={channel.actionUrl}
                    onClick={() => setActiveTab('create')}
                    className="inline-flex items-center gap-2 text-[10px] font-black text-foreground hover:text-accent transition-colors uppercase tracking-[0.2em] group/btn"
                  >
                    <span>{channel.actionLabel}</span>
                    <ArrowRight size={14} className="group-hover/btn:translate-x-1 transition-transform" />
                  </a>
                ) : (
                  <a
                    href={channel.actionUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-[10px] font-black text-foreground hover:text-accent transition-colors uppercase tracking-[0.2em] group/btn"
                  >
                    <span>{channel.actionLabel}</span>
                    <ArrowRight size={14} className="group-hover/btn:translate-x-1 transition-transform" />
                  </a>
                )}
              </motion.div>
            );
          })}
        </div>

        {/* WEB TICKET DESK SECTION */}
        <div id="web-ticket-desk" className="scroll-mt-32">
          
          {/* Section Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
            <div>
              <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.2em] text-accent mb-1">
                <TicketIcon size={14} />
                <span>Web Ticket Support System</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-foreground uppercase tracking-tight">
                Network Operations <span className="text-foreground-muted">Dispatch Desk</span>
              </h2>
            </div>

            {/* Navigation Tabs */}
            <div className="inline-flex bg-bg-alt border border-border p-1 rounded-lg">
              <button
                onClick={() => setActiveTab('create')}
                className={`px-4 py-2 text-[10px] font-black uppercase tracking-widest rounded-md transition-all ${
                  activeTab === 'create'
                    ? 'bg-accent text-white shadow-sm'
                    : 'text-foreground-muted hover:text-foreground'
                }`}
              >
                Submit Ticket
              </button>

              <button
                onClick={() => setActiveTab('track')}
                className={`px-4 py-2 text-[10px] font-black uppercase tracking-widest rounded-md transition-all ${
                  activeTab === 'track'
                    ? 'bg-accent text-white shadow-sm'
                    : 'text-foreground-muted hover:text-foreground'
                }`}
              >
                Track Status
              </button>

              {user && (
                <button
                  onClick={() => setActiveTab('mytickets')}
                  className={`px-4 py-2 text-[10px] font-black uppercase tracking-widest rounded-md transition-all relative ${
                    activeTab === 'mytickets'
                      ? 'bg-accent text-white shadow-sm'
                      : 'text-foreground-muted hover:text-foreground'
                  }`}
                >
                  My Tickets ({myTickets.length})
                </button>
              )}
            </div>
          </div>

          {/* Main Content Area */}
          <div className="grid lg:grid-cols-12 gap-12">
            
            {/* Left Main Interactive Desk - Col 8 */}
            <div className="lg:col-span-8 bg-bg-alt border border-border rounded-xl p-8 sm:p-12 relative shadow-sm">
              
              {/* TAB 1: SUBMIT NEW TICKET */}
              {activeTab === 'create' && (
                <div>
                  <div className="mb-8 pb-6 border-b border-border flex items-center justify-between">
                    <div>
                      <h3 className="text-xl font-black text-foreground uppercase tracking-tight mb-1">
                        Dispatch Web Ticket
                      </h3>
                      <p className="text-xs text-foreground-muted">
                        Submitting directly to Network Operations. Average SLA response latency is sub-15 mins.
                      </p>
                    </div>

                    {user ? (
                      <span className="px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded text-[9px] font-black uppercase tracking-widest shrink-0 flex items-center gap-1.5">
                        <UserIcon size={12} />
                        Verified Client
                      </span>
                    ) : (
                      <span className="px-3 py-1 bg-bg border border-border text-foreground-dim rounded text-[9px] font-bold uppercase tracking-widest shrink-0">
                        Guest Dispatch
                      </span>
                    )}
                  </div>

                  {submittedTicket ? (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.98 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="p-10 bg-bg border border-emerald-500/30 rounded-xl text-center flex flex-col items-center justify-center space-y-6"
                    >
                      <div className="w-16 h-16 bg-emerald-500/10 border border-emerald-500/30 rounded-full text-emerald-400 flex items-center justify-center shadow-lg">
                        <CheckCircle2 size={36} />
                      </div>
                      
                      <div className="space-y-2">
                        <h4 className="text-2xl font-black text-foreground uppercase tracking-tight">
                          Ticket Dispatched Successfully
                        </h4>
                        <p className="text-sm text-foreground-muted max-w-md mx-auto leading-relaxed">
                          Your web support ticket has been indexed in our dispatch queue. An engineer will respond shortly.
                        </p>
                      </div>

                      {/* Ticket Number Pill */}
                      <div className="bg-bg-alt border border-border p-4 rounded-lg flex items-center gap-4">
                        <div className="text-left">
                          <div className="text-[9px] uppercase font-black tracking-widest text-foreground-dim">Ticket Reference #</div>
                          <div className="text-xl font-black text-foreground tracking-wider font-mono">{submittedTicket.ticketNumber}</div>
                        </div>
                        <button
                          onClick={() => copyTicketNumber(submittedTicket.ticketNumber)}
                          className="px-3 py-2 bg-bg border border-border hover:border-accent text-foreground text-xs font-bold rounded flex items-center gap-1.5 transition-colors"
                        >
                          {copied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                          <span>{copied ? 'Copied' : 'Copy'}</span>
                        </button>
                      </div>

                      <div className="pt-4 flex flex-wrap gap-4 justify-center">
                        {user ? (
                          <Link
                            to="/dashboard"
                            className="px-6 py-3 bg-accent text-white text-[10px] font-black uppercase tracking-widest rounded-md hover:bg-accent-muted transition-all flex items-center gap-2"
                          >
                            <span>Open in Client Dashboard</span>
                            <ExternalLink size={14} />
                          </Link>
                        ) : (
                          <button
                            onClick={() => {
                              setTrackNumber(submittedTicket.ticketNumber);
                              setActiveTab('track');
                            }}
                            className="px-6 py-3 bg-accent text-white text-[10px] font-black uppercase tracking-widest rounded-md hover:bg-accent-muted transition-all flex items-center gap-2"
                          >
                            <span>Track Ticket Status</span>
                            <Search size={14} />
                          </button>
                        )}

                        <button
                          onClick={() => setSubmittedTicket(null)}
                          className="px-6 py-3 bg-bg border border-border text-foreground hover:border-accent text-[10px] font-black uppercase tracking-widest rounded-md transition-all"
                        >
                          Submit Another Ticket
                        </button>
                      </div>
                    </motion.div>
                  ) : (
                    <form onSubmit={handleSubmitTicket} className="space-y-6">
                      
                      {errorMsg && (
                        <div className="p-4 bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs font-bold rounded-md flex items-center gap-3">
                          <AlertCircle size={16} className="shrink-0" />
                          <span>{errorMsg}</span>
                        </div>
                      )}

                      {/* Name and Email */}
                      <div className="grid sm:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <label className="text-[10px] font-black uppercase text-foreground-dim tracking-[0.2em]">Principal Name</label>
                          <input
                            type="text"
                            required
                            placeholder="e.g. Rahul Sharma"
                            value={form.name}
                            onChange={(e) => setForm({ ...form, name: e.target.value })}
                            className="w-full px-5 py-3.5 bg-bg border border-border focus:border-accent rounded-md text-sm text-foreground outline-none transition-all placeholder:text-foreground-dim"
                          />
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-black uppercase text-foreground-dim tracking-[0.2em]">Contact Email</label>
                          <input
                            type="email"
                            required
                            placeholder="e.g. rahul@domain.com"
                            value={form.email}
                            onChange={(e) => setForm({ ...form, email: e.target.value })}
                            className="w-full px-5 py-3.5 bg-bg border border-border focus:border-accent rounded-md text-sm text-foreground outline-none transition-all placeholder:text-foreground-dim"
                          />
                        </div>
                      </div>

                      {/* Department and Priority */}
                      <div className="grid sm:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <label className="text-[10px] font-black uppercase text-foreground-dim tracking-[0.2em]">Support Department</label>
                          <select
                            value={form.department}
                            onChange={(e) => setForm({ ...form, department: e.target.value as TicketDepartment })}
                            className="w-full px-5 py-3.5 bg-bg border border-border focus:border-accent rounded-md text-sm text-foreground outline-none transition-all cursor-pointer appearance-none"
                          >
                            <option value="Technical Support">Technical Support (Hardware / OS / Network)</option>
                            <option value="Billing & Payments">Billing & Accounts (Invoices / Refunds)</option>
                            <option value="Server Inquiry">Server Inquiry & Custom Node Quotes</option>
                            <option value="General">General Inquiry</option>
                            <option value="Abuse/Security">Abuse / DMCA / Security Disclosure</option>
                          </select>
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-black uppercase text-foreground-dim tracking-[0.2em]">Ticket Priority</label>
                          <select
                            value={form.priority}
                            onChange={(e) => setForm({ ...form, priority: e.target.value as TicketPriority })}
                            className="w-full px-5 py-3.5 bg-bg border border-border focus:border-accent rounded-md text-sm text-foreground outline-none transition-all cursor-pointer appearance-none"
                          >
                            <option value="low">Low - Setup Advice / General Question</option>
                            <option value="medium">Medium - Operational Inquiry (SLA &lt; 1 hr)</option>
                            <option value="high">High - Service Interruption (SLA &lt; 30 min)</option>
                            <option value="urgent">Urgent - Complete Outage (SLA &lt; 15 min)</option>
                          </select>
                        </div>
                      </div>

                      {/* Attach Service (if logged in and services exist) */}
                      {user && userServices.length > 0 && (
                        <div className="space-y-2">
                          <label className="text-[10px] font-black uppercase text-foreground-dim tracking-[0.2em]">Relating to Service (Optional)</label>
                          <select
                            value={form.serviceId}
                            onChange={(e) => {
                              const selectedId = e.target.value;
                              const svc = userServices.find(s => s.id === selectedId);
                              setForm({
                                ...form,
                                serviceId: selectedId,
                                serviceName: svc ? `${svc.name} (${svc.ip || svc.location})` : ''
                              });
                            }}
                            className="w-full px-5 py-3.5 bg-bg border border-border focus:border-accent rounded-md text-sm text-foreground outline-none transition-all cursor-pointer appearance-none"
                          >
                            <option value="">-- No specific server selected --</option>
                            {userServices.map(svc => (
                              <option key={svc.id} value={svc.id}>
                                {svc.name} ({svc.ip || svc.location}) - Status: {svc.status}
                              </option>
                            ))}
                          </select>
                        </div>
                      )}

                      {/* Subject */}
                      <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-foreground-dim tracking-[0.2em]">Subject Title</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. FiveM server port forwarding inquiry / Node latency check"
                          value={form.subject}
                          onChange={(e) => setForm({ ...form, subject: e.target.value })}
                          className="w-full px-5 py-3.5 bg-bg border border-border focus:border-accent rounded-md text-sm text-foreground outline-none transition-all placeholder:text-foreground-dim"
                        />
                      </div>

                      {/* Message */}
                      <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-foreground-dim tracking-[0.2em]">Detailed Technical Inquiry</label>
                        <textarea
                          required
                          rows={5}
                          placeholder="Provide specific details about your server, IP, error logs, or requirements..."
                          value={form.message}
                          onChange={(e) => setForm({ ...form, message: e.target.value })}
                          className="w-full px-5 py-3.5 bg-bg border border-border focus:border-accent rounded-md text-sm text-foreground outline-none transition-all placeholder:text-foreground-dim resize-none"
                        />
                      </div>

                      <button
                        type="submit"
                        disabled={isSubmitting}
                        className="w-full py-4 bg-accent hover:bg-accent-muted disabled:opacity-50 text-white font-black text-[10px] uppercase tracking-[0.3em] rounded-md transition-all flex items-center justify-center gap-3 shadow-lg shadow-accent/20"
                      >
                        {isSubmitting ? (
                          <>
                            <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                            <span>Indexing Web Ticket...</span>
                          </>
                        ) : (
                          <>
                            <Send size={16} />
                            <span>Transmit Web Ticket Dispatch</span>
                          </>
                        )}
                      </button>
                    </form>
                  )}
                </div>
              )}

              {/* TAB 2: TRACK TICKET STATUS */}
              {activeTab === 'track' && (
                <div>
                  <div className="mb-8 pb-6 border-b border-border">
                    <h3 className="text-xl font-black text-foreground uppercase tracking-tight mb-1">
                      Track Ticket Status
                    </h3>
                    <p className="text-xs text-foreground-muted">
                      Lookup real-time status, department assignment, and engineer response for any web ticket.
                    </p>
                  </div>

                  <form onSubmit={handleTrackTicket} className="space-y-6 mb-8">
                    <div className="grid sm:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-foreground-dim tracking-[0.2em]">Ticket Reference #</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. TICK-4821"
                          value={trackNumber}
                          onChange={(e) => setTrackNumber(e.target.value)}
                          className="w-full px-5 py-3.5 bg-bg border border-border focus:border-accent rounded-md text-sm text-foreground outline-none transition-all placeholder:text-foreground-dim uppercase font-mono"
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-foreground-dim tracking-[0.2em]">Requester Email</label>
                        <input
                          type="email"
                          required
                          placeholder="e.g. user@example.com"
                          value={trackEmail}
                          onChange={(e) => setTrackEmail(e.target.value)}
                          className="w-full px-5 py-3.5 bg-bg border border-border focus:border-accent rounded-md text-sm text-foreground outline-none transition-all placeholder:text-foreground-dim"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={isSearching}
                      className="w-full py-4 bg-foreground hover:bg-foreground/90 disabled:opacity-50 text-bg font-black text-[10px] uppercase tracking-[0.2em] rounded-md transition-all flex items-center justify-center gap-2"
                    >
                      {isSearching ? (
                        <>
                          <div className="w-4 h-4 border-2 border-bg/30 border-t-bg rounded-full animate-spin" />
                          <span>Searching Index...</span>
                        </>
                      ) : (
                        <>
                          <Search size={16} />
                          <span>Fetch Ticket Record</span>
                        </>
                      )}
                    </button>
                  </form>

                  {/* Search Result */}
                  {foundTicket ? (
                    <div className="bg-bg border border-border rounded-xl p-6 space-y-6">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-border pb-4">
                        <div>
                          <div className="text-[9px] font-black text-foreground-dim uppercase tracking-widest font-mono">
                            {foundTicket.ticketNumber}
                          </div>
                          <h4 className="text-lg font-black text-foreground uppercase tracking-tight">
                            {foundTicket.subject}
                          </h4>
                        </div>
                        <div>{getStatusBadge(foundTicket.status)}</div>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
                        <div>
                          <span className="text-foreground-dim block text-[9px] uppercase font-bold">Department</span>
                          <span className="font-bold text-foreground">{foundTicket.department}</span>
                        </div>
                        <div>
                          <span className="text-foreground-dim block text-[9px] uppercase font-bold">Priority</span>
                          <span className="font-bold uppercase text-accent">{foundTicket.priority}</span>
                        </div>
                        <div>
                          <span className="text-foreground-dim block text-[9px] uppercase font-bold">Created</span>
                          <span className="text-foreground-muted">{new Date(foundTicket.createdAt).toLocaleDateString()}</span>
                        </div>
                        <div>
                          <span className="text-foreground-dim block text-[9px] uppercase font-bold">Last Reply</span>
                          <span className="text-foreground-muted uppercase">{foundTicket.lastReplyBy || 'user'}</span>
                        </div>
                      </div>

                      {foundTicket.lastMessage && (
                        <div className="p-4 bg-bg-alt border border-border rounded-md text-xs space-y-1">
                          <span className="text-[9px] font-black uppercase text-foreground-dim block">Latest Message Snippet:</span>
                          <p className="text-foreground-muted italic font-mono">"{foundTicket.lastMessage}"</p>
                        </div>
                      )}

                      {user && (
                        <div className="pt-2">
                          <Link
                            to="/dashboard"
                            className="inline-flex items-center gap-2 px-5 py-2.5 bg-accent text-white text-[10px] font-black uppercase tracking-widest rounded hover:bg-accent-muted transition-all"
                          >
                            <span>Open Ticket Thread in Dashboard</span>
                            <ExternalLink size={14} />
                          </Link>
                        </div>
                      )}
                    </div>
                  ) : searchAttempted && !isSearching ? (
                    <div className="p-8 bg-bg border border-border rounded-xl text-center text-foreground-muted space-y-2">
                      <AlertCircle size={32} className="mx-auto text-accent opacity-60" />
                      <div className="font-bold text-foreground text-sm uppercase">No Ticket Found</div>
                      <p className="text-xs max-w-sm mx-auto">
                        Could not locate ticket matching <span className="font-mono text-accent">{trackNumber}</span> and email <span className="text-foreground">{trackEmail}</span>. Please verify reference details.
                      </p>
                    </div>
                  ) : null}

                  {/* Guest Recent History */}
                  {guestHistory.length > 0 && (
                    <div className="mt-10 pt-8 border-t border-border">
                      <h4 className="text-xs font-black text-foreground uppercase tracking-wider mb-4">
                        Recently Submitted Web Tickets (This Device)
                      </h4>
                      <div className="space-y-2">
                        {guestHistory.map((g, i) => (
                          <div
                            key={i}
                            onClick={() => {
                              setTrackNumber(g.ticketNumber);
                              setTrackEmail(g.email);
                            }}
                            className="p-3 bg-bg border border-border hover:border-accent rounded-lg flex items-center justify-between cursor-pointer transition-colors"
                          >
                            <div className="flex items-center gap-3">
                              <span className="font-mono font-bold text-xs text-accent">{g.ticketNumber}</span>
                              <span className="text-xs font-medium text-foreground truncate max-w-[200px]">{g.subject}</span>
                            </div>
                            <span className="text-[10px] text-foreground-dim uppercase">{g.department}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* TAB 3: MY TICKETS (FOR LOGGED IN USERS) */}
              {activeTab === 'mytickets' && user && (
                <div>
                  <div className="mb-8 pb-6 border-b border-border flex items-center justify-between">
                    <div>
                      <h3 className="text-xl font-black text-foreground uppercase tracking-tight mb-1">
                        My Active Support Tickets
                      </h3>
                      <p className="text-xs text-foreground-muted">
                        Overview of all your client tickets synced live with Firestore database.
                      </p>
                    </div>

                    <Link
                      to="/dashboard"
                      className="px-4 py-2 bg-accent text-white text-[10px] font-black uppercase tracking-widest rounded hover:bg-accent-muted transition-all flex items-center gap-1.5"
                    >
                      <span>Full Dashboard</span>
                      <ExternalLink size={12} />
                    </Link>
                  </div>

                  {loadingMyTickets ? (
                    <div className="py-12 text-center text-xs text-foreground-muted">
                      Loading user ticket history...
                    </div>
                  ) : myTickets.length === 0 ? (
                    <div className="p-8 bg-bg border border-border rounded-xl text-center space-y-4">
                      <LifeBuoy size={32} className="mx-auto text-foreground-dim" />
                      <div className="text-sm font-bold text-foreground uppercase">No Open Tickets</div>
                      <p className="text-xs text-foreground-muted">You have no active support tickets at this time.</p>
                      <button
                        onClick={() => setActiveTab('create')}
                        className="px-5 py-2.5 bg-accent text-white text-[10px] font-black uppercase tracking-widest rounded"
                      >
                        Create Your First Ticket
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {myTickets.map(tkt => (
                        <div
                          key={tkt.id}
                          className="p-5 bg-bg border border-border hover:border-accent rounded-xl transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                        >
                          <div>
                            <div className="flex items-center gap-3 mb-1">
                              <span className="font-mono font-black text-xs text-accent">{tkt.ticketNumber}</span>
                              {getStatusBadge(tkt.status)}
                              <span className="text-[9px] uppercase font-bold text-foreground-dim">{tkt.department}</span>
                            </div>
                            <h4 className="text-sm font-bold text-foreground uppercase tracking-tight">
                              {tkt.subject}
                            </h4>
                            <div className="text-[10px] text-foreground-muted mt-1">
                              Last updated: {new Date(tkt.updatedAt).toLocaleString()}
                            </div>
                          </div>

                          <Link
                            to="/dashboard"
                            className="px-4 py-2 bg-bg-alt border border-border hover:border-accent text-foreground text-[10px] font-black uppercase tracking-widest rounded text-center shrink-0 flex items-center justify-center gap-1.5"
                          >
                            <span>Open Thread</span>
                            <ArrowRight size={12} />
                          </Link>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

            </div>

            {/* Right Side Info & Metrics - Col 4 */}
            <div className="lg:col-span-4 space-y-8">
              
              {/* Quick Response Stats Card */}
              <div className="bg-bg-alt border border-border rounded-xl p-8 space-y-8 shadow-sm">
                <div className="flex items-center gap-3 text-accent mb-2">
                  <Clock size={20} />
                  <h4 className="text-[11px] font-black uppercase tracking-[0.2em] text-foreground">
                    Dispatch Metrics
                  </h4>
                </div>

                <div className="space-y-px bg-border border border-border rounded overflow-hidden">
                  {[
                    { label: 'Avg Ticket Latency', value: '11 Minutes', detail: 'SLA Guaranteed < 1 hr' },
                    { label: 'Network Operations', value: '24/7/365 Active', detail: 'Real-time NOC auditing' },
                    { label: 'Technical Tier', value: 'L3 Certified', detail: 'Direct access to senior engineers' },
                  ].map((m, idx) => (
                    <div key={idx} className="p-5 bg-bg">
                      <div className="text-[10px] text-foreground-dim uppercase font-black tracking-widest mb-1">{m.label}</div>
                      <div className="text-base font-black text-foreground uppercase tracking-tight">{m.value}</div>
                      <div className="text-[10px] text-foreground-muted uppercase tracking-wider mt-1">{m.detail}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Compliance Warning block */}
              <div className="p-6 bg-bg-alt border border-border rounded-xl flex gap-4 shadow-sm">
                <ShieldAlert className="text-accent shrink-0 mt-0.5" size={20} />
                <div className="space-y-2">
                  <h4 className="text-sm font-black text-foreground uppercase tracking-tight">
                    Compliance & Abuse
                  </h4>
                  <p className="text-xs text-foreground-muted leading-relaxed font-normal">
                    For legal notices, DMCA takedowns, or security vulnerabilities, direct dispatches to <span className="font-bold text-foreground">compliance@hectorhosting.com</span>.
                  </p>
                </div>
              </div>

            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
