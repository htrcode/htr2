import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  Trash2, 
  ArrowRight, 
  ArrowLeft, 
  ShieldCheck, 
  Zap, 
  Clock, 
  Tag, 
  Check, 
  X, 
  Server, 
  Cpu, 
  Globe,
  ShoppingCart
} from 'lucide-react';
import { User as FirebaseUser } from 'firebase/auth';
import { CartItem, AppData } from '../types';
import { cartService } from '../services/cartService';

interface CartPageProps {
  user: FirebaseUser | null;
  data: AppData;
  activeCurrency?: 'INR' | 'USD';
}

interface PromoCode {
  code: string;
  type: 'percent' | 'flat';
  value: number;
  minAmount?: number;
  description: string;
}

const AVAILABLE_PROMOS: Record<string, PromoCode> = {
  HECTOR10: {
    code: 'HECTOR10',
    type: 'percent',
    value: 10,
    description: '10% discount on total cart'
  },
  WELCOME20: {
    code: 'WELCOME20',
    type: 'percent',
    value: 20,
    minAmount: 500,
    description: '20% off on orders above ₹500'
  },
  SAVE50: {
    code: 'SAVE50',
    type: 'flat',
    value: 50,
    minAmount: 200,
    description: 'Flat ₹50 instant deduction'
  }
};

export const CartPage: React.FC<CartPageProps> = ({ user, data, activeCurrency = 'INR' }) => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [promoInput, setPromoInput] = useState('');
  const [appliedPromo, setAppliedPromo] = useState<PromoCode | null>(() => {
    try {
      const saved = sessionStorage.getItem('hh_applied_promo');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [promoError, setPromoError] = useState<string | null>(null);
  const [promoSuccess, setPromoSuccess] = useState<string | null>(null);

  const navigate = useNavigate();

  const loadCart = async () => {
    setLoading(true);
    try {
      const items = await cartService.getCart(user ? user.uid : null);
      setCart(items);
    } catch (err) {
      console.error('Failed to load cart items:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCart();
  }, [user]);

  const handleUpdateQuantity = async (itemId: string, newQty: number) => {
    if (newQty < 1) {
      await handleRemoveItem(itemId);
      return;
    }
    await cartService.updateQuantity(itemId, newQty, user ? user.uid : null);
    await loadCart();
  };

  const handleRemoveItem = async (itemId: string) => {
    await cartService.removeFromCart(itemId, user ? user.uid : null);
    await loadCart();
  };

  const handleClearCart = async () => {
    if (window.confirm('Are you sure you want to clear all items from your cart?')) {
      await cartService.clearCart(user ? user.uid : null);
      setCart([]);
      setAppliedPromo(null);
      sessionStorage.removeItem('hh_applied_promo');
    }
  };

  // Subtotal Calculation
  const subtotal = cart.reduce((sum, item) => {
    const numericPrice = parseFloat(String(item.price).replace(/[^0-9.]/g, '')) || 0;
    return sum + (numericPrice * item.quantity);
  }, 0);

  // Discount Calculation
  let discountAmount = 0;
  if (appliedPromo) {
    if (appliedPromo.minAmount && subtotal < appliedPromo.minAmount) {
      // Not eligible
    } else if (appliedPromo.type === 'percent') {
      discountAmount = Math.round((subtotal * appliedPromo.value) / 100);
    } else if (appliedPromo.type === 'flat') {
      discountAmount = Math.min(subtotal, appliedPromo.value);
    }
  }

  const finalTotal = Math.max(0, subtotal - discountAmount);

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    setPromoError(null);
    setPromoSuccess(null);

    const clean = promoInput.trim().toUpperCase();
    if (!clean) {
      setPromoError('Please enter a coupon code.');
      return;
    }

    const promo = AVAILABLE_PROMOS[clean];
    if (!promo) {
      setPromoError('Invalid coupon code. Try HECTOR10 or WELCOME20.');
      return;
    }

    if (promo.minAmount && subtotal < promo.minAmount) {
      setPromoError(`Code requires a minimum subtotal of ₹${promo.minAmount}.`);
      return;
    }

    setAppliedPromo(promo);
    sessionStorage.setItem('hh_applied_promo', JSON.stringify(promo));
    setPromoSuccess(`Coupon applied! ${promo.description}`);
    setPromoInput('');
  };

  const handleRemovePromo = () => {
    setAppliedPromo(null);
    sessionStorage.removeItem('hh_applied_promo');
    setPromoSuccess(null);
    setPromoError(null);
  };

  const handleProceedToCheckout = () => {
    if (!user) {
      navigate('/auth/login?redirect=checkout');
      return;
    }
    navigate('/checkout');
  };

  const formatPrice = (inrVal: number) => {
    if (activeCurrency === 'USD') {
      return `$${(inrVal / 83).toFixed(2)}`;
    }
    return `₹${inrVal.toLocaleString('en-IN')}`;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#08060c] pt-32 pb-20 px-4 sm:px-6 flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-10 h-10 border-2 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs font-semibold text-slate-400 tracking-wider uppercase">Loading Cart...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#08060c] text-slate-100 pt-28 pb-24 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-7xl mx-auto">
        
        {/* Page Breadcrumbs & Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-3">
            <Link to="/" className="hover:text-purple-400 transition-colors">Home</Link>
            <span>/</span>
            <span className="text-slate-200 font-semibold">Shopping Cart</span>
          </div>
          <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2 border-b border-[#231938] pb-5">
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
              Shopping Cart
            </h1>
            <span className="text-xs text-slate-400 font-medium">
              {cart.reduce((acc, item) => acc + item.quantity, 0)} {cart.length === 1 ? 'service item' : 'service items'} configured
            </span>
          </div>
        </div>

        {cart.length === 0 ? (
          /* Empty Cart State */
          <div className="bg-[#130e22] border border-[#231938] rounded-xl p-10 sm:p-16 text-center max-w-2xl mx-auto my-12">
            <div className="w-14 h-14 bg-[#1a1330] border border-[#231938] rounded-xl flex items-center justify-center text-purple-400 mx-auto mb-5">
              <ShoppingCart size={26} />
            </div>
            <h2 className="text-xl font-bold text-white mb-2">Your cart is empty</h2>
            <p className="text-sm text-slate-400 max-w-md mx-auto mb-8 leading-relaxed">
              You do not have any active hosting or game server nodes in your cart. Choose a server plan to get started with instant automated provisioning.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-md mx-auto text-left">
              <Link
                to="/game-servers"
                className="p-3.5 rounded-lg border border-[#231938] bg-[#0c0818] hover:bg-[#1a1330] hover:border-purple-500/50 transition-all flex items-center justify-between group"
              >
                <div>
                  <div className="text-xs font-semibold text-white group-hover:text-purple-300">Game Servers</div>
                  <div className="text-[11px] text-slate-400">Minecraft, Palworld, CS2</div>
                </div>
                <ArrowRight size={14} className="text-slate-400 group-hover:text-purple-400 group-hover:translate-x-0.5 transition-transform" />
              </Link>
              <Link
                to="/vps-hosting"
                className="p-3.5 rounded-lg border border-[#231938] bg-[#0c0818] hover:bg-[#1a1330] hover:border-purple-500/50 transition-all flex items-center justify-between group"
              >
                <div>
                  <div className="text-xs font-semibold text-white group-hover:text-purple-300">VPS Hosting</div>
                  <div className="text-[11px] text-slate-400">AMD RYZEN 9 5950X & EPYC KVM</div>
                </div>
                <ArrowRight size={14} className="text-slate-400 group-hover:text-purple-400 group-hover:translate-x-0.5 transition-transform" />
              </Link>
              <Link
                to="/discord-bot-hosting"
                className="p-3.5 rounded-lg border border-[#231938] bg-[#0c0818] hover:bg-[#1a1330] hover:border-purple-500/50 transition-all flex items-center justify-between group"
              >
                <div>
                  <div className="text-xs font-semibold text-white group-hover:text-purple-300">Discord Bot Hosting</div>
                  <div className="text-[11px] text-slate-400">Node.js, Python, Java</div>
                </div>
                <ArrowRight size={14} className="text-slate-400 group-hover:text-purple-400 group-hover:translate-x-0.5 transition-transform" />
              </Link>
              <Link
                to="/dedicated-servers"
                className="p-3.5 rounded-lg border border-[#231938] bg-[#0c0818] hover:bg-[#1a1330] hover:border-purple-500/50 transition-all flex items-center justify-between group"
              >
                <div>
                  <div className="text-xs font-semibold text-white group-hover:text-purple-300">Dedicated Bare Metal</div>
                  <div className="text-[11px] text-slate-400">Unmetered 10Gbps</div>
                </div>
                <ArrowRight size={14} className="text-slate-400 group-hover:text-purple-400 group-hover:translate-x-0.5 transition-transform" />
              </Link>
            </div>
          </div>
        ) : (
          /* Active Cart Grid */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Left Column: Cart Items & Specs (70% - 8 cols) */}
            <div className="lg:col-span-8 space-y-6">
              
              {/* Items Card List */}
              <div className="bg-[#130e22] border border-[#231938] rounded-xl overflow-hidden divide-y divide-[#231938]">
                {/* Table Header Row (Desktop) */}
                <div className="hidden md:grid grid-cols-12 gap-4 px-6 py-3.5 bg-[#0c0818] text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                  <div className="col-span-6">Service / Configuration</div>
                  <div className="col-span-2 text-center">Unit Price</div>
                  <div className="col-span-2 text-center">Quantity</div>
                  <div className="col-span-2 text-right">Subtotal</div>
                </div>

                {cart.map((item, idx) => {
                  const unitPrice = parseFloat(String(item.price).replace(/[^0-9.]/g, '')) || 0;
                  const itemTotal = unitPrice * item.quantity;
                  const itemId = item.id || `item_${idx}`;

                  return (
                    <div key={itemId} className="p-5 sm:p-6 transition-colors hover:bg-[#150f26]">
                      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
                        
                        {/* Service Details (6 cols) */}
                        <div className="md:col-span-6 space-y-2">
                          <div className="flex items-start gap-3">
                            <div className="w-10 h-10 rounded-lg bg-[#1a1330] border border-[#231938] flex items-center justify-center text-purple-400 shrink-0 mt-0.5">
                              <Server size={18} />
                            </div>
                            <div className="min-w-0 flex-1">
                              <h3 className="text-sm sm:text-base font-semibold text-white truncate">
                                {item.name}
                              </h3>
                              <div className="flex flex-wrap items-center gap-x-2 text-xs text-slate-400 mt-0.5">
                                <span>{item.category || 'Hosting Node'}</span>
                                <span aria-hidden="true">·</span>
                                <span>{item.location || 'Mumbai Datacenter (NIXI)'}</span>
                                <span aria-hidden="true">·</span>
                                <span className="capitalize">{item.billingCycle || 'Monthly'}</span>
                              </div>
                            </div>
                          </div>

                          {/* Add-ons or features if present */}
                          {item.features && item.features.length > 0 && (
                            <div className="text-[11px] text-slate-400 pl-13 pt-1">
                              Includes: {item.features.slice(0, 2).join(' · ')}
                            </div>
                          )}
                        </div>

                        {/* Unit Price (2 cols) */}
                        <div className="md:col-span-2 text-left md:text-center">
                          <span className="md:hidden text-xs text-slate-400 mr-2">Unit Price:</span>
                          <span className="text-sm font-semibold text-slate-200 tabular-nums">
                            {formatPrice(unitPrice)}
                          </span>
                        </div>

                        {/* Quantity Controls (2 cols) */}
                        <div className="md:col-span-2 flex items-center md:justify-center gap-2">
                          <span className="md:hidden text-xs text-slate-400 mr-2">Qty:</span>
                          <div className="inline-flex items-center border border-[#231938] bg-[#0c0818] rounded-lg">
                            <button
                              onClick={() => handleUpdateQuantity(itemId, item.quantity - 1)}
                              className="w-7 h-7 flex items-center justify-center text-slate-400 hover:text-white hover:bg-[#1a1330] rounded-l-lg transition-colors"
                              title="Decrease quantity"
                              aria-label="Decrease quantity"
                            >
                              -
                            </button>
                            <span className="w-8 text-center text-xs font-semibold text-white tabular-nums">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => handleUpdateQuantity(itemId, item.quantity + 1)}
                              className="w-7 h-7 flex items-center justify-center text-slate-400 hover:text-white hover:bg-[#1a1330] rounded-r-lg transition-colors"
                              title="Increase quantity"
                              aria-label="Increase quantity"
                            >
                              +
                            </button>
                          </div>
                        </div>

                        {/* Line Total & Remove (2 cols) */}
                        <div className="md:col-span-2 flex items-center justify-between md:justify-end gap-3 pt-2 md:pt-0 border-t md:border-t-0 border-[#231938]/60">
                          <div className="text-right">
                            <div className="text-base font-bold text-white tabular-nums">
                              {formatPrice(itemTotal)}
                            </div>
                          </div>
                          <button
                            onClick={() => handleRemoveItem(itemId)}
                            className="p-2 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-rose-500/10 transition-colors"
                            title="Remove item"
                            aria-label="Remove item"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>

                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Cart Control Links */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
                <Link
                  to="/game-servers"
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg border border-[#231938] bg-[#130e22] text-xs font-semibold text-slate-300 hover:text-white hover:border-purple-500/40 transition-colors"
                >
                  <ArrowLeft size={14} />
                  <span>Continue Browsing Plans</span>
                </Link>

                <button
                  onClick={handleClearCart}
                  className="w-full sm:w-auto text-xs text-slate-500 hover:text-rose-400 transition-colors px-3 py-2 text-center"
                >
                  Clear Entire Cart
                </button>
              </div>

              {/* Enterprise Hosting Guarantee Points */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
                <div className="bg-[#130e22] border border-[#231938] rounded-xl p-4 flex items-start gap-3">
                  <Zap size={18} className="text-purple-400 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-xs font-semibold text-white">Instant Provisioning</h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">Nodes boot within 60 seconds after invoice settlement.</p>
                  </div>
                </div>
                <div className="bg-[#130e22] border border-[#231938] rounded-xl p-4 flex items-start gap-3">
                  <ShieldCheck size={18} className="text-purple-400 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-xs font-semibold text-white">DDoS Scrubbing</h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">3.2 Tbps Anycast mitigation on Indian and Global nodes.</p>
                  </div>
                </div>
                <div className="bg-[#130e22] border border-[#231938] rounded-xl p-4 flex items-start gap-3">
                  <Clock size={18} className="text-purple-400 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-xs font-semibold text-white">99.99% Hardware SLA</h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">Enterprise NVMe storage and dual-redundant power supplies.</p>
                  </div>
                </div>
              </div>

            </div>

            {/* Right Column: Order Summary (30% - 4 cols) */}
            <div className="lg:col-span-4 space-y-6">
              
              <div className="bg-[#130e22] border border-[#231938] rounded-xl p-6 sticky top-28 space-y-6">
                <h2 className="text-base font-bold text-white border-b border-[#231938] pb-4">
                  Order Summary
                </h2>

                {/* Pricing Breakdown */}
                <div className="space-y-3 text-xs">
                  <div className="flex items-center justify-between text-slate-400">
                    <span>Subtotal</span>
                    <span className="font-semibold text-slate-200 tabular-nums">{formatPrice(subtotal)}</span>
                  </div>

                  {appliedPromo && discountAmount > 0 && (
                    <div className="flex items-center justify-between text-emerald-400">
                      <div className="flex items-center gap-1.5">
                        <Tag size={12} />
                        <span>Promo ({appliedPromo.code})</span>
                        <button 
                          onClick={handleRemovePromo}
                          className="text-slate-500 hover:text-rose-400 ml-1"
                          title="Remove promo"
                        >
                          <X size={12} />
                        </button>
                      </div>
                      <span className="font-semibold tabular-nums">-{formatPrice(discountAmount)}</span>
                    </div>
                  )}

                  <div className="flex items-center justify-between text-slate-400">
                    <span>Setup Fees</span>
                    <span className="font-semibold text-emerald-400">Free (₹0)</span>
                  </div>

                  <div className="flex items-center justify-between text-slate-400">
                    <span>GST / Processing</span>
                    <span className="font-semibold text-slate-200">Included</span>
                  </div>

                  <div className="pt-3 border-t border-[#231938] flex items-baseline justify-between">
                    <span className="text-sm font-semibold text-white">Total Due</span>
                    <span className="text-2xl font-bold text-purple-400 tabular-nums">
                      {formatPrice(finalTotal)}
                    </span>
                  </div>
                </div>

                {/* Promo Code Input */}
                <form onSubmit={handleApplyPromo} className="space-y-2 pt-2 border-t border-[#231938]">
                  <label htmlFor="promoInput" className="text-xs font-semibold text-slate-400 block">
                    Have a promo code?
                  </label>
                  <div className="flex gap-2">
                    <input
                      id="promoInput"
                      type="text"
                      value={promoInput}
                      onChange={(e) => setPromoInput(e.target.value)}
                      placeholder="e.g. HECTOR10"
                      className="flex-1 bg-[#0c0818] border border-[#231938] rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                    />
                    <button
                      type="submit"
                      className="px-3.5 py-2 bg-[#1a1330] hover:bg-[#231938] text-purple-300 hover:text-white border border-[#231938] hover:border-purple-500/50 rounded-lg text-xs font-semibold transition-colors"
                    >
                      Apply
                    </button>
                  </div>
                  {promoError && (
                    <p className="text-[11px] text-rose-400 mt-1">{promoError}</p>
                  )}
                  {promoSuccess && (
                    <p className="text-[11px] text-emerald-400 mt-1 flex items-center gap-1">
                      <Check size={12} /> {promoSuccess}
                    </p>
                  )}
                </form>

                {/* Primary Proceed CTA */}
                <button
                  onClick={handleProceedToCheckout}
                  className="w-full py-3.5 px-4 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-colors flex items-center justify-center gap-2 shadow-sm"
                >
                  <span>Proceed to Checkout</span>
                  <ArrowRight size={15} />
                </button>

                {/* Trust and Payment Assurances */}
                <div className="text-[11px] text-slate-400 space-y-2 pt-2 border-t border-[#231938]">
                  <div className="flex items-center gap-2 text-slate-300">
                    <ShieldCheck size={14} className="text-purple-400 shrink-0" />
                    <span>256-Bit SSL Encrypted Checkout</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-400">
                    <Globe size={14} className="text-slate-500 shrink-0" />
                    <span>Instant UPI & QR Payments Supported</span>
                  </div>
                </div>

              </div>

            </div>

          </div>
        )}

      </div>
    </div>
  );
};
