export interface DynamicLocation {
  id: string;
  name: string;
  rawName: string;
  flag: string;
  ping: string;
  load?: string;
  latency?: string;
}

export function getDynamicLocations(configuredLocations: string[] = []): DynamicLocation[] {
  // If no locations configured or empty, default to India
  const rawList = configuredLocations && configuredLocations.length > 0 
    ? configuredLocations 
    : ['India'];

  return rawList.map((loc) => {
    const raw = loc.trim();
    const lower = raw.toLowerCase();

    if (lower.includes('india') || lower.includes('mumbai') || lower.includes('delhi') || lower.includes('in')) {
      const isNamed = raw.includes('(');
      return {
        id: 'in',
        name: isNamed ? raw : `${raw} (Mumbai)`,
        rawName: raw,
        flag: '🇮🇳',
        ping: '12ms',
        latency: '12ms',
        load: 'Optimized'
      };
    }

    if (lower.includes('singapore') || lower.includes('sg')) {
      const isNamed = raw.includes('(');
      return {
        id: 'sg',
        name: isNamed ? raw : `${raw} (SG)`,
        rawName: raw,
        flag: '🇸🇬',
        ping: '28ms',
        latency: '28ms',
        load: 'Low Load'
      };
    }

    if (lower.includes('germany') || lower.includes('frankfurt') || lower.includes('de')) {
      const isNamed = raw.includes('(');
      return {
        id: 'de',
        name: isNamed ? raw : `${raw} (Frankfurt)`,
        rawName: raw,
        flag: '🇩🇪',
        ping: '110ms',
        latency: '110ms',
        load: 'High Perf'
      };
    }

    if (lower.includes('usa') || lower.includes('us') || lower.includes('ashburn') || lower.includes('america')) {
      const isNamed = raw.includes('(');
      return {
        id: 'us',
        name: isNamed ? raw : `${raw} (Ashburn)`,
        rawName: raw,
        flag: '🇺🇸',
        ping: '180ms',
        latency: '180ms',
        load: 'Standard'
      };
    }

    if (lower.includes('uk') || lower.includes('london') || lower.includes('britain')) {
      const isNamed = raw.includes('(');
      return {
        id: 'uk',
        name: isNamed ? raw : `${raw} (London)`,
        rawName: raw,
        flag: '🇬🇧',
        ping: '125ms',
        latency: '125ms',
        load: 'Standard'
      };
    }

    // Dynamic fallback for any custom location added via Admin Panel
    return {
      id: raw.toLowerCase().replace(/[^a-z0-9]/g, '-'),
      name: raw,
      rawName: raw,
      flag: '🌐',
      ping: '<25ms',
      latency: '<25ms',
      load: 'Active'
    };
  });
}
