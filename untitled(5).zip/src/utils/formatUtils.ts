/**
 * Utility functions for parsing and formatting monetary amounts, currency strings, and numbers.
 */

export function parseAmount(val: any): number {
  if (typeof val === 'number') {
    return isNaN(val) ? 0 : val;
  }
  if (!val) return 0;
  
  // Clean out currency symbols, letters, commas, etc., keeping only digits and decimal point
  const str = String(val).trim();
  const cleaned = str.replace(/[^0-9.]/g, '');
  
  if (!cleaned) return 0;
  const parsed = parseFloat(cleaned);
  return isNaN(parsed) ? 0 : parsed;
}

export function formatINR(val: any, minimumFractionDigits: number = 0): string {
  const num = parseAmount(val);
  return `₹${num.toLocaleString('en-IN', {
    minimumFractionDigits,
    maximumFractionDigits: 2
  })}`;
}
