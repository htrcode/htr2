import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { AdminPanel } from './components/AdminPanel';
import { AppData, Plan, Feedback, Testimonial, ServiceStatus, Game } from './types';
import { DEFAULT_DATA } from './constants';
import { dataService } from './services/dataService';
import { authService } from './services/authService';
import { User as FirebaseUser } from 'firebase/auth';
import { db } from './services/firebase';
import { doc, onSnapshot, collection } from 'firebase/firestore';

import { BrowserRouter, Routes, Route, useLocation, useNavigate, Navigate } from 'react-router-dom';
import { ContentPage } from './components/ContentPage';
import { Home } from './pages/Home';
import { GameServersPage } from './pages/GameServersPage';
import { GamePricingPage } from './pages/GamePricingPage';
import { VpsHostingPage } from './pages/VpsHostingPage';
import { DiscordBotPage } from './pages/DiscordBotPage';
import { DedicatedServersPage } from './pages/DedicatedServersPage';
import { Footer } from './components/Footer';
import { WebHostingPage } from './pages/WebHostingPage';
import { CategoryPage } from './pages/CategoryPage';
import { AboutPage } from './pages/AboutPage';
import { StatusPage } from './pages/StatusPage';
import { ContactPage } from './pages/ContactPage';
import { TermsPage } from './pages/TermsPage';
import { PrivacyPage } from './pages/PrivacyPage';
import { RefundPage } from './pages/RefundPage';
import { InfrastructurePage } from './pages/InfrastructurePage';
import { LegalPage } from './pages/LegalPage';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { DashboardPage } from './pages/Dashboard';
import { CheckoutPage } from './pages/CheckoutPage';
import { CartPage } from './pages/CartPage';
import { MaintenancePage } from './pages/MaintenancePage';
import { cartService } from './services/cartService';
import { CartItem } from './types';

// ScrollToTop component to reset window scroll on page change
function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
}

export default function App() {
  const [data, setData] = useState<AppData>(DEFAULT_DATA);
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [isRegistered, setIsRegistered] = useState<boolean | null>(null);
  const [isAuthChecking, setIsAuthChecking] = useState(true);
  const [activeCurrency, setActiveCurrency] = useState<'INR' | 'USD'>('INR');
  const [feedbackForm, setFeedbackForm] = useState({ name: '', msg: '', rating: 5 });
  const [isLoading, setIsLoading] = useState(true);
  const [isConfigMissing, setIsConfigMissing] = useState(false);

  // Auth & Admin Check
  useEffect(() => {
    let unsubUserDoc: (() => void) | null = null;
    
    setIsAuthChecking(true);
    const unsubAuth = authService.onAuthStateChanged(async (u) => {
      setUser(u);
      
      if (unsubUserDoc) {
        unsubUserDoc();
        unsubUserDoc = null;
      }

      if (u) {
        const adminStatus = await authService.isAdmin(u.uid, u.email);
        setIsAdmin(adminStatus);
        
        // Listen to user document in Firestore in real-time
        unsubUserDoc = onSnapshot(doc(db, 'users', u.uid), (snap) => {
          if (snap.exists() && snap.data()?.pterodactylId) {
            setIsRegistered(true);
          } else {
            setIsRegistered(false);
          }
          setIsAuthChecking(false);
        }, (err) => {
          console.error("Error listening to user document:", err);
          setIsRegistered(false);
          setIsAuthChecking(false);
        });
      } else {
        setIsAdmin(false);
        setIsRegistered(null);
        setIsAuthChecking(false);
      }
    });

    return () => {
      unsubAuth();
      if (unsubUserDoc) {
        unsubUserDoc();
      }
    };
  }, []);

  // Seeding trigger: Run only when an admin is detected and config is missing
  useEffect(() => {
    if (isAdmin && isConfigMissing) {
      console.log("Admin detected and database is empty. Seeding default data...");
      dataService.seedAllDefaultData(DEFAULT_DATA).then(success => {
        if (success) {
          console.log("Database seeded successfully.");
          setIsConfigMissing(false);
        }
      }).catch(err => {
        console.error("Failed to seed database:", err);
      });
    }
  }, [isAdmin, isConfigMissing]);

  // Data Sync
  useEffect(() => {
    const unsubSettings = onSnapshot(doc(db, 'config/site'), (snap) => {
      if (snap.exists()) {
        setIsConfigMissing(false);
        const docData = snap.data() as any;

        const rootSettings: any = {};
        const settingsKeys = [
          'site_name', 'tagline', 'brand_name', 'announcement_text', 'show_announcement',
          'support_email', 'discord_url', 'billing_url', 'upi_id', 'payment_instructions',
          'maintenance_mode', 'maintenance_message', 'theme', 'font', 'color', 'currency',
          'whatsapp_number', 'whatsapp_message', 'nav_links'
        ];
        settingsKeys.forEach(k => {
          if (docData[k] !== undefined) {
            rootSettings[k] = docData[k];
          }
        });

        const productConfigs = docData.productConfigs || docData.settings?.productConfigs;

        const mergedSettings = {
          ...docData.settings,
          ...rootSettings,
          ...(productConfigs !== undefined ? { productConfigs } : {})
        };

        setData(prev => ({
          ...prev,
          settings: { ...prev.settings, ...mergedSettings },
          privacy: docData.privacy || prev.privacy,
          refund: docData.refund || prev.refund,
          tos: docData.tos || prev.tos,
          legal: docData.legal || prev.legal,
          infrastructure: docData.infrastructure || prev.infrastructure,
          about: docData.about || prev.about,
          categories: Array.from(new Set(docData.categories || prev.categories)),
          locations: Array.from(new Set(docData.locations || prev.locations)),
          nodes: Array.from(new Set(docData.nodes || prev.nodes))
        }));
      } else {
        setIsConfigMissing(true);
      }
    }, (err) => {
      console.error("Settings listener error:", err);
      setIsConfigMissing(true);
    });

    const unsubPlans = onSnapshot(collection(db, 'plans'), (snap) => {
      const plans = snap.docs.map(d => ({ ...d.data(), id: d.id } as Plan));
      // Defensive: Filter out any potential duplicate document IDs from the snapshot array
      const uniquePlans = Array.from(new Map(plans.map(item => [item.id, item])).values());
      setData(prev => ({ ...prev, plans: uniquePlans }));
    }, (err) => {
      console.error("Plans listener error:", err);
    });

    const unsubGames = onSnapshot(collection(db, 'games'), (snap) => {
      const games = snap.docs.map(d => ({ ...d.data(), id: d.id } as Game));
      const sorted = games.sort((a, b) => (a.order || 0) - (b.order || 0));
      setData(prev => ({ ...prev, games: sorted }));
    }, (err) => {
      console.error("Games listener error:", err);
    });

    const unsubTestimonials = onSnapshot(collection(db, 'testimonials'), (snap) => {
      const testimonials = snap.docs.map(d => ({ ...d.data(), id: d.id } as Testimonial));
      // Defensive: Filter out any potential duplicate document IDs
      const uniqueTestimonials = Array.from(new Map(testimonials.map(item => [item.id, item])).values());
      setData(prev => ({ ...prev, testimonials: uniqueTestimonials }));
      setIsLoading(false);
    }, (err) => {
      console.error("Testimonials listener error:", err);
      setIsLoading(false);
    });

    const unsubFeedback = dataService.subscribeFeedbacks((feedbacks) => {
      setData(prev => ({ ...prev, feedbacks }));
    });

    return () => {
      unsubSettings();
      unsubPlans();
      unsubGames();
      unsubTestimonials();
      unsubFeedback();
    };
  }, []);

  useEffect(() => {
    // Apply themes to document
    document.documentElement.setAttribute('data-theme', data.settings.theme);
    document.documentElement.setAttribute('data-color', data.settings.color);
    document.documentElement.setAttribute('data-font', data.settings.font);
  }, [data.settings]);

  const toggleTheme = () => {
    setData(prev => ({
      ...prev,
      settings: { ...prev.settings, theme: prev.settings.theme === 'dark' ? 'light' : 'dark' }
    }));
  };

  const handleOrder = (plan: Plan) => {
    const phone = data.settings.whatsapp_number.replace(/\D/g, '');
    const priceVal = plan.price_inr || plan.price;

    const message = data.settings.whatsapp_message
      .replace('{plan}', plan.name)
      .replace('{price}', priceVal)
      .replace('{currency}', '₹')
      .replace('{features}', plan.features.join(', '))
      + `\n\nConfig:\n📍 Loc: ${plan.location}\n⚙️ Node: ${plan.node}`;
    
    const url = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  const submitFeedback = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackForm.msg) return;

    const feedbackData: Omit<Feedback, 'id'> = {
      name: feedbackForm.name || 'Anonymous',
      msg: feedbackForm.msg,
      rating: feedbackForm.rating,
      time: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
    };

    await dataService.addFeedback(feedbackData);
    setFeedbackForm({ name: '', msg: '', rating: 5 });
  };

  if (isLoading || isAuthChecking) {
    return (
      <div className="min-h-screen bg-bg flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-accent border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (isAdminMode && isAdmin) {
    return (
      <AdminPanel 
        data={data} 
        setData={setData} 
        onClose={() => setIsAdminMode(false)} 
        user={user}
        isAdmin={isAdmin}
      />
    );
  }

  return (
    <BrowserRouter>
      <ScrollToTop />
      <AppLayout 
        data={data}
        setData={setData}
        user={user}
        isAdmin={isAdmin}
        isRegistered={isRegistered}
        setIsAdminMode={setIsAdminMode}
        toggleTheme={toggleTheme}
        feedbackForm={feedbackForm}
        setFeedbackForm={setFeedbackForm}
        submitFeedback={submitFeedback}
        handleOrder={handleOrder}
        activeCurrency={activeCurrency}
        setActiveCurrency={setActiveCurrency}
      />
    </BrowserRouter>
  );
}

function AppLayout({ 
  data, 
  setData,
  user, 
  isAdmin, 
  isRegistered,
  setIsAdminMode, 
  toggleTheme,
  feedbackForm,
  setFeedbackForm,
  submitFeedback,
  handleOrder,
  activeCurrency,
  setActiveCurrency
}: { 
  data: AppData; 
  setData: (data: AppData) => void;
  user: FirebaseUser | null; 
  isAdmin: boolean;
  isRegistered: boolean | null;
  setIsAdminMode: (val: boolean) => void;
  toggleTheme: () => void;
  feedbackForm: any;
  setFeedbackForm: any;
  submitFeedback: any;
  handleOrder: (plan: Plan) => void;
  activeCurrency: 'INR' | 'USD';
  setActiveCurrency: (c: 'INR' | 'USD') => void;
}) {
  const location = useLocation();
  const navigate = useNavigate();
  const isDashboard = location.pathname.startsWith('/dashboard');
  const isCheckout = location.pathname.startsWith('/checkout');
  const isAdminRoute = location.pathname.startsWith('/admin');
  const isAuthPage = location.pathname === '/login' || location.pathname === '/register' || location.pathname === '/auth/login' || location.pathname === '/auth/register';
  
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  const fetchCart = async () => {
    try {
      const items = await cartService.getCart(user ? user.uid : null);
      setCartItems(items);
    } catch (error) {
      console.error("Error fetching cart:", error);
    }
  };

  useEffect(() => {
    fetchCart();
  }, [user, location.pathname]);

  // Redirect logic based on registration status
  useEffect(() => {
    if (user) {
      if (isRegistered === true) {
        // Fully registered users cannot go to register or login pages
        if (location.pathname === '/auth/register' || location.pathname === '/register' || location.pathname === '/auth/login' || location.pathname === '/login') {
          navigate('/dashboard', { replace: true });
        }
      } else if (isRegistered === false) {
        // Authenticated but NOT fully registered users (e.g. pending Google setup)
        // Must complete registration if trying to access dashboard, checkout, login page, or cart
        const isProtectedRoute = location.pathname.startsWith('/dashboard') || 
                                 location.pathname.startsWith('/checkout') || 
                                 location.pathname.startsWith('/cart') ||
                                 location.pathname === '/auth/login' ||
                                 location.pathname === '/login';
        if (isProtectedRoute) {
          navigate('/auth/register', { 
            state: { 
              googleUser: { 
                uid: user.uid, 
                email: user.email, 
                displayName: user.displayName 
              } 
            },
            replace: true 
          });
        }
      }
    }
  }, [user, isRegistered, location.pathname, navigate]);

  const onAddToCart = async (plan: Plan) => {
    try {
      sessionStorage.setItem('checkout_selected_plan', JSON.stringify(plan));
    } catch (e) {
      console.error('Failed to store checkout plan:', e);
    }
    navigate(`/checkout?plan=${plan.id}`);
  };

  const isMaintenanceActive = data.settings.maintenance_mode && !isAdmin;
  const isPermittedRoute = 
    location.pathname === '/status' || 
    location.pathname === '/login' || 
    location.pathname === '/register' || 
    location.pathname.startsWith('/admin');

  if (isMaintenanceActive && !isPermittedRoute) {
    return <MaintenancePage data={data} />;
  }

  return (
    <div className="min-h-screen">
      {!isDashboard && !isCheckout && !isAdminRoute && !isAuthPage && (
        <Navbar 
          settings={data.settings} 
          categories={data.categories}
          toggleTheme={toggleTheme} 
          user={user}
          isAdmin={isAdmin}
          setIsAdminMode={setIsAdminMode}
          cartCount={cartItems.reduce((sum, item) => sum + item.quantity, 0)}
          onOpenCart={() => navigate('/cart')}
          activeCurrency={activeCurrency}
          setActiveCurrency={setActiveCurrency}
        />
      )}
      
      <main>
        <Routes>
          <Route path="/cart" element={<Navigate to="/checkout" replace />} />
          <Route path="/checkout" element={
            <CheckoutPage 
              data={data} 
              activeCurrency={activeCurrency} 
            />
          } />
          <Route path="/" element={
            <Home 
              data={data}
              feedbackForm={feedbackForm}
              setFeedbackForm={setFeedbackForm}
              submitFeedback={submitFeedback}
              onAddToCart={onAddToCart}
            />
          } />
          <Route path="/admin" element={
            <AdminPanel 
              data={data} 
              setData={setData} 
              onClose={() => navigate('/dashboard')} 
              user={user}
              isAdmin={isAdmin}
            />
          } />
          <Route path="/dashboard/*" element={
            <DashboardPage 
              user={user} 
              isAdmin={isAdmin} 
              onOpenAdmin={() => setIsAdminMode(true)} 
            />
          } />
          <Route path="/game-servers" element={
              <GameServersPage 
                data={data}
                activeCurrency={activeCurrency}
                handleOrder={onAddToCart}
              />
            } />
            <Route path="/game-hosting" element={
              <GameServersPage 
                data={data}
                activeCurrency={activeCurrency}
                handleOrder={onAddToCart}
              />
            } />
            <Route path="/games" element={
              <GameServersPage 
                data={data}
                activeCurrency={activeCurrency}
                handleOrder={onAddToCart}
              />
            } />
            <Route path="/game/:gameId" element={
              <GamePricingPage 
                data={data}
                activeCurrency={activeCurrency}
                handleOrder={onAddToCart}
              />
            } />
            <Route path="/vps-hosting" element={
              <VpsHostingPage 
                data={data}
                activeCurrency={activeCurrency}
                handleOrder={onAddToCart}
              />
            } />
            <Route path="/vps" element={
              <VpsHostingPage 
                data={data}
                activeCurrency={activeCurrency}
                handleOrder={onAddToCart}
              />
            } />
            <Route path="/discord-bot-hosting" element={
              <DiscordBotPage 
                data={data}
                activeCurrency={activeCurrency}
                handleOrder={onAddToCart}
              />
            } />
            <Route path="/bot-hosting" element={
              <DiscordBotPage 
                data={data}
                activeCurrency={activeCurrency}
                handleOrder={onAddToCart}
              />
            } />
            <Route path="/dedicated-servers" element={
              <DedicatedServersPage 
                data={data}
                activeCurrency={activeCurrency}
                handleOrder={onAddToCart}
              />
            } />
            <Route path="/ded-servers" element={
              <DedicatedServersPage 
                data={data}
                activeCurrency={activeCurrency}
                handleOrder={onAddToCart}
              />
            } />
            <Route path="/web-hosting" element={
              <WebHostingPage 
                data={data}
                handleOrder={onAddToCart}
              />
            } />
            <Route path="/web" element={
              <WebHostingPage 
                data={data}
                handleOrder={onAddToCart}
              />
            } />
            <Route path="/plans" element={
              <VpsHostingPage 
                data={data}
                activeCurrency={activeCurrency}
                handleOrder={onAddToCart}
              />
            } />
            <Route path="/about" element={<AboutPage data={data} />} />
            <Route path="/contact" element={<ContactPage data={data} user={user} />} />
            <Route path="/infrastructure" element={<InfrastructurePage data={data} />} />
            <Route path="/status" element={<StatusPage data={data} />} />
            <Route path="/auth/login" element={<LoginPage />} />
            <Route path="/auth/register" element={<RegisterPage />} />
            <Route path="/login" element={<Navigate to="/auth/login" replace />} />
            <Route path="/register" element={<Navigate to="/auth/register" replace />} />
            <Route path="/privacy" element={<PrivacyPage data={data} />} />
            <Route path="/refund" element={<RefundPage data={data} />} />
            <Route path="/tos" element={<TermsPage data={data} />} />
            <Route path="/legal" element={<LegalPage data={data} />} />
            
            {/* Dynamic Category Catch-all */}
            <Route path="/:categoryId" element={
              <CategoryPage 
                data={data} 
                handleOrder={onAddToCart} 
              />
            } />
          </Routes>
        </main>

        {!isDashboard && !isCheckout && !isAdminRoute && !isAuthPage && (
          <Footer data={data} isAdmin={isAdmin} setIsAdminMode={setIsAdminMode} />
        )}
      </div>
  );
}

