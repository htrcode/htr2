export interface ParsedPolicy {
  title: string;
  subtitle: string;
  sections: { id: string; title: string; content: string }[];
}

export function parsePolicyMarkdown(markdown: string, defaultTitle: string): ParsedPolicy {
  if (!markdown) {
    return { title: defaultTitle, subtitle: '', sections: [] };
  }

  const lines = markdown.split('\n');
  let title = defaultTitle;
  let subtitleLines: string[] = [];
  const sections: { id: string; title: string; content: string }[] = [];
  
  let currentSection: { id: string; title: string; content: string } | null = null;
  let isParsingHeader = true;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmedLine = line.trim();

    if (trimmedLine.startsWith('# ')) {
      title = trimmedLine.replace('# ', '').trim();
      isParsingHeader = true;
      continue;
    }

    if (trimmedLine.startsWith('## ')) {
      isParsingHeader = false;
      if (currentSection) {
        sections.push({
          ...currentSection,
          content: currentSection.content.trim()
        });
      }
      const sectionTitle = trimmedLine.replace(/^##\s+/, '').trim();
      const id = `sec-${sectionTitle.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
      currentSection = {
        id,
        title: sectionTitle,
        content: ''
      };
      continue;
    }

    if (isParsingHeader) {
      if (trimmedLine && !trimmedLine.toLowerCase().startsWith('last updated:')) {
        subtitleLines.push(trimmedLine);
      }
    } else if (currentSection) {
      currentSection.content += line + '\n';
    }
  }

  if (currentSection) {
    sections.push({
      ...currentSection,
      content: currentSection.content.trim()
    });
  }

  return {
    title,
    subtitle: subtitleLines.filter(Boolean).join(' '),
    sections
  };
}

export function serializePolicyMarkdown(title: string, subtitle: string, sections: { title: string; content: string }[]): string {
  let md = `# ${title}\n\n`;
  if (subtitle) {
    md += `${subtitle}\n\n`;
  }
  sections.forEach(sec => {
    md += `## ${sec.title}\n${sec.content}\n\n`;
  });
  return md.trim();
}

export interface ParsedAbout {
  title: string;
  subtitle: string;
  mission: string;
  philosophy: string;
  values: { title: string; desc: string }[];
  milestones: { year: string; title: string; desc: string }[];
}

export function parseAboutMarkdown(markdown: string): ParsedAbout {
  const defaultAbout: ParsedAbout = {
    title: 'About Hector Hosting',
    subtitle: "India's Premier Game & High-Frequency Cloud Infrastructure.",
    mission: 'To power Indian gaming communities, independent developers, and digital enterprises with ultra-low latency, carrier-grade infrastructure built on genuine high-frequency silicon at honest, transparent price points.',
    philosophy: 'We believe that hosting infrastructure should be "invisible". You focus on building your application and community; we handle the silicon, routing, and packets.',
    values: [
      { title: 'Performance First', desc: 'Strictly zero CPU overselling. Dedicated high-frequency cores with guaranteed resources.' },
      { title: 'Indian Support that Cares', desc: 'Real systems engineers based in India ready 24/7/365, not automated bot scripts.' },
      { title: 'Transparent Pricing', desc: 'Direct Indian Rupee pricing with zero hidden fees or unexpected renewal surprises.' }
    ],
    milestones: [
      { year: '2018', title: 'The Genesis in India', desc: 'Launched our flagship low-latency AMD RYZEN™ 9 5950X node in Mumbai, India.' },
      { year: '2020', title: 'National Peering Backbone', desc: 'Integrated direct NIXI peering and sub-15ms routing across major Indian metro hubs.' },
      { year: '2022', title: '10,000+ Deployments', desc: 'Reached over 10,000 active virtual environments and game server deployments across India.' },
      { year: '2024', title: 'The EPYC Hardware Era', desc: 'Upgraded infrastructure to enterprise AMD EPYC and AMD RYZEN™ 9 5950X NVMe Gen4 architecture in Indian Tier-4 datacenters.' }
    ]
  };

  if (!markdown) return defaultAbout;

  const lines = markdown.split('\n');
  let title = defaultAbout.title;
  let subtitleLines: string[] = [];
  let mission = defaultAbout.mission;
  let philosophy = defaultAbout.philosophy;
  const values: { title: string; desc: string }[] = [];
  const milestones: { year: string; title: string; desc: string }[] = [];

  let currentSection = ''; // 'mission', 'philosophy', 'values', 'growth'
  let valuesBlock = '';
  let growthBlock = '';

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trim();

    if (trimmed.startsWith('# ')) {
      title = trimmed.replace('# ', '').trim();
      currentSection = 'header';
      continue;
    }

    if (trimmed.startsWith('## Our Mission') || trimmed.startsWith('## Mission')) {
      currentSection = 'mission';
      mission = '';
      continue;
    }

    if (trimmed.startsWith('## Our Philosophy') || trimmed.startsWith('## Philosophy')) {
      currentSection = 'philosophy';
      philosophy = '';
      continue;
    }

    if (trimmed.startsWith('### Core Values') || trimmed.startsWith('## Core Values')) {
      currentSection = 'values';
      continue;
    }

    if (trimmed.startsWith('## Our Growth') || trimmed.startsWith('## Growth')) {
      currentSection = 'growth';
      continue;
    }

    if (trimmed.startsWith('## ') || trimmed.startsWith('### ')) {
      currentSection = 'other';
      continue;
    }

    if (currentSection === 'header') {
      if (trimmed) {
        subtitleLines.push(trimmed);
      }
    } else if (currentSection === 'mission') {
      if (trimmed) {
        mission += (mission ? ' ' : '') + trimmed;
      }
    } else if (currentSection === 'philosophy') {
      if (trimmed) {
        philosophy += (philosophy ? ' ' : '') + trimmed;
      }
    } else if (currentSection === 'values') {
      if (trimmed) {
        valuesBlock += trimmed + '\n';
      }
    } else if (currentSection === 'growth') {
      if (trimmed) {
        growthBlock += trimmed + '\n';
      }
    }
  }

  if (valuesBlock) {
    const valueLines = valuesBlock.split('\n');
    for (const vLine of valueLines) {
      const match = vLine.match(/(?:\d+\.|\*)\s*\*\*(.*?)\*\*[:\s]+(.*)/);
      if (match) {
        values.push({ title: match[1].trim(), desc: match[2].trim() });
      } else {
        const fallbackMatch = vLine.match(/(?:\d+\.|\*)\s*(.*)/);
        if (fallbackMatch && fallbackMatch[1].trim()) {
          const parts = fallbackMatch[1].split(':');
          if (parts.length > 1) {
            values.push({ title: parts[0].trim(), desc: parts.slice(1).join(':').trim() });
          } else {
            values.push({ title: 'Core Value', desc: fallbackMatch[1].trim() });
          }
        }
      }
    }
  }

  if (growthBlock) {
    const growthLines = growthBlock.split('\n');
    for (const gLine of growthLines) {
      const match = gLine.match(/(?:\d+\.|\*)\s*\*\*(.*?)\*\*[:\s]+(.*)/);
      if (match) {
        const parts = match[2].split(':');
        if (parts.length > 1) {
          milestones.push({ year: match[1].trim(), title: parts[0].trim(), desc: parts.slice(1).join(':').trim() });
        } else {
          milestones.push({ year: match[1].trim(), title: 'Milestone Achievement', desc: match[2].trim() });
        }
      }
    }
  }

  return {
    title,
    subtitle: subtitleLines.join(' '),
    mission: mission || defaultAbout.mission,
    philosophy: philosophy || defaultAbout.philosophy,
    values: values.length > 0 ? values : defaultAbout.values,
    milestones: milestones.length > 0 ? milestones : defaultAbout.milestones
  };
}

export function serializeAboutMarkdown(about: ParsedAbout): string {
  let md = `# ${about.title}\n\n${about.subtitle}\n\n`;
  md += `## Our Mission\n${about.mission}\n\n`;
  md += `## Our Philosophy\n${about.philosophy}\n\n`;
  md += `### Core Values\n`;
  about.values.forEach((v, i) => {
    md += `${i + 1}. **${v.title}:** ${v.desc}\n`;
  });
  md += `\n## Our Growth in India\n`;
  about.milestones.forEach(m => {
    md += `* **${m.year}:** ${m.title}: ${m.desc}\n`;
  });
  return md.trim();
}

export interface ParsedInfrastructure {
  title: string;
  subtitle: string;
  datacenter: string;
  peering: string;
  latencyTarget: string;
  specs: { metric: string; guaranteed: string; average: string }[];
  hardwareStack: { title: string; desc: string }[];
  sections: { id: string; title: string; content: string }[];
}

export function parseInfrastructureMarkdown(markdown: string): ParsedInfrastructure {
  const defaultInfra: ParsedInfrastructure = {
    title: 'Our High-Speed Infrastructure in India',
    subtitle: 'Enterprise-grade compute clusters and network peering fabrics engineered directly in Mumbai, India for sub-15ms latency.',
    datacenter: 'Tier 4 Datacenter in Mumbai, Maharashtra, India',
    peering: 'Direct NIXI & Tier-1 Indian Telco Peering (Airtel, Jio, Tata)',
    latencyTarget: '< 15ms Indian Subcontinent',
    specs: [
      { metric: 'Network Uplink', guaranteed: '10 Gbps', average: '8.8 Gbps' },
      { metric: 'SSD NVMe IOPS', guaranteed: '100k+', average: '150k+' },
      { metric: 'CPU Frequency', guaranteed: '3.7 GHz+', average: '4.9 GHz (Boost)' },
      { metric: 'Subcontinent Ping', guaranteed: '< 35ms', average: '12ms' }
    ],
    hardwareStack: [
      { title: 'High-Clock CPUs', desc: 'AMD EPYC™ 7763 & AMD RYZEN™ 9 5950X processors delivering single-thread execution leadership.' },
      { title: 'Enterprise NVMe RAID 10', desc: 'Gen4 solid-state storage arrays with hardware controller redundancy.' },
      { title: 'Automated Anti-DDoS', desc: 'Line-rate L3/L4 and L7 volumetric protection with zero throughput degradation.' }
    ],
    sections: []
  };

  if (!markdown) return defaultInfra;

  const parsed = parsePolicyMarkdown(markdown, defaultInfra.title);
  // Deduplicate and filter out hardcoded header sections
  const customSections: { id: string; title: string; content: string }[] = [];
  const seenTitles = new Set<string>();

  for (const s of parsed.sections) {
    const lower = s.title.toLowerCase();
    if (lower.includes('tier 4 datacenter') || lower.includes('performance benchmark')) {
      continue;
    }
    if (!seenTitles.has(lower)) {
      seenTitles.add(lower);
      customSections.push(s);
    }
  }

  return {
    title: parsed.title,
    subtitle: parsed.subtitle || defaultInfra.subtitle,
    datacenter: defaultInfra.datacenter,
    peering: defaultInfra.peering,
    latencyTarget: defaultInfra.latencyTarget,
    specs: defaultInfra.specs,
    hardwareStack: defaultInfra.hardwareStack,
    sections: customSections
  };
}

export function serializeInfrastructureMarkdown(infra: ParsedInfrastructure): string {
  let md = `# ${infra.title}\n\n${infra.subtitle}\n\n`;
  md += `## Tier 4 Datacenter in Mumbai\n${infra.datacenter}. ${infra.peering}.\n\n`;
  md += `## Performance Benchmark\n${infra.latencyTarget}\n\n`;
  infra.sections.forEach(sec => {
    md += `## ${sec.title}\n${sec.content}\n\n`;
  });
  return md.trim();
}

export interface ParsedLegal {
  title: string;
  subtitle: string;
  entityName: string;
  jurisdiction: string;
  complianceList: string[];
  sections: { id: string; title: string; content: string }[];
}

export function parseLegalMarkdown(markdown: string): ParsedLegal {
  const defaultLegal: ParsedLegal = {
    title: 'Legal Information & Compliance',
    subtitle: 'Statutory framework, regulatory compliance standards, and corporate governance for Hector Hosting infrastructure.',
    entityName: 'Hector Hosting India Pvt Ltd',
    jurisdiction: 'Exclusive Jurisdiction of Courts in Mumbai, Maharashtra, India',
    complianceList: [
      'IT Act 2000 & Digital Personal Data Protection (DPDP)',
      'CERT-In Cyber Security Directions (Indian Computer Emergency Response Team)',
      'ISO 27001 Information Security Management Standards',
      'DMCA & Intellectual Property Safeguards'
    ],
    sections: []
  };

  if (!markdown) return defaultLegal;

  const parsed = parsePolicyMarkdown(markdown, defaultLegal.title);
  const customSections: { id: string; title: string; content: string }[] = [];
  const seenTitles = new Set<string>();

  for (const s of parsed.sections) {
    const lower = s.title.toLowerCase();
    if (lower.includes('entity information')) {
      continue;
    }
    if (!seenTitles.has(lower)) {
      seenTitles.add(lower);
      customSections.push(s);
    }
  }

  return {
    title: parsed.title,
    subtitle: parsed.subtitle || defaultLegal.subtitle,
    entityName: defaultLegal.entityName,
    jurisdiction: defaultLegal.jurisdiction,
    complianceList: defaultLegal.complianceList,
    sections: customSections
  };
}

export function serializeLegalMarkdown(legal: ParsedLegal): string {
  let md = `# ${legal.title}\n\n${legal.subtitle}\n\n`;
  md += `## Entity Information\n${legal.entityName}. ${legal.jurisdiction}.\n\n`;
  legal.sections.forEach(sec => {
    md += `## ${sec.title}\n${sec.content}\n\n`;
  });
  return md.trim();
}
