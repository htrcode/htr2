# Security Specification - Hector Hosting

## Data Invariants
1. `plans`, `statuses`, `incidents`, `testimonials`, `config/site` are read-only for public users, and writeable only by admins.
2. `feedbacks` can be created by any authenticated user, but modified/deleted only by admins.
3. `user_services` and `user_activities` are strictly isolated: a user can only read their own records. No one (except admins) can write to these directly in a way that spoofs `userId`.
4. `tickets` and `ticket_messages` are strictly isolated by `userId` or `ticketUserId`.
5. `admins` collection is read-only for everyone except admins.
6. Identity spoofing (setting `userId` to another user's UID) must be blocked.

## The "Dirty Dozen" Payloads

1. **Spoof User Service**: Attempt to create a `user_services` document with `userId` of another user.
2. **Admin Config Hijack**: Unauthenticated user trying to update `config/site`.
3. **Plan Price Manipulation**: Authenticated (non-admin) user trying to update a plan's price.
4. **Activity Erasure**: User trying to delete their own `user_activities` (audit logs should be immutable or admin-only).
5. **Ticket Snooping**: User A trying to read a ticket belonging to User B.
6. **Message Injection**: User A trying to post a message to User B's ticket.
7. **Admin Promotion**: User trying to add themselves to the `admins` collection.
8. **Feedback Spam**: User trying to create a feedback with a 1MB message.
9. **Status Fakeout**: Non-admin trying to change a service status to 'operational'.
10. **Incident Deletion**: Non-admin trying to delete an incident report.
11. **Service Theft**: User trying to update `user_services` to change the `panelPassword` of a service they don't own.
12. **System Field Poisoning**: User trying to set `createdAt` to a future date instead of `request.time`.

## The Test Runner (Mock)
The tests will ensure that all above payloads return `PERMISSION_DENIED`.
