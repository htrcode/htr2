import axios from 'axios';
import type { AxiosInstance } from 'axios';

export interface PteroUserAttributes {
  id: number;
  external_id: string | null;
  uuid: string;
  username: string;
  email: string;
  first_name: string;
  last_name: string;
  language: string;
  root_admin: boolean;
  '2fa': boolean;
  created_at: string;
  updated_at: string;
}

export function getPterodactylConfig() {
  const rawUrl = process.env.PTERODACTYL_URL || process.env.VITE_PTERODACTYL_URL || 'https://gp.hector.host';
  const cleanUrl = rawUrl.trim().replace(/^["']|["']$/g, '').replace(/\/+$/, '');
  const rawKey = process.env.PTERODACTYL_API_KEY || process.env.VITE_PTERODACTYL_API_KEY || '';
  const apiKey = rawKey.trim().replace(/^["']|["']$/g, '');

  return {
    panelUrl: cleanUrl,
    apiUrl: `${cleanUrl}/api/application`,
    apiKey
  };
}

export function getPterodactylClient(): AxiosInstance | null {
  const { apiUrl, apiKey } = getPterodactylConfig();
  if (!apiKey) {
    return null;
  }
  return axios.create({
    baseURL: apiUrl,
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
      'Accept': 'application/json, application/vnd.pterodactyl.v1+json',
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Accept-Language': 'en-US,en;q=0.9',
      'Cache-Control': 'no-cache',
    },
    timeout: 15000,
  });
}


// Sanitize a valid Pterodactyl username (letters, digits, underscores, dashes; 3-32 characters)
export function sanitizeUsername(raw: string, email: string): string {
  let clean = raw
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_-]/g, '_')
    .replace(/^_+|_+$/g, '');

  if (clean.length < 3) {
    const emailPrefix = email.split('@')[0].toLowerCase().replace(/[^a-z0-9_-]/g, '_');
    clean = (clean + '_' + emailPrefix).slice(0, 24);
  }

  if (clean.length < 3) {
    clean = 'user_' + Math.floor(1000 + Math.random() * 9000);
  }

  return clean.slice(0, 30);
}

// Split full name into first and last name
export function splitName(fullName?: string, fallbackEmail: string = ''): { firstName: string; lastName: string } {
  if (!fullName || !fullName.trim()) {
    const prefix = fallbackEmail.split('@')[0] || 'User';
    return { firstName: prefix, lastName: 'Member' };
  }

  const parts = fullName.trim().split(/\s+/);
  if (parts.length === 1) {
    return { firstName: parts[0], lastName: 'Member' };
  }

  return {
    firstName: parts[0],
    lastName: parts.slice(1).join(' ')
  };
}

export const pterodactyl = {
  // Test connection and get overall metrics
  async getStatus() {
    const { panelUrl } = getPterodactylConfig();
    const client = getPterodactylClient();

    if (!client) {
      return {
        connected: false,
        panelUrl,
        latency: '0ms',
        stats: { totalUsers: 0, totalServers: 0, totalNodes: 0 },
        nodes: [],
        error: 'PTERODACTYL_API_KEY is not configured'
      };
    }

    try {
      const startTime = Date.now();
      const [nodesRes, usersRes, serversRes] = await Promise.allSettled([
        client.get('/nodes'),
        client.get('/users?per_page=1'),
        client.get('/servers?per_page=1')
      ]);

      const latencyMs = Date.now() - startTime;

      const nodesSuccess = nodesRes.status === 'fulfilled';
      const usersSuccess = usersRes.status === 'fulfilled';
      const serversSuccess = serversRes.status === 'fulfilled';

      const isConnected = nodesSuccess || usersSuccess || serversSuccess;

      const totalNodes = nodesSuccess ? (nodesRes.value.data?.data?.length || 0) : 0;
      const totalUsers = usersSuccess ? (usersRes.value.data?.meta?.pagination?.total || 0) : 0;
      const totalServers = serversSuccess ? (serversRes.value.data?.meta?.pagination?.total || 0) : 0;

      const nodes = nodesSuccess 
        ? (nodesRes.value.data?.data || []).map((n: any) => n.attributes)
        : [];

      return {
        connected: isConnected,
        panelUrl,
        latency: `${latencyMs}ms`,
        stats: {
          totalUsers,
          totalServers,
          totalNodes,
        },
        nodes,
        error: !isConnected ? 'Failed to connect to Pterodactyl Panel API' : undefined
      };
    } catch (error: any) {
      let detailMsg = error.message;
      if (error.response?.status === 403) {
        detailMsg = 'Cloudflare WAF / Security Challenge blocked request (403 Forbidden). Ensure server IP or User-Agent is allowed on Pterodactyl panel domain.';
      } else if (error.response?.status === 401) {
        detailMsg = 'Invalid Pterodactyl API Key (401 Unauthorized)';
      } else if (error.response?.data?.errors?.[0]?.detail) {
        detailMsg = error.response.data.errors[0].detail;
      }

      return {
        connected: false,
        panelUrl,
        latency: '0ms',
        stats: { totalUsers: 0, totalServers: 0, totalNodes: 0 },
        nodes: [],
        error: detailMsg
      };
    }

  },

  // Find user by email
  async findUserByEmail(email: string): Promise<PteroUserAttributes | null> {
    const client = getPterodactylClient();
    if (!client) return null;
    try {
      const res = await client.get(`/users?filter[email]=${encodeURIComponent(email.toLowerCase().trim())}`);
      const data = res.data?.data;
      if (Array.isArray(data) && data.length > 0) {
        return data[0].attributes as PteroUserAttributes;
      }
      return null;
    } catch (err: any) {
      console.warn(`[Pterodactyl] findUserByEmail error:`, err.response?.data || err.message);
      return null;
    }
  },

  // Find user by username
  async findUserByUsername(username: string): Promise<PteroUserAttributes | null> {
    const client = getPterodactylClient();
    if (!client) return null;
    try {
      const res = await client.get(`/users?filter[username]=${encodeURIComponent(username.toLowerCase().trim())}`);
      const data = res.data?.data;
      if (Array.isArray(data) && data.length > 0) {
        return data[0].attributes as PteroUserAttributes;
      }
      return null;
    } catch (err: any) {
      return null;
    }
  },

  // Create or retrieve existing Pterodactyl user
  async createOrLinkUser(params: {
    email: string;
    name?: string;
    username?: string;
    password?: string;
  }): Promise<{ user: PteroUserAttributes; alreadyExisted: boolean; panelUrl: string }> {
    const { panelUrl } = getPterodactylConfig();
    const client = getPterodactylClient();

    if (!client) {
      throw new Error('Pterodactyl integration is not configured (missing API Key)');
    }

    const cleanEmail = params.email.toLowerCase().trim();

    // 1. Check if user already exists with this email
    const existing = await this.findUserByEmail(cleanEmail);
    if (existing) {
      if (params.password && params.password.length >= 8) {
        try {
          await client.patch(`/users/${existing.id}`, {
            email: existing.email,
            username: existing.username,
            first_name: existing.first_name,
            last_name: existing.last_name,
            language: existing.language || 'en',
            password: params.password
          });
          console.log(`[Pterodactyl] Updated password for existing user #${existing.id} (@${existing.username})`);
        } catch (patchErr: any) {
          console.warn('[Pterodactyl] Could not update password on existing user:', patchErr.response?.data || patchErr.message);
        }
      }
      return { user: existing, alreadyExisted: true, panelUrl };
    }

    // 2. Prepare user payload
    const rawUsername = params.username || params.name || cleanEmail.split('@')[0];
    let username = sanitizeUsername(rawUsername, cleanEmail);

    // Check if username taken, if so, append random digits
    const existingByUsername = await this.findUserByUsername(username);
    if (existingByUsername) {
      username = `${username.slice(0, 24)}_${Math.floor(100 + Math.random() * 900)}`;
    }

    const { firstName, lastName } = splitName(params.name, cleanEmail);

    // Generate random secure password if none provided
    const password = params.password && params.password.length >= 8 
      ? params.password 
      : `Ptero#${Math.random().toString(36).slice(-8)}!${Math.floor(100 + Math.random() * 900)}`;

    const payload: any = {
      email: cleanEmail,
      username,
      first_name: firstName || 'Hector',
      last_name: lastName || 'User',
      password: password,
      language: 'en'
    };

    try {
      const createRes = await client.post('/users', payload);
      const createdUser = createRes.data?.attributes as PteroUserAttributes;
      return {
        user: createdUser,
        alreadyExisted: false,
        panelUrl
      };
    } catch (error: any) {
      const errors = error.response?.data?.errors;
      console.warn('[Pterodactyl] User creation response error:', errors || error.message);

      // If email was taken concurrently, fetch again
      const fallbackUser = await this.findUserByEmail(cleanEmail);
      if (fallbackUser) {
        return { user: fallbackUser, alreadyExisted: true, panelUrl };
      }

      // If username failed validation, retry with clean fallback username
      if (errors && Array.isArray(errors) && errors.some((e: any) => e.field === 'username')) {
        const safeFallbackUsername = `u_${Date.now().toString(36)}_${Math.floor(100 + Math.random() * 900)}`;
        payload.username = safeFallbackUsername;
        const retryRes = await client.post('/users', payload);
        return {
          user: retryRes.data?.attributes as PteroUserAttributes,
          alreadyExisted: false,
          panelUrl
        };
      }

      const errorMsg = errors?.map((e: any) => e.detail || e.field).join(', ') || error.message;
      throw new Error(`Pterodactyl user creation failed: ${errorMsg}`);
    }
  },

  // Update password for an existing Pterodactyl user by email
  async updateUserPassword(email: string, newPassword: string): Promise<{ success: boolean; user?: PteroUserAttributes; message?: string }> {
    const client = getPterodactylClient();
    if (!client) {
      throw new Error('Pterodactyl integration is not configured (missing API Key)');
    }

    const cleanEmail = email.toLowerCase().trim();
    const existing = await this.findUserByEmail(cleanEmail);

    if (!existing) {
      // If user doesn't exist yet on panel, auto-provision and set password
      const created = await this.createOrLinkUser({
        email: cleanEmail,
        password: newPassword
      });
      return {
        success: true,
        user: created.user,
        message: 'Provisioned new Pterodactyl account with updated password.'
      };
    }

    try {
      const patchRes = await client.patch(`/users/${existing.id}`, {
        email: existing.email,
        username: existing.username,
        first_name: existing.first_name,
        last_name: existing.last_name,
        language: existing.language || 'en',
        password: newPassword
      });

      const updatedUser = (patchRes.data?.attributes || patchRes.data) as PteroUserAttributes;
      console.log(`[Pterodactyl] Successfully changed password for user #${existing.id} (${existing.email})`);
      return {
        success: true,
        user: updatedUser,
        message: 'Pterodactyl panel password updated successfully.'
      };
    } catch (err: any) {
      const detail = err.response?.data?.errors?.map((e: any) => e.detail || e.field).join(', ') || err.message;
      console.error(`[Pterodactyl] Failed to update password for #${existing.id}:`, detail);
      throw new Error(`Failed to update Pterodactyl password: ${detail}`);
    }
  },

  // List all users
  async listUsers(page: number = 1, perPage: number = 50) {
    const client = getPterodactylClient();
    if (!client) return { users: [], meta: {} };
    const res = await client.get(`/users?page=${page}&per_page=${perPage}`);
    return {
      users: (res.data?.data || []).map((item: any) => item.attributes as PteroUserAttributes),
      meta: res.data?.meta
    };
  },

  // List all servers
  async listServers(page: number = 1, perPage: number = 50) {
    const client = getPterodactylClient();
    if (!client) return { servers: [], meta: {} };
    const res = await client.get(`/servers?page=${page}&per_page=${perPage}`);
    return {
      servers: (res.data?.data || []).map((item: any) => item.attributes),
      meta: res.data?.meta
    };
  },

  // List all nodes
  async listNodes() {
    const client = getPterodactylClient();
    if (!client) return [];
    const res = await client.get('/nodes');
    return (res.data?.data || []).map((item: any) => item.attributes);
  }
};
