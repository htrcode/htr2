import axios from "axios";

const BETTERSTACK_API_URL = "https://uptime.betterstack.com/api/v2";

export interface BetterStackMonitor {
  id: string;
  name: string;
  url: string;
  status: 'up' | 'down' | 'paused' | 'pending' | 'maintenance';
  monitor_type: string;
  last_checked_at: string | null;
  check_frequency: number;
  regions: string[];
  paused: boolean;
}

export interface BetterStackResource {
  id: string;
  public_name: string;
  resource_id: number | null;
  section_id: number | null;
  section_name?: string;
  status: 'operational' | 'downtime' | 'degraded' | 'maintenance' | 'not_monitored';
  availability: number; // e.g. 1.0 or 0.998
  history: Array<{
    day: string;
    status: string;
    downtime_duration: number;
    maintenance_duration: number;
  }>;
  url?: string;
}

export interface BetterStackIncident {
  id: string;
  name: string;
  url: string;
  cause: string;
  status: 'Ongoing' | 'Acknowledged' | 'Resolved' | string;
  started_at: string;
  resolved_at: string | null;
  regions: string[];
  severity: 'critical' | 'major' | 'minor' | 'info';
  description?: string;
}

export interface BetterStackStatusResponse {
  provider: 'betterstack';
  status_page: {
    id: string;
    company_name: string;
    subdomain: string;
    custom_domain: string;
    aggregate_state: 'operational' | 'degraded' | 'downtime' | string;
    published: boolean;
    timezone: string;
  };
  summary: {
    overall_status: 'operational' | 'degraded' | 'outage' | 'maintenance';
    uptime_percentage: string;
    monitored_nodes_count: number;
    active_incidents_count: number;
    last_updated: string;
  };
  sections: Array<{
    id: number;
    name: string;
    position: number;
    resources: BetterStackResource[];
  }>;
  monitors: BetterStackMonitor[];
  incidents: BetterStackIncident[];
}

class BetterStackService {
  private cache: { data: BetterStackStatusResponse; timestamp: number } | null = null;
  private readonly CACHE_TTL_MS = 25000; // 25s cache

  private getAuthHeaders() {
    const rawToken = process.env.BETTERSTACK_API_TOKEN || process.env.VITE_BETTERSTACK_API_TOKEN || "";
    const token = rawToken.trim().replace(/^["']|["']$/g, '');
    if (!token) {
      return null;
    }
    return {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
      Accept: "application/json",
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
      "Accept-Language": "en-US,en;q=0.9",
      "Cache-Control": "no-cache"
    };
  }


  async getStatusData(forceRefresh = false): Promise<BetterStackStatusResponse> {
    const now = Date.now();
    if (!forceRefresh && this.cache && now - this.cache.timestamp < this.CACHE_TTL_MS) {
      return this.cache.data;
    }

    const headers = this.getAuthHeaders();
    if (!headers) {
      // Return a graceful empty/fallback state instead of throwing to prevent app crash
      return {
        provider: 'betterstack',
        status_page: {
          id: "0",
          company_name: 'HectorHosting',
          subdomain: 'hectorhosting',
          custom_domain: 'status.hector.host',
          aggregate_state: 'operational',
          published: true,
          timezone: 'UTC',
        },
        summary: {
          overall_status: 'operational',
          uptime_percentage: '99.99%',
          monitored_nodes_count: 0,
          active_incidents_count: 0,
          last_updated: new Date().toISOString(),
        },
        sections: [],
        monitors: [],
        incidents: [],
      };
    }

    try {
      // 1. Fetch Status Pages (to get company info, custom domain, aggregate state)
      const [pagesRes, monitorsRes, incidentsRes] = await Promise.all([
        axios.get(`${BETTERSTACK_API_URL}/status-pages`, { headers, timeout: 8000 }),
        axios.get(`${BETTERSTACK_API_URL}/monitors`, { headers, timeout: 8000 }),
        axios.get(`${BETTERSTACK_API_URL}/incidents`, { headers, timeout: 8000 }),
      ]);

      const statusPage = pagesRes.data?.data?.[0];
      const pageId = statusPage ? statusPage.id : "241631";

      // 2. Fetch resources & sections for this status page
      const [resourcesRes, sectionsRes] = await Promise.all([
        axios.get(`${BETTERSTACK_API_URL}/status-pages/${pageId}/resources`, { headers, timeout: 8000 }).catch(() => ({ data: { data: [] } })),
        axios.get(`${BETTERSTACK_API_URL}/status-pages/${pageId}/sections`, { headers, timeout: 8000 }).catch(() => ({ data: { data: [] } })),
      ]);

      // Map raw monitors
      const monitors: BetterStackMonitor[] = (monitorsRes.data?.data || []).map((m: any) => ({
        id: m.id,
        name: m.attributes.pronounceable_name || m.attributes.url,
        url: m.attributes.url,
        status: m.attributes.status,
        monitor_type: m.attributes.monitor_type,
        last_checked_at: m.attributes.last_checked_at,
        check_frequency: m.attributes.check_frequency,
        regions: m.attributes.regions || [],
        paused: m.attributes.paused ?? false,
      }));

      // Create lookup map for monitors
      const monitorMap = new Map<number, BetterStackMonitor>();
      for (const m of monitors) {
        monitorMap.set(parseInt(m.id), m);
      }

      // Map raw sections
      const sectionsMap = new Map<number, { id: number; name: string; position: number }>();
      (sectionsRes.data?.data || []).forEach((s: any) => {
        sectionsMap.set(parseInt(s.id), {
          id: parseInt(s.id),
          name: s.attributes.name,
          position: s.attributes.position ?? 0,
        });
      });

      // Map raw resources
      const rawResources = resourcesRes.data?.data || [];
      const resources: BetterStackResource[] = rawResources.map((r: any) => {
        const secId = r.attributes.status_page_section_id;
        const sectionName = secId ? sectionsMap.get(secId)?.name : 'Core Services';
        const linkedMonitor = r.attributes.resource_id ? monitorMap.get(r.attributes.resource_id) : undefined;
        
        let normalizedStatus: BetterStackResource['status'] = r.attributes.status || 'operational';
        if (normalizedStatus === 'not_monitored' && linkedMonitor) {
          if (linkedMonitor.status === 'up') normalizedStatus = 'operational';
          else if (linkedMonitor.status === 'down') normalizedStatus = 'downtime';
          else if (linkedMonitor.status === 'maintenance') normalizedStatus = 'maintenance';
        }

        return {
          id: r.id,
          public_name: r.attributes.public_name,
          resource_id: r.attributes.resource_id,
          section_id: secId,
          section_name: sectionName,
          status: normalizedStatus,
          availability: typeof r.attributes.availability === 'number' ? r.attributes.availability : 1,
          history: r.attributes.status_history || [],
          url: linkedMonitor?.url,
        };
      });

      // Group resources by section
      const sectionsList: Array<{ id: number; name: string; position: number; resources: BetterStackResource[] }> = [];
      const usedSectionIds = new Set<number>();

      for (const [secId, sec] of sectionsMap.entries()) {
        const secResources = resources.filter(r => r.section_id === secId);
        sectionsList.push({
          ...sec,
          resources: secResources,
        });
        usedSectionIds.add(secId);
      }

      // Any remaining resources without a section
      const orphanResources = resources.filter(r => !r.section_id || !usedSectionIds.has(r.section_id));
      if (orphanResources.length > 0) {
        sectionsList.push({
          id: 0,
          name: 'General Infrastructure',
          position: 99,
          resources: orphanResources,
        });
      }

      sectionsList.sort((a, b) => a.position - b.position);

      // Map raw incidents
      const rawIncidents = incidentsRes.data?.data || [];
      const incidents: BetterStackIncident[] = rawIncidents.map((inc: any) => {
        const cause = inc.attributes.cause || 'Network anomaly detected';
        const isDown = inc.attributes.status !== 'Resolved';
        let severity: BetterStackIncident['severity'] = 'minor';
        if (cause.toLowerCase().includes('500') || cause.toLowerCase().includes('timeout')) {
          severity = isDown ? 'critical' : 'major';
        }

        return {
          id: inc.id,
          name: inc.attributes.name || 'Service Alert',
          url: inc.attributes.url || '',
          cause: inc.attributes.cause || '',
          status: inc.attributes.status || 'Resolved',
          started_at: inc.attributes.started_at,
          resolved_at: inc.attributes.resolved_at,
          regions: inc.attributes.regions || [],
          severity,
          description: inc.attributes.cause ? `Triggered: ${inc.attributes.cause}` : undefined,
        };
      });

      // Determine overall status
      const aggregateState = statusPage?.attributes?.aggregate_state;
      let overallStatus: 'operational' | 'degraded' | 'outage' | 'maintenance' = 'operational';
      
      const hasActiveIncident = incidents.some(i => i.status !== 'Resolved');
      const anyDown = resources.some(r => r.status === 'downtime') || monitors.some(m => m.status === 'down');
      const anyDegraded = resources.some(r => r.status === 'degraded');
      const anyMaintenance = resources.some(r => r.status === 'maintenance') || monitors.some(m => m.status === 'maintenance');

      if (anyDown) {
        overallStatus = 'outage';
      } else if (anyDegraded || (hasActiveIncident && aggregateState !== 'operational')) {
        overallStatus = 'degraded';
      } else if (anyMaintenance) {
        overallStatus = 'maintenance';
      } else {
        overallStatus = 'operational';
      }

      // Calculate average uptime percentage from resources availability
      let uptimePercentage = '100.0%';
      const validAvailabilities = resources
        .map(r => r.availability)
        .filter(a => typeof a === 'number' && a > 0);
      
      if (validAvailabilities.length > 0) {
        const avg = (validAvailabilities.reduce((sum, v) => sum + v, 0) / validAvailabilities.length) * 100;
        uptimePercentage = `${avg.toFixed(2)}%`;
      }

      const result: BetterStackStatusResponse = {
        provider: 'betterstack',
        status_page: {
          id: pageId,
          company_name: statusPage?.attributes?.company_name || 'HectorHosting',
          subdomain: statusPage?.attributes?.subdomain || 'hectorhosting',
          custom_domain: statusPage?.attributes?.custom_domain || 'status.hector.host',
          aggregate_state: aggregateState || 'operational',
          published: statusPage?.attributes?.published ?? true,
          timezone: statusPage?.attributes?.timezone || 'Chennai',
        },
        summary: {
          overall_status: overallStatus,
          uptime_percentage: uptimePercentage,
          monitored_nodes_count: resources.length || monitors.length,
          active_incidents_count: incidents.filter(i => i.status !== 'Resolved').length,
          last_updated: new Date().toISOString(),
        },
        sections: sectionsList,
        monitors,
        incidents,
      };

      this.cache = { data: result, timestamp: now };
      return result;
    } catch (error: any) {
      console.error("[BetterStack] Error querying API:", error.response?.data || error.message);
      
      // If we had a cached version, fallback to it
      if (this.cache) {
        return this.cache.data;
      }

      // Return graceful fallback state on error instead of breaking with 500
      return {
        provider: 'betterstack',
        status_page: {
          id: "0",
          company_name: 'HectorHosting',
          subdomain: 'hectorhosting',
          custom_domain: 'status.hector.host',
          aggregate_state: 'degraded',
          published: true,
          timezone: 'UTC',
        },
        summary: {
          overall_status: 'degraded',
          uptime_percentage: '99.9%',
          monitored_nodes_count: 0,
          active_incidents_count: 0,
          last_updated: new Date().toISOString(),
        },
        sections: [],
        monitors: [],
        incidents: [],
      };
    }

  }

  async toggleMonitorPause(monitorId: string, paused: boolean): Promise<any> {
    const headers = this.getAuthHeaders();
    const res = await axios.patch(
      `${BETTERSTACK_API_URL}/monitors/${monitorId}`,
      { paused },
      { headers }
    );
    // Invalidate cache
    this.cache = null;
    return res.data;
  }
}

export const betterStack = new BetterStackService();
