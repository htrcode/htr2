import express from "express";
import dotenv from "dotenv";
import { initializeApp } from "firebase/app";
import { getFirestore, doc, setDoc } from "firebase/firestore";
import fs from "fs";
import path from "path";
import { pterodactyl } from "./pterodactyl.js";
import { betterStack } from "./betterstack.js";

dotenv.config();

let localFirebaseConfig: any = {};
try {
  const configPath = path.join(process.cwd(), "firebase-applet-config.json");
  if (fs.existsSync(configPath)) {
    localFirebaseConfig = JSON.parse(fs.readFileSync(configPath, "utf-8"));
  }
} catch {
  localFirebaseConfig = {};
}


// Firebase App & Firestore Configuration (prioritizing environment variables)
const firebaseAppConfig = {
  apiKey: process.env.VITE_FIREBASE_API_KEY || localFirebaseConfig.apiKey || "AIzaSyDvi6DqpzRyHq6MoxPr6CtFPxj0hs_FKU4",
  authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN || localFirebaseConfig.authDomain || "peta-informatics-q5xj8.firebaseapp.com",
  projectId: process.env.VITE_FIREBASE_PROJECT_ID || localFirebaseConfig.projectId || "peta-informatics-q5xj8",
  storageBucket: process.env.VITE_FIREBASE_STORAGE_BUCKET || localFirebaseConfig.storageBucket || "peta-informatics-q5xj8.firebasestorage.app",
  messagingSenderId: process.env.VITE_FIREBASE_MESSAGING_SENDER_ID || localFirebaseConfig.messagingSenderId || "223948543646",
  appId: process.env.VITE_FIREBASE_APP_ID || localFirebaseConfig.appId || "1:223948543646:web:20d21856af47b164c14d8f",
};

const databaseId = process.env.VITE_FIREBASE_FIRESTORE_DATABASE_ID || localFirebaseConfig.firestoreDatabaseId;


// Initialize Firebase App
const firebaseApp = initializeApp(firebaseAppConfig);

// Initialize Firestore safely
let firestoreInstance: any;
try {
  firestoreInstance = databaseId ? getFirestore(firebaseApp, databaseId) : getFirestore(firebaseApp);
} catch (e: any) {
  console.warn("[Firebase] Defaulting to primary Firestore instance:", e.message);
  firestoreInstance = getFirestore(firebaseApp);
}

export const firestore = firestoreInstance;

export const app = express();
app.use(express.json());

// CORS & Vercel Route Alignment Middleware
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, DELETE");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  if (req.method === "OPTIONS") {
    return res.status(200).end();
  }

  // Restore original requested URL if Vercel serverless proxy header is present
  const forwardedUri = req.headers["x-forwarded-uri"] as string;
  if (forwardedUri && forwardedUri.startsWith("/api") && req.url !== forwardedUri) {
    req.url = forwardedUri;
  }

  next();
});

const apiRouter = express.Router();

// --- API ROUTES ---
apiRouter.get("/health", (req, res) => {
  const pteroKey = (process.env.PTERODACTYL_API_KEY || process.env.VITE_PTERODACTYL_API_KEY || "").trim().replace(/^["']|["']$/g, '');
  const pteroUrl = (process.env.PTERODACTYL_URL || process.env.VITE_PTERODACTYL_URL || "https://gp.hector.host").trim().replace(/^["']|["']$/g, '');
  const betterToken = (process.env.BETTERSTACK_API_TOKEN || process.env.VITE_BETTERSTACK_API_TOKEN || "").trim().replace(/^["']|["']$/g, '');

  res.json({
    status: "ok",
    service: "Hector Hosting API",
    timestamp: new Date().toISOString(),
    env: {
      hasPteroKey: Boolean(pteroKey),
      pteroKeyLength: pteroKey.length,
      pteroKeyPreview: pteroKey ? `${pteroKey.slice(0, 5)}...${pteroKey.slice(-4)}` : "not-set",
      hasPteroUrl: Boolean(pteroUrl),
      pteroUrl: pteroUrl,
      hasBetterStackToken: Boolean(betterToken),
      betterStackTokenLength: betterToken.length,
      betterStackTokenPreview: betterToken ? `${betterToken.slice(0, 4)}...${betterToken.slice(-4)}` : "not-set"
    }
  });
});


// --- PTERODACTYL INTEGRATION ROUTES ---

// 1. Get Pterodactyl Panel Status & Connection Health
apiRouter.get("/pterodactyl/status", async (req, res) => {
  try {
    const status = await pterodactyl.getStatus();
    res.json(status);
  } catch (error: any) {
    res.status(500).json({ connected: false, error: error.message });
  }
});

// 2. Create / Link Pterodactyl User (Called on Registration and on Demand)
apiRouter.post("/pterodactyl/create-user", async (req, res) => {
  const { email, username, name, password, firebaseUid } = req.body;
  if (!email) {
    return res.status(400).json({ success: false, error: "Email is required" });
  }

  try {
    console.log(`[Pterodactyl] Processing account creation for: ${email}`);
    const result = await pterodactyl.createOrLinkUser({
      email,
      username,
      name,
      password
    });

    // Update Firestore user document with Pterodactyl info if firebaseUid provided
    if (firebaseUid) {
      try {
        await setDoc(doc(firestore, "users", firebaseUid), {
          pterodactylId: result.user.id,
          pterodactylUsername: result.user.username,
          pterodactylCreatedAt: result.user.created_at,
          panelUrl: result.panelUrl
        }, { merge: true });
      } catch (dbErr: any) {
        console.warn("[Pterodactyl] Could not update user doc in Firestore:", dbErr.message);
      }
    }

    res.json({
      success: true,
      user: result.user,
      panelUrl: result.panelUrl,
      alreadyExisted: result.alreadyExisted,
      message: result.alreadyExisted 
        ? "Linked existing Pterodactyl Panel account" 
        : "Created new Pterodactyl Panel account"
    });
  } catch (error: any) {
    console.error("[Pterodactyl] Account creation error:", error.message);
    res.status(500).json({ success: false, error: error.message });
  }
});

// 3. Update Pterodactyl User Password directly on Panel
apiRouter.post("/pterodactyl/update-password", async (req, res) => {
  const { email, password, firebaseUid } = req.body;
  if (!email || !password) {
    return res.status(400).json({ success: false, error: "Email and new password are required" });
  }

  if (password.length < 8) {
    return res.status(400).json({ success: false, error: "Pterodactyl password must be at least 8 characters long." });
  }

  try {
    console.log(`[Pterodactyl] Processing real panel password update for user: ${email}`);
    const result = await pterodactyl.updateUserPassword(email, password);

    // Sync Firestore user document if firebaseUid provided
    if (firebaseUid && result.user) {
      try {
        await setDoc(doc(firestore, "users", firebaseUid), {
          pterodactylId: result.user.id,
          pterodactylUsername: result.user.username,
          panelPasswordUpdatedAt: new Date().toISOString()
        }, { merge: true });
      } catch (dbErr: any) {
        console.warn("[Pterodactyl] Could not sync user doc in Firestore:", dbErr.message);
      }
    }

    res.json({
      success: true,
      message: result.message || "Pterodactyl panel account password has been updated successfully.",
      user: result.user
    });
  } catch (error: any) {
    console.error("[Pterodactyl] Password update error:", error.message);
    res.status(500).json({ success: false, error: error.message });
  }
});

// 4. List Pterodactyl Users (Admin)
apiRouter.get("/pterodactyl/users", async (req, res) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const perPage = parseInt(req.query.per_page as string) || 50;
    const data = await pterodactyl.listUsers(page, perPage);
    res.json(data);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 4. List Pterodactyl Servers
apiRouter.get("/pterodactyl/servers", async (req, res) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const perPage = parseInt(req.query.per_page as string) || 50;
    const data = await pterodactyl.listServers(page, perPage);
    res.json(data);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 5. List Pterodactyl Nodes
apiRouter.get("/pterodactyl/nodes", async (req, res) => {
  try {
    const nodes = await pterodactyl.listNodes();
    res.json({ nodes });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// --- BETTER STACK API STATUS ROUTES ---
apiRouter.get("/status", async (req, res) => {
  try {
    const forceRefresh = req.query.refresh === 'true';
    const statusData = await betterStack.getStatusData(forceRefresh);
    res.json(statusData);
  } catch (error: any) {
    console.error("[BetterStack] /api/status error:", error.message);
    res.status(500).json({ 
      error: "Failed to retrieve Better Stack status data", 
      message: error.message 
    });
  }
});

apiRouter.post("/status/refresh", async (req, res) => {
  try {
    const statusData = await betterStack.getStatusData(true);
    res.json({ success: true, data: statusData });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

apiRouter.post("/status/monitors/:id/toggle", async (req, res) => {
  try {
    const { id } = req.params;
    const { paused } = req.body;
    const result = await betterStack.toggleMonitorPause(id, Boolean(paused));
    res.json({ success: true, result });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Mount router under both /api and root / to support direct routing and serverless function path rewrites
app.use("/api", apiRouter);
app.use("/", apiRouter);
