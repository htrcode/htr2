import type { VercelRequest, VercelResponse } from '@vercel/node';
import { app } from '../server/app.js';


export default function handler(req: VercelRequest, res: VercelResponse) {
  // Normalize req.url so Express routes work seamlessly on Vercel Serverless Functions
  const forwardedUri = (req.headers['x-forwarded-uri'] as string) || (req.headers['x-matched-path'] as string);

  if (forwardedUri && forwardedUri.startsWith('/api')) {
    req.url = forwardedUri;
  } else if (req.url && req.url.includes('/api/index')) {
    try {
      const urlObj = new URL(req.url, 'http://localhost');
      const route = urlObj.searchParams.get('route');
      if (route) {
        const cleanRoute = route.startsWith('/') ? route : `/${route}`;
        req.url = `/api${cleanRoute}`;
      }
    } catch {
      // Fallback if URL parsing fails
    }
  }

  return app(req, res);
}

