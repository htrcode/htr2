import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { app, firestore } from "./server/app.js";

// Test Firestore connection on startup
(async () => {
  try {
    const { doc, getDoc } = await import("firebase/firestore");
    const testDoc = await getDoc(doc(firestore, 'config', 'site'));
    console.log("Initial Firestore connection test:", testDoc.exists() ? "Success (doc found)" : "Success (doc not found)");
  } catch (e: any) {
    console.error("CRITICAL: Initial Firestore connection failed:", e.message);
  }
})();

async function startServer() {
  const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

  // --- VITE MIDDLEWARE ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
